<?php 
		
	defined( 'ABSPATH' ) || exit;

	if( !function_exists('smart_testimonial') ){
	function smart_testimonial($atts)
{
	ob_start();
	$default_atts = array(
'name' => '',
);
$params = shortcode_atts( $default_atts, $atts );
// Creating the button styles
if( ! empty( $params['name'] ) ){
$button_styles = $params['name'];

}
?>
	
<style>
	.sis-img img 
	{
		border-radius: 50%;
		height: 150px;
		width: 150px;
		margin-left: auto;
		margin-right: auto;
	}
	.rating-001
	{
		text-align: center;
	}
	.slide-descs
	{
		padding-top: 10px;
	}
	span.slide-descs p 
	{
		font-weight: 400;
		padding: 10px 0px;
	}
</style>
<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
        <div class="sldier-set-h set-full-w-001">
        <div class="container">
			<!--
            <div class="set-full-w-001">
                    <h3>What our customers are saying</h3>
            </div>
			-->
            <div class="set-full-w-001 main-column">
                <div class="col-md-2"></div>
                <div class="slide-here col-md-8">
				<?php
				$args = array(
				'post_type' => 'smart-testimonials',
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'tax_query' => array(
					array(
				'taxonomy' => 'slider-cat',
                'field' => 'slug',
                'terms' => $button_styles,
					)
				)
				);
				$posts = get_posts($args);
				foreach($posts as $mypost)
				{	
					$id = $mypost->ID;					
					$image = get_the_post_thumbnail($id);
				?>
					<div class="rating-001 set-full-w-001">
						<div class="sis-img" style="padding-bottom: 20px;">
						<?php  _e($image, 'all-sliders' ); ?>
						</div>
						<?php
						$meta = get_post_meta($id,'rating');
						$ratingstar = $meta[0];
								  if($ratingstar == 1)
								  {?>
									<ion-icon name="star"></ion-icon>
									 
								 <?}
								  elseif($ratingstar == 2)
								  {?>
									<ion-icon name="star" class="checked"></ion-icon> 
									<ion-icon name="star"></ion-icon>
								  <?}
								   elseif($ratingstar == 3)
								   {?>
									<ion-icon name="star" class="checked"></ion-icon> 
									<ion-icon name="star" class="checked"></ion-icon> 
									<ion-icon name="star"></ion-icon>
								   <? } 
								    elseif($ratingstar == 4)
									{?>
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star" class="checked"></ion-icon>
										<ion-icon name="star"></ion-icon>
									<?}
									elseif($ratingstar == 5)
									{?>
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star" class="checked"></ion-icon> 
										<ion-icon name="star"></ion-icon>
									<?}
									else{}?>
						<span class="slide-descs" ><?php _e($mypost->post_content, 'all-sliders' ); ?></span>
						<p class="slide-name"><em><?php  _e($mypost->post_title, 'all-sliders' ); ?></em></p>
					</div>
				<?php } ?>
                </div>
                <div class="col-md-2"></div>				
            </div>
        </div>
        </div>
	</main>

</div><!-- .content-area -->
<script type="text/javascript" src="https://smartinfosystem.com/projects/trendycloset/wp-content/plugins/all-sliders/assets/js/allslider.slick.min.js"></script>
<script type="module" src="https://smartinfosystem.com/projects/trendycloset/wp-content/plugins/all-sliders/assets/js/allslider.esm.js"></script>
<script>
  jQuery('.slide-here').slick({
  slidesToShow: 1,
  autoplay: false,
  arrows: false,
  speed: 2000,
  dots: true
});
</script>
<?php
return ob_get_clean();
}
add_shortcode('smart-testimonial-slider','smart_testimonial');
	}	
?>
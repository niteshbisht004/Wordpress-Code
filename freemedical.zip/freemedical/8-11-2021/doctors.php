<? include("include/header.php");

global $specialisations;
global $qualifications;
global $hospital_cats;
global $cities;
$conn = db();
//Specialisation List
$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$specialisations[$data['id']] = utf8_encode($data['specialisation']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification");
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM cities");
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$cities[$data['id']] = utf8_encode($data['name']);
		$c++;
	}
}


?>

<!-- Page Content -->

<div class="detail-list-front">
	<div class="container">
		<div class="col-md-12 in-filter-sets">
			<div class="row">
				<form method="get" action="">
					<div class="col-md-4 fiter-top-mainp" id="form-set-filter1">

						<select name="speci" class="form-control" data-live-search="true">
							<option value="">All Specialisations</option>
							<?php
							foreach ($specialisations as $ke => $spe) {
								$selected = "";
								$selected = ($ke == $_GET['speci']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $spe . "</option>";
							}
							?>
						</select>
					</div>
			
					<div class="col-md-4 mt-2 fiter-top-mainp" id="form-set-filter3" >

						<select name="city" class="form-control" data-live-search="true">
							<option value="">All City</option>
							<?php
							foreach ($cities as $ke => $city) {
								$selected = "";
								$selected = ($ke == $_GET['city']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $city . "</option>";
							}
							?>
						</select>
					</div>
					
					<div class="col-md-4 fiter-top-mainp" id="form-set-filter5">
						<button type="submit" class="form-control filter" name="filter" value="1">Filter</button>
	            	</div>
				</form>
			</div>
		</div>
	</div>
</div>

				<div class="col-md-12" style="padding-left:0px; padding-right:0px;">
					<?php
					$term = $_GET['term'];

					$address = $_GET['saddress'];

					$city = $_GET['city'];

					$qry = fetchAllData("`cities`", "where name='$city'");
					$city = $qry[0][0];

					$sp = $_GET['speci'];

					$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

					$docnamerows = mysqli_num_rows($docname);

					$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

					$hosnamerows = mysqli_num_rows($hosname);

					$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



					$othnamerows = mysqli_num_rows($othname);



					$searchTerms = explode(' ', $term);

					$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

					$searchTerms = array_diff($searchTerms, $removevalue);

					foreach ($searchTerms as $terms) {
						$terms = trim($terms);
						if (!empty($terms)) {
							$searchTermBits .= "or name LIKE '%$terms%'";
							$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


							$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


							$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
						}
					}

					$orderbydata = implode(' + ', $searchTermBitspls);
					$orderbydatah = implode(' + ', $searchTermBitsplsh);
					$orderbydatao = implode(' + ', $searchTermBitsplso);

					if (strpos(trim($term), ' ') !== false) {
						$term = $term;
					} else {

						$term =	rtrim($term, ',');
						$term =  str_replace(' ', '', trim($term, ','));
					}


					if ($docnamerows > 0) {
					} else {


						$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



						$num_specs = mysqli_num_rows($speciliationqs);

						if ($num_specs > 0) {

							$specidq = array();

							while ($rowq = mysqli_fetch_array($speciliationqs)) {

								$specidq[] = $rowq['id'];
							}
						} else {


							$search_item = addslashes($term);

							$string = explode(" ", $search_item);

							$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

							$result = array_diff($string, $omit_words);

							foreach ($result as $val) {

								if ($val == '') {
								} else {

									$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

									$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

									$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

									$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
								}
							}


							$orderbydataspeci = implode(' + ', $speckeywords);
							$orderbydatahdise = implode(' + ', $diseasekeywords);


							$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


							$num_spec = mysqli_num_rows($speciliationq);

							$specidq = array();

							while ($rowq = mysqli_fetch_array($speciliationq)) {

								$specidq[] = $rowq['id'];
							}



							$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



							$num_disease = mysqli_num_rows($query_disease);

							$specid = array();

							while ($row = mysqli_fetch_array($query_disease)) {

								$specid[] = $row['spec_id'];
							}
						}
					}

					$City = fetchData(" `cities` ", "where id='" . $city . "' ");

					$cityn = $City['name'];

					if ($sp != '') {

						$specq = " (specialisation like '%$sp%' or specialisation = '$sp')";
					}

					if ($city != '') {

						$cityq = " (city like '%$city%' or city = '$city' OR address like '%$cityn%')";
					}

					if ($address != '') {
						//$str = 'In My Cart : 11 12 items';
						preg_match_all('!\d+!', $address, $matches);

						foreach ($matches[0] as $val) {
							if (preg_match('/^\d{2}$/', $string)) {
								// pass
							} else {
								$fadd = "or address like '%Sector -$val%'";
								$fadd .= "or address like '%SEC-$val%'";
								$fadd .= "or address like '%Sector-$val%'";
								$fadd .= "or address like '%Sector $val%'";
							}
						}
						$addressq = "(address like '%$address%' or address = '$address' $fadd)";
					}


					if ($_GET['term']  == '' && $_GET['saddress'] == '' && $_GET['speci'] == '' && $_GET['city'] == '') {
						$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");

						include("doctor_result.php");
					} else {

						if ($_GET['term']  == '' && $_GET['saddress'] == '' && $_GET['speci'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes'");

							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");

								include("doctor_result.php");
							}
						} elseif ($_GET['term']  == '' && $_GET['saddress'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  specialisation = '$sp' AND active='Yes'");

							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes'");


								if (!empty($res_doctor)) {

									echo "<h4>We did not found any result with this <bold>$docs</bold> .  Here is the related result...</h4>";

									include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");


									echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

									include("doctor_result.php");
								}
							}
						} elseif ($_GET['term']  == '' && $_GET['speci'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $addressq AND active='Yes'");

							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes'");


								if (!empty($res_doctor)) {

									echo "<h4>We did not found any result with this <bold>$docs</bold> .  Here is the related result...</h4>";

									include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");


									echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

									include("doctor_result.php");
								}
							}
						} elseif ($_GET['term']  == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE   $cityq AND $addressq AND $specq AND active='Yes'");


							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $specq AND active='Yes'");

								if (!empty($res_doctor)) {


									echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

									include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE $specq AND active='Yes'");

									if (!empty($res_doctor)) {

										echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

										include("doctor_result.php");
									} else {

										echo "<h4>We did not found any result with this <bold>$cityn</bold>.  Here is the related result...</h4>";

										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE $specq AND active='Yes'");

										include("doctor_result.php");
									}
								}
							}
						} else {


							if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

								foreach (array_unique($specid) as $sval) {

									if ($sval == '') {
									} else {

										$redp .= " or specialisation = $sval";
									}
								}

								foreach (array_unique($specidq) as $svalq) {

									if ($svalq == '') {
									} else {

										$redp .= " or specialisation = $svalq";
									}
								}




								if ($addressq == '') {

									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $cityq");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $cityq AND $addressq ");
								}



								if (!empty($res_doctor)) {

									include("doctor_result.php");
								} else {

									echo "<h4>We did not found any result with this search.  Here is the related result...</h4>";

									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  specialisation = 79878979  $redp AND city =  $city AND active='Yes'");


									if (!empty($res_doctor)) {

										include("doctor_result.php");
									} else {


										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");

										include("doctor_result.php");
									}
								}
							} else {


								$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name = '$term' OR name like %$term% $searchTermBits AND $cityq AND $addressq ORDER BY ( " . $orderbydata . " ) DESC");




								if (!empty($res_doctor)) {

									include("doctor_result.php");
								} else {


									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' $searchTermBits AND $cityq ORDER BY ( " . $orderbydata . " ) DESC");



									if (!empty($res_doctor)) {

										include("doctor_result.php");
									} else {


										echo "<h4>We did not found any result with this search.  Here is the related result...</h4>";

										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");

										include("doctor_result.php");
									}
								}
							}
						}
					}

					?>


				</div>


			


<!-- /.container -->

<? include('include/footer.php'); ?>

<?
include("include/header.php");

global $specialisations;
global $qualifications;
global $hospital_cats;
global $cities;
global $hospital_cats;

//Specialisation List
$resHD = mysqli_query($conn, "SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$specialisations[$data['id']] = utf8_encode($data['specialisation']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM cities") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$cities[$data['id']] = utf8_encode($data['name']);
		$c++;
	}
}

//Hospital Category List
$resHD = mysqli_query($conn, "SELECT * FROM hospital_cat") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$hospital_cats[$data['id']] = utf8_encode($data['category_name']);
		$c++;
	}
}

?>
			<div class="col-md-12" style="padding-left:0px; padding-right:0px;">
			<?php
				$term = $_GET['CId'];
			
			?>



<style>
.special-d{
	overflow: hidden;
}
.pagini .paginations
    {
    text-align: right;
    float: right;
    margin-bottom: 20px;
    } 
</style>
<link href="/css/simplePagination.css" type="text/css" rel="stylesheet">
<div class="container">
	<div class="col-md-6 all-result-sort-title">
	<? $heading = fetchData("main_menu", " where host_cat = '".$_GET['CId']."'"); ?>
		<h2>All <?=$heading['menu_title']?> available</h2>
		<p>Book appointments with minimum wait-time & verified Hospital details</p>
	</div>
	<div class="col-md-6" style="padding-top: 45px;">
			<input id="txtSearchPage" type="search" class="form-control" placeholder="Search" /><br/>
		</div>
	<div class="col-md-12 cols-3 product1 cols-1-xs pad-30-all detail-doc-grids" id="results">
		
		 <? 
		 if($_GET['CId']==10)
		 {
			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE specialisation = 111");	
				$res_other = fetchAllData(" `other_service_registration` ", "WHERE specialisation = 111");
		 $n=1;
		 $j=1;
		 foreach ($res_hospital as $hosp)  
			{ 
			
		 ?>
		 
			<div class="item col-md-3 text-left <?if ($j<=12){echo "showfirst"; } ?>">
				<div class="d-details-per-column">
					<a href="/hospital/<?= $hosp['user_id'] ?>" target="_blank">
							<? if ($hosp['pro_img'] != "") { ?>
								<img src="/images/profile/<?= $hosp['pro_img'] ?>" class="img-responsive">
							<? } else { ?>
								<img src="/images/hospital1.jpg" class="img-responsive">
							<? } ?>
						</a>
					<div class="col-sm-12 in-details-main-f featured-color">
						<p class="name-d"><?= $hosp['name'] ?></p>
						<p class="special-d">
						<?
							global $specialisations;
							$specialisation = explode("|", $hosp['specialisation']);
							$specialic = $specialisation;
							$i=0;
							foreach ($specialisation as $spec)
							{
								if($i==0)
								{
									echo $specialisations[$spec];
								}
								else {
									
								}
								$i++;
							}
							
						?>
						</p>
						<div class="rating-container rating-xs rating-animate">
							<div class="average-rating-d">
							<? $res_rating = fetchAllData(" `newrating` ", " where user_id='" . $hosp['id'] . "' and rateusertype='hospital' "); 

                            $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
							</div>
							<div class="rating">
							<a style="" href="/rating/<?= $hosp['user_id'] ?>">
								<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span></span>
								<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		<? 
	
			$n++;
			$j++;
		}
		?>
		
		<!-- Fetch data from other services -->
		
		<?

		$m=1;
		 foreach ($res_other as $other)  
			{ 
		 ?>
			<div class="item col-md-3 text-left <?if ($m<=12){echo "showfirst"; } ?>">
				<div class="d-details-per-column">
					<a href="/other/<?= $other['user_id'] ?>" target="_blank">
							<? if ($other['pro_img'] != "") { ?>
								<img src="/images/profile/<?= $other['pro_img'] ?>" class="img-responsive">
							<? } else { ?>
								<img src="/images/hospital1.jpg" class="img-responsive">
							<? } ?>
						</a>
					<div class="col-sm-12 in-details-main-f featured-color">
						<p class="name-d"><?= $other['name'] ?></p>
						<p class="special-d">
						<?
							global $specialisations;
							$specialisation = explode("|", $other['specialisation']);
							$specialic = $specialisation;
							$i=0;
							foreach ($specialisation as $spec)
							{
								if($i==0)
								{
									echo $specialisations[$spec];
								}
								else {
									
								}
								$i++;
							}
							
						?>
						</p>
						<div class="rating-container rating-xs rating-animate">
							<div class="average-rating-d">
							<? $res_rating = fetchAllData(" `newrating` ", " where user_id='" . $other['id'] . "' and rateusertype='hospital' "); 

                            $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
							</div>
							<div class="rating">
							<a style="" href="/rating/<?= $other['user_id'] ?>">
								<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span></span>
								<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		<? 
			
			$m++;
		}
		
		
		 }
		 elseif($_GET['CId']==9)
		 {
			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE specialisation = 61");	
			$res_other = fetchAllData(" `other_service_registration` ", "WHERE specialisation = 61");
		 $n=1;
		 foreach ($res_hospital as $hosp)  
			{ 
		 ?>
			<div class="item col-md-3 text-left <?if ($n<=12){echo "showfirst"; } ?>">
				<div class="d-details-per-column">
					<a href="/hospital/<?= $hosp['user_id'] ?>" target="_blank">
							<? if ($hosp['pro_img'] != "") { ?>
								<img src="/images/profile/<?= $hosp['pro_img'] ?>" class="img-responsive">
							<? } else { ?>
								<img src="/images/hospital1.jpg" class="img-responsive">
							<? } ?>
						</a>
					<div class="col-sm-12 in-details-main-f featured-color">
						<p class="name-d"><?= $hosp['name'] ?></p>
						<p class="special-d">
						<?
							global $specialisations;
							$specialisation = explode("|", $hosp['specialisation']);
							$specialic = $specialisation;
							$i=0;
							foreach ($specialisation as $spec)
							{
								if($i==0)
								{
									echo $specialisations[$spec];
								}
								else {
									
								}
								$i++;
							}
							
						?>
						</p>
						<div class="rating-container rating-xs rating-animate">
							<div class="average-rating-d">
							<? $res_rating = fetchAllData(" `newrating` ", " where user_id='" . $hosp['id'] . "' and rateusertype='hospital' "); 

                            $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
							</div>
							<div class="rating">
							<a style="" href="/rating/<?= $hosp['user_id'] ?>">
								<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span></span>
								<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		<? 
			
			$n++;
		}
		?>
		
		<!-- Fetch data from other services -->
		
		<?

		$m=1;
		 foreach ($res_other as $other)  
			{ 
		 ?>
			<div class="item col-md-3 text-left <?if ($m<=12){echo "showfirst"; } ?>">
				<div class="d-details-per-column">
					<a href="/other/<?= $other['user_id'] ?>" target="_blank">
							<? if ($other['pro_img'] != "") { ?>
								<img src="/images/profile/<?= $other['pro_img'] ?>" class="img-responsive">
							<? } else { ?>
								<img src="/images/hospital1.jpg" class="img-responsive">
							<? } ?>
						</a>
					<div class="col-sm-12 in-details-main-f featured-color">
						<p class="name-d"><?= $other['name'] ?></p>
						<p class="special-d">
						<?
							global $specialisations;
							$specialisation = explode("|", $other['specialisation']);
							$specialic = $specialisation;
							$i=0;
							foreach ($specialisation as $spec)
							{
								if($i==0)
								{
									echo $specialisations[$spec];
								}
								else {
									
								}
								$i++;
							}
							
						?>
						</p>
						<div class="rating-container rating-xs rating-animate">
							<div class="average-rating-d">
							<? $res_rating = fetchAllData(" `newrating` ", " where user_id='" . $other['id'] . "' and rateusertype='hospital' "); 

                            $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
							</div>
							<div class="rating">
							<a style="" href="/rating/<?= $other['user_id'] ?>">
								<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
									</span></span>
								<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span>
									<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		<? 
		
			$m++;
		}
		 }
		 else{}
		?>
		</div>
    <div class="col-md-12 pagini">
    <div class="paginations">
    </div>
    </div>
	</div>
</div>

<!--our parters-->
			</div>
	<div class="our-slider-main">
		<div class="most-active-profile">
			<h4 class="heading">Our Associate</h4>
			<div id="jssor_2" class="jssor_2">
				<!-- Loading Screen -->
				<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
					<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
					<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
				</div>
				<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 100%; height: 100px; overflow: hidden; ">
					<?php
					$queryAs = mysqli_query($conn, "select * from our_associate");
					while ($rowAs = mysqli_fetch_object($queryAs)) {
					?>
						<div style="display: none;">
							<img data-u="image" src="admin/images/uploads/<?php echo $rowAs->image; ?>" style="margin-left:30px;" />
						</div>
					<?php
					}
					?>

				</div>
			</div>
		</div>
	</div>

</div>
<!-- /.container -->
<? include('include/footer.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$("#txtSearchPage").keyup(function() {

        var search = $(this).val();
   
		if(search == ''){
			 $(".item").hide();
	    $('#results .showfirst').show();
				
		}else{
		     $(".item").show();
		
        if (search)
            $(".item").not(":containsNoCase(" + search + ")").hide();	
			
		}
		
});

$.expr[":"].containsNoCase = function (el, i, m) {
    var search = m[3];
    if (!search) return false;
      return new RegExp(search,"i").test($(el).text());
};

</script>

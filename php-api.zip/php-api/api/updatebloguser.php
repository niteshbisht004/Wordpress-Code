<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	$post_by = $_POST['post_by'];
	$usertype = $_POST['usertype'];
	$name = $_POST['name'];  
		$gender = $_POST['gender']; 
		$qualification = $_POST['qualification'];  
		$date_birth = $_POST['date_birth'];  
		$specialisation = $_POST['specialisation']; 
		$registration_no = $_POST['registration_no'];
		$registration_auth = $_POST['registration_auth'];
		$expertise_in = $_POST['expertise_in'];
		$summary = $_POST['summary'];
		$total_experience = $_POST['total_experience'];
		$update_date = $_POST['date'];
		
		$phone_no = $_POST['phone_no'];
        $other_phone = $_POST['other_phone']; 
        $fax_no = $_POST['fax_no']; 
        $mobile_no = $_POST['mobile_no']; 
        $address = $_POST['address'];
		$country = $_POST['country']; 
        $otherEmail = $_POST['otherEmail']; 
        $city = $_POST['city'];
		$district = $_POST['district']; 
        $zipe_code = $_POST['zipe_code']; 
        $update_date = $_POST['update_date'];
		
	    $personalPhone = $_POST['personalPhone'];
        $personalMobile = $_POST['personalMobile']; 
        $personalEmail = $_POST['personalEmail']; 
        $personalUrl = $_POST['personalUrl']; 
        $personalAddress = $_POST['personalAddress'];
	 
	 
	$noOfBeds = $_POST['noOfBeds'];
	$private_room = $_POST['private_room'];
	$hospital_category = $_POST['hospital_category'];
	$clinical_test = $_POST['clinical_test'];
	$ambulance = $_POST['ambulance'];
    $heyear = $_POST['heyear'];
	$extra_feature = $_POST['extra_feature'];
	$O_contact = $_POST['O_contact'];
	$O_time_to_call = $_POST['O_time_to_call'];
	$O_email = $_POST['O_email'];
	$O_website = $_POST['O_website'];
	$O_message = $_POST['O_message'];
	$available_facility = $_POST['available_facility'];
	$special_infra = $_POST['special_infra'];
	$special_machine = $_POST['special_machine'];
	
	$O_extra_feature = $_POST['O_extra_feature'];
	$contact_no = $_POST['contact_no'];
	$time_to_call = $_POST['time_to_call'];
	$website = $_POST['website'];
	$state = $_POST['state'];
	
		$doctor_id = $_POST['doctor_id'];
	$hospital_id = $_POST['hospital_id'];
	
	$designation = $_POST['designation'];
	$hospital_c_name = $_POST['hospital_c_name'];
		$from_date = $_POST['from_date'];
	$to_date = $_POST['to_date'];
		$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];

	
	 $title = $_POST['title'];  
		
		$meta_name = $_POST['meta_name'];  
		$meta_discription = $_POST['meta_discription'];  
		$description = $_POST['description']; 
		//$image = $_POST['image'];
		$video = $_POST['video'];
		$insert_date = $_POST['insert_date'];
		$valid_from = $_POST['valid_from'];
		$valid_to = $_POST['valid_to'];
		$short_desc = $_POST['short_desc'];
		$deal_date = $_POST['deal_date'];
	 
	    $other_id = $_POST['other_id'];
 $delete_image = $_POST['delete_image'];

$explodess=explode('|', $delete_image);
foreach ($explodess as $file) {

 $filepath = '/home4/freeemedical/public_html/sisdev/admin/images/uploads/'.$file;

  unlink($filepath);
  
}
       $file =$_FILES['image']['name'];
	    $img=$file[0];
		//print_r($file); 
		if($img=='') {
			$fileName = array();
			//echo "hello";die();
		}else{
			//echo "kdfgkdgh";die();
	    $files = [];
	foreach($_FILES['image']['name'] as $i => $name) {
	//echo "hello";

    $name = $_FILES['image']['name'][$i];
    $size = $_FILES['image']['size'][$i];
    $type = $_FILES['image']['type'][$i];
    $tmp = $_FILES['image']['tmp_name'][$i];
   
    $explode = explode('.', $name);


    $ext = end($explode);
    $updatdName = $explode[0] . time() .'.'. $ext;
    $path = '/home4/freeemedical/public_html/admin/images/uploads/';
    $path = $path . basename( $updatdName );

    if(empty($_FILES['image']['tmp_name'][$i])) { 
		 	//$errorMSG = json_encode(array("message" => "Please choose at least 1 file to be uploaded.", "status" => false));	
	//echo $errorMSG;
			
				}else {

					$allowed = array('jpg','jpeg','gif','bmp','png');

					$max_size = 6000000; // 6MB

					if(in_array($ext, $allowed) === false) {
						
						//$errorMSG = json_encode(array("message" => "The file extension is not allowed.", "status" => false));	
	//echo $errorMSG;
						
					}

					if($size > $max_size) {
						//$errorMSG = json_encode(array("message" => "The file size is too hight.", "status" => false));	
	//echo $errorMSG;
						
					}

				}

				if(empty($errors)) {

					// if there is no error then set values
					$files['file_name'][] = $updatdName;
					$files['size'][] = $size;
					$files['type'][] = $type;
					$errors = array();
					if(!file_exists('/home4/freeemedical/public_html/admin/images/uploads/')) {
						mkdir('/home4/freeemedical/public_html/admin/images/uploads/', 0777);
					}

					if(move_uploaded_file($tmp, $path)) {
					//	$errorMSG = json_encode(array("message" => "The file successful upload", "status" => true));	
	                //    echo $errorMSG;
						
						
					}else {
					//	$errorMSG = json_encode(array("message" => "Something went wrong while uploading", "status" => false));	
	                // echo $errorMSG;
						
						
					}

				}else {
					foreach($errors as $error) {
						//echo '<p>'.$error.'<p>';
					}
				}

			}
		

				if(!empty($files))
			 {
				//$files['file_name'][] = $updatdName;
				$fileName = implode('|', $files['file_name']);
			}

		}
	
        if($val == 'doctor'){
            include_once 'classes/doctors.php';
            $items = new Doctors($db);
			if(!empty($fileName)){
            $stmt = $items->updateBlogbydoc($title,$specialisation,$meta_name,$meta_discription,$description,$fileName,$video,$val,$post_by,$id);
            //$allArr = array();
			
			}else{
			  $stmt = $items->updateBlogbydocs($title,$specialisation,$meta_name,$meta_discription,$description,$video,$val,$post_by,$id);
	
			}
			
			
            if($stmt){
            
            $usr[] =  array('id' => $id);
                $response['data']=$usr;
                $response['message']="Data Updated";
            $response['status']=1;
        
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
          
          
                  if($val == 'hospital'){
                    include_once 'classes/hospitals.php';
            $items = new Hospitals($db);
			if(!empty($fileName)){
            $stmt = $items->updateBlogbyhos($title,$specialisation,$meta_name,$meta_discription,$description,$fileName,$video,$val,$post_by,$id);
            //$allArr = array();
			}else{
			 $stmt = $items->updateBlogbyhoss($title,$specialisation,$meta_name,$meta_discription,$description,$video,$val,$post_by,$id);
	
			}
			
            if($stmt){
            
            $usr[] =  array('id' => $id);
                $response['data']=$usr;
                $response['message']="Data Updated";
            $response['status']=1;
        
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
          
              if($val == 'other'){
            include_once 'classes/others.php';
            $items = new Others($db);
			if(!empty($fileName)){
            $stmt = $items->updateBlogbyoth($title,$specialisation,$meta_name,$meta_discription,$description,$fileName,$video,$val,$post_by,$id);
            //$allArr = array();
			}else{
			  $stmt = $items->updateBlogbyoths($title,$specialisation,$meta_name,$meta_discription,$description,$video,$val,$post_by,$id);
	
			}
            if($stmt){
            
            $usr[] =  array('id' => $id);
                $response['data']=$usr;
                $response['message']="Data Updated";
            $response['status']=1;
        
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
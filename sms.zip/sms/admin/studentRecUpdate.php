<?php 
include('../dbcon.php');
 if(isset($_POST['btnUpdate']))
    {
       // $rollno=$_POST['rollno'];
        $name=$_POST['stuname'];
        $city=$_POST['city'];
        $standerd=$_POST['std'];
        $stu_mob=$_POST['number'];
        $upQuery="update student set `name`='$name', `city`='$city', `standerd`='$standerd', `stu_mob`='$stu_mob' where `id`=".$_COOKIE['user_id'];
        $rs = mysqli_query($con,$upQuery);	
    if ($con->query($upQuery) === TRUE)
    {
      echo "Record updated successfully . . . . . . ! !";
    }
     else
    {
        echo "Error: " . $upQuery . "<br>" . $con->error;
    }
 }
 ?>
<? include("include/header.php");
$reslt_deal = fetchAllDatas(" `deals` ");
	//print_r($reslt_deal);die;
$valid_to = $reslt_deal[0][3];
$current_date =date("d/m/Y");
if ($valid_to > $current_date){
    echo "$valid_to is latest than $current_date";
}else{
    echo "$valid_to is older than $current_date";
}


//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM cities") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$cities[$data['id']] = utf8_encode($data['name']);
		$c++;
	}
}


?>

<div class="detail-list-front">
	<div class="container">
		<div class="col-md-12 col-xs-12 col-sm-2 in-filter-sets">
			<div class="row">
				<form method="get" action="">
					<div class="col-md-2"></div>
					<div class="col-md-4 col-sm-12 col-xs-12 fiter-top-mainp" id="form-set-filter1">

						<select name="speci" class="form-control">
							<option value="">All Specialisations</option>
							<?php
							foreach ($specialisations as $ke => $spe) {
								$selected = "";
								$selected = ($ke == $_GET['speci']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $spe . "</option>";
							}
							?>
						</select>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12 fiter-top-mainp">
						<button type="submit" class="form-control" name="filter" value="1">Filter</button>
					</div>
					<div class="col-md-2"></div>
				</form>
			</div>
		</div>
	</div>
</div>
<!--deals-->
<div class="single-deals-page-p" id="c-single-deal">
	<div class="container">
		<div class="col-md-12 col-xs-12 col-sm-2" id="main-top-detail-11">
		
				<h2>Burning <span style="color:#ed1c24;">Deals</span></h2>
			
		</div>


		<div class="col-md-12 col-xs-12 col-sm-12 deals-slider">
			<div class="row" style="padding: 0px !important;">
				
				<?php

				if (isset($_GET['speci']) && !empty($_GET['speci']) ) {
							
							
						$res_deal=fetchAllData("`deals`", "WHERE specialisation = '".$_GET['speci']."' OR specialisation LIKE '%|".$_GET['speci']."|%'");
						
						
						if(!empty($res_deal))
						{
							include("deal_result.php");
						}
						else{
							
							$res_deal = fetchAllDatas(" `deals`");	
							include("deal_result.php");	
						}
							
				
				}else{
					
				$res_deal = fetchAllDatas(" `deals` ");
				include("deal_result.php");	
				}
								
					 
				
					?>
				
			</div>
		</div>
	</div>
</div>
<? include('include/footer.php'); ?>

<script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
<script type="text/javascript" src="/js/script.js"></script>
<!-- use jssor.slider-21.1.debug.js instead for debug -->


<script src="/js/star-rating.js" type="text/javascript"></script>
<script>
	jssor_2_slider_init();
	$('.rating').rating({
		'showCaption': false
	});
</script>
<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

            include_once 'config/database.php';
            $database = new Database();
            $db = $database->getConnection();
            $data = json_decode(file_get_contents("php://input"));

            $ratingid = $_POST['ratingid'];
			$commentid = $_POST['commentid']; 
			
	       if($ratingid != ''){
			
	       include_once 'classes/abusecomentapi.php';
            $items = new Getauseridapi($db);
            $stmt = $items->updateratingid($ratingid); 
			
			$items1 = new Getauseridapi($db);
            $stmts = $items1->getratingid($ratingid);
			
            $res_cmt = $stmts->fetch_assoc();
			$report_by = $res_cmt['email'];
		    $comment_by = $res_cmt['rating_by_useremail'];
			$subject = "FMI Report Abuse Information";

				$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
				
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						
					</p>				
				</body>
				</html>";
				

				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <info@freemedicalinfo.in>' . "\r\n";
				$mail1 = mail($report_by,$subject,$message_to_report_by,$headers);
			
			 if ($stmt) {

        $usr = array();
        $usr['id'] =  $ratingid;
        $response['data'] = $usr;
        $response['message'] = "Data Updated";
        $response['status'] = 1;


        $json_response = json_encode($response);
        echo $json_response;
        exit;
    } else {
        $response['message'] = "Data Not Updated";
        $response['status'] = 0;

        $json_response = json_encode($response);
        echo $json_response;
        exit;
    }
			
			

		}
          else{
         include_once 'classes/abusecomentapi.php';
         $item11 = new Getauseridapi($db);
         $stmt = $item11->updatecommentid($commentid); 
		 
		 $items2 = new Getauseridapi($db);
         $stmtss = $items2->getcommentid($commentid);
		 
		 $res_cmts = $stmtss->fetch_assoc();
		 
	     $report_by = $res_cmts['email'];
		 $comment_by = $res_cmts['rating_by_useremail'];
		 $subject = "FMI Report Abuse Information";

				$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
				
						Reported Comment :- <strong>'".$res_cmts['comment']."'</strong>. </br>
						
					</p>				
				</body>
				</html>";
				

				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <info@freemedicalinfo.in>' . "\r\n";
				$mail1 = mail($report_by,$subject,$message_to_report_by,$headers);

                 if ($stmt) {

        $usr = array();
        $usr['id'] =  $commentid;
        $response['data'] = $usr;
        $response['message'] = "Data Updated";
        $response['status'] = 1;


        $json_response = json_encode($response);
        echo $json_response;
        exit;
    } else {
        $response['message'] = "Data Not Updated";
        $response['status'] = 0;

        $json_response = json_encode($response);
        echo $json_response;
        exit;
    }

}	
   ?>

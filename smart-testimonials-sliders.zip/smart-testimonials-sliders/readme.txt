=== Smart Features for WooCommerce ===
Tags: woocommerce, woocommerce sales
Requires at least: 4.6
Tested up to: 5.8
Stable tag: 1.6.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

SMART FEATURES FOR WOOCOMMERCE

All-in-one smart features for woocommerce to boost sales. This plugin has helped websites worldwide to boost sales. This Smart features plugin helps you with your ecommerce optimization. From tracking to sales, it has all.;

DON’T LET YOUR COMPETITORS WIN;

Smart Features for WooCommerce does everything in its power to please visitors. A dedicated team of developers, testers, architects and Ecommerce experts work daily to improve the plugin with every release. Smart Features for WooCommerce plugin offers:

   - Options to add tracking code without editing theme files.
   - Options to add Custom css without editing theme files.
   - Options to add trust images on product page without editing theme files. Add trust images to your product pages, gives visitors confidence to purchase from your site.


= Documentation =


= Website =

<a href="https://ecompundit.com/all-in-one-smart-features-for-woocommerce-plugin/">https://ecompundit.com/all-in-one-smart-features-for-woocommerce-plugin/</a>

== Installation ==

Starting with Smart Features for WooCommerce consists of just two steps: installing and setting up the plugin. Smart Features for WooCommerce is designed to work with your site’s specific needs, so don’t forget to go through the 'after activation' step!

INSTALL YOAST SEO FROM WITHIN WORDPRESS

    Visit the plugins page within your dashboard and select ‘Add New’;
    Search for 'Smart Features for WooCommerce';
    Activate Smart Features for WooCommerce from your Plugins page;
    Go to 'Smart Features for WooCommerce' below.

INSTALL SMART FEATURES FOR WOOCOMMERCE MANUALLY

    Upload the 'smart-features-for-woocommerce' folder to the /wp-content/plugins/ directory;
    Activate the Yoast SEO plugin through the 'Plugins' menu in WordPress;
    Go to ‘after activation’ below.

AFTER ACTIVATION

    You should see new admin page in wordpress dashboard called "Smart Woo", once plugin is activated;
    Go through the general settings and set up the plugin for your site;
    You’re done!



== Changelog ==

= 1.0 =
= 1.1 =
= 1.2 =
= 1.3 =
= 1.4 =

* Initial release.
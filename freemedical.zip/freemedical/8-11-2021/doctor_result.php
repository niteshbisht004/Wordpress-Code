<style>
	.rating {
		font-size: 22px;

	}

	.rating-md {
		font-size: 0px;
	}

	.pagini .dpaginations {
		text-align: right;
		float: right;
		margin-bottom: 20px;
	}
</style>
<link href="/css/simplePagination.css" type="text/css" rel="stylesheet">
<div class="container">
	<div class="col-md-6 all-result-sort-title">
		<h2>ALL doctors available</h2>
		<p>Book appointments with minimum wait-time & verified doctor details</p>


	</div>
	
	<div class="col-md-6" style="padding-top: 45px;">
		<input id="txtSearchPage" type="search" class="form-control" placeholder="Search" /><br/>
	</div>
	<div class="col-md-12 dproduct1 detail-doc-grids" id="results">
		<div class="row">
			<? $j = 1;
			foreach ($res_doctor as $doct) { ?>
				<div  class="item itemd <?if ($j<=12){echo "showfirst"; } ?> col-md-4 col-lg-3 text-left">
					<div class="d-details-per-column">
						<? if ($doct['pro_img'] != "") { ?>
							<img src="/images/profile/<?= $doct['pro_img'] ?>" class="">
						<? } else { ?>
							<img src="/images/doctor-face.jpg">
						<? } ?>
						<div class="col-sm-12 in-details-main-f featured-color">
							<p class="name-d"><a href="/doctor/<?= $doct['user_id'] ?>" target="_blank"><?php echo ucfirst($doct['name']) ?></a></p>
							<p class="special-d">
								<? 
								$specialisation = explode(",", $doct['specialisation']);
								$x=0;
								foreach ($specialisation as $spec)
								{
									if($x==0)
									{
										echo $specialisations[$spec];
									}
									else{}
								$x++;
								}
								?>
							</p>
							<div class="rating-container rating-xs rating-animate">
								<div class="average-rating-d">
									<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");


									$r = 0;
									$i = 0;
									foreach ($res_cmt as $rat) {
										$r = $rat['rate'] + $r;
										$i++;
									}
									$r = $r / $i;
									if (is_nan($r)) {
										$r = 0;
									}
									$r = round($r, 1);
									if ($r == 0) {
										$var = '0%';
									}
									if ($r >= 1 && $r <= 1.5) {
										$var = '20%';
									}
									if ($r >= 1.5 && $r <= 2) {
										$var = '30%';
									}
									if ($r >= 2 && $r <= 2.5) {
										$var = '40%';
									}
									if ($r >= 2.5 && $r <= 3) {
										$var = '50%';
									}
									if ($r >= 3 && $r <= 3.5) {
										$var = '60%';
									}
									if ($r >= 3.5 && $r <= 4) {
										$var = '70%';
									}
									if ($r >= 4 && $r <= 4.5) {
										$var = '80%';
									}
									if ($r >= 4.5 && $r <= 5) {
										$var = '90%';
									}
									if ($r == 5) {
										$var = '100%';
									}
									?>
									<? if ($r == 0) {
									} else { ?><span><?php echo $r; ?></span><? } ?>
								</div>
								<div class="rating">
									<a style="" href="/rating/<?= $doct['user_id'] ?>">
										<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span></span>
										<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
									</a>
								</div>
							</div>
							<p class="special-add"><?php echo $doct['address']; ?></p>
						</div>
						
					</div>
				
				</div>
			<?
			$j++;
			}
			?>
		</div>
	</div>
	<div class="col-md-12 pagini">
		<div class="dpaginations">
		</div>
		
	</div>
</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <script type="text/javascript" src="https://flaviusmatis.github.io/simplePagination.js/jquery.simplePagination.js"></script>
<script>
      jQuery(function(jQuery) {
                var items = jQuery(".itemd");

                var numItems = items.length;
                var perPage = 12;

                // Only show the first 2 (or first `per_page`) items initially.
                items.slice(perPage).hide();

                // Now setup the pagination using the `#pagination` div.
                jQuery(".dpaginations").pagination({ 
                    items: numItems,
                    itemsOnPage: perPage,
					displayedPages:2,
					edges:2, 
                    cssStyle: "light-theme",

                    // This is the actual page changing functionality.
                    onPageClick: function(pageNumber) {
						//jQuery(window).scrollTop(0);
						jQuery("html, body").animate({ scrollTop: "200" }, 1000);

                        // We need to show and hide `tr`s appropriately.
                        var showFrom = perPage * (pageNumber - 1);
                        var showTo = showFrom + perPage;

                        // We'll first hide everything...
                        items.hide()
                             // ... and then only show the appropriate rows.
                             .slice(showFrom, showTo).show();
							 
                    }
                });
            });
			
			
$("#txtSearchPage").keyup(function() {

        var search = $(this).val();
   
		if(search == ''){
			 $(".itemd").hide();
	    $('#results .showfirst').show();
				
		}else{
		     $(".itemd").show();
		
        if (search)
            $(".itemd").not(":containsNoCase(" + search + ")").hide();	
			
		}
		
});

$.expr[":"].containsNoCase = function (el, i, m) {
    var search = m[3];
    if (!search) return false;
      return new RegExp(search,"i").test($(el).text());
};



</script>
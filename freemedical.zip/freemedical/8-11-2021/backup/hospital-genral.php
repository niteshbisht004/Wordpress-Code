<?
	include('../include/connection.php');
	include('../include/function.php');
?>
<?
	
	$resDD = fetchData(' `medical_registration` ', " where id='".$_SESSION['userId']."' ");
?>
<style>

.popup-form .control-label{
	text-align:left;
}
.popup-form .form-group {
    margin-bottom: 5px;
	border-bottom: 1px dotted #E4E4E4;
	padding-bottom: 5px;
}
#regAutSugg ul>li:hover{
	background: #ccc;
	cursor: pointer;
	padding-left:2px;
}
#regAutSugg ul>li{ padding-left:2px; }
#regAutSugg {
max-height: 100px;
overflow-y: scroll;
position: absolute;
z-index: 11;
width: 92%;
display: none;
border: 1px solid #eee;
background: #fff;
padding: 5px;
}
</style>
<script>
function reg_auth(str){
	
	if(str==""){
		document.getElementById("result").innerHTML = "";
		document.getElementById("regAutSugg").style.display  = "none";
	} else {
		document.getElementById("regAutSugg").style.display  = "block";
		var xhttp;
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (xhttp.readyState == 4 && xhttp.status == 200) {
				document.getElementById("result").innerHTML = xhttp.responseText;			
			}
		  };
		  xhttp.open("GET", "ajax-file/get_reg_authority.php?str="+str, true);
		  xhttp.send(); 
	}
	
}
function my(listId){
	var list = document.getElementById(listId);
	var txt = list["innerText" in list ? "innerText" : "textContent"];
	document.getElementById('inp').value = txt;
	document.getElementById("result").innerHTML = "";
	document.getElementById("regAutSugg").style.display  = "none";
}
</script>
<div class="popup-form">
            <form class="form-horizontal" role="form" action="/hospital-profile" method="post">
				<h4>General Information</h4>
				<hr style="margin-top: 0px;"/>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['name']?>" name="name"  class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Registration No</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_no']?>" name="registration_no" class="form-control"  required/>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Registration Authority</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_authority']?>" onKeyup="reg_auth(this.value)" name="registration_authority" class="form-control" id="inp" required/>
						<div id="regAutSugg" >
							<ul style="list-style:none; padding:0;" id="result">
															
							</ul>
						</div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Hospital Category</label>
					<div class="col-sm-9">
					<select name="hospital_category" id="hospital_category" class="form-control input-md" required>
					   <option value="">Select Hospital Category</option>
						<?php 
							 $querHosCat=mysqli_query($conn,"select * from hospital_cat");
							 while($rowHosCat=mysqli_fetch_object($querHosCat))
							 {
						   ?>
							 <option <? if($resDD['hospital_category'] == $rowHosCat->id) { echo "selected"; } ?> value="<?php echo $rowHosCat->id; ?>"><?php echo $rowHosCat->category_name; ?></option>
							 <?php } ?>  
					</select>
					</div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Specialisation</label>
					<div class="col-sm-9">
					<? $specialisation = explode("|",$resDD['specialisation']);
						$other = explode(":",$resDD['specialisation']);	
						$oth=explode("|",$other[0]);							
					?>
					<select name="specialisation[]" id="specialisation"  class="form-control selectpickerSpe input-md" data-live-search="true" data-size="6" multiple required>
					   <option value=""></option>
						<?php 
							$querSp=mysqli_query($conn,"select * from specialisation ORDER BY specialisation ASC");
							while($rowSp=mysqli_fetch_object($querSp))
						 {							 
						?>
						<option <? if(in_array($rowSp->id,$specialisation)) { echo "selected"; }  ?> value="<?php echo $rowSp->id; ?>"><?php echo $rowSp->specialisation; ?></option>
						<?php } 
						foreach($specialisation as $spli){
							 $spl = explode(":",$spli);
							 if(in_array('Other',$spl)){
								 $otherSpli = $spl[1];
								 $otherS = "OtherS";
							 }
						}
						?>
					
						<option <? if(in_array('Other',$oth)){ echo "selected";} ?> value="other">Other</option>
					</select>
					</div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Private Rooms</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['private_room']?>" name="private_room" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">No of Beds</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['noOfBeds']?>" name="noOfBeds" class="form-control" required>
                    </div>
                </div>
				    <div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Hospital Established Year</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['heyear']?>" name="heyear" class="form-control" required>
                    </div>
                </div>
				
					<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Description</label>
                    <div class="col-sm-9">
                        <textarea name="summary" class="form-control" maxlength="200"><?=$resDD['summary']?></textarea>
                    </div>
                </div>
				<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Clinic Test Available</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="clinical_test" value="yes" <? if($resDD['clinical_test']=="yes"){ echo "checked";} ?> required/>Yes
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="clinical_test" value="no" <? if($resDD['clinical_test']=="no"){ echo "checked";} ?> required/>No
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Ambulance Service</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="ambulance" value="yes" <? if($resDD['ambulance']=="yes"){ echo "checked";} ?> required />Yes
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="ambulance" value="no" <? if($resDD['ambulance']=="no"){ echo "checked";} ?> required />No
                                </label>
                            </div>
                      	
                        </div>
                    </div>
                </div>
                      			<div class="form-group">
				<? $extraF = explode(",",$resDD['extra_feature']); ?>
                    <label for="firstName" class="col-sm-3 control-label">Extra Service</label>
                    <div class="col-sm-9">
                        <div class="col-sm-3"><input <? if(in_array('Ambulance',$extraF)){ echo "checked='checked'"; } ?> id="checkbox1" type="checkbox" name="ambulance" value="Ambulance"> Ambulance </div>
                        <div class="col-sm-3"><input <? if(in_array('ICU On Wheels',$extraF)){ echo "checked='checked'"; } ?> id="checkbox1" type="checkbox" name="icu" value="ICU On Wheels"> ICU On Wheels  </div>
                        <div class="col-sm-3"><input <? if(in_array('ESI',$extraF)){ echo "checked='checked'"; } ?> id="checkbox1" type="checkbox" name="esi" value="ESI"> ESI </div>
                        <div class="col-sm-3"><input <? if(in_array('CGHS',$extraF)){ echo "checked='checked'"; } ?> id="checkbox1" type="checkbox" name="cghs" value="CGHS"> CGHS </div>
                    </div>
                </div>

<p class="inp"></p>
               
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="update_genral" class="btn btn-primary btn-block">Update</button>
                    </div>
                </div>
            </form> <!-- /form -->
</div>
<script>
  $(document).ready(function () {
    $('.selectpicker').selectpicker();
  });
  
 </script>
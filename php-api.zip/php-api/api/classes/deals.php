<?php
class Deals{

        // Connection
        private $conn;

        // Table
        private $db_table = "deals";

        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getDeals(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " order by id DESC";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
         
		 public function getDealsbyCategory($id,$term){
		
				
				if($id == '')
				{
					$sqlQuery = "SELECT deals.*, medical_registration.name, doctor_registration.name, other_service_registration.name FROM deals LEFT JOIN medical_registration ON deals.hospital_id =medical_registration.id LEFT  JOIN doctor_registration  ON deals .doctor_id =doctor_registration.id LEFT  JOIN other_service_registration ON deals.other_id =other_service_registration.id WHERE medical_registration.name like '%$term%' OR title like '%$term%' OR doctor_registration.name like '%$term%' OR other_service_registration.name like '%$term%'";
				}
				elseif($term == '')
				{
									
					 $sqlQuery = "SELECT * FROM deals WHERE specialisation like '%|$id|%' OR specialisation = $id OR specialisation like '$id|%' OR specialisation like '%|$id'";
					
				}else{
					
					 $sqlQuery = "SELECT deals.*, medical_registration.name, doctor_registration.name, other_service_registration.name FROM deals LEFT JOIN medical_registration ON deals.hospital_id =medical_registration.id LEFT  JOIN doctor_registration  ON deals .doctor_id =doctor_registration.id LEFT  JOIN other_service_registration ON deals.other_id =other_service_registration.id WHERE (medical_registration.name like '%$term%' OR title like '%$term%' OR doctor_registration.name like '%$term%' OR other_service_registration.name like '%$term%') AND (deals.specialisation like '%|$id|%' OR deals.specialisation = $id OR deals.specialisation like '$id|%' OR deals.specialisation like '%|$id')";
					 
					// echo  $sqlQuery;
					
				}	
			  $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		 public function getAllDealsbyCategory($id,$term)
		 {
			 $sqlQuery = "SELECT deals.*, medical_registration.name, doctor_registration.name, other_service_registration.name FROM deals LEFT JOIN medical_registration ON deals.hospital_id =medical_registration.id LEFT  JOIN doctor_registration  ON deals .doctor_id =doctor_registration.id LEFT  JOIN other_service_registration ON deals.other_id =other_service_registration.id WHERE (medical_registration.name like '%$term%' OR title like '%$term%' OR doctor_registration.name like '%$term%' OR other_service_registration.name like '%$term%') OR (deals.specialisation like '%|$id|%' OR deals.specialisation = $id OR deals.specialisation like '$id|%' OR deals.specialisation like '%|$id')";
			 
			 //echo $sqlQuery;die;
			 
			 $stmt = $this->conn->query($sqlQuery);
             return $stmt;
		 }
        // CREATE
        public function createUsers(){
              $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                       SET
                        user_id = :user_id, 
                        first_name = :fname, 
                        phone_no = :phone, 
                        password = :pw, 
                        email = :email,
						date_birth = :dob, 
                        active = :active, 
                        insert_date = :email
						";
        
            $stmt = $this->conn->query($sqlQuery);
        
            // sanitize
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->age=htmlspecialchars(strip_tags($this->age));
            $this->designation=htmlspecialchars(strip_tags($this->designation));
            $this->created=htmlspecialchars(strip_tags($this->created));
        
            // bind data
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":designation", $this->designation);
            $stmt->bindParam(":created", $this->created);
        
            if($stmt){
               return true;
            }
            return false;
        }
         
		 
		 
		   public function getDealsbyid($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id";

            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        } 
		
		
        // READ single
        public function getSingleDealsbydoctorid($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       doctor_id = $id";

            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }        

		   public function getSingleDealsbyhospitalid($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       hospital_id = $id";

            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }  
		
		   public function getSingleDealsbyotherid($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       other_id = $id";

            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        } 
        // UPDATE
        public function updateUsers(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        name = :name, 
                        email = :email, 
                        age = :age, 
                        designation = :designation, 
                        created = :created
                    WHERE 
                        id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->age=htmlspecialchars(strip_tags($this->age));
            $this->designation=htmlspecialchars(strip_tags($this->designation));
            $this->created=htmlspecialchars(strip_tags($this->created));
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            // bind data
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":designation", $this->designation);
            $stmt->bindParam(":created", $this->created);
            $stmt->bindParam(":id", $this->id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }
        
		
		
        // DELETE
        public function deleteDeals($id){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id=$id"; 
            $stmt = $this->conn->query($sqlQuery);
             
                return true;
           
        }

    }

?>
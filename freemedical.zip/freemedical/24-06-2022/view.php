<?php
	session_start();
 if(!empty($_SESSION['userEmail'])) 
 {  
	header('location:/profile.php');  
 } 
?>
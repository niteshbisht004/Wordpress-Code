<? 	
	session_start();
	if(empty($_SESSION['userEmail'])) { 

?>   
<style>
	#captcha {
    width: 40%;
    float: right;
    margin-top: -28px;
}
</style>
						<div class="login-box" >
							<div class="account-wall">
								<div class="loading" id="loading">
									<img class="profile-img" src="/images/loading-circle.gif" alt="">
									<h4 style="text-align:center">Please Wait Loading</h4>
								</div>
								<div class="loading" id="loginError">
								  
								</div>
								<form class="form-signup" id="form-signin">
									<select class="form-control" id="user_type" onchange="remove_utError()" >
										<option value="" disabled selected>Registration Type</option>
										<option value="userForm">User</option>
										<option value="doctorForm">Doctor</option>
										<option value="hospitalForm">Hospital / Clinic</option>
										<option value="other-medical">Other Medical Service</option>
									</select>
									
										<span id="utsError" class="errorbox" ></span>
									<input type="text" id="fname"  class="form-control" placeholder="Name"  value=""   />
										<span id="utEsrror" class="errorbox" ></span>
									<input type="tel" id="phone"  pattern="[1-9]{1}[0-9]{9}" class="form-control" placeholder="Phone"  value=""   />
									<span id="utError" class="errorbox" ></span>
									<input type="text" id="login_uid"  class="form-control" placeholder="User Id"  value=""  onblur="checkUserId()" onkeyup="userIdFormat(this.value)" />
									<span id="uidError" class="errorbox" ></span>
									<input type="email" id="login_email" class="form-control" placeholder="Email"  value=""  onblur="checkEmail()" />
									<span id="eError" class="errorbox" ></span>
									<input type="password" id="login_password" class="form-control" placeholder="Password"  value="" onblur="chkPass()" />
									<span id="pwError" class="errorbox" ></span><br/>
									<input type="password" id="login_cpassword" class="form-control" placeholder="Confirm Password"  value="" onblur="chkCPass()" />
									<span id="pwCError" class="errorbox" ></span><br/>
									
									<input type="text" name="date_birth" id="dob" class="form-control datepicker" onblur="dob_validate()" placeholder="Date of Birth"/>
									<span id="dobError" class="errorbox" ></span><br/>
									
									<select id="field" class="form-control" onchange="remove_edu()" style="display:none;">
										<option value="" disabled selected>Select Category</option>
											<?php 
                                     $conn = mysqli_connect("localhost","freeemed_new","m~RnX?x;F45m","freeemed_new");
									    if(!$conn)
										{ 
                                          echo"False Condition ";
										}
										else{
											echo"Conection Files Avroved ";
										}
										$sel = "select DISTINCT service from  other_service_registration";
								$que_sel = mysqli_query($conn,$sel) or die(mysqli_error());
									while ($res = mysqli_fetch_array($que_sel)) {
									   print_r($res['service']);
									?>
										<option value="<?php echo $res['service']; ?>"><?php echo $res['service']; ?></option>
									<?php } ?>
									</select>
									<span id="dobError" class="errorbox" ></span><br/>
									<input type="text" id="field_edu"  class="form-control" placeholder="Enter Service"  value=""  style="display:none;"  />
									
									<div class="form-group">
										<label>Captcha:</label>
										<div id="imgdiv" style="font-size:20px; border:2px solid #000; width: 40%;">
											<span id="img"></span>
										</div>	
										<span id="imgparent">
											<img id="reload" src="/captcha/reload.png" />
										</span>
										<input type="text" id="captcha" vclass="form-control"/>
									
									</div>
									<div id="result"></div>
									<!--
									<span id="imgparent">
										<div id="imgdiv" class="col-md-6">
											<img id="img" src="/captcha/captcha.php" />
										</div>
										<div class="col-md-6">
											<img id="reload" src="/captcha/reload.png" />
										</div>
									</span>
									<input type="text" id="captcha1" class="form-control" name="captcha" value="" placeholder="Enter Captcha Code">
									<span id="cptError" class="errorbox" ></span> -->
									<br/>
									<p>
									<input type="checkbox" id="checkbox" required>  I Agree to <a href="/term.php" target="_blank">Terms & Conditions</a> <br/>
									<span id="checkboxError" class="errorbox" ></span><br/>
									</p>
									<button class="btn btn-primary" onclick="submit_form()" type="button">Sign Up</button>
									
									<a href="#" id="jan" onclick="jan()";  class="pull-right need-help">Need help? </a><span class="clearfix"></span>
								</form>
							</div>
						</div>
					

  
<script src="/captcha/script.js"></script>  
<script src="/js/bootstrap-datepicker.js"></script>
<script>
function validations(){
	//var url = url_exist(document.getElementById("O_website").value);
	/*if(url==false){
		return false;
	}*/
	var mob = document.getElementById("phone");	
	if(mob.value.length < 10){
		alert("Mobile no must be 10 Digit!")
		document.getElementById("mobileNo").focus();
		return false;		
	}
	else{		
		return true;
	}
}
function dob_validate(){
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();
	if(dd<10){
		dd='0'+dd;
	} 
	if(mm<10){
		mm='0'+mm;
	} 
	var today = mm+'/'+dd+'/'+yyyy;		
	var dob = document.getElementById('dob').value;
	
	var str1= dob.split('/');
	var str2= today.split('/');

	  //   yyyy , mm  , dd
	  var t1 = new Date(str1[2], str1[0]-1, str1[1]);
	  var t2 = new Date(str2[2], str2[0]-1, str2[1]);
	
	  var diffMS = t2 - t1;    
	  console.log(diffMS + ' ms');

	  var diffS = diffMS / 1000;    
	  console.log(diffS + ' ');

	  var diffM = diffS / 60;
	  console.log(diffM + ' minutes');

	  var diffH = diffM / 60;
	  console.log(diffH + ' hours');

	  var diffD = diffH / 24;
	  console.log(diffD + ' days');
	  
	  var age = diffD / 365;
	  
	  
	  if(dob == ""){
			document.getElementById('dobError').innerHTML= 'Please Select Date of Birth';
			var error = true;			
		}
		if(dob != ""){
			document.getElementById('dobError').innerHTML= '';						
		}
		
	  var user_type = document.getElementById('user_type').value;
	  
		
		if(user_type == 'doctorForm'){		 
		  if(age >= 19){
			 //alert("able to go");
		  }
		  else{			  
			  document.getElementById('dobError').innerHTML= 'Candidate Age should be 19 year to Registered. ';
			  document.getElementById('dob').value = "";
				return false;
			}
		}
		if(user_type == 'userForm'){			
			if(age >= 13){
			 // alert(age+"able");			  
			}
		  else{
			  document.getElementById('dobError').innerHTML= 'Candidate Age should be 13 year to Registered.';
			  document.getElementById('dob').value = "";
			  return false;
			}
		}
}
window.onkeydown = function( event ) {
    if ( event.keyCode == 13 ) {
        submit_form();
    }
};
	function userIdFormat(u){
		u = u.replace(/[^a-zA-Z0-9_]/g, '');
		document.getElementById('login_uid').value = u;
	}
	function checkUserId(){
		var user_type = document.getElementById('user_type').value;
		var user_id = document.getElementById('login_uid').value;
		if(user_type == ""){
			document.getElementById('utError').innerHTML= 'Please Select First Resitration Type';
			document.getElementById("uidError").innerHTML = "You can't leave this empty.";
			document.getElementById('login_uid').value= "";
			document.getElementById('user_type').focus();
			return false;
		} else {
			if(user_id != ""){
			  var xhttp;
			  str = "regForm="+user_type+"&userId="+user_id;
			 
			  xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					document.getElementById("uidError").innerHTML = xhttp.responseText;
				}
			  };
			  xhttp.open("GET", "/ajax-file/check-userid.php?"+str, true);
			  xhttp.send();
			} else {
				document.getElementById("uidError").innerHTML = "You can't leave this empty.";
				return false;
			} 
		}
	}
	
	function checkEmail(){
		
		var user_type = document.getElementById('user_type').value;
		var emailId = document.getElementById('login_email').value;
		if(user_type == ""){
			document.getElementById('utError').innerHTML= 'Please Select First Resitration Type';
			document.getElementById("eError").innerHTML = "You can't leave this empty.";
			document.getElementById('login_email').value= "";
			document.getElementById('user_type').focus();
			return false;
		} else {
			if(emailId != ""){
				
			  var xhttp;
			  str = "regForm="+user_type+"&emailId="+emailId;
			 
			  xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					document.getElementById("eError").innerHTML = xhttp.responseText;
				}
			  };
			  xhttp.open("GET", "/ajax-file/check-email.php?"+str, true);
			  xhttp.send();
			} else {				
				document.getElementById("eError").innerHTML = "You can't leave this empty.";
				return false;
			}
		}
	}
	
	function chkPass(){
		var p=document.getElementById("login_password").value;
		if(p=="")
		{
		document.getElementById("pwError").innerHTML="You can't leave this empty.";
		return false;
		}
		else if(p.length<6)
		{
		document.getElementById("pwError").innerHTML= 'Lenght must be 6';
		return false;
		}
		else
		{
		document.getElementById("pwError").innerHTML= '';
		return true;
		}
	}
	
	function chkCPass(){
		var p=document.getElementById("login_password").value;
		var cp=document.getElementById("login_cpassword").value;
		if(cp=="")
		{
		document.getElementById("pwCError").innerHTML="You can't leave this empty.";
		return false;
		}
		else if(cp.length<6)
		{
		document.getElementById("pwCError").innerHTML= 'Lenght must be 6';
		return false;
		}
		else if(cp!=p)
		{
		document.getElementById("pwCError").innerHTML= "Can't Match Password";
		return false;
		}
		else
		{
		document.getElementById("pwCError").innerHTML= '';
		return true;
		}
	}

	function remove_utError(){
		var user_type = document.getElementById('user_type').value;
		if(user_type == 'hospitalForm'){		
		document.getElementById('dob').style='display:none';
		document.getElementById('dobError').style='display:none';
		document.getElementById('field').style='display:none';
		}
		else if(user_type == 'other-medical'){		
		document.getElementById('dob').style='display:none';
		document.getElementById('dobError').style='display:none';
		document.getElementById('field').style='display:block';
		}
		else{
			document.getElementById('dob').style='display:block';
			document.getElementById('dobError').style='display:block';
			document.getElementById("dobError").innerHTML= '';
			document.getElementById('field').style='display:none';
		}
		document.getElementById('utError').innerHTML= '';
	}
	
	
		function remove_edu(){
		var field = document.getElementById('field').value;
		if(field == 'other'){		
		
		document.getElementById('field_edu').style='display:block';
	   
		}
	
	}
	function submit_form(){
		//alert('jan');
		var user_type = document.getElementById('user_type').value;
		var user_id = document.getElementById('login_uid').value;
		var fname = document.getElementById('fname').value;
		
		var phone = document.getElementById('phone').value;
		var email = document.getElementById('login_email').value;
		var password = document.getElementById('login_password').value;
		var captcha = document.getElementById('captcha').value;
		var dob = document.getElementById('dob').value;
		var field_edu = document.getElementById('field_edu').value;
		var field = document.getElementById('field').value;

		
		var checkUID = checkUserId();
		
		if(!document.getElementById('checkbox').checked){
            document.getElementById('checkboxError').innerHTML= 'Checkbox Not Checked!';
            return false;
		}		
		
		if(checkUID==false){
			var error = true;
		}
		
		var checkEID = checkEmail();
		if(checkEID==false){
			var error = true;
		}
		
		var checkPW = chkPass();
		if(checkPW==false){
			var error = true;
		}
		
		var checkCPW = chkCPass();
		if(checkCPW==false){
			var error = true;
		}
		
		var dob_validat = dob_validate();
		if(dob_validat==false){
			var error = true;
		}
				
		if(captcha == ""){
			document.getElementById('cptError').innerHTML= 'Please Enter Captcha Code';
			var error = true;			
		}
		
		
		if(error!=true){
			var dataString = 'captcha=' + captcha;
			alert(dataString);
            $.ajax({
                type: "POST",
                url: "/captcha/verify",
                data: 'type='+captcha,
                success: function(html) { 
				
                    if(html=="success"){
						success = "success";
						document.getElementById('loading').style.display = "block";
						str = "regForm="+user_type+"&fname="+fname+"&phone="+phone+"&email="+email+"&pw="+password+"&user_id="+user_id+"&dob="+dob+"&fld="+field+"&fldedu="+field_edu;
						register(str);
					} else {						
						alert("Wrong Captcha");
					}
                }
            });			
		}
		
		
	}
 
	function register(str) {		
	  var xhttp;	
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			if(xhttp.responseText=="success"){
				window.location.href = '/registration-successfully.php';
			} else {
				document.getElementById("loginError").innerHTML = xhttp.responseText;
				document.getElementById('loginError').style.display = "block";
				document.getElementById('loading').style.display = "none";
				$("img#img").remove();
				var id = Math.random();
				$('<img id="img" src="/captcha/captcha.php?id='+id+'"/>').appendTo("#imgdiv");
				id ='';
			}
		}
	  };
	  xhttp.open("GET", "/registration-validation.php?"+str, true);
	  xhttp.send();  
	  
	}
	
	
	
	 $('.datepicker').datepicker();
	 
</script>
<script>
	$(document).ready(function(){
		$('#img').load('captcha/captchareg.php');
	});
</script>
      
<?	} else { ?>

						<div class="login-box" >
							<div class="account-wall">
								<div class="" id="loading">
									<img class="profile-img" src="/images/logged.png"	alt="">
									<h4 style="text-align:center">Your Are Already Logged-in</h4>
								</div>
							</div>
						</div>

<? } ?>	


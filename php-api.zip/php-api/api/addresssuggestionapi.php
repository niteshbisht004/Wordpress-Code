<?php
error_reporting(0);
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	

	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['search'];
	$city = $_POST['city'];
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getaddresssuggestions($val,$city);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
        
        
          while ($row = $stmt->fetch_assoc()){
			
            $userArr[] = $row;
			 		
					 
				 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
		exit;		
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;	
    }
	
    
	
	
	
?>
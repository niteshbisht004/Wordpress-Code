<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

            include_once 'config/database.php';
            $database = new Database();
            $db = $database->getConnection();
            $data = json_decode(file_get_contents("php://input"));


            $userid = $_POST['userid'];
            $commentid = $_POST['commentid'];
            $ratingid = $_POST['ratingid'];
            $val = $_POST['cat'];
            $data = $_POST['data'];  

     

    if($val == 'rcomment')
    {
       
        if($data == 'like'){

            include_once 'classes/rating.php';
            $items = new Ratings($db);
            $stmt = $items->insertcommentlike($commentid,$userid);

        }else{

            include_once 'classes/rating.php';
            $items = new Ratings($db);
            $stmt = $items->insertcommentdislike($commentid,$userid);
            
        } 
    //$allArr = array();
            if ($stmt) {

                $usr = array();
                $usr['id'] =  $items->id;
                $response['data'] = $usr;
                $response['message'] = "Done";
                $response['status'] = 1;


                $json_response = json_encode($response);
                echo $json_response;
                exit;
            } else {
                $response['message'] = "Already Done";
                $response['status'] = 0;

                $json_response = json_encode($response);
                echo $json_response;
                exit;
            }

    }else{
        if($data == 'like'){

            include_once 'classes/rating.php';
            $items = new Ratings($db);
            $stmt = $items->insertratinglike($ratingid,$userid);

        }else{

            include_once 'classes/rating.php';
            $items = new Ratings($db);
            $stmt = $items->insertratingdislike($ratingid,$userid);

        }     
       
        //$allArr = array();
        if ($stmt) {
    
            $usr = array();
            $usr['id'] =  $items->id;
            $response['data'] = $usr;
            $response['message'] = "Done";
            $response['status'] = 1;
    
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
            $response['message'] = "Already Done";
            $response['status'] = 0;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }   



    }

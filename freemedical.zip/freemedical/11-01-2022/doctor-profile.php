<? include("include/header.php"); ?>
<? if(empty($_SESSION['userId']) || $_SESSION['userType']!="doctor"){
	header("location:/index.php");
} ?>

<?php



if (isset($_POST['image_gallerys'])) {
$files = [];
	foreach($_FILES['image_gallery']['name'] as $i => $name) {

    $name = $_FILES['image_gallery']['name'][$i];
    $size = $_FILES['image_gallery']['size'][$i];
    $type = $_FILES['image_gallery']['type'][$i];
    $tmp = $_FILES['image_gallery']['tmp_name'][$i];

    $explode = explode('.', $name);


    $ext = end($explode);

    $updatdName = $explode[0] . time() .'.'. $ext;
    $path = 'images/gallery/';
    $path = $path . basename( $updatdName );

    if(empty($_FILES['image_gallery']['tmp_name'][$i])) { 
		?>
			<script>
				alert('Please choose at least 1 file to be uploaded.');
			</script>
		<?
				}else {

					$allowed = array('jpg','jpeg','gif','bmp','png');

					$max_size = 6000000; // 6MB

					if(in_array($ext, $allowed) === false) {
						?>
						<script>
							alert('The file extension is not allowed.');
						</script>
						<?
					}

					if($size > $max_size) {
						?>
						<script>
							alert('The file size is too hight.');
						</script>
						<?  
					}

				}

				if(empty($errors)) {

					// if there is no error then set values
					$files['file_name'][] = $updatdName;
					$files['size'][] = $size;
					$files['type'][] = $type;
					$errors = array();
					if(!file_exists('images/gallery/')) {
						mkdir('images/gallery/', 0777);
					}

					if(move_uploaded_file($tmp, $path)) {
						?>
						<script>
							alert('The file successful upload');
						</script>
						<? 
					}else {
						?>
						<script>
							alert('Something went wrong while uploading ');
						</script>
						<? 
					}

				}else {
					foreach($errors as $error) {
						echo '<p>'.$error.'<p>';
					}
				}

			}

			if(!empty($files))
			 {
				//$files['file_name'][] = $updatdName;
				$img = implode('|', $files['file_name']);
			}
					 
		else{			
			$img = $_POST['oldfiless'];		
		}

$updatess = "UPDATE doctor_registration set 
  `image_gallery` = '".$img."' where `id` = '".$_SESSION['userId']."' ";
 //echo $inss;die;
	mysqli_query($conn,$updatess) or die(mysqli_error()); 
	header('location:/doctor-profile.php');



}

?>


<?

if (isset($_POST['submitRedeem'])) {
    $upiid = $_POST['upiid'];
	
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
// Output: 54esmdr0qf
$random =substr(str_shuffle($permitted_chars), 0, 12);
 //$random = rand(100000,999999);
 //print_r($random);
// die();
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://payout.payumoney.com/payout/payment',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'[
{
"purpose":"Citi test",
"amount":"1.0",
"batchId":"citi",
"merchantRefId":"'.$random.'",
"paymentType" :"UPI",
"retry":false,
"vpa":"'.$upiid.'"
}
]',
  CURLOPT_HTTPHEADER => array(
    'payoutMerchantId: 1116283',
    'Authorization: Bearer 9dc3e4bad7b7a04bd643d2ddf845cfa93ff46b22ec1bdc519a016af7ff70ccc4',
    'Content-Type: application/json'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

  header("location:/doctor-profile?status=success");
if( $_GET['status'] == 'success') {
   echo '<script>  alert("Coupan Redeem Successfully");   </script>';
}
else{
}
}
?>
<?

if (isset($_POST['rsubmit'])) {
	$rcmnt = $_POST['comnt'];
	$ridd = $_POST['rateIdd'];
	$uid = $_POST['userId'];
	$umail = $_POST['uemail'];
	$utype = $_POST['utype'];
	$urid = $_POST['urateId'];
	$urmail = $_POST['urateMail'];
	$urtype = $_POST['urateType'];
	$date = date("Y-m-d H:i:s");
	$rpId = $_POST['rplyid'];


	$rqry = "insert into rnewrating(`comment`,`rating_id`,`reply_id`,`user_id`,`email`,`rateusertype`,`rating_by_userid`,`rating_by_useremail`,`user_type`,`insert_date`) values('$rcmnt','$ridd','$rpId','$uid','$umail','$utype','$urid','$urmail','$urtype','$date')";
	$run = mysqli_query($conn, $rqry);
	if ($run) {
?>
		<script>
			//alert('Thanks for your comment.');
			if (window.location.href.indexOf("comments") > -1) {
               var url=window.location.href;
			window.history.replaceState(null, null, url);
    }else{
			var url=window.location.href+"#comments";
			window.history.replaceState(null, null, url);
	}
		</script>
<?
	} else {
		echo "error......!";
	}
}
$current_date = date('Y/m/d h:i:s'); 
if(isset($_GET['del']) && $_GET['del']=="ProExp"){
	delRow("prof_exp_doc"," where id = '".$_GET['id']."' ");
	header("location:/doctor-profile#pexp");
}
if(isset($_GET['del']) && $_GET['del']=="CH"){
	delRow("current_hospital"," where id = '".$_GET['id']."' ");
	header("location:/doctor-profile#chospital");
}
if(isset($_POST['submit']))
	 {
		 $ins = "insert into comment_doctor set
		 `name` = '".$_POST['name']."', 
		 `email` = '".$_POST['email']."', 
		 `comment` = '".$_POST['comment']."', 
		 `doc_id` = '".$_SESSION['userId']."', 
		 `status` = 'no',		 
		 `insert_date` = now() 
		 ";
		 mysqli_query($conn,$ins) or die(mysqli_error());			
		header("location:/doctor-profile?openTab=commentsTab");
	 }
if(isset($_POST['replysubmit'])){
		 $comment_id = $_POST['cmnt_id'];
		$rpy_commnt = mysqli_query($conn,"insert into comment_reply_doctor set 
		`comment_id`='$comment_id', 
		`reply_by_id`='".$_SESSION['userId']."',
		`reply_by_name`='".$_SESSION['userName']."',
		`reply_by_email`='".$_SESSION['userEmail']."',
		`reply_message`='".$_POST['Rcomment']."',
		`status`='no' ") or die(mysqli_error());
		header("location:/doctor-profile?openTab=commentsTab");
	}
if(isset($_GET['Cid']))
	 {
		$del = "delete from comment_doctor where id = '".$_GET['Cid']."' ";
		mysqli_query($conn,$del) or die(mysqli_error());
		header("location:/doctor-profile?openTab=commentsTab");
	 }
if(isset($_GET['rid']))
	 {
		 $report_cmt = " UPDATE comment_doctor set `status`='no', `report`='report' where id = '".$_GET['rid']."' ";
		 mysqli_query($conn,$report_cmt) or die(mysqli_error());		 
		 	 
		 $Query_cmnt = mysqli_query($conn," select * from comment_doctor where id = '".$_GET['rid']."' ") or die(mysqli_error());		
		 $num = mysqli_num_rows($Query_cmnt);
		 $res_cmt = mysqli_fetch_array($Query_cmnt);
		
			
			// Mail to Report Abuse By...
				$report_by = $_SESSION['userEmail'];
				$comment_by = $res_cmt['email'];
				
				$subject = "FMI Report Abuse Information";

				$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>You did Report Abuse of <strong>'".$res_cmt['name']."'</strong> Comment. </br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";
				
				$message_to_comment_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>Your Comment have been Reported Abuse By <strong>'".$_SESSION['userName']."'</strong>. so we have to unpublished your comment due to the reason. </br>
						Reported By :- <strong>'".$_SESSION['userEmail']."'</strong></br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";

				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <webmaster@example.com>' . "\r\n";
				$headers .= 'Cc: myboss@example.com' . "\r\n";

				$mail1 = mail($report_by,$subject,$message_to_report_by,$headers);
				$mail2 = mail($comment_by,$subject,$message_to_comment_by,$headers);
			
			// Mail to Commentor ..
			
			header('location:/doctor-profile?openTab=commentsTab');
	 }	 
	 
if(isset($_POST['update_genral'])){	
	function array_replace_value($array, $replacementTo, $replacement)
	{
		if (in_array($replacementTo, $array)) {
			$key = array_search($replacementTo, $array);
			$array[$key] = $replacement;
			return $array;
		}
	}
	
	$qualification = implode("|",$_POST['qualification']);
	if(in_array("Other",$_POST['qualification'])){
		//$qualification = $qualification.":".$_POST['otherQuali'];
		$qualO = array_replace_value($_POST['qualification'], "Other", $_POST['otherQuali']);
		$qualification = implode("|",$qualO);
		$insert_quali = "insert into `qualification` set `qualification` = '".$_POST['otherQuali']."' "; 
		mysqli_query($conn,$insert_quali) or die(mysqli_error());
	}
	
	
	
	$specialisation = implode("|",$_POST['specialisation']);
	if(in_array("other",$_POST['specialisation'])){
		//$specialisation = $specialisation.":".$_POST['otherSpeci'];
		$specO = array_replace_value($_POST['specialisation'], "other", $_POST['otherSpeci']);
		$specialisation = implode("|",$specO);
		$insert_spec = "insert into `specialisation` set `specialisation` = '".$_POST['otherSpeci']."' "; 
		mysqli_query($conn,$insert_spec) or die(mysqli_error());
	}
	
	
	$update = "update `doctor_registration` set  
		`name` = '".$_POST['name']."',  
		`gender` = '".$_POST['gender']."', 
		`qualification` = '".$qualification."', 
		`date_birth` = '".$_POST['date_birth']."',  
		`specialisation` = '".$specialisation."',
		`registration_no` = '".$_POST['registration_no']."',
		`registration_auth` = '".$_POST['registration_auth']."',
		`expertise_in` = '".$_POST['expertise_in']."',
		`fees` = '".$_POST['fees']."',
		`summary` = '".$_POST['summary']."',
		`total_experience` = '".$_POST['total_experience']."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:/doctor-profile#general");
}


if(isset($_POST['update_contact'])){
	$update = "update `doctor_registration` set  
		`phone_no` = '".$_POST['PcountryCode']."-".$_POST['stdCode']."-".$_POST['phoneNo']."',
		`other_phone` = '".$_POST['other_phone']."-".$_POST['Other_stdCode']."-".$_POST['Other_phoneNo']."', 
		`fax_no` = '".$_POST['fax_no']."-".$_POST['fax_stdCode']."-".$_POST['fax_phoneNo']."', 
		`mobile_no` = '".$_POST['countryCode']."-".$_POST['mobileNo']."',  
		`address` = '".$_POST['address']."', 
		`country` = '".$_POST['country']."', 
		`otherEmail` = '".$_POST['otherEmail']."',  
		`state` = '".$_POST['state']."',  
		`city` = '".$_POST['city']."',
		`district` = '".$_POST['district']."',
		`zipe_code` = '".$_POST['zipe_code']."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:/doctor-profile#contact");
}

if(isset($_POST['update_personalDetails'])){
	$update = "update `doctor_registration` set  
		`personalPhone` = '".$_POST['other_phone']."-".$_POST['Other_stdCode']."-".$_POST['personalPhone']."',
		`personalMobile` = '".$_POST['countryCode']."-".$_POST['personalMobile']."',		 
		`personalEmail` = '".$_POST['personalEmail']."',  
		`personalUrl` = '".$_POST['personalUrl']."', 
		`personalAddress` = '".$_POST['personalAddress']."',
		`update_date` = '".$current_date."'
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());		
		header("location:/doctor-profile#personal");
}

if(isset($_POST['update_pp'])){
	// echo "hello";
	// die();
	/*if(!empty($_FILES['photo']['name'])){
		$img = fileUpload("images/profile/", $_FILES['photo'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $img= $_POST['oldfile'];
	}*/
	if(!empty($_FILES['image']['name'])){
	// Get the file information
    $fileName   = rand().basename($_FILES["image"]["name"]);
    $fileTmp    = $_FILES["image"]["tmp_name"];
    $fileType   = $_FILES["image"]["type"];
    $fileSize   = $_FILES["image"]["size"];
    $fileExt    = substr($fileName, strrpos($fileName, ".") + 1);
    
    // Specify the images upload path
    $largeImageLoc = 'images/profile/fullprofileimage/'.$fileName;
    $thumbImageLoc = 'images/profile/'.$fileName;

    // Check and validate file extension
    if((!empty($_FILES["image"])) && ($_FILES["image"]["error"] == 0)){
        if($fileExt != "jpg" && $fileExt != "jpeg" && $fileExt != "png" && $fileExt != "gif"){
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }
    }else{
        $error = "Select an image file to upload.";
    }

    // If everything is ok, try to upload file
    if(empty($error) && !empty($fileName)){
        if(move_uploaded_file($fileTmp, $largeImageLoc)){
            // File permission
            chmod($largeImageLoc, 0777);
            
            // Get dimensions of the original image
            list($width_org, $height_org) = getimagesize($largeImageLoc);
            
            // Get image coordinates
            $x = (int) $_POST['x'];
            $y = (int) $_POST['y'];
            $width = (int) $_POST['w'];
            $height = (int) $_POST['h'];

            // Define the size of the cropped image
            $width_new = $width;
            $height_new = $height;
            
            // Create new true color image
            $newImage = imagecreatetruecolor($width_new, $height_new);
            
            // Create new image from file
            switch($fileType) {
                case "image/gif":
                    $source = imagecreatefromgif($largeImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    $source = imagecreatefromjpeg($largeImageLoc); 
                    break;
                case "image/png":
                case "image/x-png":
                    $source = imagecreatefrompng($largeImageLoc); 
                    break;
            }
            
            // Copy and resize part of the image
            imagecopyresampled($newImage, $source, 0, 0, $x, $y, $width_new, $height_new, $width, $height);
            
            // Output image to file
            switch($fileType) {
                case "image/gif":
                    imagegif($newImage, $thumbImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    imagejpeg($newImage, $thumbImageLoc, 90); 
                    break;
                case "image/png":
                case "image/x-png":
                    imagepng($newImage, $thumbImageLoc);  
                    break;
            }
            
            // Destroy image
            imagedestroy($newImage);
		unlink("images/profile/".$_POST['oldfile']);
		unlink("images/profile/fullprofileimage/".$_POST['oldfile']);
    }
	}
	}
	$update = "update `doctor_registration` set  
		`pro_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:doctor-profile.php");
}
if(isset($_POST['update_pps'])){	
	if(!empty($_FILES['image']['name'])){
		$fileName = fileUpload("images/profile/", $_FILES['image'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $fileName= $_POST['oldfile'];
	}
	
	$update = "update `doctor_registration` set  
		`pro_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:/doctor-profile/");
}

if(isset($_POST['update_tp'])){
	//echo "hello";
	 //die();
	/*if(!empty($_FILES['photo']['name'])){
		$img = fileUpload("images/profile/", $_FILES['photo'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $img= $_POST['oldfile'];
	}*/
	if(!empty($_FILES['image']['name'])){
	// Get the file information
    $fileName   = rand().basename($_FILES["image"]["name"]);
    $fileTmp    = $_FILES["image"]["tmp_name"];
    $fileType   = $_FILES["image"]["type"];
    $fileSize   = $_FILES["image"]["size"];
    $fileExt    = substr($fileName, strrpos($fileName, ".") + 1);
    
    // Specify the images upload path
    $largeImageLoc = 'images/timeline/'.$fileName;
    $thumbImageLoc = 'images/timeline/'.$fileName;

    // Check and validate file extension
    if((!empty($_FILES["image"])) && ($_FILES["image"]["error"] == 0)){
        if($fileExt != "jpg" && $fileExt != "jpeg" && $fileExt != "png" && $fileExt != "gif"){
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }
    }else{
        $error = "Select an image file to upload.";
    }

    // If everything is ok, try to upload file
    if(empty($error) && !empty($fileName)){
        if(move_uploaded_file($fileTmp, $largeImageLoc)){
            // File permission
            chmod($largeImageLoc, 0777);
            
            // Get dimensions of the original image
            list($width_org, $height_org) = getimagesize($largeImageLoc);
            
            // Get image coordinates
            $x = (int) $_POST['x'];
            $y = (int) $_POST['y'];
            $width = (int) $_POST['w'];
            $height = (int) $_POST['h'];

            // Define the size of the cropped image
            $width_new = $width;
            $height_new = $height;
            
            // Create new true color image
            $newImage = imagecreatetruecolor($width_new, $height_new);
            
            // Create new image from file
            switch($fileType) {
                case "image/gif":
                    $source = imagecreatefromgif($largeImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    $source = imagecreatefromjpeg($largeImageLoc); 
                    break;
                case "image/png":
                case "image/x-png":
                    $source = imagecreatefrompng($largeImageLoc); 
                    break;
            }
            
            // Copy and resize part of the image
            imagecopyresampled($newImage, $source, 0, 0, $x, $y, $width_new, $height_new, $width, $height);
            
            // Output image to file
            switch($fileType) {
                case "image/gif":
                    imagegif($newImage, $thumbImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    imagejpeg($newImage, $thumbImageLoc, 90); 
                    break;
                case "image/png":
                case "image/x-png":
                    imagepng($newImage, $thumbImageLoc);  
                    break;
            }
            
            // Destroy image
            imagedestroy($newImage);
		unlink("images/timeline/".$_POST['oldfile']);
		unlink("images/timeline/".$_POST['oldfile']);
    }
	}
	}
	$update = "update `doctor_registration` set  
		`timeline_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:doctor-profile.php");
}


if(isset($_POST['update_tps'])){
	
	list($width, $height, $type) = getimagesize($_FILES["image"]['tmp_name']);
	
	if($width >= 1920 && $height <= 400){
	if(!empty($_FILES['image']['name']))
	{
		$img = fileUploadss("images/timeline/", $_FILES['image'], "jpg|png|jpeg", true);
		if(!empty($img))
		{
			unlink("images/timeline/".$_POST['oldfile']);
		}
	}
		else 
		{
			 $img= $_POST['oldfile'];
		}	
		
	
	
		$update = "update `doctor_registration` set  
		`timeline_img` = '".$img."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		"; 
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:/doctor-profile");    
}
	else 
	{
		
	echo '<script>
			
				alert("Image upload should be 1920px!");
			
		</script>';
		
	} 

		


	
}
 














if(isset($_POST['update_tpss'])){



list($width, $height, $type) = getimagesize($_FILES["mobile_banner_image"]['tmp_name']);

	if($width >= 400 && $height <= 200){
	if(!empty($_FILES['mobile_banner_image']['name']))
	{
		$imgs = fileUploadss("images/timeline/", $_FILES['mobile_banner_image'], "jpg|png|jpeg", true);
		if(!empty($imgs))
		{
			unlink("images/timeline/".$_POST['oldfiles']);
		}
	}
		else 
		{
			 $imgs= $_POST['oldfiles'];
		}	
		
	
	
		$update = "update `doctor_registration` set  
		`mobile_banner_image` = '".$imgs."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		"; 
		//echo $update;
		//echo "hello";die;
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:/doctor-profile");    
}
	else 
	{
		
	echo '<script>
			
				alert("Image upload should be 400px!");
			
		</script>';
		
	} 
} 
if((isset($_POST['update_pro_exp']) || isset($_POST['update_pro_exp_edit'])) && $_POST['hospital_id']!=""){
		
		//insert hospital
		if ($_POST['hospital_id']=="other") {
		
			$query_hos = "INSERT INTO medical_registration SET 
			 
					
					name = '".$_POST['hospital_c_name']."' ,
					address = '".$_POST['address']."',
					city = '".$_POST['city']."',
					state = '".$_POST['state']."',
					country = '".$_POST['country']."',
					active = 'no',
					insert_date = '".date("Y-m-d H:i:s")."',
					timestamp = '".date("Y-m-d H:i:s")."'";
				
			
			$add_hos = mysqli_query($conn,$query_hos); 
		
	
		$hosid = mysqli_insert_id($conn); 
		$query="insert into prof_exp_doc SET";
			$query.="
		`doctor_id` = '".$_SESSION['userId']."', 
		`hospital_id` = '".$hosid."', 
		`designation` = '".$_POST['designation']."',
		`address` = '".$_POST['address']."', 
		`hospital_c_name` = '".$_POST['hospital_c_name']."',  
		`country` = '".$_POST['country']."',  
		`state` = '".$_POST['state']."',  
		`city` = '".$_POST['city']."',    
		`from_date` = '".$_POST['from_date']."', 
		`to_date` = '".$_POST['to_date']."'"; 
	
mysqli_query($conn,$query) or die(mysqli_error());
			
			
			
			
			
		}else{
		
		if (isset($_POST['update_pro_exp_edit'])) { 
			$query="UPDATE prof_exp_doc SET ";
		} else {
			$query="insert into prof_exp_doc SET ";
		}	
			
		$query.="
		`doctor_id` = '".$_SESSION['userId']."', 
		`hospital_id` = '".$_POST['hospital_id']."', 
		`designation` = '".$_POST['designation']."',
		`address` = '".$_POST['address']."', 
		`hospital_c_name` = '".$_POST['hospital_c_name']."',  
		`country` = '".$_POST['country']."',  
		`state` = '".$_POST['state']."',  
		`city` = '".$_POST['city']."',    
		`from_date` = '".$_POST['from_date']."', 
		`to_date` = '".$_POST['to_date']."'"; 
		
		if (isset($_POST['update_pro_exp_edit'])) {
			
			$query.=" WHERE `id` = '".$_POST['proId']."' and `doctor_id` = '".$_SESSION['userId']."'";
		}
	
		mysqli_query($conn,$query) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:/doctor-profile#pexp");
   }
}

/*
if(isset($_POST['update_pro_exp_edit1'])){
		$query="update prof_exp_doc set 
		`hospital_c_name` = '".$_POST['hospital_c_name']."', 
		`designation` = '".$_POST['designation']."', 
		`from_date` = '".$_POST['from_date']."', 
		`to_date` = '".$_POST['to_date']."', 
		`address` = '".$_POST['address']."-|-".$_POST['country']."-|-".$_POST['state']."-|-".$_POST['city']."-|-".$_POST['zip']. "'
		where `id` = '".$_POST['proId']."' and `doctor_id` = '".$_SESSION['userId']."'
		";
		mysqli_query($query) or die(mysqli_error());
		$update_query = mysqli_query("update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:doctor-profile.php?openTab=experienceTab");
}

*/
if((isset($_POST['add_current_hospital']) || isset($_POST['update_current'])) && $_POST['hospital_id']!=""){
	
	
	//insert hospital
	if ($_POST['hospital_id']=="other") {
		
		$query_hos = "INSERT INTO medical_registration SET 
				
				name = '".$_POST['hospital_c_name']."' ,
				address = '".$_POST['address']."',
				city = '".$_POST['city']."',
				state = '".$_POST['state']."',
				country = '".$_POST['country']."',
				active = 'no',
				insert_date = '".date("Y-m-d H:i:s")."',
				timestamp = '".date("Y-m-d H:i:s")."'";
		
	
		
	$add_hos = mysqli_query($conn,$query_hos); 
		
	
		$hosid = mysqli_insert_id($conn); 
		$query="INSERT INTO current_hospital SET `doc_id` = '".$_SESSION['userId']."',`hospital_id` = '".$hosid."', ";

	
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
	
	$query.="`level` = '".$_POST['level']."', 
	`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
	`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
	`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
	`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
	`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
	`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
	`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
	`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
	`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
	`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
	`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
	`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
	`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
	`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."'";
	
mysqli_query($conn,$query) or die(mysqli_error());
		
	}else{
	
	
	if (isset($_POST['update_current'])) {
		$query="UPDATE current_hospital SET ";
	} else {
		$query="INSERT INTO current_hospital SET ";
	}

	
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
		
		
		
	$query.=" 
	`doc_id` = '".$_SESSION['userId']."',
	`hospital_id` = '".$_POST['hospital_id']."', 
	`level` = '".$_POST['level']."', 
	`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
	`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
	`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
	`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
	`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
	`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
	`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
	`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
	`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
	`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
	`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
	`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
	`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
	`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."'";
	
	
	if (isset($_POST['update_current'])) {
			
		$query.=" WHERE `id` = '".$_POST['curId']."' AND `doc_id` = '".$_SESSION['userId']."'";
	}
		
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/doctor-profile#chospital");
}

}

/*
if(isset($_POST['update_current'])){
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
		$query="update current_hospital set 
		`hospital_name` = '".$_POST['hospital_name']."', 
		`level` = '".$_POST['level']."', 
		`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
		`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
		`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
		`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
		`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
		`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
		`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
		`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
		`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
		`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
		`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
		`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
		`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
		`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."', 
		`address` = '".$_POST['address']."-|-".$_POST['country']."-|-".$_POST['state']."-|-".$_POST['city']."-|-".$_POST['zip']. "'
		 where `id` = '".$_POST['curId']."' and `doc_id` = '".$_SESSION['userId']."'
		";
		mysqli_query($query) or die(mysqli_error());
		$update_query = mysqli_query("update doctor_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."'");
		header("location:doctor-profile.php?openTab=hospitalTab");
}
*/


//Specialisation List
$resHD = mysqli_query($conn,"SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}

//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$qualifications[$data['id']] = utf8_encode($data['qualification']); 
		$c++;
	}		
}

?>
<style>
.error{color:red;}
</style>
<?
	$resDD = fetchData(' `doctor_registration` ', " where id='".$_SESSION['userId']."' ");
	$docid = $resDD['user_id'];
	$res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $docid . "' and rateusertype='doctor'");
?>

<div class="container">
	<div class="drmf-main-banner-top col-md-12">
		<div class="row">
		<a href="/profile-edit-pages/timeline_pic.php" class="ajax" title="Click to Change Image">
		<? if ($resDD['timeline_img'] != "") { ?>
					<img src="/images/timeline/<?= $resDD['timeline_img'] ?>" /><? 
				} else { ?>
					<img src="../images/home-icons/doctor-banner.jpg">
		<? } ?>
		</a>

	
		
		</div>
	</div>
	<div class="col-md-12 drmf-main-section1">
		<div class="row">
			<div class="col-md-3 single-showimg-left">
				<? if ($resDD['pro_img'] != "") { ?>
				<a href="/profile-edit-pages/profile-pic.php" class="ajax1"><img src="/images/profile/<?= $resDD['pro_img'] ?>" /></a><? 
				} else { ?>
					<a href="/profile-edit-pages/profile-pic.php" class="ajax1"><img src="/images/default.jpg" /></a>
				<? } ?>
			</div>
			<div class="col-md-9">
				<h1><?= $resDD['name']; ?></h1>
				<div class="rating-container rating-xs rating-animate col-sm-12">
				 <?  $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$count = $i;
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
							?>
					<a style="" href="#review-down">
						<div class="rating">
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						</div>
					</a>
				</div>
				<div class="drmf-main-describe col-sm-12">
					<p class="drmf-110"><span class="text-center"><?= $resDD['total_experience'] ?></span></p>
		             <p class="drmf-111">
		<?
		$specialisation = explode("|", $resDD['specialisation']);
		foreach ($specialisation as $spl) {
		 echo $specialisations[$spl];
		}
			
		?></p>
				</div>
				<? if($resDD['summary'] == ''){ }else{?>
				<div class="col-sm-12">
					<p><?php echo $resDD['summary']; ?></p>
				</div>
				<?php } ?>
				<div class="col-sm-12">
				<?php 
					$User_email = $_SESSION['userEmail'];
					$copval = fetchData(" `rewards` ", " where user_email= '" . $User_email . "' ");
					$cval = $copval['coupon_point'];
					$rval = $copval['register_point'];
					$refval = $copval['reference_point'];
					$revval = $copval['review_point'];
					$cnew = $cval + $rval + $revval;
					
				?>	
				<style>
					.reward-point button {
						margin-left: 18px;
					}
				</style>
				<div class="reward-point">
						<b>Total Points:</b> <?php echo $cnew;?> 
						<button type="submit" id="redeemshow" class="btn btn-primary" >Redeem Points</button>
				</div>
				<div class="ref-url">
				<span id="nbref-url">Reference URL:<a href="<?php echo $refval;?>"> <?php echo $refval;?></a></span>
				           
							
				</div>	
				<?php if($cnew >=100){ ?>
				   <div class="redeemss" style="display:none">
			    <div style="width:30%;">
				<form method="post" action="">
					<div class="form-group">
						<input type="text" class="form-control" name="upiid" placeholder="Enter Your UPI ID" required>
					</div>
					
										
					<div class="form-group">
						<button type="submit" name="submitRedeem" class="btn btn-primary">submit</button>
					</div>
				</form>					
			</div>
          </div>
				<? }
				?>
					
					
					
				
					
					
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-12" id="info-detail-single-p">
		<span id="general"></span>
		<h2>General Information <span class="eright"><a href="/profile-edit-pages/doctor-genral.php" class="ajax" ><i class="far fa-edit"></i></a></span></h2>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Name</b></p>
					<p><?=$resDD['name'];?></p>
				</div>
			</div>
		</div>
		
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-users"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Gender</b></p>
					<p><?= $resDD['gender'] ?></p>
				</div>
			</div>
		</div>
		
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-bell"></i>
				</div>
				<div class="show-main-p1">
					<p><b>DOB</b></p>
					<p><?=$resDD['date_birth']?></p>
				</div>
			</div>
		</div>
		
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-award"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Total Experience</b></p>
					<p><?= $resDD['total_experience'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-graduate"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Qualification</b></p>
					<p>
						<?php $qualification = explode("|", $resDD['qualification']); ?>
						<?
							foreach ($qualification as $quali)
							{
								$qualiOther = explode(":", $quali);
								if ($qualiOther[0] == "Other")
								{
									echo $qualiOther[1] . "<br/>";
								}
								else
								{
									echo $qualifications[$quali] . "&nbsp;&nbsp;";
								}
							}
						?>
					</p>
				</div>
			</div>
		</div>


		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-address-card"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration Authority</b></p>
					<p><?= $resDD['registration_auth'] ?></p>
				</div>
			</div>
		</div>


		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-info-circle"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration No.</b></p>
					<p><?= $resDD['registration_no'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Expertise in</b></p>
					<p><?= $resDD['expertise_in'] ?></p>
				</div>
			</div>
		</div>
		
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-dollar"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Fees </b></p>
					<p><?= $resDD['fees'] ?></p>
				</div>
			</div>
		</div>

	</div>
	<div class="col-md-12 info-specialise" id="info-detail-single-p">
		<p class="sp-li-title">Specialisations</p>
	
		<?
		$specialisation = explode("|", $resDD['specialisation']);
		foreach ($specialisation as $spl) {
		?>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Specialisation</b></p>
					<p><?php echo $specialisations[$spl]; ?></p>
				</div>
			</div>
		</div>
		<?php 
		}	
		?>
	</div>

	<div class="col-md-12" id="info-detail-single-p">
	<span id="contact"></span>
		<h3>Contact Information <span class="eright"><a href="/profile-edit-pages/ContactV2Doctor.php?<?=rand(999999,99999999)?>" class="ajax" ><i class="far fa-edit"></i></a></span></h3>
		<?php if($resDD['phone_no'] == '91--') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
				<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Phone No</b></p>
					<p><?= $resDD['phone_no'] ?></p>
				</div>
			</div>
		</div>
		<?php } ?>
		<?php if($resDD['mobile_no'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p><?= $resDD['mobile_no'] ?></p>
				</div>
			</div>
		</div>
        <?php } ?>
		
		<?php if($resDD['otherEmail'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-envelope"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Email</b></p>
					<p><a href="mailto:<?=$resDD['otherEmail']?>"><?=$resDD['otherEmail']?></a></p>
				</div>
			</div>
		</div>
        <?php } ?>
		
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-home"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Address</b></p>
					<p><?= $resDD['address'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-flag"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Country</b></p>
					<? $country = fetchData("`countries`"," where id = '".$resDD['country']."' "); ?>
					<p><?=$country['name']?></p>
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-map-marker-alt"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Zip Code</b></p>
					<p><?=$resDD['zipe_code']?></p>
				</div>
			</div>
		</div>

	</div>
	
	<div class="col-md-12" id="info-detail-single-p">
	<span id="personal"></span>
		<h3>Personal Information <span class="eright"><a href="/profile-edit-pages/doctor-personal-details.php" class="ajax" ><i class="far fa-edit"></i></a></span></h3>
		<?php if($resDD['personalAddress'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
				<i class="fas fa-home"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Residence Address</b></p>
					<p><?=$resDD['personalAddress']?></p>
				</div>
			</div>
		</div>
		<?php } ?>
		<?php if($resDD['personalPhone'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Resi. Ph. No.</b></p>
					<p>+<?=$resDD['personalPhone']?></p>
				</div>
			</div>
		</div>
        <?php } ?>
		
		<?php if($resDD['personalMobile'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p>+<?=$resDD['personalMobile']?></p>
				</div>
			</div>
		</div>
        <?php } ?>
		
		<?php if($resDD['personalEmail'] == '') {}else{ ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-envelope"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Email</b></p>
					<p><a href="mailto:<?=$resDD['personalEmail']?>"><?=$resDD['personalEmail']?></a></p>
				</div>
			</div>
		</div>
        <?php } ?>
		
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-globe-asia"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Website Address</b></p>
					<p><a href="<?=$resDD['personalUrl']?>"><?=$resDD['personalUrl']?></a></p>
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-12 experin-detail-p" id="main-table-sty">
	<span id="chospital"></span>
	<h4>Current Hospital<span><a href="/profile-edit-pages/doctor-edit-current-hospital.php" class="ajax" ><i class="fa fa-plus"></i></a></span></h4>
		   
	<? $resCH = fetchAllData(" `current_hospital` ", " where doc_id = '" . $resDD['id'] . "' ");  ?> 
	 
		<div class="col-md-12 show1" id="show2">
			<table class="table">
		
			<tbody>
			<?php foreach ($resCH  as $CH) {
				
           $hospital = fetchData(" `medical_registration`", " where id = '" . $CH['hospital_id'] . "'"); 
            ?>
				<tr>
				<td><?= $CH['level']; ?></td>
					<td>
					<?= $hospital['name'] ?>
					&nbsp;-<a class="ajax" href="/profile-edit-pages/doctor-edit-current-hospital.php?id=<?=$CH['id']?>&edit=1"> <i class="glyphicon glyphicon-edit"></i></a>&nbsp;
					
					<a href="#" onclick="deleteCH('<?=$CH['id']?>')"> <i class="glyphicon glyphicon-remove-sign"></i></a>
					</td>
					
				</tr>
			<?php } ?>
			</tbody>
		</table>
		</div>
  </div>
   <? $resDPI = fetchAllData(" `prof_exp_doc` ", " where doctor_id = '".$resDD['id']."' "); ?>
   <div class="col-md-12 experin-detail-p" id="main-table-sty">
   <span id="pexp"></span>
		<h4>Past Experience <span><a href="/profile-edit-pages/doctor-add-professional-experience.php" class="ajax" ><i class="fa fa-plus"></i></a></span></h4>
		<div class="col-md-12 show1" id="show2">
			<table class="table">
			<tbody>
				<tr>
				<? foreach($resDPI  as $DPI) 
					{
					$hospital = fetchData(" `medical_registration`", " where id = '".$DPI['hospital_id']."'");
					?>
					<td><?=$DPI['designation']?> (<?=$DPI['from_date']?> - <?=$DPI['to_date']?>)</td>
					<td>
						<? if($DPI['hospital_c_name'] == '')
						{
							echo $hospital['name'];	
						}
						else
						{ 				
							echo $DPI['hospital_c_name']; 
						}
						?> 
						&nbsp;-<a class="ajax" href="/profile-edit-pages/doctor-add-professional-experience.php?id=<?=$DPI['id']?>&edit=1"> <i class="glyphicon glyphicon-edit"></i></a> &nbsp;
						
						<a href="#" onclick="deleteExp('<?=$DPI['id']?>')"> <i class="glyphicon glyphicon-remove-sign"></i></a>
					</td>
					<?}?> 	
				</tr>
			</tbody>
		</table>
		</div>
   </div>
   
   <div class="tab-pane" id="change_password">
		<h3 class="title">Change Password</h3>
			<div style="width:100%;">
				<form method="post" action="change_password">
					<div class="form-group">
						<label for="exampleInputPassword1">Old Password</label>
						<input type="password" class="form-control" id="Old_Password" placeholder="Old Password" required>
						<input type="hidden" id="Opass" value="<?=$resDD['password']?>">
						<span class="error" id="error_oldpass"></span>
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">New Password</label>
						<input type="password" class="form-control" id="New_Password" placeholder="New Password"  required>
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Repeat Password</label>
						<input type="password" class="form-control" name="password" id="Repeat_Password" placeholder="Repeat Password" required>
						<span class="error" id="error_repeatpass"></span>
					</div>
										
					<div class="form-group">
						<button type="submit" onclick="return changepass()" class="btn btn-primary">Change Password</button>
					</div>
				</form>					
			</div>
	 </div>
   
   
   
   <div class="tab-pane" id="change_password">
   <h3 class="title">Image Gallery</h3>
   <div style="width:100%;">
   <form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="image_gallery[]" multiple>
	<input type="hidden" name="oldfiless">
    <input type="submit" value="Upload Now" name="image_gallerys">
</form>
   
				
	</div>
	 </div>
	 
	 
	 <div class="col-md-12 align-center text-sm review-slider" id="recommend-deals-1">

			<?php
			$image = $resDD['image_gallery'];
		    $imagess= explode('|',$image);
			//print_r($imagess);
			//echo " `doctor_registration` ", "WHERE city = 1119 AND active='Yes' ORDER BY last_login LIMIT 0,10";die;
			foreach ($imagess as $galleryss) {
			?>
				<div class="item col-md-3 text-left">
					
						<img src="/images/gallery/<?= $galleryss; ?>">
					
				</div>

			<?php
			}
			?>

		</div>

   <div class="drmf-main-banner-top col-md-12">
		<div class="row">
		<a href="/profile-edit-pages/bannermobile_timeline_pic.php" class="ajax" title="Click to Change Image">
		<? if ($resDD['mobile_banner_image'] != "") { ?>
					<img src="/images/timeline/<?= $resDD['mobile_banner_image'] ?>" /><? 
				} else { ?>
					<img src="../images/home-icons/doctor-banner.jpg">
		<? } ?>
		</a>

	
		
		</div>
	</div>
   
   
   
   
   
   <div class="col-md-12 main-work-sl-p deal-single-p">
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-deal.php">Manage Deals</a></h4>
      </div>
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-blog.php">Manage Blog</a></h4>
      </div>
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-ads.php">Manage Advertisment</a></h4>
		<div class="col-md-4 text-left">
		<h4><a href="/manage-appointments.php">Manage Appointments</a></h4>
      </div>
      </div>
    </div>
   
	<div class="col-md-12">
		<div class="single-p-review" id="review-down">
			<div class="col-md-6">
				<div class="single-set-rating text-center">
					<p class="p-rate-1"><b>Overall Rating</b></p>
                  <div class="rating-container rating-xs rating-animate col-sm-12">
					<div class="single-p-rating rating">
				
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						
					</div>
					</div>
					<p class="p-rate-2">Based on <?php echo $count; ?> Experiences</p>
				</div>
			</div>
			<div class="col-md-6">
				<div class="single-set-rating2 text-center">
					<p class="p-rate-1"><b>Rate your experience</b></p>
					<p class="p-rate-2">How likely are you to recommend us?</p>
					<div class="single-p-rating1">
					<a style="" href="/rating/<?= $docid ?>">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="col-md-12 tab-pane" id="comments">
	<div class="col-md-12 news-single-p">
	<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h6>Comments</h6>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
					
					</div>
				</div>
			</div>
	</div>
	<? include('review.php'); ?>

	</div>
	</div>						
</div>
  <script>
      $(document).ready(function(){
          setTimeout(function() {
              <?php
              if( $_GET['status'] == 'success') {
                  echo 'alert("Coupan Redeem Successfully");';
              }
			  else{
}
              ?>
              });
      });
  </script>
<script>
$(document).ready(function () {
    $("#redeemshow").click(function(){
         $(".redeemss").show();
    });

});
</script>
<script>
  $(document).ready(function(){
  $("#nbref-url").click(function(){
    document.location.href = "https://dev.freemedicalinfo.in/register.php";
  });
  $('#nbref-url').css( 'cursor', 'pointer' );
});
</script>
<script>
	function deleteExp(id){
		if(confirm("Are you sure delete this")){
			window.location = "/doctor-profile.php?id="+id+"&del=ProExp";
		}
	}
	function deleteCH(id){
		if(confirm("Are you sure delete this")){
			window.location = "/doctor-profile.php?id="+id+"&del=CH";
		}
	}
	function changepass(){
		var curentpass = document.getElementById('Opass').value;
		var Oldpass = document.getElementById('Old_Password').value;
		var newpass = document.getElementById('New_Password').value;
		var repass = document.getElementById('Repeat_Password').value;
		if(Oldpass==""){
			var msg1="Please type Old Password!";
			document.getElementById('error_oldpass').innerHTML=msg1;
			return false;
		}
		if(curentpass!=Oldpass){
			var msg="You have type wrong password!";
			document.getElementById('error_oldpass').innerHTML=msg;
			return false;
		}	
		if(newpass!=repass){
			var msg2="New Password and Repeat Password did not match!";
			document.getElementById('error_repeatpass').innerHTML=msg2;
			return false;
		}		
		
		
	}	
	
jssor_2_slider_init();
</script>
<? include('include/footer.php'); ?>
 <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
 <script type="text/javascript" src="/js/script.js"></script>
 <script>
	$('.review-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 6000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1220,
				settings: {
					slidesToShow: 3,
				},
			},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>



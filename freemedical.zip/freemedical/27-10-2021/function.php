<?php 
define("MAX_SIZE", "9999999999");
function db () {
    static $conn;
    if ($conn===NULL){ 
        $conn = mysqli_connect("localhost","freeemed_sisdev","MWA13Bw6t)PB","freeemed_sisdev");
    }
    return $conn;
}

/**
 * trims text to a space then adds ellipses if desired
 * @param string $input text to trim
 * @param int $length in characters to trim to
 * @param bool $ellipses if ellipses (...) are to be added
 * @param bool $strip_html if html tags are to be stripped
 * @return string 
 */
function trim_text($input, $length, $ellipses = true, $strip_html = true) {
    //strip tags, if desired
    if ($strip_html) {
        $input = strip_tags($input);
    }
  
    //no need to trim, already shorter than trim length
    if (strlen($input) <= $length) {
        return $input;
    }
  
    //find last space within length
    $last_space = strrpos(substr($input, 0, $length), ' ');
    $trimmed_text = substr($input, 0, $last_space);
  
    //add ellipses (...)
    if ($ellipses) {
        $trimmed_text .= '...';
    }
  
    return $trimmed_text;
}

function getExtension($str)
	{
	$i = strrpos($str, ".");
	if (!$i)
		{
		return "";
		}

	$l = strlen($str) - $i;
	$ext = substr($str, $i + 1, $l);
	return $ext;
	}

function fileUpload($path, $file, $ext, $uniname)
	{
	$_FILES['file'] = $file;
	$filename = stripslashes($_FILES['file']['name']);
	$extension = getExtension($filename);
	$extension = strtolower($extension);
	$exte = explode("|", $ext);
	
	if (in_array($extension, $exte))
		{
		$size = filesize($_FILES['file']['tmp_name']);
		if ($size > MAX_SIZE * 1024)
			{
			echo "<script>alert('File is big in size');</script>";
			$errors = 1;
			}

		if ($uniname == "true")
			{
			$image_name = time() . "-" . str_replace(" ", "-", $_FILES['file']['name']);
			}
		  else
			{
			$image_name = $_FILES['file']['name'];
			}

		$newname = $path . $image_name;
		$copied = copy($_FILES['file']['tmp_name'], $newname);
		if (!$copied)
			{
			echo "<script>alert('File not Copied');</script>";
			$errors = 1;
			}
		}
	  else
		{
		echo "<script>alert('Not Vailid Extension, File not Uploaded..!');</script>";
		$errors = 1;
		}

	if ($errors == 1)
		{
		return false;
		}
	  else
		{
		return @$image_name;
		}
	}
function removeDir($path, $dir_name)
	{
	$files = glob($path . $dir_name . '/*');
	foreach($files as $file)
		{
		if (is_file($file)) unlink($file);
		}

	rmdir($path . $dir_name);
	}

function delRow($table_from, $where_condition)
	{
	$conn = db();	
	$del = "delete from " . $table_from . " " . $where_condition;
	mysqli_query($conn,$del);
	return @$del;
	}

function selRow($table_from, $where_condition)
	{
	$conn = db();
	$sel = "select * from " . $table_from . " " . $where_condition;
	$que_sel = mysqli_query($conn,$sel);
	return @$que_sel;
	}

function countRow($table_from, $where_condition)
	{
	$conn = db();
	$sel = "select * from " . $table_from . " " . $where_condition;
	$que_sel = mysqli_query($conn,$sel);
	$res = mysqli_num_rows($que_sel);
	return @$res;
	}
	

function doctor_detail($table_from, $where_condition)
{
	$conn=db();
	$query="select specialisation, city from " . $table_from ." " . $where_condition;
	
	$que_sel = mysqli_query($conn,$query);
	$res = mysqli_fetch_array($que_sel);
	return @$res;
}


function hospital_detail($table_from, $where_condition)
{
	$conn=db();
	$query="select specialisation, city from " . $table_from ." " . $where_condition;
	
	$que_sel = mysqli_query($conn,$query);
	$res = mysqli_fetch_array($que_sel);
	return @$res;
}

function fetchData($table_from, $where_condition)
	{
	$conn = db();
	$sel = "select * from " . $table_from . " " . $where_condition;
	$que_sel = mysqli_query($conn,$sel);
	$res = mysqli_fetch_array($que_sel);
	return @$res;
	}

function fetchAllData($table_from,$where_condition)
	{
	$conn = db();
	$sel = "select * from " . $table_from . " " . $where_condition;
	$que_sel = mysqli_query($conn,$sel);
	while ($res = mysqli_fetch_array($que_sel))
		{
		$data[] = $res;
		}

	return @$data;
	}
	
	
	function fetchAllDatas($table_from)
	{
	$conn = db();
	$sel = "select * from " . $table_from;
	$que_sel = mysqli_query($conn,$sel);
	while ($res = mysqli_fetch_array($que_sel))
		{
		$data[] = $res;
		}

	return @$data;
	}

function fetchAllDataWithPagination($table_from, $where_condition, $itemPerPage, $link)
	{
	 $conn = db();   
	include ('pagination.php');
    
	$sel = "select * from " . $table_from . " " . $where_condition;
	$que_sel = mysqli_query($conn, getPagingQuery($sel, $itemPerPage));
	while ($res = mysqli_fetch_array($que_sel))
		{
		$data[] = $res;
		}

	$Plink = getPagingLink($sel, $itemPerPage, $link);
	$dataWithLink[0] = $data;
	$dataWithLink[1] = $Plink;
	return @$dataWithLink;
	}

if (isset($_GET['request']))
	{
	$address = $_GET['address'];
	$name = $_GET['name'];
	if ($address != "" && $name != "")
		{
		$un = unlink($_SERVER['DOCUMENT_ROOT'] . $address . $name);
		}
	}



function insert_keyword ($keyword , $parent_id = 0) {
	$conn = db();
	if ($keyword){
		
		$insert_keyword = mysqli_query($conn,"INSERT INTO keywords SET keyword='$keyword' , parent_id = '$parent_id' ");
		if (mysqli_affected_rows()>0) {
			
			$id = mysqli_insert_id();
		
		} else {
			
			$id = find_keyword($keyword);
		}
		
	} else {
	
		$id = false;
	
	}
	
	
	return $id;
}

function find_keyword($keyword) {
	$conn = db();
	if ($keyword) {
		$select_keyword = mysqli_query($conn,"SELECT * FROM keywords WHERE keyword='$keyword'");
		if (mysqli_num_rows($select_keyword)>0) {
			$myfa = mysqli_fetch_assoc($select_keyword);
			
			if ($myfa['parent_id']>0) {
				
				$id['id'] = $myfa['id'];
				$id['parent_id'] = $myfa['parent_id']; 	
			} else {
				$id = $myfa['id'];	
			}
			
		} else {
			$id = false;
		}
	}
	return $id;
}

function find_keyword_children($keyword_id) {
	$conn = db();
	if ($keyword_id) {
	
		$select_keyword = mysqli_query($conn,"SELECT * FROM keywords WHERE parent_id='$keyword_id'");
		if (mysqli_num_rows($select_keyword)>0) {
			
			while($myfa = mysqli_fetch_assoc($select_keyword)) {
				$ids[] = $myfa['id'];
			}
			
		} else {
			
			$ids = array();
		
		}
	}
	return $ids;
}

function find_in_keywords($word) {
	$conn = db();
	if ($word) {
		$select_keyword = mysqli_query($conn,"SELECT * FROM keywords WHERE LOWER(keyword) LIKE LOWER('%".$word."%') ");
		if (mysqli_num_rows($select_keyword)>0) {
			
			$keyword_ids = array(); 
			$c = 0 ;
			while($myfa = mysqli_fetch_assoc($select_keyword)) {
				
				if ($myfa['parent_id']>0) {
					$keyword_ids[] = $myfa['id'];
					$keyword_ids[] = $myfa['parent_id']; 	
				} else {
					$keyword_ids[] = $myfa['id'];	
				}
					
				$c++;
			} 
			
			
			
		} else {
			$keyword_ids = false;
		}
	}
	return $keyword_ids;
}


function insert_keyword_relation ($keyword_id , $object_id , $object_type ) {
	$conn = db();
	if ($keyword_id && $object_id && $object_type){
		
		$select_keyword = mysqli_query($conn,"SELECT * FROM keywords_relation WHERE keyword_id='$keyword_id' AND object_id='$object_id' AND object_type='$object_type' ");
		
		if (mysqli_num_rows($select_keyword)>0) {
			
			$myfa = mysqli_fetch_assoc($select_keyword);
			$id = $myfa['id'];
		
		} else {
			
			$insert_keyword = mysqli_query($conn,"INSERT INTO keywords_relation SET keyword_id='$keyword_id' , object_id='$object_id', object_type='$object_type' ");
			
			if (mysqli_affected_rows()>0) {
				
				$id = mysqli_insert_id();
			
			} else {
			
				$id = false;
			
			}
			
		}
		
	} else {
		
		$id = false;
	}
	
	return $id;
}



function get_city_name ($city_id) {
	$conn = db();
	if ($city_id) {
		
		$select_city = mysqli_query($conn,"SELECT * FROM cities WHERE id='$city_id'");
		
		if (mysqli_num_rows($select_city)>0) {
			
			$city_data = mysqli_fetch_assoc($select_city);
			$city = $city_data['name'];
		
		} else {
		
			$city = false;
		
		}
		
	} else {
		
		$city = false;
	
	}
	
	return $city;
	
}

function get_state_name ($state_id) {
	$conn = db();
	if ($state_id) {
		
		$select_state = mysqli_query($conn,"SELECT * FROM states WHERE id='$state_id'");
		
		if (mysqli_num_rows($select_state)>0) {
			
			$state_data = mysqli_fetch_assoc($select_state);
			$state = $state_data['name'];
		
		} else {
		
			$state = false;
		
		}
		
	} else {
		
		$state = false;
	
	}
	
	return $state;
	
}



function show_blog_results ($blog_ids) {
	
		$res_blog = fetchAllData(" `blog` ", " WHERE id IN (".implode(",",$blog_ids).")");
		return $res_blog;  
	
}

function show_doctor_results ($doctor_ids) {
	
		$res_doct = fetchAllData(" `doctor_registration` ", " WHERE id IN (".implode(",",$doctor_ids).")  AND active='yes' ");
		return $res_doct;  
}

function show_service_results ($service_ids) {
	
		$res_om = fetchAllData(" `other_service_registration` ", " WHERE id IN (".implode(",",$service_ids).")");
		return $res_om;  
}

function show_hospital_results ($hospital_ids) {
	
		$res_hosp = fetchAllData(" `medical_registration` ", " WHERE id IN (".implode(",",$hospital_ids).") AND active='yes' ");
		return $res_hosp;  
}


function show_deal_results ($deal_ids) {
	
		$res_deal = fetchAllData(" `deals` ", " WHERE id IN (".implode(",",$deal_ids).")");
		return $res_deal;  
}

function show_disease_results ($disease_ids) {
	
		$res_deal = fetchAllData(" `disease` ", " WHERE id IN (".implode(",",$disease_ids).")");
		return $res_deal;  
}


function match_specis ($term) {
	
	if (empty($term)) {
		
		return array();
	}
	
	
	$res_disease = fetchAllData(" `disease` ", " WHERE disease_name LIKE '%".$term."%' OR keywords LIKE '%".$term."%' OR short_description LIKE '%".$term."%' OR description LIKE '%".$term."%' ");
	
	$res_specs = fetchAllData(" `specialisation` ", " WHERE specialisation LIKE '%".$term."%' OR specialist LIKE '%".$term."%' OR description LIKE '%".$term."%' OR short_description LIKE '%".$term."%' OR keyword LIKE '%".$term."%' OR meta_description LIKE '%".$term."%' OR diseases LIKE '%".$term."%'  ");
	
	$spec_ids = [];
	
	
	foreach ($res_disease as $dis) {
		
		$spec_ids[] = $dis['spec_id']; 
	}
	
	
	//var_dump($res_specs);
	
	foreach ($res_specs as $sp) {
		
		$spec_ids[] = $sp['id']; 
	}
	
	
	
	
	return array_unique($spec_ids,SORT_NUMERIC);
} 



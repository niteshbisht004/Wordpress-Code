<?php
session_start();


if(isset($_POST['type']))
{
	$captcha = $_POST['type'];
	
if ($_SESSION['answer'] == $captcha) {
    echo "success";
} else {
    echo "unsuccess";
}
}
	


?>
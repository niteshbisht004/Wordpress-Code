<?php
error_reporting(0);
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
	include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db); 
	
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	$expereience = $_POST['experience'];
	
	if($val == 'users'){
    include_once 'classes/users.php';
	$items = new Users($db);
    $stmt = $items->getUsers();
    }
	
	if($val == 'doctor' && $expereience  == 'past' ){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);

	 $stmt = $items->getSingleprofexp($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
	
    $stmt = $items->deletePastExperience($id);
  $allArr = array('id' => $id);
       
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
	
	
	
	
    }
	
	
		if($val == 'doctor' && $expereience  == 'current' ){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);

	 $stmt = $items->getSinglecurrentexp($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
	
    $stmt = $items->deleteCurrentExperience($id);
  $allArr = array('id' => $id);
       
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
	
	
	
	
    }
	
	
	if($val == 'hospital'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
   
   $stmt = $items->getavailabledoc($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
	
    $stmt = $items->deleteavailabledoc($id);
  $allArr = array('id' => $id);
       
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
   
   
   
   
    }
	if($val == 'other'){
    include_once 'classes/others.php';
	$items = new Others($db);
      $stmt = $items->getavailabledoc($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
	
    $stmt = $items->deleteavailabledoc($id);
  $allArr = array('id' => $id);
       
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
	
    }
	
	if($val == 'deals'){
    include_once 'classes/deals.php';
	$items = new Deals($db);
	 $stmt = $items->getDealsbyid($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
	
    $stmt = $items->deleteDeals($id);
  $allArr = array('id' => $id);
       
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
	
	
	
    }
	
	if($val == 'blogs'){
    include_once 'classes/blog.php';
	$items = new Blogs($db); 
	
	
	 $stmt = $items->getSingleBlog($id);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
    $stmt = $items->deleteBlogs($id);
  $allArr = array('id' => $id);
   
     
		
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
   
	}
    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'deletecommentonblog'){
    include_once 'classes/blog.php';
	$items = new Blogs($db); 
	$stmt = $items->delDocBlogComment($id);
	if(stmt)
	{
	$allArr = array('id' => $id);	
	$response['message']="Delete Sucessfully";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
   }

    else{
    $response['message'] = "ID Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	

    if($val == 'rcomment')
    {
        include_once 'classes/rating.php';
        $items = new Ratings($db); 
        $stmt = $items->getSingleComment($id);
        $itemCount = mysqli_num_rows($stmt); 

       if($itemCount > 0)
       {

        $stmt = $items->deleteComment($id);
        $allArr = array('id' => $id);
                   
        $response['message']="Delete Sucessfully";
        $response['status']=1;
        $response['data']= $allArr;
        
        $json_response = json_encode($response);
        echo $json_response;
        exit;			
       
        }else
        {
        $response['message'] = "ID Not Found";
        $response['status'] = 0;
        $json_response = json_encode($response);
        echo $json_response;
        exit;
        }
        
    }



	
	
	    $itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
        
        $userArr = array();
		$cityArr = array();
        $allArr  = array();
       
          while ($row = $stmt->fetch_assoc()){
			   $userArr[] = $row;
			 		
				  $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
			 
			 	if($row['pro_img'] == ''){
			
			$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
		}else{
			$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
			
		}
			 
			 
			 $allArr[] = array_merge($row,$cityArr);		 
					 
					 
					 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
				
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
    }
     
   	
?>
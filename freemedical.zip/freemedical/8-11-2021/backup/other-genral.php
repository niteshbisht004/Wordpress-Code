<?php
	include('../include/connection.php');
	include('../include/function.php');
?>
<?
	
	$resDD = fetchData(' `other_service_registration` ', " where id='".$_SESSION['userId']."' ");
?>
<style>

.popup-form .control-label{
	text-align:left;
}
.popup-form .form-group {
    margin-bottom: 5px;
	border-bottom: 1px dotted #E4E4E4;
	padding-bottom: 5px;
}
#regAutSugg ul>li:hover{
	background: #ccc;
	cursor: pointer;
	padding-left:2px;
}
#regAutSugg ul>li{ padding-left:2px; }
#regAutSugg {
max-height: 100px;
overflow-y: scroll;
position: absolute;
z-index: 11;
width: 92%;
display: none;
border: 1px solid #eee;
background: #fff;
padding: 5px;
}
</style>
<script>
function reg_auth(str){
	
	if(str==""){
		document.getElementById("result").innerHTML = "";
		document.getElementById("regAutSugg").style.display  = "none";
	} else {
		document.getElementById("regAutSugg").style.display  = "block";
		var xhttp;
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (xhttp.readyState == 4 && xhttp.status == 200) {
				document.getElementById("result").innerHTML = xhttp.responseText;			
			}
		  };
		  xhttp.open("GET", "ajax-file/get_reg_authority.php?str="+str, true);
		  xhttp.send(); 
	}
	
}
function my(listId){
	var list = document.getElementById(listId);
	var txt = list["innerText" in list ? "innerText" : "textContent"];
	document.getElementById('inp').value = txt;
	document.getElementById("result").innerHTML = "";
	document.getElementById("regAutSugg").style.display  = "none";
}
</script>
<div class="popup-form">
            <form class="form-horizontal" role="form" action="/other-profile" method="post">
				<h4>General Information</h4>
				<hr style="margin-top: 0px;"/>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Hospital Name</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['name']?>" name="name"  class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Registration No</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_no']?>" name="registration_no" class="form-control"  required/>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Registration Authority</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_authority']?>" onKeyup="reg_auth(this.value)" name="registration_authority" class="form-control" id="inp" required/>
						<div id="regAutSugg" >
							<ul style="list-style:none; padding:0;" id="result">
															
							</ul>
						</div>
                    </div>
                </div>                
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Specialisation</label>
					<div class="col-sm-9">
					<select multiple name="specialisation[]" id="specialisation" class="form-control input-md" data-size="5" data-live-search="true" required>
						<?php 
							$specialisation = explode("|",$resDD['specialisation']);
							$querSp=mysqli_query($conn,"select * from specialisation ORDER BY specialisation ASC");
							while($rowSp=mysqli_fetch_object($querSp))
						 {
						?>
							<option <? if(in_array($rowSp->id ,$specialisation)) { echo "selected"; }  ?> value="<?php echo $rowSp->id; ?>"><?php echo $rowSp->specialisation; ?></option>
						<?php } ?>  
					</select>
					</div>
                </div>
                		<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Extra Feature</label>
                    <div class="col-sm-9"><? $extra = explode(',',$resDD['O_extra_feature']);					
					?>
                        <div class="col-sm-3"><input id="checkbox1" type="checkbox" name="ambulance" value="Ambulance" <? if($extra[0] == 'Ambulance'){ echo "checked "; } ?>> Ambulance </div>
                        <div class="col-sm-3"><input id="checkbox1" type="checkbox" name="icu" value="ICU On Wheels" <? if($extra[1] == 'ICU On Wheels'){ echo "checked "; } ?>> ICU On Wheels  </div>
                        <div class="col-sm-3"><input id="checkbox1" type="checkbox" name="esi" value="ESI" <? if($extra[2] == 'ESI'){ echo "checked "; } ?>> ESI </div>
                        <div class="col-sm-3"><input id="checkbox1" type="checkbox" name="cghs" value="CGHS" <? if($extra[3] == 'CGHS'){ echo "checked "; } ?>> CGHS </div>
					
                    </div>
                </div>

<p class="inp"></p>
               
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="other_genral" class="btn btn-primary btn-block">Update</button>
                    </div>
                </div>
            </form> <!-- /form -->
</div>
<script>
  $(document).ready(function () {
    $('.selectpicker').selectpicker();
  });
  
 </script>
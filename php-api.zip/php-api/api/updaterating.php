<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

$id = $_POST['id'];
$user_id = $_POST['user_id'];
$rateusertype = $_POST['rateusertype'];
$email = $_POST['email'];
$rate = $_POST['rate'];
$recommend = $_POST['recommend'];
$comment = $_POST['comment'];
$rating_by_userid = $_POST['rating_by_userid'];
$rating_by_useremail = $_POST['rating_by_useremail'];
$user_type = $_POST['user_type'];
$val = $_POST['cat'];

    include_once 'classes/rating.php';
    
   if($val ==  'rcomment'){

    $items = new Ratings($db);
    $stmt = $items->updateComment($comment,$id);
    //$allArr = array();
    if ($stmt) {

        $usr = array();
        $usr['id'] =  $id;
        $response['data'] = $usr;
        $response['message'] = "Data Updated";
        $response['status'] = 1;


        $json_response = json_encode($response);
        echo $json_response;
        exit;
    } else {
        $response['message'] = "Data Not Updated";
        $response['status'] = 0;

        $json_response = json_encode($response);
        echo $json_response;
        exit;
    }



   }

    $items = new Ratings($db);
    $stmt = $items->updateRating($user_id,
    $rateusertype,
    $email,
    $rate,
    $recommend,
    $comment,
    $rating_by_userid,
    $rating_by_useremail,
    $user_type,$id
    );
    //$allArr = array();
    if ($stmt) {

        $usr = array();
        $usr['id'] =  $id;
        $response['data'] = $usr;
        $response['message'] = "Data Updated";
        $response['status'] = 1;


        $json_response = json_encode($response);
        echo $json_response;
        exit;
    } else {
        $response['message'] = "Data Not Updated";
        $response['status'] = 0;

        $json_response = json_encode($response);
        echo $json_response;
        exit;
    }



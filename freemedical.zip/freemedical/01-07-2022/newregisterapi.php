<?php
	//ini_set('display_errors', 1);
	//ini_set('display_startup_errors', 1);
	//error_reporting(E_ALL);
	
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	    // get posted data
	$data = file_get_contents("php://input");
	
	$cat = $_POST['cat'];
	$fname = $_POST['name'];
	$phone = $_POST['phone_no'];
	$email = $_POST['email'];
	$current_date = date('Y/m/d h:i:s');
	
	function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 6; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
	 }
	
	if($cat == 'user'){
    include_once 'classes/users.php';
	$items = new Users($db);
	$fv = $items->getVerifyUsersbyphone($phone);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		// echo 'user_id ='.$itemCount;
    $response['message'] = "Phone Number Already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyUsersbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }
	 else
	{
		$first_name = $fname;
		$phone_no = $phone;
		$password = randomPassword();
		$email = $email;
		$a = explode('@', $email);
        $foo = $a[0];
		$foo = preg_replace('/[^a-zA-Z0-9_ -]/s','',$foo);
		$active = rand(100000,999999);
		$insert_date = $current_date;
		
		
		
		$stmt = $items->createUsers($foo,$first_name,$phone_no,$password,$email,$active,$insert_date);


		 
	}

	 }
}
		if($cat == 'doctor'){
    include_once 'classes/doctors.php';
		$items = new Doctors($db);
		$fv = $items->getVerifyDoctorsbyPhone($phone);
		$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Phone Number Already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyDoctorsbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
		$first_name = $fname;
		$phone_no = $phone;
		$password = randomPassword();
		$email = $email;
		$a = explode('@', $email);
        $foo = $a[0];
		$foo = preg_replace('/[^a-zA-Z0-9_ -]/s','',$foo);
		$active = rand(100000,999999);
		$insert_date = $current_date;
		
		
		
		$stmt = $items->createDoctors($foo,$first_name,$phone_no,$password,$email,$active,$insert_date);
	 }
	 }
	}

	
			if($cat == 'hospital'){
        include_once 'classes/hospitals.php';
		$items = new Hospitals($db);
		
	$fv = $items->getVerifyHospitalsbyPhone($phone);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Phone already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyHospitalsbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
		$first_name = $fname;
		$phone_no = $phone;
		$password = randomPassword();
		$email = $email;
		$a = explode('@', $email);
        $foo = $a[0];
		$foo = preg_replace('/[^a-zA-Z0-9_ -]/s','',$foo);
		$active = rand(100000,999999);
		$insert_date = $current_date;
		
		
		
		$stmt = $items->createHospitals($foo,$first_name,$phone_no,$password,$email,$active,$insert_date);
	 }
	 }
	}
	
	if($cat == 'other'){
		
    include_once 'classes/others.php';
	$items = new Others($db);
	
    $fv = $items->getVerifyOthersbyPhone($phone);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Phone already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyOthersbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
     	
	    $first_name = $fname;
		$phone_no = $phone;
		$password = randomPassword();
		$email = $email;
		$a = explode('@', $email);
        $foo = $a[0];
		$foo = preg_replace('/[^a-zA-Z0-9_ -]/s','',$foo);
		$active = rand(100000,999999);
		$insert_date = $current_date;
		$stmt = $items->createOthers($foo,$first_name,$phone_no,$password,$email,$active,$insert_date);
		
	 }
	 }
	
	}

    if($stmt){
      
     $usr =  array('cat'=>$cat,'id' => $items->id,'userid' => $foo,'Name' => $first_name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email, 'Active' => $active,'Date' => $insert_date);
		$response['data']=$usr;
		
			$num = $phone_no;
			$fields = array(
				"sender_id" => "TXTIND",
				"message" => "Thank you for registering at freemedicalinfo.in site. Here is the OTP:\n ".$active,
				"route" => "v3",
				"numbers" => $num,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: ",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			curl_exec($curl);
			curl_error($curl);
		    curl_close($curl);
		    $to = $email;
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n https://www.freemedicalinfo.in/sisdev/account-active.php?x=$id-user&y=$active\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($to, $subject, $body, $additionalheaders);
			$response['message']="user Created Successfully";
			$response['status']=1;

	
			$json_response = json_encode($response);
			echo $json_response;
			//echo $response; die;
			
		
   
    }else{
      $response['message'] = "User not created";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
    }
	
	
	 
	
?>
<?php
	//ini_set('display_errors', 1);
	//ini_set('display_startup_errors', 1);
	//error_reporting(E_ALL);
	
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	    // get posted data
	$data = file_get_contents("php://input");
	
	$cat = $_POST['cat'];
	$id = $_POST['id'];
	$otp = $_POST['otp'];
	if($cat == 'user')
	{
		
		include_once 'classes/users.php';
		$items = new Users($db);
		$stmt = $items->getUserActive($id,$otp);
		if($stmt)
		{
			$stmts = $items->getActiveuser($id);
			$row = $stmts->fetch_array();
			
			$name = $row['first_name'];
			$userid = $row['user_id'];
			$password = $row['password'];
			$email = $row['email'];
			$phone_no = $row['phone_no'];
			
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n Here is the login details, \n\n Userid: $userid \n\n Password: $password";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($email, $subject, $body, $additionalheaders);
		
		  $fields = array(
				"sender_id" => "TXTIND",
				"message" => "Login details for registering at freemedicalinfo site. \n Userid: $userid \n Password: $password",
				"route" => "v3",
				"numbers" => $phone_no,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			//$response = curl_exec($curl);
			curl_exec($curl);
			curl_error($curl);
		    curl_close($curl);

			 $usr =  array('cat'=>$cat,'id' => $id,'userid' => $userid,'Name' => $name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email);
		
			$response['message']="user Activated Successfully";
			$response['data']=$usr;	
			$response['status']=1;
			$json_response = json_encode($response);
			echo $json_response;
			
		}
   
		else
		{
			$response['message'] = "User not Activate";
			$response['status'] = 0;
			
			$json_response = json_encode($response);
			echo $json_response;
		}
	
	}
	
	if($cat == 'doctor')
	{
		
		include_once 'classes/doctors.php';
		$items = new Doctors($db);
		$stmt = $items->getDoctorActive($id,$otp);
		if($stmt)
		{
			$stmts = $items->getActiveuser($id);
			$row = $stmts->fetch_array();
			
			$name = $row['name'];
			$userid = $row['user_id'];
			$password = $row['password'];
			$email = $row['email'];
			$phone_no = $row['phone_no'];
			
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n Here is the login details, \n\n Userid: $userid \n\n Password: $password";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($email, $subject, $body, $additionalheaders);
		
		  $fields = array(
				"sender_id" => "TXTIND",
				"message" => "Login for registering at freemedicalinfo.\n Userid: $userid \n pwd: $password",
				"route" => "v3",
				"numbers" => $phone_no,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			//$response = curl_exec($curl);
			curl_exec($curl);
			curl_error($curl);
		    curl_close($curl);
			 $usr =  array('cat'=>$cat,'id' => $id,'userid' => $userid,'Name' => $name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email);
		
			$response['message']="user Activated Successfully";
			$response['data']=$usr;	
			$response['status']=1;
			$json_response = json_encode($response);
			echo $json_response;
			
		}
   
		else
		{
			
			$response['message'] = "User not Activate";
			$response['status'] = 0;
			
			$json_response = json_encode($response);
			echo $json_response;
		}
	
	}
	
		if($cat == 'hospital')
	{
		
		include_once 'classes/hospitals.php';
		$items = new Hospitals($db);
		$stmt = $items->getHospitalActive($id,$otp);
		if($stmt)
		{
			
				$stmts = $items->getActiveuser($id);
			$row = $stmts->fetch_array();
			
			$name = $row['name'];
			$userid = $row['user_id'];
			$password = $row['password'];
			$email = $row['email'];
			$phone_no = $row['phone_no'];
			
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n Here is the login details, \n\n Userid: $userid \n\n Password: $password";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($email, $subject, $body, $additionalheaders);
		
		  $fields = array(
				"sender_id" => "TXTIND",
				"message" => "Login for registering at freemedicalinfo.\n Userid: $userid \n pwd: $password",
				"route" => "v3",
				"numbers" => $phone_no,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			//$response = curl_exec($curl);
			curl_exec($curl);
			curl_error($curl);
		    curl_close($curl);

			

				
				
			 $usr =  array('cat'=>$cat,'id' => $id,'userid' => $userid,'Name' => $name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email);
		
			$response['message']="user Activated Successfully";
			$response['data']=$usr;	
			$response['status']=1;
			$json_response = json_encode($response);
			echo $json_response;
			
		}
   
		else
		{
			$response['message'] = "User not Activate";
			$response['status'] = 0;
			
			$json_response = json_encode($response);
			echo $json_response;
		}
	
	}
	
	
		if($cat == 'other')
	{
		
		include_once 'classes/others.php';
		$items = new Others($db);
		$stmt = $items->getOtherActive($id,$otp);
		if($stmt)
		{
			
				$stmts = $items->getActiveuser($id);
			$row = $stmts->fetch_array();
			
			$name = $row['name'];
			$userid = $row['user_id'];
			$password = $row['password'];
			$email = $row['email'];
			$phone_no = $row['phone_no'];
			
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n Here is the login details, \n\n Userid: $userid \n\n Password: $password";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($email, $subject, $body, $additionalheaders);
		
		  $fields = array(
				"sender_id" => "TXTIND",
				"message" => "Login for registering at freemedicalinfo.\n Userid: $userid \n pwd: $password",
				"route" => "v3",
				"numbers" => $phone_no,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			//$response = curl_exec($curl);
			curl_exec($curl);
			curl_error($curl);
		    curl_close($curl);
		

		
				
				
			 $usr =  array('cat'=>$cat,'id' => $id,'userid' => $userid,'Name' => $name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email);
		
			$response['message']="user Activated Successfully";
			$response['data']=$usr;	
			$response['status']=1;
			$json_response = json_encode($response);
			echo $json_response;
			
		}
   
		else
		{
			$response['message'] = "User not Activate";
			$response['status'] = 0;
			
			$json_response = json_encode($response);
			echo $json_response;
		}
	
	}
	 
	
?>
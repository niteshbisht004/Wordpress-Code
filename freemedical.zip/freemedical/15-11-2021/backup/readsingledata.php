<?php
//error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	$rusertype = $_POST['usertype'];
	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db); 
	
	include_once 'classes/rating.php';
	$rateitems = new Ratings($db);
	
	if($val == 'user'){
    include_once 'classes/users.php';
	$items = new Users($db);
    $stmt = $items->getSingleUsers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
												
		 
			 
		if($row['pro_img'] == ''){
			
			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/'.$row['timeline_img'];
			
		}
		
				
									
		 
			 
			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	if($val == 'usergeninfo'){
    include_once 'classes/users.php';
	$items = new Users($db);
    $stmt = $items->getSingleUsers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = array();
												
		    $userArr['first_name'] = $row['first_name'];
			$userArr['last_name'] = $row['last_name'];
			$userArr['date_birth'] = $row['date_birth'];
			$userArr['gender'] = $row['gender'];
			$userArr['blood_group'] = $row['blood_group'];
			$userArr['interested'] = $row['interested'];
			$userArr['qualification'] = $row['qualification'];
			
		
									
		 
			 
			// $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	
	
	if($val == 'doctor'){
		
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getSingleDoctors($id);
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				if($row['pro_img'] == ''){
			
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
		}else{
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
	 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			
			$rating =  mysqli_fetch_row($statestmts);

									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);
 
			 
			 
					 
			$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			
			
	include_once 'classes/blog.php';		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	} 
			 
			 
			 
			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
		if($val == 'doctorgeninfo'){
		
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getSingleDoctors($id);
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			$userArr['name'] = $row['name'];
			$userArr['gender'] = $row['gender'];
			$userArr['qualification'] = $row['qualification'];
			$userArr['date_birth'] = $row['date_birth'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
			$userArr['expertise_in'] = $row['expertise_in'];
			$userArr['summary'] = $row['summary'];
			
	 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
			 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}									
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	if($val == 'hospital'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
			 if($row['pro_img'] == ''){
			
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/hospital1.jpg';
		}else{
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
		 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			
		      $catid = $row['hospital_category'];
			 $catstmt = $items->getHospitalsbyCategoryid($catid);
			  $hosname =  mysqli_fetch_row($catstmt);
			 $cityArr['hospital_categoryname'] = $hosname[1];
			 
			 
			 
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyhospitalid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);

    $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	} 
			 
			 
			 
			 
			 
			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	if($val == 'hospitalgeninfo'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			
		$userArr['name'] = $row['name'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
			$userArr['noOfBeds'] = $row['noOfBeds'];
			$userArr['private_room'] = $row['private_room'];
			
				$userArr['hospital_category'] = $row['hospital_category'];
			$userArr['clinical_test'] = $row['clinical_test'];
			$userArr['ambulance'] = $row['ambulance'];
			$userArr['summary'] = $row['summary'];
			$userArr['heyear'] = $row['heyear'];
			
			$userArr['extra_feature'] = $row['extra_feature'];
			$userArr['update_date'] = $row['update_date'];
			$userArr['id'] = $row['id'];
	
					 
 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}									
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	
	
	
	if($val == 'other'){
    include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getSingleOthers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				
		     if($row['pro_img'] == ''){
			
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/hospital1.jpg';
		}else{
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
		 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			};	

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];


            include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other-medical');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}			
		 
			 
			 $allArr = array_merge($row,$cityArr);
		   
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	if($val == 'othergeninfo'){
include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getSingleOthers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			
		    $userArr['name'] = $row['name'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
		
			$userArr['extra_feature'] = $row['extra_feature'];
	
	


            $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}								
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	if($val == 'pastexpdoctors'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getPastExperience($id);
	
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $userexp = $items->getSingleHospitals($row['hospital_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		  
			 $cityArr['hospitalid'] = $row['hospital_id'];
		     $cityArr['hospitalname'] = $rows['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	
  	if($val == 'currentexpdoctors'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getCurrentExperience($id);
	
	$itemCount = mysqli_num_rows($stmt);

    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $userexp = $items->getSingleHospitals($row['hospital_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		  
			 $cityArr['hospitalid'] = $row['hospital_id'];
		     $cityArr['hospitalname'] = $rows['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }

  	if($val == 'getavailabledoctorsinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getAvailableDoctors($id);
	
	$itemCount = mysqli_num_rows($stmt);

    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['doctor_id'];
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $userexp = $items->getSingleDoctors($row['doctor_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		if($rows['pro_img'] == ''){
			
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rows['pro_img'];
			
		}
		
		 $cityArr['doctorname'] = $rows['name'];
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rows['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rows['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'availablefacilityinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['available_facility']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	if($val == 'specialinfrainhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['special_infra']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
		if($val == 'specialmachineinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['special_machine']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	
	
	
	
	
	
	
	if($val == 'deals'){
    include_once 'classes/deals.php';
	$items = new Deals($db);
	if($usertype == 'doctor'){
		
	$stmt = $items->getSingleDealsbydoctorid($id);
	}
	if($usertype == 'hospital'){
		
	$stmt = $items->getSingleDealsbyhospitalid($id);
	}
	if($usertype == 'other'){
		
	$stmt = $items->getSingleDealsbyotherid($id);
	}
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				
		     $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$row['image'];
			    $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$row['image']; 
			  $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];									
		 
			 
			 $allArr[] = array_merge($cityArr,$row);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	
    }
	
    
	if($val == 'blogs'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
	$stmt = $items->getSingleBlog($id);
	
	$itemCount = mysqli_num_rows($stmt);


    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$row['image'];
			  			 
	
	
			$cmntstmt = $items->getBlogComment($id);
			$comntCount = mysqli_num_rows($cmntstmt);
			if($comntCount>0)
				$cmntArr = array();
			{
				while($rows = $cmntstmt->fetch_assoc())
				{
					$cmntArr[] = $rows;
			
					$cityArr['comment'][] = $rows;
				}
				
				
			}
		
			 $allArr[] = array_merge($row,$cityArr);
				
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
     
	 
	 if($val == 'coupan'){
    include_once 'classes/coupan.php';
	$items = new Coupans($db);
	if($usertype == 'doctor'){
		
	$stmt = $items->getCoupansbyDoctor($id);
	}
	if($usertype == 'hospital'){
		
	$stmt = $items->getCoupansbyHospital($id);
	}
	if($usertype == 'other'){
		
	$stmt = $items->getCoupansbyOther($id);
	}
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
									
		 
			 
			 //$allArr[] = array_merge($cityArr,$row);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	
    }
	 


	
	
		if($val == 'getCommentsbyDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getCommentsbyDoc($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'getCommentsbyHos'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getCommentsbyHos($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'getCommentsbyOth'){
    include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getCommentsbyOth($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "Data Not Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }


    if($val == 'rating') {
    
        include_once 'classes/rating.php';
        $items = new Ratings($db);
        $stmt = $items->getRatingsbyuserid($id,$rusertype);
        $itemCount = mysqli_num_rows($stmt);
        
        if ($itemCount > 0) { 
    
            $userArr = array();
            $cityArr = array();
            $allArr  = array();
    
            while ($row = $stmt->fetch_assoc()) {
                
               $userArr[] = $row;
            
               $uid=$row['user_id'];
               $utype=$row['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
               
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArr['name']=$rowd['name'];
            }
       
       
           $rid=$row['rating_by_userid'];
           $rtype=$row['user_type'];
    
           if($rtype=='user')
           {
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['first_name'];
                    }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['name'];
                    }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
    
           $cityArr['rate'] = $row['rate'];
            
           $stmtl = $items->getlikebyid($row['id']);
           $cityArr['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $items->getdislikebyid($row['id']);
           $cityArr['dislike'] = mysqli_num_rows($stmtd);
		   
		   
		 
		   
		    $stmtco = $items->getcommentssbyratingrid($row['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
        if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
    
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                        $cityArrco['username'] = $rowuco['first_name'];
                    }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                        $cityArrco['username'] = $rowuco['name'];
                    }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['username'] = $rowuco['name'];
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['username'] = $rowuco['name'];
                }
           }
            
          
		   $stmtlco = $items->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $items->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
                $cityArr['comments'][] = array_merge($rowco, $cityArrco);
            }
		   
		   
		}  
		    
		   
		              
    
                $allArr[] = array_merge($row, $cityArr);
            }
            $response['message'] = "Data Found";
            $response['count'] = $itemCount;
            $response['status'] = 1;
            $response['data'] = $allArr;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
    
            $response['message'] = "Data Not Found";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }
    }
	

    if($val == 'rcomments') {
    
        include_once 'classes/rating.php';
        $items = new Ratings($db);
        $stmt = $items->getcommentssbyratingrid($id);
        $itemCount = mysqli_num_rows($stmt);
        
        if ($itemCount > 0) { 
    
            $userArr = array();
            $cityArr = array();
            $allArr  = array();
    
            while ($row = $stmt->fetch_assoc()) {
                
               $userArr[] = $row;
            
               $uid=$row['user_id'];
               $utype=$row['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
               
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArr['name']=$rowd['name'];
            }
       
       
           $rid=$row['rating_by_userid'];
           $rtype=$row['user_type'];
    
           if($rtype=='user')
           {
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['first_name'];
                    }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['name'];
                    }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
    
           $cityArr['rate'] = $row['rate'];
		   $stmtl = $items->getrlikebyid($row['id']);
           $cityArr['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $items->getrdislikebyid($row['id']);
           $cityArr['dislike'] = mysqli_num_rows($stmtd);
    
                $allArr[] = array_merge($row, $cityArr);
            }
            $response['message'] = "Data Found";
            $response['count'] = $itemCount;
            $response['status'] = 1;
            $response['data'] = $allArr;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
    
            $response['message'] = "Data Not Found";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }
    }
	
?>
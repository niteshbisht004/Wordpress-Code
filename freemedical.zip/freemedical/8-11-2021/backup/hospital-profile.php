<? 
include("include/header.php"); ?>
<? if(empty($_SESSION['userId']) || $_SESSION['userType']!="hospital"){
	header("location:/index.php");
}

//var_dump(); 
if (isset($_POST['rsubmit'])) {
	$rcmnt = $_POST['comnt'];
	$ridd = $_POST['rateIdd'];
	$uid = $_POST['userId'];
	$umail = $_POST['uemail'];
	$utype = $_POST['utype'];
	$urid = $_POST['urateId'];
	$urmail = $_POST['urateMail'];
	$urtype = $_POST['urateType'];
	$date = date("Y-m-d H:i:s");
	$rpId = $_POST['rplyid'];


	$rqry = "insert into rnewrating(`comment`,`rating_id`,`reply_id`,`user_id`,`email`,`rateusertype`,`rating_by_userid`,`rating_by_useremail`,`user_type`,`insert_date`) values('$rcmnt','$ridd','$rpId','$uid','$umail','$utype','$urid','$urmail','$urtype','$date')";
	$run = mysqli_query($conn, $rqry);
	if ($run) {
?>
		<script>
			//alert('Thanks for your comment.');
			if (window.location.href.indexOf("comments") > -1) {
               var url=window.location.href;
			window.history.replaceState(null, null, url);
    }else{
			var url=window.location.href+"#comments";
			window.history.replaceState(null, null, url);
	}
		</script>
<?
	} else {
		echo "error......!";
	}
}
$current_date = date('Y/m/d h:i:s');
if(isset($_POST['submit']))
	 {
		 $ins = "insert into comment_hospital set
		 `hos_id` = '".$_SESSION['userId']."',
		 `name` = '".$_POST['name']."', 
		 `email` = '".$_POST['email']."', 
		 `comment` = '".$_POST['comment']."',
		 `insert_date` = now(),
		 `status` = 'no'	 
		 ";
		 mysqli_query($conn,$ins) or die(mysqli_error());			
		header("location:/hospital-profile?openTab=commentsTab");
	 }
if(isset($_POST['replysubmit'])){
		 $comment_id = $_POST['cmnt_id'];
		$rpy_commnt = mysqli_query($conn,"insert into comment_reply_hospital set 
		`comment_id`='$comment_id', 
		`reply_by_id`='".$_SESSION['userId']."',
		`reply_by_name`='".$_SESSION['userName']."',
		`reply_by_email`='".$_SESSION['userEmail']."',
		`reply_message`='".$_POST['Rcomment']."',
		`status`='no' ") or die(mysqli_error());
		header("location:/hospital-profile?openTab=commentsTab");
	}
if(isset($_GET['Cid']))
	 {
		$del = "delete from comment_hospital where id = '".$_GET['Cid']."' ";
		mysqli_query($conn,$del) or die(mysqli_error());
		header("location:/hospital-profile?openTab=commentsTab");
	 }
if(isset($_GET['rid']))
	 {
		 $report_cmt = "UPDATE comment_hospital set `status`='no', `report`='report' where id = '".$_GET['rid']."' ";
		 mysqli_query($conn,$report_cmt) or die(mysqli_error());		 
		 	 
		 $Query_cmnt = mysqli_query($conn," select * from comment_hospital where id = '".$_GET['rid']."' ") or die(mysqli_error());		
		 $num = mysqli_num_rows($Query_cmnt);
		 $res_cmt = mysqli_fetch_array($Query_cmnt);
		
			
			// Mail to Report Abuse By...
				$report_by = $_SESSION['userEmail'];
				$comment_by = $res_cmt['email'];
				
				$subject = "FMI Report Abuse Information";

				$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>You did Report Abuse of <strong>'".$res_cmt['name']."'</strong> Comment. </br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";
				
				$message_to_comment_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>Your Comment have been Reported Abuse By <strong>'".$_SESSION['userName']."'</strong>. so we have to unpublished your comment due to the reason. </br>
						Reported By :- <strong>'".$_SESSION['userEmail']."'</strong></br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";

				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <webmaster@example.com>' . "\r\n";
				$headers .= 'Cc: myboss@example.com' . "\r\n";

				$mail1 = mail($report_by,$subject,$message_to_report_by,$headers);
				$mail2 = mail($comment_by,$subject,$message_to_comment_by,$headers);
			
			// Mail to Commentor ..
			
			header('location:/hospital-profile?openTab=commentsTab');
	 }	 
	  

if(isset($_POST['add_avail_doct']) || (isset($_POST['update_avail_doct']) && $_POST['doctId']!="")) {
	 
	// var_dump($_POST);
	// exit;
	

	
	//insert hospital
	if ($_POST['doctor_id']=="other") {
		
		function array_replace_value($array, $replacementTo, $replacement)
		{
			if (in_array($replacementTo, $array)) {
				$key = array_search($replacementTo, $array);
				$array[$key] = $replacement;
				return $array;
			}
		}
		
		$qualification = implode("|",$_POST['qualification']);
		if(in_array("Other",$_POST['qualification'])){
			//$qualification = $qualification.":".$_POST['otherQuali'];
			$qualO = array_replace_value($_POST['qualification'], "Other", $_POST['otherQuali']);
			$qualification = implode("|",$qualO);
			$insert_quali = "insert into `qualification` set `qualification` = '".$_POST['otherQuali']."' "; 
			mysqli_query($conn,$insert_quali) or die(mysqli_error());
		}
		
		$specialisation = implode("|",$_POST['specialisation']);
		if(in_array("other",$_POST['specialisation'])){
			//$specialisation = $specialisation.":".$_POST['otherSpeci'];
			$specO = array_replace_value($_POST['specialisation'], "other", $_POST['otherSpeci']);
			$specialisation = implode("|",$specO);
			$insert_spec = "insert into `specialisation` set `specialisation` = '".$_POST['otherSpeci']."' "; 
			mysqli_query($conn,$insert_spec) or die(mysqli_error());
		}
		
		
		$query_doc = "INSERT INTO doctor_registration SET 
				
				`name` = '".$_POST['doc_name']."',  
				`mobile_no` = '".$_POST['mobile']."',  
				`email` = '".$_POST['email']."',  
				`gender` = '".$_POST['gender']."', 
				`qualification` = '".$qualification."',  
				`specialisation` = '".$specialisation."',
				`registration_no` = '".$_POST['reg_no']."',
				`registration_auth` = '".$_POST['reg_auth']."',
				`expertise_in` = '".$_POST['expertise']."',
				`total_experience` = '".$_POST['total_exp']."',
				`active` = 'no',
				`insert_date` = '".date("Y-m-d H:i:s")."',
				`update_date` = '".date("Y-m-d H:i:s")."'";
	
		$add_doc = mysqli_query($conn,$query_doc) or die(mysqli_error());
	
			$docid = mysqli_insert_id($conn); 
		
		
		$query="INSERT INTO available_doc_info_hospital_reg SET `H_id` = '".$_SESSION['userId']."', ";

	
	
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
	
	$query .= 
		
		"`doctor_id` = '".$docid."',
		`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
		`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
		`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
		`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
		`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
		`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
		`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
		`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
		`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
		`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
		`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
		`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
		`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
		`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."'";
		
mysqli_query($conn,$query) or die(mysqli_error());

		
		
		
	}else{
	
	
	
	if (isset($_POST['update_avail_doct'])) {
		// var_dump($_POST);
		// exit;
		
		$query="UPDATE available_doc_info_hospital_reg SET ";
	} else {
		$query="INSERT INTO available_doc_info_hospital_reg SET `H_id` = '".$_SESSION['userId']."', ";
	}
	
	
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
	
	$query .= 
		
		"`doctor_id` = '".$_POST['doctor_id']."',
		`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
		`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
		`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
		`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
		`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
		`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
		`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
		`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
		`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
		`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
		`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
		`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
		`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
		`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."'";
		
		if (isset($_POST['update_avail_doct'])) {
			
		
			$query.=" WHERE `H_id` = '".$_SESSION['userId']."' and `id` = '".$_POST['doctId']."'";
		
			
		} 

		mysqli_query($conn,$query) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update medical_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
	}
		//header("location:/hospital-profile?openTab=doctorsTab");
}


/*	 
if(isset($_POST['add_avail_doct'])){
	$time = implode(":",$_POST['fromTime'])." to ".implode(":",$_POST['toTime']);
	$update = "insert into `available_doc_info_hospital_reg` set  
		`doc_name` = '".$_POST['doc_name']."',  
		`mobile` = '".$_POST['mobile']."',  
		`email` = '".$_POST['email']."',  
		`gender` = '".$_POST['gender']."', 
		`qualification` = '".$_POST['qualification']."',  
		`specialisation` = '".$_POST['specialisation']."',
		`reg_no` = '".$_POST['reg_no']."',
		`sun_FT` = '".$_POST['sunF_FT']."-".$_POST['sunT_FT']."',
		`sun_ST` = '".$_POST['sunF_ST']."-".$_POST['sunT_ST']."',		
		`mon_FT` = '".$_POST['monF_FT']."-".$_POST['monT_FT']."',
		`mon_ST` = '".$_POST['monF_ST']."-".$_POST['monT_ST']."',		
		`tue_FT` = '".$_POST['tusF_FT']."-".$_POST['tusT_FT']."',		
		`tue_ST` = '".$_POST['tusF_ST']."-".$_POST['tusT_ST']."',		
		`wed_FT` = '".$_POST['wedF_FT']."-".$_POST['wedT_FT']."',		
		`wed_ST` = '".$_POST['wedF_ST']."-".$_POST['wedT_ST']."',		
		`thu_FT` = '".$_POST['thuF_FT']."-".$_POST['thuT_FT']."',		
		`thu_ST` = '".$_POST['thuF_ST']."-".$_POST['thuT_ST']."',		
		`fri_FT` = '".$_POST['friF_FT']."-".$_POST['friT_FT']."',		
		`fri_ST` = '".$_POST['friF_ST']."-".$_POST['friT_ST']."',		
		`sat_FT` = '".$_POST['satF_FT']."-".$_POST['satT_FT']."',
		`sat_ST` = '".$_POST['satF_ST']."-".$_POST['satT_ST']."',		
		`reg_auth` = '".$_POST['reg_auth']."',
		`expertise` = '".$_POST['expertise']."',
		`total_exp` = '".$_POST['total_exp']."', 
		 
		`doc_img` = '".$_POST['doc_img']."', 
		`H_id` = '".$_SESSION['userId']."' 
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:/hospital-profile?openTab=doctorsTab");
}
*/


if(isset($_POST['update_hpp'])){
	if(!empty($_FILES['image']['name'])){
	// Get the file information
    $fileName   = rand().basename($_FILES["image"]["name"]);
    $fileTmp    = $_FILES["image"]["tmp_name"];
    $fileType   = $_FILES["image"]["type"];
    $fileSize   = $_FILES["image"]["size"];
    $fileExt    = substr($fileName, strrpos($fileName, ".") + 1);
    
    // Specify the images upload path
    $largeImageLoc = 'images/profile/fullprofileimage/'.$fileName;
    $thumbImageLoc = 'images/profile/'.$fileName;

    // Check and validate file extension
    if((!empty($_FILES["image"])) && ($_FILES["image"]["error"] == 0)){
        if($fileExt != "jpg" && $fileExt != "jpeg" && $fileExt != "png" && $fileExt != "gif"){
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }
    }else{
        $error = "Select an image file to upload.";
    }

    // If everything is ok, try to upload file
    if(empty($error) && !empty($fileName)){
        if(move_uploaded_file($fileTmp, $largeImageLoc)){
            // File permission
            chmod($largeImageLoc, 0777);
            
            // Get dimensions of the original image
            list($width_org, $height_org) = getimagesize($largeImageLoc);
            
            // Get image coordinates
            $x = (int) $_POST['x'];
            $y = (int) $_POST['y'];
            $width = (int) $_POST['w'];
            $height = (int) $_POST['h'];

            // Define the size of the cropped image
            $width_new = $width;
            $height_new = $height;
            
            // Create new true color image
            $newImage = imagecreatetruecolor($width_new, $height_new);
            
            // Create new image from file
            switch($fileType) {
                case "image/gif":
                    $source = imagecreatefromgif($largeImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    $source = imagecreatefromjpeg($largeImageLoc); 
                    break;
                case "image/png":
                case "image/x-png":
                    $source = imagecreatefrompng($largeImageLoc); 
                    break;
            }
            
            // Copy and resize part of the image
            imagecopyresampled($newImage, $source, 0, 0, $x, $y, $width_new, $height_new, $width, $height);
            
            // Output image to file
            switch($fileType) {
                case "image/gif":
                    imagegif($newImage, $thumbImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    imagejpeg($newImage, $thumbImageLoc, 90); 
                    break;
                case "image/png":
                case "image/x-png":
                    imagepng($newImage, $thumbImageLoc);  
                    break;
            }
            
            // Destroy image
            imagedestroy($newImage);
		unlink("images/profile/".$_POST['oldfile']);
		unlink("images/profile/fullprofileimage/".$_POST['oldfile']);
    }
	}
	}
	$update = "update `medical_registration` set  
		`pro_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = ".$_SESSION['userId']."
		";

		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:hospital-profile");
}

if(isset($_POST['update_hpps'])){	
	if(!empty($_FILES['image']['name'])){
		$fileName = fileUpload("images/profile/", $_FILES['image'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $fileName= $_POST['oldfile'];
	}
	
	$update = "update `medical_registration` set  
		`pro_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = ".$_SESSION['userId']."
		";

		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:hospital-profile");
}

if(isset($_POST['update_tp'])){
	 //echo "hello";
	//die();
	/*if(!empty($_FILES['photo']['name'])){
		$img = fileUpload("images/profile/", $_FILES['photo'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $img= $_POST['oldfile'];
	}*/
	if(!empty($_FILES['image']['name'])){
	// Get the file information
    $fileName   = rand().basename($_FILES["image"]["name"]);
    $fileTmp    = $_FILES["image"]["tmp_name"];
    $fileType   = $_FILES["image"]["type"];
    $fileSize   = $_FILES["image"]["size"];
    $fileExt    = substr($fileName, strrpos($fileName, ".") + 1);
    
    // Specify the images upload path
    $largeImageLoc = 'images/timeline/'.$fileName;
    $thumbImageLoc = 'images/timeline/'.$fileName;

    // Check and validate file extension
    if((!empty($_FILES["image"])) && ($_FILES["image"]["error"] == 0)){
        if($fileExt != "jpg" && $fileExt != "jpeg" && $fileExt != "png" && $fileExt != "gif"){
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }
    }else{
        $error = "Select an image file to upload.";
    }

    // If everything is ok, try to upload file
    if(empty($error) && !empty($fileName)){
        if(move_uploaded_file($fileTmp, $largeImageLoc)){
            // File permission
            chmod($largeImageLoc, 0777);
            
            // Get dimensions of the original image
            list($width_org, $height_org) = getimagesize($largeImageLoc);
            
            // Get image coordinates
            $x = (int) $_POST['x'];
            $y = (int) $_POST['y'];
            $width = (int) $_POST['w'];
            $height = (int) $_POST['h'];

            // Define the size of the cropped image
            $width_new = $width;
            $height_new = $height;
            
            // Create new true color image
            $newImage = imagecreatetruecolor($width_new, $height_new);
            
            // Create new image from file
            switch($fileType) {
                case "image/gif":
                    $source = imagecreatefromgif($largeImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    $source = imagecreatefromjpeg($largeImageLoc); 
                    break;
                case "image/png":
                case "image/x-png":
                    $source = imagecreatefrompng($largeImageLoc); 
                    break;
            }
            
            // Copy and resize part of the image
            imagecopyresampled($newImage, $source, 0, 0, $x, $y, $width_new, $height_new, $width, $height);
            
            // Output image to file
            switch($fileType) {
                case "image/gif":
                    imagegif($newImage, $thumbImageLoc); 
                    break;
                case "image/pjpeg":
                case "image/jpeg":
                case "image/jpg":
                    imagejpeg($newImage, $thumbImageLoc, 90); 
                    break;
                case "image/png":
                case "image/x-png":
                    imagepng($newImage, $thumbImageLoc);  
                    break;
            }
            
            // Destroy image
            imagedestroy($newImage);
		unlink("images/timeline/".$_POST['oldfile']);
		unlink("images/timeline/".$_POST['oldfile']);
    }
	}
	}
	$update = "update `medical_registration` set  
		`timeline_img` = '".$fileName."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update medical_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:hospital-profile");
}

if(isset($_POST['update_tps'])){
	if(!empty($_FILES['image']['name'])){
		$img = fileUpload("images/timeline/", $_FILES['image'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/timeline/".$_POST['oldfile']);
		}
	} else {
		 $img= $_POST['oldfile'];
	}
	$update = "update `medical_registration` set  
		`timeline_img` = '".$img."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:hospital-profile.php");
		
}

if(isset($_POST['update_avl_doc']))
{
	if(!empty($_FILES['photo']['name'])){
		$img = fileUpload("images/profile/", $_FILES['photo'], "jpg|png|jpeg", true);
		if(!empty($img)){
			unlink("images/profile/".$_POST['oldfile']);
		}
	} else {
		 $img= $_POST['oldfile'];
	}
	
	$update = "update `available_doc_info_hospital_reg` set  
		`doc_img` = '".$img."'
		where `H_id` = '".$_SESSION['userId']."' and `id` = '".$_POST['doctId']."'
		";
		
		mysqli_query($conn,$update) or die(mysqli_error());
		$update_query = mysqli_query($conn,"update medical_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
          
		header("location:/hospital-profile#avldoctor");
}


if(isset($_POST['update_contact'])){
	$update = "update `medical_registration` set  
		`phone_no` = '".$_POST['PcountryCode']."-".$_POST['stdCode']."-".$_POST['phoneNo']."', 
		`mobile_no` = '".$_POST['countryCode']."-".$_POST['mobileNo']."',  
		`address` = '".$_POST['address']."', 
		`country` = '".$_POST['country']."', 
		`state` = '".$_POST['state']."',  
		`city` = '".$_POST['city']."',
		`O_contact`= '".$_POST['OcountryCode']."-".$_POST['OstdCode']."-".$_POST['OphoneNo']."',
		`O_time_to_call`= '".$_POST['O_time_to_call']."',
		`O_email`= '".$_POST['O_email']."',
		`O_website`= '".$_POST['O_website']."',
		`O_message`= '".$_POST['O_message']."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$update) or die(mysqli_error());
		header("location:/hospital-profile#contact");
}


if(isset($_POST['update_genral'])){
		$query="update medical_registration set 
		`name`= '".$_POST['name']."',
		`registration_no`= '".$_POST['registration_no']."',
		`registration_authority`= '".$_POST['registration_authority']."',
		`specialisation` = '".implode("|",$_POST["specialisation"])."',
		`noOfBeds`= '".$_POST['noOfBeds']."',
		`private_room`=  '".$_POST['private_room']."', 
		`hospital_category`= '".$_POST['hospital_category']."',
		`clinical_test`= '".$_POST['clinical_test']."',
		`ambulance`= '".$_POST['ambulance']."',
		`summary`= '".$_POST['summary']."',
		`heyear`= '".$_POST['heyear']."',
		`extra_feature` = '".$_POST['ambulance'].",".$_POST['icu'].",".$_POST['esi'].",".$_POST['cghs']."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#general");
}

if(isset($_POST['add_facility'])){
		if(!empty($_POST['oldData'])){
			$available_facility = $_POST['oldData'] . "-|-" . $_POST['available_facility'];
		} else {
			$available_facility =  $_POST['available_facility'];
		}
		$query="update medical_registration set 
		`available_facility`= '".$available_facility."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#facility");
}

if(isset($_POST['update_facility'])){
		$query="update medical_registration set 
		`available_facility`= '".implode("-|-",$_POST['available_facility'])."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#facility");
}

if(isset($_POST['add_infra'])){
		if(!empty($_POST['oldData'])){
			$special_infra = $_POST['oldData'] . "-|-" . $_POST['special_infra'];
		} else {
			$special_infra =  $_POST['special_infra'];
		}
		$query="update medical_registration set 
		`special_infra`= '".$special_infra."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#infastructure");
}

if(isset($_POST['update_infra'])){
		$query="update medical_registration set 
		`special_infra`= '".implode("-|-",$_POST['special_infra'])."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#infastructure");
}

if(isset($_POST['add_machine'])){
		if(!empty($_POST['oldData'])){
			$special_machine = $_POST['oldData'] . "-|-" . $_POST['special_machine'];
		} else {
			$special_machine =  $_POST['special_machine'];
		}
		$query="update medical_registration set 
		`special_machine`= '".$special_machine."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#machine");
}

if(isset($_POST['update_machine'])){
		$query="update medical_registration set 
		`special_machine`= '".implode("-|-",$_POST['special_machine'])."',
		`update_date` = '".$current_date."'	
		where `id` = '".$_SESSION['userId']."'
		";
		mysqli_query($conn,$query) or die(mysqli_error());
		header("location:/hospital-profile#machine");
}

if(isset($_POST['update_other_info'])){
		
		$data = " `phone` = '".$_POST['PcountryCode']."-".$_POST['stdCode']."-".$_POST['phoneNo']."', 
		`mobile` = '".$_POST['countryCode']."-".$_POST['mobileNo']."',  
		`address` = '".$_POST['address']."', 
		`country` = '".$_POST['country']."', 
		`state` = '".$_POST['state']."',  
		`city` = '".$_POST['city']."', 
		`Name` = '".$_POST['name']."', 
		`email` = '".$_POST['email']."', 
		`website` = '".$_POST['website']."', 
		`zipcode` = '".$_POST['zipcode']."',
		`update_date` = '".$current_date."'	
		 
		";
		$table = "hospital_private_info";
		$count = countRow($table, " where hospitalId = '".$_SESSION['userId']."' ");
		if($count>0){
			$query = " update " .$table.' set '.$data . "where hospitalId = '".$_SESSION['userId']."'";
			mysqli_query($conn,$query) or die(mysqli_error());
		} else {
			$query = " insert into " .$table.' set '.$data . ", hospitalId = '".$_SESSION['userId']."'";
			mysqli_query($conn,$query) or die(mysqli_error());
		}
		$update_query = mysqli_query($conn,"update medical_registration set `update_date` = '".$current_date."' where id = '".$_SESSION['userId']."' ");
		header("location:/hospital-profile#personal");
}
if(isset($_GET['act']) && $_GET['act']=="delDoc"){

	$del = "delete from available_doc_info_hospital_reg where `H_id` = '".$_SESSION['userId']."' and `id` = '".$_GET['id']."' ";

	mysqli_query($conn,$del) or die(mysqli_error());
	header("location:/hospital-profile#avldoctor");
}


//Specialisation List
$resHD = mysqli_query($conn,"SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}

//Hospital Category List
$resHD = mysqli_query($conn,"SELECT * FROM hospital_cat") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$hospital_cats[$data['id']] = utf8_encode($data['category_name']); 
		$c++;
	}		
}

//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$qualifications[$data['id']] = utf8_encode($data['qualification']); 
		$c++;
	}		
}



$resHD = fetchData(' `medical_registration` ', " where id='".$_SESSION['userId']."' ");
$hosids = $resHD['id'];
$hosuserid = $resHD['user_id'];
$res_rating = fetchAllData(" `newrating` ", " where user_id='" . $hosids . "' and rateusertype='hospital' ");
?>
<style type="text/css">
	@media (max-width: 767px)
	{
       .recontainer{
         margin-top: 150px;
       }  
	}
</style>


<div class="container">
	<div class="drmf-main-banner-top col-md-12" id="hos-banner-sp">
		<div class="row">
		<a href="/profile-edit-pages/timeline_pic.php" class="ajax" title="Click to Change Image">
			<? if ($resHD['timeline_img'] != "") { ?>
						<img class="img-responsive" src="/images/timeline/<? echo $resHD['timeline_img'] ?>">
					<? } else { ?>
						<img class="img-responsive" src="/images/about.png">
				<? } ?>
				</a>
		</div>
	</div>
	<div class="col-md-12 drmf-main-section1">
		<div class="row">
			<div class="col-md-4">
				<? if ($resHD['pro_img'] != "") { ?>
					<img src="/images/profile/<?= $resHD['pro_img'] ?>" /><a href="/profile-edit-pages/profile-pic.php" class="ajax1"><i class="far fa-edit"></i></a>
				<? } else { ?>
					<img src="/images/hospital.png" /><a href="/profile-edit-pages/profile-pic.php" class="ajax1"><i class="far fa-edit"></i></a>
				<? } ?>
			</div>
			<div class="col-md-8">
				<h1><?= ucwords($resHD['name']); ?></h1>
				<div class="rating-container rating-xs rating-animate col-sm-12">
						<? $r = 0;
						$i = 0;
						foreach ($res_rating as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}

						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
					<a href="#review-down">
						<div class="rating">
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						</div>
					</a>
				</div>
				<div class="drmf-main-describe col-sm-12">
				<!--	<p class="drmf-110"><span class="text-center">25 years</span></p> -->
					   <p class="drmf-111">
		<?
		$specialisation = explode("|", $resHD['specialisation']);
		$i = 0;
		foreach ($specialisation as $spl) {
			if($i == 0){
		 echo $specialisations[$spl];
			}else{
				
				
			}
		$i++; 
		}
			
		?></p>
				</div>
				<? if($resHD['summary'] != "") {?>
					<div class="col-sm-12">
						<p><?= $resHD['summary']?></p>
					</div>
				<? } ?>
			</div>
		</div>
	</div>

	<div class="col-md-12" id="info-detail-single-p">
		<span id="general"></span>
		<h2>General Information<span class="eright float-right"><a href="/profile-edit-pages/hospital-genral.php" class="ajax" ><i class="far fa-edit"></i></a></span></h2>
	
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-info-circle"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration No.</b></p>
					<p><?= $resHD['registration_no'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-address-card"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration Authority</b></p>
					<p><?= $resHD['registration_authority'] ?></p>
				</div>
			</div>
		</div>


		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-hospital-user"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Private Room</b></p>
					<p><?= $resHD['private_room'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-bed"></i>
				</div>
				<div class="show-main-p1">
					<p><b>No. Of Beds</b></p>
					<p><?= $resHD['noOfBeds'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-notes-medical"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Clinical Test Available</b></p>
					<p><?= $resHD['clinical_test'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-ambulance"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Ambulance Available</b></p>
					<p><?= $resHD['ambulance'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-briefcase-medical"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Medical Category</b></p>
					<p><?= $hospital_cats[$resHD['hospital_category']] ?></p>
				</div>
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
		<div class="col-md-12 info-specialise" id="info-detail-single-p">
		<p class="sp-li-title">Specialisations</p>
	
		<?
		$specialisation = explode("|", $resHD['specialisation']);
						foreach ($specialisation as $spec) {
						if($specialisations[$spec] == ''){}else{						 
											?>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Specialisation</b></p>
					<p><?php echo $specialisations[$spec]."&nbsp;&nbsp;"; ?></p>
				</div>
			</div>
		</div>
		<?php 
		}
     	}
		
		?>
	
	
	</div>
	
	


	<div class="col-md-12" id="info-detail-single-p">
	<span id="contact"></span>
		<h3>Contact Information <span class="eright float-right"><a href="/profile-edit-pages/ContactV2Hospital.php" class="ajax" ><i class="far fa-edit"></i></a></span></h3>
		<?php if($resHD['phone_no'] == '+91-'){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Phone No</b></p>
					<p>+<?= $resHD['phone_no'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['mobile_no'] == '+91-' || $resHD['mobile_no'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p>+<?= $resHD['mobile_no'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['email'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-envelope"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Email</b></p>
					<p><a href="mailto:<?= $resHD['email'] ?>"><?= $resHD['email'] ?></a></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['O_website'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-globe-asia"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Website</b></p>
					<p><a href="<?= $resHD['O_website'] ?>"><?= $resHD['O_website'] ?></a></p>
				</div>
			</div>
		</div>
		<?php } ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-clock"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Time to call</b></p>
					<p><?= $resHD['O_time_to_call'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-map-marker-alt"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Address</b></p>
					<p><?= $resHD['address'] ?></p>
				</div>
			</div>
		</div>


	</div>
	
<? $resPD = fetchData(' `hospital_private_info` ', " where hospitalId='".$_SESSION['userId']."' "); ?>

	<div class="col-md-12" id="info-detail-single-p">
	<span id="personal"></span>
		<h3>Personal Information <span class="eright float-right"><a href="/profile-edit-pages/hospital-other-information.php" class="ajax" ><i class="far fa-edit"></i></a></span></h3>
			<?php if($resPD['Name'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Name</b></p>
					<p><?= $resPD['Name'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resPD['phone'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Phone No</b></p>
					<p>+<?= $resPD['phone'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resPD['mobile'] == '+91-' || $resPD['mobile'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p>+<?= $resPD['mobile_no'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resPD['email'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-envelope"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Email</b></p>
					<p><a href="mailto:<?= $resPD['email'] ?>"><?= $resPD['email'] ?></a></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resPD['website'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-globe-asia"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Website</b></p>
					<p><a href="<?= $resPD['website'] ?>"><?= $resPD['website'] ?></a></p>
				</div>
			</div>
		</div>
		<?php } ?>
	
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-map-marker-alt"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Address</b></p>
					<p><?= $resPD['address'] ?></p>
				</div>
			</div>
		</div>


	</div>
	
		<? 
		
		   $resDPI = fetchAllData(" `available_doc_info_hospital_reg` ", " WHERE H_id = '" . $resHD['id'] . "' ");
	   if(!empty($resDPI)){
 
	?> 
	   <div class="col-md-12 experin-detail-p" id="main-table-sty">
	   <span id="avldoctor"></span>
		<h4>Available Doctors<span class="eright float-right">
		<a href="/profile-edit-pages/add-doctor-available-in-hospital.php" class="ajax" >
			<i class="fa fa-plus" aria-hidden="true"></i>
		</a>
		</span>
		</h4>
		<div class="col-md-12 show1" id="show2">
			<table class="table">
		
			<tbody>
			<?php 	foreach ($resDPI  as $D) {
           $DPI = fetchData(" `doctor_registration` ", " where id = '" . $D['doctor_id'] . "' "); 
		   if($DPI['name'] ==  ''){}else{
            ?>
				<tr>
				<td><?= $DPI['name'] ?> - <a class="ajax" href="/doctor-available-in-hospital.php?id=<?= $D['id'] ?>"> View Timing</a></td>
					<td>	<?php
												$specialisation = explode("|", $DPI['specialisation']);
												foreach ($specialisation as $spl) {
													$spliOther = explode(":", $spl);
													if ($spliOther[0] == "Other") {
														echo $spliOther[1] . "<br/>";
													} else {
														echo $specialisations[$spl] . "&nbsp;";
													}
												}
												?> -
					<a class="ajax" href="/profile-edit-pages/add-edit-available-in-hospital.php?id=<?=$D['id']?>"> <i class="far fa-edit"></i></a> &nbsp; 
					<a  onclick="delDoctor('<?=$D['id']?>')"> <i class="glyphicon glyphicon-trash"></i></a>
												
</td>
					
				</tr>
		   <?php }} ?>
			</tbody>
		</table>
		</div>
		</div>
	<?php } ?>
	
	
	
	<?php if($resHD['available_facility'] == ''){}else{?>
	
	<div class="col-md-12 experin-detail-p" id="main-table-sty">
	<span id="facility"></span>
		<h4>AVAILABLE FACILITY<span class="eright float-right"><a href="/profile-edit-pages/hospital-add-facility.php" class="ajax" ><i class="far fa-edit"></i>
</a> | <a href="/profile-edit-pages/hospital-manage-facility.php" class="ajax" ><i class="fas fa-cogs"></i>
</a></span></h4>
     <div class="col-md-12 show1" id="show1">
			<table class="table">
				<?
					$available_facility = explode("-|-", $resHD['available_facility']); 
				?>
				<tbody>
					<tr>
						<?
							foreach ($available_facility as $facility)
							{
								echo '<td>' . $facility . '</td>';
							}
						?>
					</tr>
				</tbody>
			</table>


		</div>

	</div>
	<? 
	}
		$special_infra = explode("-|-", $resHD['special_infra']);
	?>

	<div class="col-md-12 experin-detail-p" id="main-table-sty">
	<span id="infastructure"></span>
		<h4>SPECIAL INFRASTRUCTURE<span class="eright float-right">	<a href="/profile-edit-pages/hospital-add-infrastructure.php" class="ajax" ><i class="far fa-edit"></i></a> | 
								<a href="/profile-edit-pages/hospital-manage-infrastructure.php" class="ajax" ><i class="fas fa-cogs"></i></a></span></h4>
								
		<div class="col-md-12 show1" id="show1">
			<table class="table">
				<tbody>
					<tr>
						<?
						foreach ($special_infra as $infra)
						{
							echo '<td>'. $infra . '</td>';
						}
						?>
					</tr>
				</tbody>
			</table>


		</div>
	</div>

	<? 
		$special_machine = explode("-|-", $resHD['special_machine']);
	?>

	<div class="col-md-12 experin-detail-p" id="main-table-sty">
	<span id="machine"></span>
		<h4>SPECIAL MACHINERY<span class="eright float-right">
		<a href="/profile-edit-pages/hospital-add-machinery.php" class="ajax" ><i class="far fa-edit"></i></a> | 
								<a href="/profile-edit-pages/hospital-manage-machinery.php" class="ajax" ><i class="fas fa-cogs"></i></a></span></h4>

								
		<div class="col-md-12 show1" id="show1">
			<table class="table">
				<tbody>
					<tr>
						<?
						foreach ($special_machine as $machine)
						{
							echo '<td>' . $machine . '</td>';
						}
						?>
					</tr>

				</tbody>
			</table>


		</div>
	</div>

<!--accordian
	<div class="col-md-12 drmf-main-accordion">
		<p class="ac-btn-title">Frequently Asked Questions</p>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
	</div>
-->

	<!--deals-->
	<div class="col-md-12 main-work-sl-p deal-single-p">
		<h5>Change Password</h5>
		<div class="deals-sliders" id="recommend-sdeals-2">
			<div style="width:100%;">
									<form method="post" action="change_password">
										<div class="form-group">
											<label for="exampleInputPassword1">Old Password</label>
											<input type="text" class="form-control" id="Old_Password" placeholder="Old Password" value="<?=$resHD['password']?>" required>
											<input type="hidden" id="Opass" value="<?=$resHD['password']?>">
											<span class="error" id="error_oldpass"></span>
										</div>
										<div class="form-group">
											<label for="exampleInputPassword1">New Password</label>
											<input type="password" class="form-control" id="New_Password" placeholder="New Password" required>
										</div>
										<div class="form-group">
											<label for="exampleInputPassword1">Repeat Password</label>
											<input type="password" name="password" class="form-control" id="Repeat_Password" placeholder="Repeat Password" required>
											<span class="error" id="error_repeatpass"></span>
										</div>										
										<div class="form-group">
											<button type="submit" onclick="return changepass()" class="btn btn-primary">Change Password</button>
										</div>
									</form>
										
								</div>
		</div>
	</div>
	
		  
	        <div class="col-md-12 main-work-sl-p deal-single-p">
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-deal.php">Manage Deals</a></h4>
      </div>
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-blog.php">Manage Blog</a></h4>
      </div>
	  <div class="col-md-4 text-left">
		<h4><a href="/manage-ads.php">Manage Advertisment</a></h4>
      </div>
     </div>
	
	
	
	<div class="col-md-12">
		<div class="single-p-review" id="review-down">
			<div class="col-md-6">
				<div class="single-set-rating text-center">
					<p class="p-rate-1"><b>Overall Rating</b></p>
  <div class="rating-container rating-xs rating-animate col-sm-12">
					<div class="single-p-rating rating">
				
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						
					</div>
					</div>
					<p class="p-rate-2">Based on <?php echo $count; ?> Experiences</p>
				</div>
			</div>
			<div class="col-md-6">
				<div class="single-set-rating2 text-center">
					<p class="p-rate-1"><b>Rate your experience</b></p>
					<p class="p-rate-2">How likely are you to recommend us?</p>
					<div class="single-p-rating1">
					<a href="/rating/<?= $hosuserid ?>">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	
<div class="col-md-12 tab-pane" id="comments">
<div class="col-md-12 news-single-p">
	<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h6>Comments</h6>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
					
					</div>
				</div>
			</div>
	</div>
	<? include('review.php'); ?>

	</div>
	</div>

</div>



<script>
	function delDoctor(id){
		if(confirm("Are you sure delete this.")){
			window.location="/hospital-profile.php?id=" + id + "&act=delDoc";
		}
	}

	function reportOnComment(str) {
		
	  var xhttp;

	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
				document.getElementById("report").innerHTML = xhttp.responseText;
			
		}
	  };
	  xhttp.open("GET", "/ajax-file/report-on-hospital.php?id="+str, true);
	  xhttp.send();  
	  
	}
	function changepass(){
		var curentpass = document.getElementById('Opass').value;
		var Oldpass = document.getElementById('Old_Password').value;
		var newpass = document.getElementById('New_Password').value;
		var repass = document.getElementById('Repeat_Password').value;
		if(Oldpass==""){
			var msg1="Please type Old Password!";
			document.getElementById('error_oldpass').innerHTML=msg1;
			return false;
		}
		if(curentpass!=Oldpass){
			var msg="You have type wrong password!";
			document.getElementById('error_oldpass').innerHTML=msg;
			return false;
		}	
		if(newpass!=repass){
			var msg2="New Password and Repeat Password did not match!";
			document.getElementById('error_repeatpass').innerHTML=msg2;
			return false;
		}		
		
		
	}
</script>  
<? include('include/footer.php'); ?>
    <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
   <script> $("document").ready(function(){$("#<?=$_GET['openTab']?>").trigger("click");}); </script> 
	 <script>
        jssor_2_slider_init();
    </script>
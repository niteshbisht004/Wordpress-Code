<?php 
	$name=$_POST['uname'];
	$mail=$_POST['umail'];
	$subject=$_POST['message'];
	
	$email_form='niteshbishtanni@gmail.com';
	$email_subject='my form submission';
	$email_body="User name: ".$name;
	$email_body="User email: ".$mail;
	$email_body="user Message: ".$subject;
	
	$to='niteshbisht004@gmail.com';
	$header="From: $email_form \r\n";
	$header="Reply To: $mail \r\n";
	
	mail($to,$email_body,$email_subject,$header);
	
	header("Location: template.html");
?>

<!DOCTYPE html>
<html>
	<head>
		<title>template form</title>
	</head>
	<body>
		<div class="container">
			<div class="form">
				<form method="post" action="template.php">
					<label>Name:
						<input type="text" name="uname"><br><br>
					</label>
					<label>E-mail:
						<input type="text" name="umail"><br><br>
					</label>
					<label>Message:
						<input type="textarea" name="message"><br><br>
					</label>
					<button type="submit" name="sub">Submit</button>
				</form>
			</div>
		</div>
	</body>
</html>
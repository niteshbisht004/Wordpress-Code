<?php

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
include('connection.php');
include('function.php');
global $specialisations;
global $qualifications;
global $hospital_cats;
global $cities;
$conn = db();

include 'config/database.php';
$database = new Database();
$db = $database->getConnection();

include 'classes/city.php';
$cityitems = new Cities($db);

include 'classes/states.php';
$stateitems = new States($db);

include 'classes/country.php';
$countryitems = new Countries($db);

include 'classes/special.php';
$specialitems = new Special($db);

include 'classes/rating.php';
$rateitems = new Ratings($db);

include 'classes/qual.php';
$qualitems = new Qual($db);

include 'classes/doctors.php';
include 'classes/hospitals.php';
include 'classes/others.php';

$data = json_decode(file_get_contents("php://input"));

$val = $_POST['cat'];
$srow = $_POST['skiprow'];
$rows = $_POST['row'];
$allArr  = array();
if ($val == 'all') {

	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}









	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	
	if($sp != '' && $term == ''){
		
	 $specidq = "specialisation = $sp OR specialisation like '%|$sp|%'";
      $res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`featured`,`arate`,`city`,`state`,`country` ,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `doctor_registration` WHERE active = 'Yes' AND $specidq order by featured DESC, arate DESC LIMIT 0,10");	
	  
	  foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}	
		
		
	}else{
	 $docterms = "( doctor_registration.name LIKE '%$term%' )";
	$hosterms = "( medical_registration.name LIKE '%$term%' )";
    $othterms = "( other_service_registration.name LIKE '%$term%' )";
 
	$searchTermsn = explode(' ', $term);
	
    $removevalue = array('Dr','Doctors','Hospitals','doctor','hospital','Doctor','Hospital','and','in','is','kumar','Ji','A','J.','O.P','AK','Dr.','Clinic');
	
    $searchTermsn = array_diff($searchTermsn, $removevalue );
	
	foreach ($searchTermsn as $terms) {
    $terms = trim($terms);
    if (!empty($terms)) {
        if($terms == ''){}else{
		$searchTermBitsplsn[] = "( name LIKE '%$terms%' )";
        }
		
	    }
		
    }
	
	$orderbydatas = implode( ' + ' , $searchTermBitsplsn );

	
	foreach($searchTermsn as $val){
		if($val == ''){}else{
		$add .=" OR name like '%$val%' ";
		}
	}

	$docname = mysqli_query($conn,"select * from `doctor_registration` where active='Yes' AND name = '$term' order by id DESC");
	
	$docnamerows = mysqli_num_rows($docname);
	
		if($sp == '' && $docnamerows >= 1){
	$docval = mysqli_fetch_array($docname);	
	$sp = $docval['specialisation'];
	$specidqs = "OR specialisation = $sp";
	
	}
	
	$hosname = mysqli_query($conn,"select * from `medical_registration` where active='Yes' AND name = '$term' order by id DESC");
		
	$hosnamerows = mysqli_num_rows($hosname);
	
	if($sp == '' && $hosnamerows >= 1){
	$hosval = mysqli_fetch_array($hosname);	
	$sp = $hosval['specialisation'];
	$sps = explode("|",$sp);
	$specidqh = "OR specialisation = $sps[0]";
	}
	
	$othname = mysqli_query($conn,"select * from `other_service_registration` where active='Yes' AND name = '$term' order by id DESC");
		
	$othnamerows = mysqli_num_rows($othname);
	
	if($sp == '' && $othnamerows >= 1){
	$othval = mysqli_fetch_array($othname);	
	$sp = $othval['specialisation'];
	$sps = explode("|",$sp);
	$specidqo = "OR specialisation = $sps[0]";
	}
	  	
	if($docnamerows >= 1 || $hosnamerows >= 1  || $othnamerows >= 1){
	
	$res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country` ,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `doctor_registration` WHERE active = 'Yes' AND (name like '%$term%') $specidqs UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country` ,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `medical_registration` WHERE active = 'Yes' AND (name like '%$term%') $specidqh UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country` ,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `other_service_registration` WHERE active = 'Yes' AND (name like '%$term%') $specidqo ORDER BY name LIKE '%$term%' DESC Limit 0,20");

		

	foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}


	}else{
		
	$speciliationqs = mysqli_query($conn,"select * from `specialisation` where specialisation = '$term' OR keyword like '%$term%' order by id DESC");
		
  
	$num_specs = mysqli_num_rows($speciliationqs);
		
	if($num_specs > 0){
		
	//$specidq = array();
	$y = 0;
	
	while($rowq = mysqli_fetch_array($speciliationqs)){
	$idg = $rowq['id'];
	$specidq .= "OR specialisation = $idg OR specialisation like '%$idg|%' OR specialisation like '%|$idg%' OR specialisation like '%|$idg|%'";
	}
	
	
	
    $res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees` ,`featured`,`arate` ,`last_login`, `update_date` FROM `doctor_registration` WHERE active = 'Yes' AND specialisation = 'fsdfdsf' $specidq UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` ,`last_login`, `update_date` FROM `medical_registration` WHERE active = 'Yes' AND specialisation = 'fsdfdsf' $specidq UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` ,`last_login`, `update_date` FROM `other_service_registration` WHERE active = 'Yes' AND specialisation = 'fsdfdsf' $specidq order by featured DESC, arate DESC ,  last_login DESC, update_date");
	
	foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}

	
	
	}else{
	
	
	$search_item=addslashes($term);
	
	$string = explode(" ", $search_item);  

	$omit_words = array('the','for','in','or','to','and','doctors','hospitals','hospital','others','deals','Dr','Skin','Problems','doctor','sector','Sector','Hospital','A','J.','O.P','AK','Clinic','Dr.');  
	
	$result = array_diff($string,$omit_words);
			
    foreach($result as $val){
		
	if($val == ''){
	
  					 
	}else{
		
	$keywordsqt .= " or keywords like '%$val%' OR keywords = '$val'";				
	
    $keywordsqsu .= " or keyword like '%$val%' OR keyword = '$val'";	
    
	$speckeywordsr[] = "( specialisation.keyword LIKE '%$val%' )";
	
	$diseasekeywordse[] = "( disease.keywords LIKE '%$val%' )";
    	
	}
	
	}
	
	
	$orderbydataspeci = implode( ' + ' , $speckeywordsr );
	$orderbydatahdise = implode( ' + ' , $diseasekeywordse );
    
    
	 $speciliationq = mysqli_query($conn,"select * from `specialisation` where keyword like '%$term%' $keywordsqsu ORDER BY ( ".$orderbydataspeci." ) DESC") ;
	
	
    $num_spec = mysqli_num_rows($speciliationq);
	
	$specidq = array();
	$yy = 0;
	if($num_spec > 0){
	while($rowq = mysqli_fetch_array($speciliationq)){
		
		if($yy > 1){
			
		}else{
		$idgs = $rowq['id'];
	$specidq = "specialisation = $idgs";
		}
	$yy++;
	
	}
    
	$res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `doctor_registration` WHERE active = 'Yes' AND $specidq   UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `medical_registration` WHERE active = 'Yes' AND $specidq  UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `other_service_registration` WHERE active = 'Yes' AND $specidq order by featured DESC, arate DESC");
	
		
	foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}


		
	}else{        
	$query_disease=mysqli_query($conn,"select * from `disease` where keywords like '%$term%' $keywordsqt ORDER BY ( ".$orderbydatahdise." ) DESC");
		
     
	
    $num_disease = mysqli_num_rows($query_disease);	
	$yys = 0;
	$specid = array();
	if($num_disease > 0){
	while($row = mysqli_fetch_array($query_disease)){
		
	if($yys > 1){
			
		}else{
		$idgs = $row['id'];
	$specidq = "specialisation = $idgs";
		}
	$yys++;
	
		$res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `doctor_registration` WHERE active = 'Yes' AND $specidq  UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `medical_registration` WHERE active = 'Yes' AND $specidq  UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees`,`featured`,`arate` FROM `other_service_registration` WHERE active = 'Yes' AND $specidq order by featured DESC, arate DESC");
	
		
	foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}


	
	}
	}else{
		
	
	$res_all = fetchAllsearchDatas("SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `doctor_registration`  WHERE active = 'Yes' AND (name like '%$term%') $specidqs  UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `medical_registration` WHERE active = 'Yes' AND (name like '%$term%') $specidqh  UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active`,`city`,`state`,`country`,`phone_no`,`mobile_no`,`registration_no`,`fees` FROM `other_service_registration` WHERE active = 'Yes' AND (name like '%$term%') $specidqo ORDER BY name LIKE '%$term%' DESC  Limit 0,20");
    
		
	foreach ($res_all as $row) {

     include 'allsearchinclude.php';
					
			}


		
	}
   	}
	}
	}

	}
	
	
	




	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC");

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC");

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC");



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar', 'Dr.', 'dr.');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " AND (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}
     
	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	$term = str_replace('Dr. ', '', $term);
	$term = str_replace('dr. ', '', $term);

	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
	
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date");
		$tcount = count($res_doctorc);
		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {

              include 'adocsearchinclude.php';

						
			}


			
		} else {



			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date" );
			$tcount = count($res_doctorc);
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		$sps = $_POST['specialisation'];
		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  active='Yes' AND specialisation = '$sps' order by featured DESC, arate DESC LIMIT $srow,$rows ");
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  active='Yes' AND specialisation = '$sps' order by featured DESC, arate DESC");
		$tcount = count($res_doctorc);
		

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'  $cityq AND $addressq order by featured DESC, arate DESC LIMIT $srow,$rows");


		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'  $cityq  AND $addressq order by featured DESC, arate DESC");
		$tcount = count($res_doctorc);

		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		} else {

			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  active='Yes'  $cityq AND $addressq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq active='Yes'  $cityq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");
			$tcount = count($res_doctorc);
			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

				 include 'adocsearchinclude.php';
				}


			
			} else {

				$res_doctor = fetchAllData(" `doctor_registration`", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_doctorc = fetchAllData(" `doctor_registration`", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_doctorc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

						   include 'adocsearchinclude.php';
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  active='Yes'  $cityq AND $addressq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'  $cityq AND $addressq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");
		$tcount = count($res_doctorc);
		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {

               include 'adocsearchinclude.php';
				
			}


			
		} else {

			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'  $cityq AND $specq order by featured DESC, arate DESC LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' $cityq AND $specq order by featured DESC, arate DESC");
			$tcount = count($res_doctorc);
			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

				   include 'adocsearchinclude.php';
					
				}


			
			} else {

				$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC,  last_login DESC, update_date");
				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {

							   include 'adocsearchinclude.php';
					}


				
				} else {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		}
	} else {

  	$docnamet = mysqli_query($conn, "select * from `doctor_registration` where active ='Yes' AND name like '%$term%' order by id DESC");
	


	$docnamerows = mysqli_num_rows($docnamet);
	$docval = mysqli_fetch_array($docnamet);	
	$sp = $docval['specialisation'];
	$specidqn = "AND specialisation = $sp OR specialisation like '%|$sp|%'";
		if (($num_disease > 0 or $num_spec > 0 or $num_specs > 0) && $docnamerows == 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval or specialisation like '%|$sval|%'";
				}
			}

			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {

					$redp .= " or specialisation = $svalq or specialisation like '%|$svalq|%'";
				}
			}


				


			if ($addressq == '') {

				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redp ) $cityq order by featured DESC, arate DESC,  last_login DESC, update_date LIMIT $srow,$rows");
		

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redp ) $cityq order by featured DESC, arate DESC,  last_login DESC, update_date");
				$tcount = count($res_doctorc);
			} else {

				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE active='Yes'  AND (specialisation = 79878979  $redp ) AND  $addressq  $cityq order by featured DESC, arate DESC,  last_login DESC, update_date LIMIT $srow,$rows");
				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE active='Yes'  AND  (specialisation = 79878979  $redp ) AND $addressq $cityq order by featured DESC, arate DESC,  last_login DESC, update_date");
				$tcount = count($res_doctorc);
			}



			if (!empty($res_doctor)) {
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

 
					   include 'adocsearchinclude.php';
	
				}


			
			} else {



				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE active='Yes'  specialisation = 79878979  $redp order by featured DESC, arate DESC,  last_login DESC, update_date LIMIT $srow,$rows");

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE active='Yes' specialisation = 79878979  $redp order by featured DESC, arate DESC,  last_login DESC, update_date");

				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				} else {


					$res_doctor = fetchAllData(" `doctor_registration` ","WHERE active='Yes' order by featured DESC, arate DESC,  last_login DESC, update_date LIMIT $srow,$rows");
					$res_doctorc = fetchAllData(" `doctor_registration`" ,"WHERE active='Yes' order by featured DESC, arate DESC,  last_login DESC, update_date");
					$tcount = count($res_doctorc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		} else {


			$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  active='Yes' AND (name = '$term' OR name like '%$term%') $specidqn  ORDER BY %$term% DESC LIMIT $srow,$rows");
          
			$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE active='Yes' AND (name = '$term' OR name like '%$term%') $specidqn ORDER BY %$term% DESC ");

			$tcount = count($res_doctorc);

			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {


					   include 'adocsearchinclude.php';
				}


			
			} else {


				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  active='Yes' AND (name = '$term' OR name like '%$term%' $searchTermBits) ORDER BY ( " . $orderbydata . " ) DESC LIMIT $srow,$rows");

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE active='Yes' AND (name = '$term' OR name like '%$term%' $searchTermBits) ORDER BY ( " . $orderbydata . " ) DESC");


				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				} else {



					$res_doctor = fetchAllData(" `doctor_registration` ","WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
					$res_doctorc = fetchAllData(" `doctor_registration`" ,"WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date");
					$tcount = count($res_doctorc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		}
	}



	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC");

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC");

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC");



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC ");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " AND (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	if ($hosnamerows > 0 or $othnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}









	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  active='Yes' $cityq order by featured DESC, arate DESC LIMIT $srow,$rows");
		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  active='Yes'  $cityq order by featured DESC, arate DESC");
		$tcount = count($res_hospitalc);
		if (!empty($res_hospital)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		} else {



			$res_hospital = fetchAllData(" `medical_registration` ","WHERE  active='Yes' order by featured DESC, arate DESC LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration`","WHERE  active='Yes' order by featured DESC, arate DESC");
			$tcount = count($res_hospitalc);
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		$sps = $_POST['specialisation'];
		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes' AND (specialisation = $sps OR specialisation LIKE '%|$sps|%') order by featured DESC, arate DESC  LIMIT $srow,$rows");
		
		
		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' AND (specialisation = $sps OR specialisation LIKE '%|$sps|%') order by featured DESC, arate DESC");

		$tcount = count($res_hospitalc);
	//	if (!empty($res_hospital)) {

				foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}
		/*} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq ORDER BY featured DESC,arate DESC,  last_login DESC, update_date LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq ORDER BY featured DESC,arate DESC,  last_login DESC, update_date");
			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
			} else {

				$res_hospital = fetchAllData(" `medical_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_hospitalc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
				}


			
			}
		}*/
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes'  $cityq AND $addressq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq AND $addressq order by featured DESC, arate DESC, last_login DESC, update_date");

		$tcount = count($res_hospitalc);

		if (!empty($res_hospital)) {
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date");

			$tcount = count($res_hospitalc);

			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				
				}


			
			} else {

				$res_hospital = fetchAllData(" `medical_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_hospitalc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes'  $cityq AND $addressq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes'  $cityq AND $addressq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");

		$tcount = count($res_hospitalc);

		if (!empty($res_hospital)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
			}


			
		} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' $cityq AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");
			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				}


			
			} else {

				$res_hospital = fetchAllData(" `medical_registration` ", "WHERE active='Yes'AND  $specq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				} else {


					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					}


				
				}
			}
		}
	} else {

     	$hosnamet = mysqli_query($conn, "select * from `medical_registration` where active= 'YES' AND name like '%$term%' order by id DESC");
      
	$hosnamerowst = mysqli_num_rows($hosnamet);
	

		if (($num_disease > 0 or $num_spec > 0 or $num_specs > 0) && $hosnamerowst == 0) {
			
			

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {
                 $redps .= " or specialisation = $sval or specialisation like '%|$sval|%'";
					
				}
			}

			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {
                  $redps .= " or specialisation = $svalq or specialisation like '%|$svalq|%'";
					
				}
			}

			if ($addressq == '') {

				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redps ) $cityq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redps )  $cityq order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_hospitalc);
			} else {

				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redps ) $cityq AND $addressq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE active='Yes'  AND (specialisation = 79878979  $redps )  $cityq AND $addressq order by featured DESC, arate DESC, last_login DESC, update_date");
				$tcount = count($res_hospitalc);
			}



			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				
				}


			
			} else {


				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE active='Yes'  AND (specialisation = 79878979  $redps) order by featured DESC, arate DESC LIMIT $srow,$rows");

				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE active='Yes'  AND (specialisation = 79878979  $redps) order by featured DESC, arate DESC");

				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
						
					}


				
				} else {


					$res_hospital = fetchAllData(" `medical_registration` ", " WHERE active='Yes' order by featured DESC, arate DESC LIMIT $srow,$rows");
					$res_hospitalc = fetchAllData(" `medical_registration`", " WHERE active='Yes' order by featured DESC, arate DESC");
					$tcount = count($res_hospitalc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				}
			}
		} else {


			$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  active='Yes' AND (name = '$term' or name like '%$term%' )  ORDER BY '%$term%' DESC LIMIT $srow,$rows");
			
			
			$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE active='Yes' AND (name = '$term' or name like '%$term%') ORDER BY '%$term%' DESC");

			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
					
				}


			
			} else {


				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  active='Yes' AND (name = '$term' or name like '%$term%' $searchTermBits) ORDER BY '%$term%' DESC LIMIT $srow,$rows");

				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  active='Yes' AND (name = '$term' or name like '%$term%' $searchTermBits) ORDER BY '%$term%' DESC");

				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				} else {


					

					$res_hospital = fetchAllData(" `medical_registration` ", " WHERE active='Yes' order by featured DESC, arate DESC LIMIT $srow,$rows");
					$res_hospitalc = fetchAllData(" `medical_registration`", " WHERE active='Yes' order by featured DESC, arate DESC");
					$tcount = count($res_hospitalc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				}
			}
		}
	}

   
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC");

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC");

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC");



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " AND (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}

       


	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {
            
		$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
      
		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

     
				include('aothsearchinclude.php');
				
			}


			
		} else {



			$res_om = fetchAllData(" `other_service_registration`", "WHERE active='Yes' $cityq order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

			include('aothsearchinclude.php');
				
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		
		$sps = $_POST['specialisation'];
		$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' AND (specialisation = $sps OR specialisation LIKE '%|$sps|%') order by featured DESC, arate DESC, last_login DESC, update_date  LIMIT $srow,$rows");
             
		

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {
                
			include('aothsearchinclude.php');
				
			}

/*
		if (!empty($res_oms)) {	
		} else {
			
             $sps = $_POST['specialisation'];
			$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' AND specialisation like '%$sps%' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
            

			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {
                 
				$res_om = fetchAllData(" `other_service_registration`", "WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");
               
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {
					
					

                include('aothsearchinclude.php');
				
				
				}


			
			}
			
		}*/
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes'  $cityq AND $addressq order by featured DESC, arate DESC LIMIT $srow,$rows");

		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

			include('aothsearchinclude.php');
			
			}


			
		} else {

			$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' $cityq order by featured DESC, arate DESC LIMIT $srow,$rows");


			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {

				$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' order by featured DESC, arate DESC LIMIT $srow,$rows");

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' $cityq AND $addressq AND $specq order by featured DESC, arate DESC LIMIT $srow,$rows");


		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

            include('aothsearchinclude.php');
				
			}


			
		} else {

			$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' $cityq AND $specq order by featured DESC, arate DESC LIMIT $srow,$rows");

			if (!empty($res_om)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {

				$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC LIMIT $srow,$rows");

				if (!empty($res_om)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
						
					}


				
				} else {



					$res_om = fetchAllData(" `other_service_registration` ", "WHERE active='Yes' AND $specq order by featured DESC, arate DESC, LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {
                   $redpw .= " or specialisation = $sval or specialisation like '%|$sval|%'";
					
				}
			}


			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {
                    $redpw .= " or specialisation = $svalq or specialisation like '%|$svalq|%'";
					
				}
			}

      
  
  
			if ($addressq == '') {

				$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redpw )$cityq  order by featured DESC, arate DESC LIMIT $srow,$rows");
			} else {

				$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' AND (specialisation = 79878979  $redpw ) $cityq AND $addressq  order by featured DESC, arate DESC LIMIT $srow,$rows");
			}



			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {



				$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes'  specialisation = 79878979  $redpw order by featured DESC, arate DESC LIMIT $srow,$rows");


				if (!empty($res_om)) {


					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				} else {


					$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
				
				
					}


				
				}
			}
		} else {


			$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' AND (name = '$term' or name like '%$term%' $searchTermBits) ORDER BY '%$term%' DESC  LIMIT $srow,$rows ");



			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {


				include('aothsearchinclude.php');
				}


			
			} else {


				$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' AND (name = '$term' or name like '%$term%' $searchTermBits)  ORDER BY ( " . $orderbydatao . " ) DESC  LIMIT $srow,$rows");



				if (!empty($res_om)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				} else {



					$res_om = fetchAllData(" `other_service_registration` ", " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC, update_date LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				}
			}
		}
	}



	
	
  
	
	
	
	
	

	$tcount = 30;
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC");

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC");

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC");



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {
		$sp = explode("|", $sp);
		$specq = "(specialisation like '%dfdfdfd%'";
		foreach ($sp as $vsp) {
			$specq .= "or specialisation like '%|$vsp|%' or specialisation = '$vsp'";
		}
		$specq .= ")";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}



	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq LIMIT $srow,$rows");

		if (!empty($res_deal)) {


			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

			
		} else {



			$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

		
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		if (!empty($res_deal)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq LIMIT $srow,$rows");


			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");


		if (!empty($res_deal)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

			
		} else {

			$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");

			if (!empty($res_deal)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_deal = fetchAllData(" `deals` ", "WHERE $specq LIMIT $srow,$rows");

				if (!empty($res_deal)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_deal = fetchAllData(" `deals` ", "WHERE $specq LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval";
				}
			}

             
			$res_deal = fetchAllData(" `deals` ", " WHERE  title like '%$term%' OR (specialisation = 79878979  $redp ) LIMIT $srow,$rows");

			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
           
					if ($row['doctor_id'] != '') {
                       
						
					
						$itemsd = new Doctors($db);
						
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
				
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {



				$res_deal = fetchAllData(" `deals` ", " WHERE  specialisation = 79878979  $redp OR city =  $city LIMIT $srow,$rows");


				if (!empty($res_deal)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {
					$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		} else {


			$res_deal = fetchAllData(" `deals` ", " WHERE  title = '$term' LIMIT $srow,$rows");



			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {


				$res_deal = fetchAllData(" `deals` ", " WHERE  title = '$term' LIMIT $srow,$rows");


				if (!empty($res_deal)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	}
	
	


	$tcount = 30;
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC");

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC");

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC");



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC");



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC");


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC");



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {
		$sp = explode("|", $sp);
		$specq = "(specialisation like '%dfdfdfd%'";
		foreach ($sp as $vsp) {
			$specq .= "or specialisation like '%$vsp%' or specialisation = '$vsp'";
		}
		$specq .= ")";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq LIMIT $srow,$rows");

		if (!empty($res_blog)) {


			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {



			$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

			
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		if (!empty($res_blog)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq LIMIT $srow,$rows");


			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");


		if (!empty($res_blog)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");

			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_blog = fetchAllData(" `blog` ", "WHERE $specq LIMIT $srow,$rows");

				if (!empty($res_blog)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_blog = fetchAllData(" `blog` ", "WHERE $specq LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval";
				}
			}


			$res_blog = fetchAllData(" `blog` ", " WHERE  title like '%$term%' OR (specialisation = 79878979  $redp ) LIMIT $srow,$rows");

			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {



				$res_blog = fetchAllData(" `blog` ", " WHERE  specialisation = 79878979  $redp LIMIT $srow,$rows");
				if (!empty($res_blog)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				} else {
					$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		} else {


			$res_blog = fetchAllData(" `blog` ", " WHERE  title = '$term' LIMIT $srow,$rows");



			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {


				$res_blog = fetchAllData(" `blog` ", " WHERE  title = '$term' LIMIT $srow,$rows");


				if (!empty($res_blog)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				} else {




					$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	}
	

	
	
	
	
	
	
	
}
            $specialstmt = $specialitems->getSingleSpecials($_POST['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
				$allArr['specialisationname'] = $specialname[1];
			$allArr['specialisationdescription'] = $specialname[3];
			if($specialname[4] == ''){
			$allArr['specialisationbannerimageurl'] = "https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg";
			
            }else{
				
			$allArr['specialisationbannerimageurl'] = "https://www.freemedicalinfo.in/admin/images/uploads/".$specialname[4];	
			}
			
			    $pecid = $_POST['specialisation'];
				
			$res_diease = fetchAllData("disease"," WHERE spec_id = $pecid");
			foreach ($res_diease as $des) {
		
			$allArr['specialisationkeywords'][] = $des;
			}
			//print_r($specialname);
            $response['message'] = "Data Found";
			//$response['totalcount'] = $tcount;
			$response['skiprow'] =  $srow;
			$response['row'] =  $rows;
			$response['status'] = 1;
			$response['data'] = $allArr;
		
			$json_response = json_encode($response);
			echo $json_response;
			exit;
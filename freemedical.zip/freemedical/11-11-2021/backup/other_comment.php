 <style>
 .glyphicon-thumbs-down
 {
	margin-left: 10px;
	color: #FF3F29;
 }
 .counter-down
 {
	 color: #FF3F29;
 }
 .counter-up
 {
	 color: #00916F;
 }
 .glyphicon-thumbs-up
 {
	color: #00916F;
 }
 .glyphicon-thumbs-up span.counter 
{
    color: green;
}
 </style>

<?php
	//echo $othid;
	if($othid != ''){
		
		$i=1;
		$x=1;
		$review=fetchAllData(" `newrating` ","where user_id='".$othid."' AND status = 0");
			//echo " `newrating` ","where user_id='".$othid."' AND status = 0";
			
			if (empty($review)) 
			{
				?>
				<center><a class="btn btn-success" href="/rating/<?= $oid; ?>">Rate Now</a></center>
				<?
			}else{
		foreach($review as $rate) {
		$uid=$rate['user_id'];
		$utype=$rate['rateusertype'];
		
		if($utype == 'doctor')
		{
			$res_cmt = fetchAllData(" `doctor_registration` ", " where id='".$uid."'"); 
			//echo " `doctor_registration` ", " where id='".$uid."'";
		}
		if($utype == 'other')
		{
			$res_cmt = fetchAllData(" `other_service_registration` ", " where id='".$uid."'"); 
		}
	if($utype == 'hospital')
		{
			$res_cmt = fetchAllData(" `medical_registration` ", " where id='".$uid."'"); 

			
		}
		
   foreach($res_cmt as $row)
   {  
	   $name=$row['name'];
   }

	$rid=$rate['rating_by_userid'];
	$rtype=$rate['user_type'];
	if($rtype=='user')
	{
		$ratqrys=  fetchAllData(" `users` ", " where id='".$rid."'");
			foreach($ratqrys as $rows)
			{
				$names=$rows['first_name'];
				$img=$row['pro_img'];
			}	
	}
	if($rtype=='doctor')
	{
		$ratqrys=  fetchAllData(" `doctor_registration` ", " where id='".$rid."'");
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
			}
	}
	if($rtype=='hospital')
	{
		$ratqrys=  fetchAllData(" `medical_registration` ", " where id='".$rid."'");
			
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
			}
	}
	
	if($rtype=='other')
	{
		$ratqrys=  fetchAllData(" `other_service_registration` ", " where id='".$rid."'");
		
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
				$mail=$row['email'];				
			}
			
	}	
	$r=$rate['rate'];
	if($r==0){
					$var='0%';
				}
				if($r==1)
				{
					$var='20%';
				}
				if($r==2){
					$var='40%';
				}
				if($r==3)
				{
					$var='60%';
				}
				if($r==4)
				{
					$var='80%';
				}
				if($r==5)
				{
					$var='100%';
				}
				if($img=="")
				{
					$img="profile-1.png";
				}
				
				$ratnqrys=  fetchAllData(" `rnewrating` ", " where rating_id='".$rate['id']."' AND status = 0");
				
				$cmntid=$rate['id'];
				$sqlqry="select * from cmnt_like_dislike where `rating_id`='$cmntid' && `like`=1";
				//echo $sqlqry;
				$ldrun=mysqli_query($conn,$sqlqry);
				$like=mysqli_num_rows($ldrun);
				
				$sqlqryd="select * from cmnt_like_dislike where `rating_id`='$cmntid' && `dislike`=1";
				//echo $sqlqry;
				$ldrund=mysqli_query($conn,$sqlqryd);
				$dlike=mysqli_num_rows($ldrund);

		?>
		<div class="col-md-12 review" style="padding:0px;">
		<div style="padding-left:0px; padding-right: 0px;" class="col-md-1">
		<img src="/images/profile/<?php echo $img;?>" class="wpx-100 img-round mgb-20 pb-3" style="height: 50px; width: 50px;">
		</div>
		<div  class="col-md-11">
		<div class="float-left" style="display:inline-block;">
		<p class="col-sm-12 bottom-name-h" style="padding: 0px;margin-bottom:-5px;"><?php echo $names; ?></p></div>
		<div class="pull-right">
		 
			<div class="dropdown">
				<button class="dropbtn">Action<i class="caret"></i></button>
				<div class="dropdown-content">										
				<span style="color:green" class="cmnt-btn" id="clc<? echo $i; ?>"> Reply <i class="fa fa-reply"></i></span>
				
				<?php 
					$oids = $_SESSION['userId'];
					$oidut = $_SESSION['userType'];
					$orest = fetchAllData(" `all_users` ", " where `userId`= '".$oids."' AND user_type='".$oidut."'");
					foreach($orest as $ocmnt)
					{
						$odid=$ocmnt['userId'];
						$odtype=$ocmnt['user_type'];
					}
						
					if($odid == $rid && $odtype == $rtype) {?>
					<span style="color:red" class="edit-btn" id="edit"><a href="https://dev.freemedicalinfo.in/editrating/?ratingid=<?=$rate['id'];?>"> Edit </a></span>
					
					<span style="color:red" class="delt-btn" onclick="cmnt_delt('<?php echo $rate['id']; ?>')">Delete</span>
				<?}?>
				
				<? if(!empty($_SESSION['userEmail'])){
                 if($_SESSION['userEmail'] ==  $rate['rating_by_useremail']){
				 
			 }else{
					?>								
				<span style="color:orange" onclick="report('<?php echo $rate['id']; ?>')">Report Abuse <i class="fa fa-exclamation-circle"></i></span><? } ?>	
					<? } } ?>
				</div>
				</div>
					
				</div>
		  	<div class="rating-container rating-xs rating-animate"><div class="rating">
			<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
			<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
			<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
			<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
		</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
		</span></span>
		
		<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
		<span class="star"><i class="glyphicon glyphicon-star"></i></span>
		<span class="star"><i class="glyphicon glyphicon-star"></i></span>
		<span class="star"><i class="glyphicon glyphicon-star"></i></span>
		<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
	</div></div>
		  
    <p class="fs-110 font-cond-l cmnt-btn" contenteditable="false" ><i><?php echo $rate['comment']; ?></i></p>
  
		  <? if(!empty($_SESSION['userEmail'])){ ?>
		  
		  <div class="post-options" style="font-size: 17px; padding: 0px 5px;">
			<i class="glyphicon glyphicon-thumbs-up" onclick="setLikeDislike('like','<?php echo $rate['id']?>','<? echo $_SESSION['userId']; ?>')" id="like_<?php echo $rate['id']?>"></i>
			<span class="counter-up">(<?php echo $like; ?>)</span> 
			
			<i class="glyphicon glyphicon-thumbs-down" onclick="setLikeDislike('dislike','<?php echo $rate['id']?>','<? echo $_SESSION['userId']; ?>')" id="dislike_<?php echo $rate['id']?>"></i>
			<span class="counter-down">(<?php echo $dlike; ?>)</span>
		</div>

		  <form class="clc<? echo $i; ?>" method="post" style="display: none;">
			<textarea class="form-control" name="comnt" rows="4" placeholder="reply your comment..."></textarea>
			<input type="hidden" name="ipadd" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
			<input type="hidden" name="rateIdd" value="<? echo $rate['id']?>">
			<input type="hidden" name="userId" value="<? echo $rate['user_id'] ?>">
			<input type="hidden" name="uemail" value="<? echo $rate['email'] ?>">
			<input type="hidden" name="utype" value="<? echo $rate['rateusertype'] ?>">
			
			<input type="hidden" name="urateId" value="<? echo $_SESSION['userId']; ?>">
			<input type="hidden" name="urateMail" value="<? echo $_SESSION['userEmail']; ?>">
			<input type="hidden" name="urateType" value="<? echo $_SESSION['userType']; ?>"><br>
			<input type="submit" name="rsubmit" style="float: right;margin-top: -10px;
    margin-bottom: 10px;" value="Submit" class="btn btn-success btn-send">
		  </form>
		  
		  <?php }else{ ?>
		  
		  <div class="post-options" style="font-size: 17px; padding: 0px 5px;">
			<i class="glyphicon glyphicon-thumbs-up" onclick="check_login('<?php echo $i; ?>')" id="like_<?php echo $rate['id']?>"></i>
			<span class="counter-up">(<?php echo $like; ?>)</span> 
			
			<i class="glyphicon glyphicon-thumbs-down" onclick="check_login('<?php echo $i; ?>')" id="dislike_<?php echo $rate['id']?>"></i>
			<span class="counter-down">(<?php echo $dlike; ?>)</span>
		</div>
			  
			  	<center class="clc<? echo $i; ?>" style="display: none;"><a class="btn btn-success ajax" href="/login.php">Please Login</a></center>
			  
		<?php  }
		  $x=1;
				foreach($ratnqrys as $rnew)
				{
					$comnt =$rnew['comment'];
					$uSesmail=$_SESSION['userEmail'];
					$rpId=$rnew['id'];
					
	
		$uid=$rnew['user_id'];
		$utype=$rnew['rateusertype'];
		
		if($utype == 'doctor')
		{
			$res_cmt = fetchAllData(" `doctor_registration` ", " where id='".$uid."'"); 

		}
		if($utype == 'other')
		{
			$res_cmt = fetchAllData(" `other_service_registration` ", " where id='".$uid."'"); 
		}
	if($utype == 'hospital')
		{
			$res_cmt = fetchAllData(" `medical_registration` ", " where id='".$uid."'"); 

			
		}
		
   foreach($res_cmt as $row)
   {  
	   $name=$row['name'];
   }

	$rid=$rnew['rating_by_userid'];
	$rtype=$rnew['user_type'];
	if($rtype=='user')
	{
		$ratqrys=  fetchAllData(" `users` ", " where id='".$rid."'");
			foreach($ratqrys as $rows)
			{
				$names=$rows['first_name'];
				$img=$row['pro_img'];
			}	
	}
	if($rtype=='doctor')
	{
		$ratqrys=  fetchAllData(" `doctor_registration` ", " where id='".$rid."'");
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
			}
	}
	if($rtype=='hospital')
	{
		$ratqrys=  fetchAllData(" `medical_registration` ", " where id='".$rid."'");
			
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
			}
	}
	
	if($rtype=='other')
	{
		$ratqrys=  fetchAllData(" `other_service_registration` ", " where id='".$rid."'");
		
		foreach($ratqrys as $rows)
			{
				$names=$rows['name'];
				$img=$row['pro_img'];
			}
	}	
					
					
		if($img=="")
				{
					$img="profile-1.png";
				}			
					
					
					/* reply comment */
				$ocmntid=$rnew['id'];
				$osqlqry="select * from rcmnt_like_dislike where `rating_id`='$ocmntid' && `like`=1";
				$oldrun=mysqli_query($conn,$osqlqry);
				$olike=mysqli_num_rows($oldrun);
				
				$osqlqryd="select * from rcmnt_like_dislike where `rating_id`='$ocmntid' && `dislike`=1";
				$oldrund=mysqli_query($conn,$osqlqryd);
				$odlike=mysqli_num_rows($oldrund);
				/* reply comment */
					
					
						
		  ?>
		  <div style="padding: 15px 0px;
    background: #f9f9f9;
    border-radius: 8px;
    margin-bottom: 20px;" class="col-md-12">
		  <div style="padding-left:0px; padding-right: 0px;" class="col-md-1">
		  <img src="/images/profile/<?php echo $img; ?>" class="wpx-100 img-round mgb-20 pb-3" style="height: 50px; width: 50px;">
		  </div>
		  <div style="padding-left:30px;" class="col-md-11">
		  <div class="float-left" style="display:inline-block;">
	<p class="col-sm-12 bottom-name-h" style="padding: 0px;margin-bottom:-5px;"><?php echo $names; ?></p></div>
		<div class="pull-right"> 
		<div class="dropdown">
			<button class="dropbtn">Action<i class="caret"></i></button>
			<div class="dropdown-content">
			<span style="color:green" class="cmnt-btn-x" id="clc-x<? echo $x; ?>"> Reply <i class="fa fa-reply"></i></span>
			
			<?php 
					$orids = $_SESSION['userId'];
					$oridut = $_SESSION['userType'];
					$orrest = fetchAllData(" `all_users` ", " where `userId`= '".$orids."' AND user_type='".$oridut."'");
					foreach($orrest as $orcmnt)
					{
						$ordid=$orcmnt['userId'];
						$ordtype=$orcmnt['user_type'];
					}
						
					if($ordid == $rid && $ordtype == $rtype) {?>
					
					<span style="color:red" class="edit-btn" id="edit"><a href="/commentedit/?replyid=<?=$rnew['id'];?>"> Edit </a></span>
					
					<span style="color:red" class="delt-btn" onclick="rcmnt_delt('<?php echo $rnew['id']; ?>')">Delete</span>
				<?}?>
			<? if(!empty($_SESSION['userEmail'])){
                 if($_SESSION['userEmail'] ==  $rate['rating_by_useremail']){
				 
			 }else{
					?>
			<span style="color:orange" onclick="report1('<?php echo $rnew['id']; ?>')">Report Abuse <i class="fa fa-exclamation-circle"></i></span>										
			<? }} ?>
			</div>
		</div>
		</div>
		  <?php 
			
		  ?>
		  <p class="fs-110 font-cond-2 cmnt-btn-x" contenteditable="false" id="clc-x<? echo $x; ?>"><i><?php echo $comnt;?></i></p>
		  <? if(!empty($_SESSION['userEmail'])){ ?>
		  
		  <div class="post-options" style="font-size: 17px; padding: 0px 5px;">
			<i class="glyphicon glyphicon-thumbs-up" onclick="reply_like('like','<?php echo $rnew['id']?>','<? echo $_SESSION['userId']; ?>')" id="like_<?php echo $rnew['id']?>"></i>
			<span class="counter-up">(<?php echo $olike; ?>)</span> 
			
			<i class="glyphicon glyphicon-thumbs-down" onclick="reply_like('dislike','<?php echo $rnew['id']?>','<? echo $_SESSION['userId']; ?>')" id="dislike_<?php echo $rnew['id']?>"></i>
			<span class="counter-down">(<?php echo $odlike; ?>)</span>
		</div>
		  
		  
		 <form class="clc-x<? echo $x; ?>" method="post" style="display: none;">
			<textarea class="form-control" name="comnt" rows="4" placeholder="reply your comment..."></textarea>
			<input type="hidden" name="ipadd" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
			<input type="hidden" name="rateIdd" value="<? echo $rate['id']?>">
			<input type="hidden" name="userId" value="<? echo $rate['user_id'] ?>">
			<input type="hidden" name="uemail" value="<? echo $rate['email'] ?>">
			<input type="hidden" name="utype" value="<? echo $rate['rateusertype'] ?>">
			<input type="hidden" name="rplyid" value="<? echo $rpId; ?>">			
			<input type="hidden" name="urateId" value="<? echo $_SESSION['userId']; ?>">
			<input type="hidden" name="urateMail" value="<? echo $_SESSION['userEmail']; ?>">
			<input type="hidden" name="urateType" value="<? echo $_SESSION['userType']; ?>"><br>
			<input type="submit" name="rsubmit" style="float: right;" value="Reply">
		 </form>
		<? } else {?>
			<div class="post-options" style="font-size: 17px; padding: 0px 5px;">
			<i class="glyphicon glyphicon-thumbs-up" onclick="check_login_x('<?php echo $x; ?>')" id="like_<?php echo $rnew['id']?>"></i>
			<span class="counter-up">(<?php echo $olike; ?>)</span> 
			
			<i class="glyphicon glyphicon-thumbs-down" onclick="check_login_x('<?php echo $x; ?>')" id="dislike_<?php echo $rnew['id']?>"></i>
			<span class="counter-down">(<?php echo $odlike; ?>)</span>
		</div>
		 <center class="clc-x<? echo $x; ?>" style="display: none;"><a class="btn btn-success ajax" href="/login.php">Please Login</a></center>
		  <?}?>
		  </div>
	</div>
				<? $x++;
				}
				$i++; ?>
		</div></div>
	<? }

		}

	?>
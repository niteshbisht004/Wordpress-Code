<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	    // get posted data
	$data = file_get_contents("php://input");
	$cat = $_POST['cat'];
	$password = $_POST['password'];
	$userid = $_POST['userid'];
	$fname = $_POST['first_name'];
	$phone = $_POST['phone_no'];
	$email = $_POST['email'];
	$dob = $_POST['date_birth'];
	$active = $_POST['active'];
	$idate = $_POST['insert_date'];
	
	
	if($cat == 'user'){
    include_once 'classes/users.php';
	$items = new Users($db);
	$fv = $items->getVerifyUsersbyid($userid);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Userid already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyUsersbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
		 $user_id = $userid;
 $first_name = $fname;
  $phone_no = $phone;
  $password = $password;
  $email = $email;
  $date_birth = $dob;
   $active = $active;
   $insert_date = $idate;
$stmt = $items->createUsers($user_id,$first_name,$phone_no,$password,$email,$date_birth,$active,$insert_date); 
	 }

	 }
	}
		if($cat == 'doctor'){
    include_once 'classes/doctors.php';
		$items = new Doctors($db);
		$fv = $items->getVerifyDoctorsbyid($userid);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Userid already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyDoctorsbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	 $user_id = $userid;
	 $first_name = $fname;
	  $phone_no = $phone;
	  $password = $password;
	  $email = $email;
	  $date_birth = $dob;
	   $active = $active;
	   $insert_date = $idate;
	$stmt = $items->createDoctors($user_id,$first_name,$phone_no,$password,$email,$date_birth,$active,$insert_date);
	 }
	 }
	}

	
			if($cat == 'hospital'){
        include_once 'classes/hospitals.php';
		$items = new Hospitals($db);
		
	$fv = $items->getVerifyHospitalsbyid($userid);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Userid already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyHospitalsbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	 $user_id = $userid;
	 $first_name = $fname;
	  $phone_no = $phone;
	  $password = $password;
	  $email = $email;
	   $active = $active;
	   $insert_date = $idate;
	$stmt = $items->createHospitals($user_id,$first_name,$phone_no,$password,$email,$active,$insert_date);
	 }
	 }
	}
	
	if($cat == 'other'){
		
    include_once 'classes/others.php';
	$items = new Others($db);
	
    $fv = $items->getVerifyOthersbyid($userid);
	$itemCount = mysqli_num_rows($fv);
	
	 if($itemCount > 0){
		 
    $response['message'] = "Userid already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
	$sv = $items->getVerifyOthersbyemail($email);
	$itemCounts = mysqli_num_rows($sv);
	 if($itemCounts > 0){
		 
    $response['message'] = "Email already Exit";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response; 
	exit;	 
		 
	 }else{
     	
	 $user_id = $userid;
	 $first_name = $fname;
	  $phone_no = $phone;
	  $password = $password;
	  $email = $email;
	  $active = $active;
	   $insert_date = $idate;
	$stmt = $items->createOthers($user_id,$first_name,$phone_no,$password,$email,$active,$insert_date);
	 }
	 }
	
	}

    if($stmt){
      
     $usr =  array('cat'=>$cat,'id' => $items->id,'userid' => $user_id,'Name' => $first_name,'Phone' => $phone_no, 'Password' => $password, 'Email' => $email, 'Active' => $active,'Date' => $insert_date);
		$response['data']=$usr;
		
		    $to = $email;
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n https://www.freemedicalinfo.in/account-active.php?x=$id-user&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <info@freemedicalinfo.in>\r\n";
			$additionalheaders .= "Reply-To: info@freemedicalinfo.in";
			mail($to, $subject, $body, $additionalheaders);
      $response['message']="user Created Successfully";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
		
   
    }else{
      $response['message'] = "User not created";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
    }
	
	
	 
	
?>
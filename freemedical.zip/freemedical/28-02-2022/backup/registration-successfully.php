<? include("include/header.php"); ?>
    <!-- Page Content -->
<?
	if(isset($_POST['user'])){
		echo "<script>alert('miss u');</script>";
	}
	
	
	
	function random_password( $length ) {
		$chars = "0123456789";
		$password = substr( str_shuffle( $chars ), 0, $length );
		return $password;
	}
	$firstCap = random_password(1) ;
	$secondCap = random_password(1) ;
	$_SESSION['captcha'] = $firstCap + $secondCap;
?>
    <div class="container">

        <div class="row">
			<? include('include/sidebar.php'); ?>
			<!-- Slider Start -->
		
            <div class="col-md-9">
				<center><img src="/images/success.jpg"</center>
				<h2 class='bg-success' style='font-size:14px; padding-top:8px; padding-bottom:8px; text-align:center;'>Registration successful, please check your email to activate your account.</h2>
            </div>
		
<div class="clearfix" style="height:20px;"></div>			
<br/>
<br/>
			<div class="col-md-12">
				<div class="most-active-profile">
					<h4 class="heading">Our Associate</h4>
					<div id="jssor_2" class="jssor_2">
					<!-- Loading Screen -->
					<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
						<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
						<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
					</div>
					<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 100%; height: 100px; overflow: hidden; ">
						<?php 
						   $queryAs=mysqli_query($conn,"select * from our_associate");
						   while($rowAs=mysqli_fetch_object($queryAs))
						   {
						 ?>
						   <div style="display: none;">
								<img data-u="image" src="/admin/images/uploads/<?php echo $rowAs->image; ?>" style="margin-left:30px;"/>
							</div>
							<?php 
						   }
							?>
						
					</div>
					</div>
				</div>
			</div>
			
        </div>

    </div>
    <!-- /.container -->
<script src="/js/form-validation/other-registration.js"></script>
<script src="/js/jquery.duplicate.js"></script>
<? include('include/footer.php'); ?>
    <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
    
	 <script>
        jssor_2_slider_init();
    </script>
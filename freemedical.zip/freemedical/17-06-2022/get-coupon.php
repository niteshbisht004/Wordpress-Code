<? include("include/header.php"); ?>
<!-- Page Content -->
<div class="container">
	<?
	$msg = "";
	$dealD = fetchData(" `deals` ", " where id= '" . $_GET['id'] . "' ");
	$doctor = $dealD['doctor_id'];
	$hospital = $dealD['hospital_id'];
	if ($doctor != "") {
		$offer_by = fetchData(" `doctor_registration` ", " where id= '" . $doctor . "' ");
		$visit_offer = "/doctor-details.php?Did=" . $doctor;
		$email = $offer_by['email'];
		$serviename = $offer_by['name'];
		$serviceaddress = $offer_by['address'];
	}
	if ($hospital != "") {
		$offer_by = fetchData(" `medical_registration` ", " where id= '" . $hospital . "' ");
		$visit_offer = "hospital-details.php?Hid=" . $hospital;
		$email = $offer_by['email'];
		$serviename = $offer_by['name'];
		$serviceaddress = $offer_by['address'];
	}
	$lastAppoint = fetchData(" `coupan` ", " where deal_id= '" . $_GET['id'] . "' and email='" . $_SESSION['userEmail'] . "' ");
	
	if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
		$link = "https";
	else
		$link = "http";

	// Here append the common URL characters. 
	$link .= "://";

	// Append the host(domain name, ip) to the URL. 
	$link .= $_SERVER['HTTP_HOST'];

	// Append the requested resource location to the URL 
	$link .= $_SERVER['REQUEST_URI'];

	if (empty($_SESSION['userEmail'])) {
		$msg = '<div class="alert alert-danger text-center" id="loginError"><h3 style="margin-top: 10px; margin-bottom: 10px;"><a href="/login.php?location=' . $link . '" class="ajax">Please Login OR&nbsp;</a><a class="ajax cboxElement" href="https://www.freemedicalinfo.in/registration.php">Register</a></h3></div>';
	}
	?>
	<?
	if (isset($_POST['submit'])) {


		$dealDId = $_GET['id'];
		
		$User_Id = $_SESSION['user_Id'];
		$patientName = $_POST['name'];
		$User_email = $_SESSION['userEmail'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$contact_number = $_POST['phone'];
		$appointment_date = $_POST['date'];
		$appointment_time = $_POST['time'];
		$purpose = $_POST['purpose'];
		$ap1 = 'FMI';
		$ap2 = date("dmY");
		$qa = mysqli_query($conn, "select * from coupan order by id desc") or die(mysqli_error());
		$re = mysqli_num_rows($qa);
		if ($re == 0 or $re < 0) {
			$apCounter = 1;
		} else {
			$apCounter = $re + 1;
		}
		$coupan_id = $ap1 . $ap2 . $apCounter;
		
		echo $coupan_id;
		
		$queryD = mysqli_query($conn, "insert into coupan(deal_id, hospital_id, doctor_id,  patient_name, email, gender, appointment_date, appointment_time, purpose, address, coupan_id, contact_number, status) 
			values('$dealDId', '$hospital', '$doctor', '$patientName', '$User_email', '$gender', '$appointment_date', '$appointment_time', '$purpose', '$address', '$coupan_id', $contact_number, 'Unused')") or die(mysqli_error());

		$coupanId = mysqli_insert_id($conn);
		
		$copval = fetchData(" `rewards` ", " where user_email= '" . $User_email . "' ");
		$cval = $copval['coupon_point'];
		$cnew = $cval + 10;
		
		$insrew = "update rewards set
					  `coupon_point` = '".$cnew."' where `user_email` = '".$User_email."'
				";
		$query = mysqli_query($conn,$insrew) or die(mysqli_error());

		//****** sending Email ********
		echo $msg;

		if (!empty($_SESSION['userEmail'])) {
			$lastAppoints = fetchAllData(" `coupan` ", " where deal_id= '" . $_GET['id'] . "' and email='" . $_SESSION['userEmail'] . "' ");
			foreach ($lastAppoints as $lastAppoint) {
				$url = '<a href="https://www.freemedicalinfo.in/download_pdf.php?couponid=' . $lastAppoint['coupan_id'] . ' " download >Download pdf</a>';
			}

			$deal = fetchData(" `deals` ", " where id= '" . $_GET['id'] . "' ");
			$name = $deal['title'];
			$validto = $deal['valid_to'];


	?><?php

			$to      = $User_email;
			//$to1     = $email;
			$subject = 'FMI Coupon Generation Detail';
			$message = '<html>
<head>
<title>GET A QUOTE</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#333337">
<tbody>
<tr>
<td align="center" valign="top"  style="height:100%;margin:0;padding:10px;width:100%;border-top:0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;border:0;max-width:600px!important">
<tbody>
<tr>
<td valign="top"  style="background:#fff none no-repeat center/cover;background-color:#fff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
<td valign="top" style="padding:9px">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                        <tbody>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
	<p><img src="https://www.freemedicalinfo.in/images/free_medical_info.gif"></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p><strong>Exclusive Deal for <a href="https://www.freemedicalinfo.in/">www.FreeMedicalInfo.in</a> users!</strong></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p>Coupon Code: ' . $coupan_id . '</p>
							   <p>' . $name . '</p>
							 <br> </td>
                        </tr>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:left">
							
							<p><strong>Dear Mr. / Ms. ' . $patientName . '</strong></p>



<p>Congratulations for availing the Exclusive Discount Coupon on <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> !</p>

<p>Visit the Clinic and redeem it by simply showing your coupon.</p>


<p><strong>Your discount coupon is here:</strong> ' . $coupan_id . '</p>



<p>Patients need to show this coupon in advance at the billing counter before treatment.</p>



<p><strong>' . $name . '</strong></p>

<p><strong>Offered by:</strong> ' . $serviename . ' ' . $serviceaddress . '</p>


<p><strong>Coupon Code:</strong> ' . $coupan_id . '</p>

<p><strong>Patient Name:</strong> ' . $patientName . '</p>

<p><strong>Gender:</strong> ' . $gender . ' </p>

<p><strong>Date of Visit:</strong> ' . $appointment_date . '</p> 

<p><strong>Time of Visit:</strong> ' . $appointment_time . '</p>

<p><strong>Treatment:</strong> ' . $purpose . '</p>

<p><strong>Valid till:</strong> ' . $validto . '</p>



<p>Discount applicable will be informed at the Billing Counter prior to Conducting the Treatment.</p>


<p>Visit and Register at <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> for generating more Coupons for future requirements.</p>

<p><strong>Best Wishes</strong></p>

<p>Team <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a></p>

<p><a target="_blank" href="https://www.freemedicalinfo.in/term.php">Terms & Conditions</a></p>
							 <br> </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
 <td valign="top" id="m_7045481687344905526m_8011562112826686489templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
 <td valign="top" style="padding-top:9px">
<table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%">
<tbody>
<tr>
<td valign="top" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
<p dir="ltr" style="margin:30px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">




                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td></tr></tbody></table>

					</td>
                </tr>
            </tbody></table></body>
</html>';
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";


			mail($to, $subject, $message, $headers);
			//mail($to1, $subject, $message, $headers);
		}
			header("location:/get-coupon.php?id=" . $_GET['id'] . "&appointment=true&offeredby=".$serviename."&code".$coupan_id."&date=".$appointment_date."&time=".$appointment_time."");
	}
	
	
	if (!empty($lastAppoint['patient_name'])) {
		if ($_GET['appointment'] == "true") {
			
	?>
	
	<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center">Your appointment successfully generated. Here is the details </h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
<p><strong>Coupon Code:</strong> <?php echo  $_GET['code']; ?></p>
<p><strong>Date of Visit:</strong><?php echo  $_GET['date']; ?></p> 
<p><strong>Time of Visit:</strong> <?php echo  $_GET['time']; ?></p>
<p><strong>Offered by:</strong> <?php echo  $_GET['offeredby']; ?></p>
              
            </div>
        </div>
    </div>
</div>
	
	
	<?
	

		}
	}
	if (isset($_POST['submit'])) {
		$dealDId = $_GET['id'];

		$patientName = $_POST['name'];
		$User_email = $_SESSION['userEmail'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$contact_number = $_POST['phone'];
		$appointment_date = $_POST['date'];
		$appointment_time = $_POST['time'];
		$purpose = $_POST['purpose'];
		$ap1 = 'FMI';
		$ap2 = date("dmY");
		$qa = mysqli_query($conn, "select * from coupan order by id desc") or die(mysqli_error());
		$re = mysqli_num_rows($qa);
		if ($re == 0 or $re < 0) {
			$apCounter = 1;
		} else {
			$apCounter = $re + 1;
		}
		$coupan_id = $ap1 . $ap2 . $apCounter;


		//****** sending Email ********


		$to     = $email;
		$subject = 'FMI Coupon Generation Detail';
		$message = 'Coupon Generated Successfully. Coupon No. is "' . $coupan_id . '"';
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";

		mail($to, $subject, $message, $headers);
		//mail($to1, $subject, $message, $headers);
	}
	?>

	<link rel="stylesheet" type="text/css" href="///cdn.jsdelivr.net/npm/datetimepicker@latest/dist/DateTimePicker.min.css" />
	<script type="text/javascript" src="///cdn.jsdelivr.net/npm/datetimepicker@latest/dist/DateTimePicker.min.js"></script>
	<script>
		$(document).ready(function() {


			$("#dtBox").DateTimePicker({
				timeFormat: "HH:mm"
			});
		});
	</script>
	<style>
		td.day {
			position: relative;
		}

		td.day.disabled:hover:before {
			content: 'This date is disabled';
			color: red;
			background-color: white;
			top: -22px;
			position: absolute;
			width: 136px;
			left: -34px;
			z-index: 1000;
			text-align: center;
			padding: 2px;
		}
	</style>


	<div class="col-md-12 coupon-get-login">
		<div class="row">



			<?
			echo $msg;

			if (!empty($_SESSION['userEmail'])) {
				$lastAppoints = fetchAllData(" `coupan` ", " where deal_id= '" . $_GET['id'] . "' and email='" . $_SESSION['userEmail'] . "' "); ?>
				<div class="">
					<table class="table spc-table" cellpadding="1" cellspacing="1">
						<? if (!empty($msg)) { ?>
						<? } else { ?>
							<tr>
								<td>Patient Name</td>
								<td>Address</td>
								<td>Gender</td>
								<td>Appointment Date</td>
								<td>Appointment Time</td>
								<td>Coupon Status</td>
								<td>Your Coupon</td>
							</tr><? } ?>
						<?
						foreach ($lastAppoints as $lastAppoint) {
						?>
							<tr>
								<td><?= $lastAppoint['patient_name'] ?></td>
								<td><?= $lastAppoint['address'] ?></td>
								<td><?= $lastAppoint['gender'] ?></td>
								<td><?= $lastAppoint['appointment_date'] ?></td>
								<td><?= $lastAppoint['appointment_time'] ?></td>
								<td><?= $lastAppoint['status'] ?></td>

								<td><?= $lastAppoint['coupan_id'] ?><br><a href="/download_pdf.php?couponid=<?= $lastAppoint['coupan_id'] ?>" download>Download pdf</a></td>
							</tr>
						<?	}		?>


					</table>
				</div>
				<div class="well">
					<form id="contact-form" method="post" role="form">

						<div class="messages"></div>

						<div class="controls">
							<h3 style="margin-top: 0px;" class="popup-title"><?= ucwords($dealD['title']) ?></h3>
							<!--	<h4>Offered By :<a href="/<?= $visit_offer ?>" target="_blank"><span class="offer-by"> <?= $offer_by['name'] ?></span></a> </h4>
							<strong>Valid From : </strong> <span><?= $dealD['valid_from'] ?></span><br/>
							<strong>Valid to : </strong> <span><?= $dealD['valid_to'] ?></span><br/>
							<p><?= $dealD['description'] ?></p>-->
							<!--Visit on deal provider : <a href="/<?= $visit_offer ?>" target="_blank">Click Here</a>-->

							<hr />

							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_name">Patient Name </label>
										<input id="form_name" type="text" name="name" class="form-control" placeholder="Patient Name " required="required">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_phone">Phone</label>
										<input id="phone" type="tel" placeholder="Phone" name="phone" class="form-control" maxlength="10" onkeypress="return isNumberKey(event);" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_phone">Date Of appointment</label>
										<input id="date" type="text" name="date" class="form-control datepicker" placeholder="Date Of appointment" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_phone">Time Of appointment</label>
										<input type="text" data-field="time" data-format="hh:mm AA" name="time" placeholder="Time Of appointment" class="form-control fillDateTime" id="time1">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_phone">Purpose of Visit</label>
										<input type="text" name="purpose" class="form-control" placeholder="Purpose of Visit" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="form_phone">Gender</label>
										<div style="padding: 6px 12px;">
											<input type="radio" required name="gender" value="Male" style="margin:0px;"> Male &nbsp;
											<input type="radio" required name="gender" value="Female" style="margin:0px;"> Female
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="form_message">Address</label>
										<textarea id="form_message" name="address" class="form-control" placeholder="Address" rows="4"></textarea>
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<input type="checkbox" required> I Agree to <a href="/term.php" target="_blank">Terms & Conditions</a> </br>
									<p> &nbsp; </br></p>
								</div>
								<div class="col-md-6 float-left">
									<input type="submit" name="submit" class="btn btn-success btn-send" value="Get Coupon">
								</div>
								<div class="col-md-6 float-right">
									<a href="/javascript:history.go(-1)" class="btn btn-success btn-send" title="Cancel">Cancel</a>

								</div>
							</div>


						</div>

					</form>
				</div>

			<? } ?>
		</div>

	</div>

</div>
<!-- /.container -->
<div id="dtBox"></div>

<!-- use jssor.slider-21.1.debug.js instead for debug -->
<script src="/js/bootstrap-datepicker.js"></script>
<script>
	$('.datepicker').datepicker({
		format: "dd/mm/yyyy",
		startDate: "<?= $dealD['valid_from'] ?>",
		endDate: "<?= $dealD['valid_to'] ?>"
	});

	jssor_1_slider_init();
	jssor_2_slider_init();

	function isNumberKey(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))
			return false;
		return true;
	}

	function validation() {
		var mob = document.getElementById("phone");
		if (mob.value.length < 10) {
			alert("Mobile no must be 10 Digit!")
			document.getElementById("mobileNo").focus();
			return false;
		} else {
			return true;
		}
	}
</script>
<script>
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>


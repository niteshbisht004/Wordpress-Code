<?php
error_reporting(E_ALL);
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
	$val = $_POST['stateid'];
	
	include_once 'classes/states.php';
	
	$sitems = new States($db);
	
	include_once 'classes/city.php';
	
	$items = new Cities($db);
	
    $stmt = $items->getCities($val);
    
    $itemCount = mysqli_num_rows($stmt);
    
	
	
    if($itemCount > 0){
        $allArr = array();
		$cityarr = array();
		$all = array();
     while ($row = $stmt->fetch_assoc()){
				$allArr[] = $row;		 
			
   $statestmt = $sitems->getSingleState($row['state_id']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
		  
        $all[] = array_merge($row,$cityArr);			 
        }
				
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $all;
	
	$json_response = json_encode($response);
	echo $json_response;
				
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
    }
?>
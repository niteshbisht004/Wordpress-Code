<?php 

/**
 * Plugin Name: Spotlight
 *	Plugin URI: http://wordpress.org/plugins/#
 *	Description: This plugin is created to add the spotlight of any html elements in wordpress
 *	Author: Brandclever
 *	Version: 1.0.0
 *	Author URI: https://#
 */
 
 defined( 'ABSPATH' ) || exit;

if(! function_exists('add_action'))
{
	exit;
}

if ( ! class_exists( 'brandclever_mediavine', false ) )
{
Class brandclever_mediavine
 {
	
	// Uninstallation stuff here
	public function my_plugin_uninstall() 
		{
             unregister_post_type( 'brandclever-mediavine' );
        }
	

 }
 
 /**
 * Register the "Spotlight" custom menu type
 */
function pluginprefix_setup_post_type() {
   add_menu_page('Spotlight', 'Spotlight', '','bcm-mediavine', '', plugin_dir_url( __FILE__).'uploads/spotlight.png',48 );
   add_submenu_page('bcm-mediavine',  'Spotlight Settings', 'Spotlight Settings',   'manage_options', 'brandclever-mediavine','bcm_myplugins_mediavine');
} 
add_action( 'admin_menu', 'pluginprefix_setup_post_type' );

 
	/*
	 * Include plugin files for the admin area
	 *
	 */
	function load_resources_admin() 
	{
	
		define('BCM_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . dirname( plugin_basename(__FILE__) ) );
	
		
		if( file_exists( BCM_PLUGIN_DIR . '/includes/mediavine-fields.php' ) )
			include_once( BCM_PLUGIN_DIR . '/includes/mediavine-fields.php' );	
		
	}
	add_action( 'init', 'load_resources_admin' );
	
	/*
	 * Enqueue scripts for the front-end
	 *
	 */
	function init_front_end_scripts() 
	{
		
		//define('BCM_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . dirname( plugin_basename(__FILE__) ) );
		//define('BCM_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
		
        
		if( file_exists( BCM_PLUGIN_DIR . '/includes/front-mediavine.php' ) )
			include_once( BCM_PLUGIN_DIR . '/includes/front-mediavine.php' );
	}
	add_action( 'wp_enqueue_scripts', 'init_front_end_scripts' );
/**
 * Activate the plugin.
 */
function pluginprefix_activate() { 
    pluginprefix_setup_post_type(); 
    flush_rewrite_rules(); 
}
register_activation_hook( __FILE__, 'pluginprefix_activate' );


/**
 * Deactivation hook.
 */
function pluginprefix_deactivate() {
    unregister_post_type( 'book' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'pluginprefix_deactivate' );
}

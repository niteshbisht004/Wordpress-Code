<? include("include/header.php");

global $specialisations;
global $qualifications;
global $hospital_cats;
global $cities;
$conn = db();
//Specialisation List

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification");
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM cities");
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$cities[$data['id']] = utf8_encode($data['name']);
		$c++;
	}
}


?>
<style>
.d-details-per-column{
min-height:450px !important;
}
.pagini{display:none;}
</style>
<!-- Page Content -->
	
<div class="detail-list-front">
	<div class="container">
		<div class="col-md-12 in-filter-sets">
			<div class="row">
				<form method="get" action="">
					<div class="col-md-4 fiter-top-mainp" id="form-set-filter1">

						<select name="speci" class="form-control" data-live-search="true">
							<option value="">All Specialisations</option>
							<?php
							foreach ($specialisations as $ke => $spe) {
								$selected = "";
								$selected = ($ke == $_GET['speci']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $spe . "</option>";
							}
							?>
						</select>
					</div>
			
					<div class="col-md-4 mt-2 fiter-top-mainp" id="form-set-filter3" >

						<select name="city" class="form-control" data-live-search="true">
							<option value="">All City</option>
							<?php
							foreach ($cities as $ke => $city) {
								$selected = "";
								$selected = ($ke == $_GET['city']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $city . "</option>";
							}
							?>
						</select>
					</div>
					
					<div class="col-md-4 fiter-top-mainp" id="form-set-filter5">
						<button type="submit" class="form-control filter" name="filter" value="1">Filter</button>
	            	</div>
				</form>
			</div>
		</div>
	</div>
</div>


           <div class="container">
				<div class="col-md-9" >
					<?php
					$term = $_GET['term'];

					$address = $_GET['saddress'];

					$cityp = $_GET['city'];

					$qry = fetchAllData("`cities`", "where id='$cityp'");
					$city = $qry[0][0];

					$sp = $_GET['speci'];

					$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

					$docnamerows = mysqli_num_rows($docname);

					$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

					$hosnamerows = mysqli_num_rows($hosname);

					$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



					$othnamerows = mysqli_num_rows($othname);



					$searchTerms = explode(' ', $term);

					$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

					$searchTerms = array_diff($searchTerms, $removevalue);

					foreach ($searchTerms as $terms) {
						$terms = trim($terms);
						if (!empty($terms)) {
							$searchTermBits .= "or name LIKE '%$terms%'";
							$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


							$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


							$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
						}
					}

					$orderbydata = implode(' + ', $searchTermBitspls);
					$orderbydatah = implode(' + ', $searchTermBitsplsh);
					$orderbydatao = implode(' + ', $searchTermBitsplso);

					if (strpos(trim($term), ' ') !== false) {
						$term = $term;
					} else {

						$term =	rtrim($term, ',');
						$term =  str_replace(' ', '', trim($term, ','));
					}


					if ($docnamerows > 0) {
					} else {


						$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



						$num_specs = mysqli_num_rows($speciliationqs);

						if ($num_specs > 0) {

							$specidq = array();

							while ($rowq = mysqli_fetch_array($speciliationqs)) {

								$specidq[] = $rowq['id'];
							}
						} else {


							$search_item = addslashes($term);

							$string = explode(" ", $search_item);

							$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

							$result = array_diff($string, $omit_words);

							foreach ($result as $val) {

								if ($val == '') {
								} else {

									$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

									$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

									$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

									$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
								}
							}


							$orderbydataspeci = implode(' + ', $speckeywords);
							$orderbydatahdise = implode(' + ', $diseasekeywords);


							$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


							$num_spec = mysqli_num_rows($speciliationq);

							$specidq = array();

							while ($rowq = mysqli_fetch_array($speciliationq)) {

								$specidq[] = $rowq['id'];
							}



							$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



							$num_disease = mysqli_num_rows($query_disease);

							$specid = array();

							while ($row = mysqli_fetch_array($query_disease)) {

								$specid[] = $row['spec_id'];
							}
						}
					}

					$City = fetchData(" `cities` ", "where id='" . $city . "' ");

					$cityn = $City['name'];

					if ($sp != '') {

						$specq = " (specialisation like '%$sp%' or specialisation = '$sp')";
					}

					if ($cityp != '') {

						$cityq = " (city like '%$city%' or city = '$city' OR address like '%$cityn%')";
					}

					if ($address != '') {
						//$str = 'In My Cart : 11 12 items';
						preg_match_all('!\d+!', $address, $matches);

						foreach ($matches[0] as $val) {
							if (preg_match('/^\d{2}$/', $string)) {
								// pass
							} else {
								$fadd = "or address like '%Sector -$val%'";
								$fadd .= "or address like '%SEC-$val%'";
								$fadd .= "or address like '%Sector-$val%'";
								$fadd .= "or address like '%Sector $val%'";
							}
						}
						$addressq = "(address like '%$address%' or address = '$address' $fadd)";
					}


					if ($_GET['term']  == '' && $_GET['saddress'] == '' && $_GET['speci'] == '' && $_GET['city'] == '') {
						$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' order by last_login DESC LIMIT 0,8");

						include("doctor_result.php");
					} else {

						if ($_GET['term']  == '' && $_GET['saddress'] == '' && $_GET['speci'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes' LIMIT 0,8");
                            
							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {


								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' LIMIT 0,8");

								include("doctor_result.php");
							}
						} elseif ($_GET['term']  == '' && $_GET['saddress'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  (specialisation = '$sp' OR specialisation like '%$sp|%' OR specialisation like '%|$sp%') AND active='Yes' LIMIT 0,8");

							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes' LIMIT 0,8");


								if (!empty($res_doctor)) {

							

									include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' LIMIT 0,8");



									include("doctor_result.php");
								}
							}
						} elseif ($_GET['term']  == '' && $_GET['speci'] == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $addressq AND active='Yes' LIMIT 0,8");
							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND active='Yes' LIMIT 0,8");


								if (!empty($res_doctor)) {

							include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' LIMIT 0,8");



									include("doctor_result.php");
								}
							}
						} elseif ($_GET['term']  == '') {

							$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE   $cityq AND $addressq AND $specq AND active='Yes' LIMIT 0,8");


							if (!empty($res_doctor)) {

								include("doctor_result.php");
							} else {

								$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $specq AND active='Yes' LIMIT 0,8");

								if (!empty($res_doctor)) {



									include("doctor_result.php");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE $specq AND active='Yes' LIMIT 0,8");

									if (!empty($res_doctor)) {


										include("doctor_result.php");
									} else {


										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE $specq AND active='Yes' LIMIT 0,8");

										include("doctor_result.php");
									}
								}
							}
						} else {


							if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

								foreach (array_unique($specid) as $sval) {

									if ($sval == '') {
									} else {

										$redp .= " or specialisation = $sval";
									}
								}

								foreach (array_unique($specidq) as $svalq) {

									if ($svalq == '') {
									} else {

										$redp .= " or specialisation = $svalq";
									}
								}




								if ($addressq == '') {

									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $cityq AND active='Yes' LIMIT 0,8");
								} else {

									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $cityq AND $addressq AND active='Yes' LIMIT 0,8");
								}



								if (!empty($res_doctor)) {

									include("doctor_result.php");
								} else {


									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  specialisation = 79878979  $redp AND city =  $city AND active='Yes' LIMIT 0,8");


									if (!empty($res_doctor)) {

										include("doctor_result.php");
									} else {


										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' LIMIT 0,8");

										include("doctor_result.php");
									}
								}
							} else {


								$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name = '$term' OR name like %$term% $searchTermBits AND active='Yes' AND $cityq AND $addressq ORDER BY ( " . $orderbydata . " ) DESC  LIMIT 0,8");




								if (!empty($res_doctor)) {

									include("doctor_result.php");
								} else {


									$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' $searchTermBits AND active='Yes' AND $cityq ORDER BY ( " . $orderbydata . " ) DESC LIMIT 0,8");



									if (!empty($res_doctor)) {

										include("doctor_result.php");
									} else {



										$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes' LIMIT 0,8");

										include("doctor_result.php");
									}
								}
							}
						}
					}

					?>
      </div>	
		<div class="col-md-3 deals-slider main-work-sl-p" id="recommend-deals-2" style="padding-top: 60px;">
		<? include('include/advertisement.php'); ?>
			</div>	
		</div>		
				
				

			

            


			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			




			
				
				
				
				
				
				
				
				
		<div style="padding-top:15px !important;" id="main-top-detail-16">
	<div class="container">
	 <div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-4 col-sm-12">
					
				</div>
				<?php 
					$actual_link = "$_SERVER[REQUEST_URI]";
					$new_link = explode('?',$actual_link);
					//print_r($new_link[1]);
					if($new_link[1] == ""){
				?>
				<div class="col-md-4 desk col-sm-12">
					<div class="special-btn-area text-center">
						<a href="/alldoctors">View All Doctors <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
				<?} else{?>
				<div class="col-md-4 desk col-sm-12">
					<div class="special-btn-area text-center">
						<a href="/alldoctors<?php echo '?'.$new_link[1];?>">View All Doctors <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
				<?}?>
				<div class="col-md-4 desk col-sm-12">
					
				</div>
			</div>
		</div>

	</div>
</div>

<? include('include/footer.php'); ?>


<?php 
function sts_myplugins_smart_testi_slider()
{
	echo "<br>";
	echo "<h1>Short Code</h1>";		$terms = get_terms('slider-cat');	    foreach($terms as $taxonomy){		$term_name = $taxonomy->name;        $term_slug = $taxonomy->slug;		echo "<p style='font-size: 22px;'>Use <strong>[smart-testimonial-slider name = '$term_name']</strong> short code to access all the smart testimonial slider in any page of your website.</p>";	}
	
	
	
}
?>
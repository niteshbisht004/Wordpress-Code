<?php 
session_start();
if(!isset($_SESSION['user_id']))
{
	header("Location:../login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>
	<h3><a href="dashboard.php" style="padding-left: 60px">Back To Dashboard </a></h3>
	<h4><a href="logout.php" style=" padding-left: 64px;">Logout</a></h4>
	<div class="admindash" align="center">
		<h1>Welcome To Admin Dashboard</h1>
	</div>
	<form method="post" action="addstudent.php">
    	<table border="2" align="center" style="width:60%" class="table table-dark table-hover">
        	<tr>
            	<th>Roll No</th>
                <td><input type="text" name="rollno" maxlength="8" placeholder="Enter Rollno" required /></td>
            </tr>
            <tr>
            	<th>Nmae</th>
                <td><input type="text" name="stuname" placeholder="Enter Name" required /></td>
            </tr>
            <tr>
            	<th>city</th>
                <td><input type="text" name="city" placeholder="Enter city Name" required /></td>
            </tr>
            <tr>
            	<th>Mobile Number:</th>
                <td><input type="text" name="number"  maxlength="10" placeholder="Enter phone No" required /></td>
            </tr>
            <tr>
            	<th>Standerd</th>
                <td>
					<select name="std">
						<option value="6">6th</option>
						<option value="7">7th</option>
						<option value="8">8th</option>
						<option value="9">9th</option>
						<option value="10">10th</option>
					</select>
				</td>
            </tr>
            <tr>
            	<td colspan="2" align="center"><input type="submit" name="submit" value="Submit"></td>
           	</tr>

        </table>
    </form>
</body>
</html>
<?php
	include('../dbcon.php');
	if(isset($_POST['submit']))
	{
		$rollno=$_POST['rollno'];
		$name=$_POST['stuname'];		
		$city=$_POST['city'];
		$stuNumber=$_POST['number'];
		$std=$_POST['std'];
		$qry="INSERT INTO student (`rollno`, `name`, `city`, `stu_mob`, `standerd`) 
		VALUES ('$rollno','$name','$city','$stuNumber','$std')";
		$run=mysqli_query($con,$qry);
		if($run == true)
			{
				?>
                	<script>
                    	alert('New Data inserted successfully.');
                    </script>
                <?php	
			}
			else
			{
				echo "Data not inserted!!!";	
			}
		
	}


 ?>

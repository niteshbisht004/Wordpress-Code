<?php 
 session_start();
 if(!isset($_SESSION['user_id']))
{
	header("Location:../login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
td{
    padding: 5px 10px;
}
</style>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>
	<h3><a href="dashboard.php" style="padding-left: 60px">Back To Dashboard </a></h3>
	<h4><a href="logout.php" style=" padding-left: 64px;">Logout</a></h4>
	<div class="admindash" align="center">
		<h1>Welcome To Admin Dashboard</h1>
	</div>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
        <table align="center" border="0" class="table table-dark" style="width: 60%">
            <tr>
                <th>Student Roll No</th>
                <td><input type="text" name="rollno" required placeholder="Enter Roll No" /></td>
               
                <td><input type="submit" name="btnSearch" value="Search"></td>
            </tr>
        </table>
    </form>
</body>
</html>
<?php  
include('../dbcon.php');
if(isset($_POST['btnSearch']))
{
    $stuRollno=$_POST['rollno'];
  //  $stuName=$_POST['stuname'];
   // echo "roll no is:--".$stuRollno;
   // echo "<br>";
  //  echo "name is:--".$stuName;
$query="SELECT  id, rollno, name, city, stu_mob, standerd FROM student WHERE rollno='$stuRollno'";
    $result=mysqli_query($con,$query);
    $row=mysqli_fetch_array($result,MYSQLI_BOTH);
    $cookie_name="user_id";
    $cookie_value= $row['id'];
    setcookie($cookie_name,$cookie_value, time () + (60*60));
echo "
<form method='POST' action='studentRecUpdate.php'>";
		//<div class="container">
        echo "<table align='center' border='1' class='table table-dark table-hover' style='width:50%'>";
       // echo "<tr><td>Roll No:</td><td><input type='text' value=$row[rollno] name='rollno'></td></tr>";
        echo "<tr><td>Name:</td><td><input type=text maxlength=20 value=$row[name] name=stuname></td></tr>";
        echo "<tr><td>city:</td><td><input type=text maxlength=20 value=$row[city] name=city></td></tr>";
        echo "<tr><td>Standerd:</td><td><select name=std><option value=6>6th</option><option value=7>7th</option><option value=8>8th</option><option value=9>9th</option><option value=10>10th</option></td></tr>";
        echo "<tr><td>contact No:</td><td><input type=text maxlength=10 value=$row[stu_mob] name=number></td></tr>";
        echo "<tr><td><input type=submit name=btnUpdate value=Update></td><td><input type=reset></td></tr>";
        echo "</table>";
		//</div>
 
 echo "</form>";
}
?>
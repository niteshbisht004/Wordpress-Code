<? 	
	session_start();
	if(empty($_SESSION['userEmail'])) { 

?>   
<style>
	#captcha {
    width: 40%;
    float: right;
    margin-top: -28px;
}

.captcha-reload{
	margin-top: -33px;
}
</style>
						<div class="login-box" >
							<div class="account-wall">
								<div class="loading" id="loading">
									<img class="profile-img" src="/images/loading-circle.gif" alt="">
									<h4 style="text-align:center">Please Wait Loading</h4>
								</div>
								<div class="loading" id="loginError">
								  
								</div>
								<form class="form-signup" id="form-signin">
									<select class="form-control" id="user_type" onchange="remove_utError()" >
										<option value="" disabled selected>Registration Type</option>
										<option value="userForm">Patient/user</option>
										<option value="doctorForm">Doctor</option>
										<option value="hospitalForm">Hospital / Clinic</option>
										<option value="other">Other Medical Service</option>
									</select>
									
										<span id="utsError" class="errorbox" ></span>
									<input type="text" id="fname"  class="form-control" placeholder="Name"  value=""   />
										<span id="utEsrror" class="errorbox" ></span>
									<input type="tel" id="phone"  pattern="[1-9]{1}[0-9]{9}" class="form-control" placeholder="Phone"  onblur="checkPhone()" value=""   />
									<span id="utError" class="errorbox" ></span>
									
									
									<input type="email" id="login_email" class="form-control" placeholder="Email"  value=""  onblur="checkEmail()" />
									<span id="eError" class="errorbox" ></span>
									
									
									<select id="field" class="form-control" onchange="remove_edu()" style="display:none;">
										<option value="" disabled selected>Select Category</option>
											<?php 
                                     $conn = mysqli_connect("localhost","freeemed_new","m~RnX?x;F45m","freeemed_new");
									    if(!$conn)
										{ 
                                          echo"False Condition ";
										}
										else{
											echo"Conection Files Avroved ";
										}
										$sel = "select DISTINCT service from  other_service_registration";
								$que_sel = mysqli_query($conn,$sel) or die(mysqli_error());
									while ($res = mysqli_fetch_array($que_sel)) {
								
									?>
										<option value="<?php echo $res['service']; ?>"><?php echo $res['service']; ?></option>
									<?php } ?>
									</select>
									<span id="dobError" class="errorbox" ></span><br/>
									<input type="text" id="field_edu"  class="form-control" placeholder="Enter Service"  value=""  style="display:none;"  />
									
									<div class="form-group">
									<div class="row col md-12">
										<label>Captcha:</label>
										<div id="imgdiv" class="col md-6" style="font-size:20px; border:2px solid #000; width: 40%;">
										<span id="img"></span>
										</div>
										<div class="col md-2 captcha-reload text-center">
										<span id="imgparent">
											<img id="reload" src="/captcha/reload.png" />
										</span>
										</div>
										<input type="text" id="captcha" vclass="form-control"/>
									</div>
									</div>
									<div id="result"></div>
									
									<br/>
									<p>
									<input type="checkbox" id="checkbox" required>  I Agree to <a href="/term.php" target="_blank">Terms & Conditions</a> <br/>
									<span id="checkboxError" class="errorbox" ></span><br/>
									</p>
									<button class="btn btn-primary" onclick="submit_form()" type="button">Sign Up</button>
									
									<a href="#" id="jan" onclick="jan()";  class="pull-right need-help">Need help? </a><span class="clearfix"></span>
								</form>
							</div>
						</div>
					

  
<script src="/captcha/script.js"></script>  
<script src="/js/bootstrap-datepicker.js"></script>
<script>
function validations(){
	//var url = url_exist(document.getElementById("O_website").value);
	/*if(url==false){
		return false;
	}*/
	var mob = document.getElementById("phone");	
	if(mob.value.length < 10){
		alert("Mobile no must be 10 Digit!")
		document.getElementById("mobileNo").focus();
		return false;		
	}
	else{		
		return true;
	}
}

window.onkeydown = function( event ) {
    if ( event.keyCode == 13 ) {
        submit_form();
    }
};

	
	function checkEmail(){
		
		var user_type = document.getElementById('user_type').value;
		var emailId = document.getElementById('login_email').value;
		if(user_type == ""){
			document.getElementById('utError').innerHTML= 'Please Select First Resitration Type';
			document.getElementById("eError").innerHTML = "You can't leave this empty.";
			document.getElementById('login_email').value= "";
			document.getElementById('user_type').focus();
			return false;
		} else {
			if(emailId != ""){
				
			  var xhttp;
			  str = "regForm="+user_type+"&emailId="+emailId;
			 
			  xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					document.getElementById("eError").innerHTML = xhttp.responseText;
				}
			  };
			  xhttp.open("GET", "/ajax-file/check-email.php?"+str, true);
			  xhttp.send();
			} else {				
				document.getElementById("eError").innerHTML = "You can't leave this empty.";
				return false;
			}
		}
	}
	
	
		function checkPhone(){
		
		var user_type = document.getElementById('user_type').value;
		var phone = document.getElementById('phone').value;
	
		if(user_type == ""){
			document.getElementById("utError").innerHTML= 'Please Select First Resitration Type';
			document.getElementById("utEsrror").innerHTML = "You can't leave this empty.";
			document.getElementById("phone").value= "";
			document.getElementById("user_type").focus();
			
			return false;
				
		} else {
			if(phone != ""){
				
			  var xhttp;
			  str = "regForm="+user_type+"&phone="+phone;
			 
			  xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (xhttp.readyState == 4 && xhttp.status == 200) {
					document.getElementById("utEsrror").innerHTML = xhttp.responseText;
				}
			  };
			  xhttp.open("GET", "/ajax-file/check-phone.php?"+str, true);
			  xhttp.send();
			} else {				
				document.getElementById("utEsrror").innerHTML = "You can't leave this empty.";
				return false;
			}
		}
	}
	
	


	function remove_utError(){
		var user_type = document.getElementById('user_type').value;
		if(user_type == 'hospitalForm'){		
		
		document.getElementById('field').style='display:none';
		}
		else if(user_type == 'other'){		
		
		document.getElementById('field').style='display:block';
		}
		else{
		
			document.getElementById('field').style='display:none';
		}
		document.getElementById('utError').innerHTML= '';
	}
	
	
		function remove_edu(){
		var field = document.getElementById('field').value;
		if(field == 'Extra'){		
		
		document.getElementById('field_edu').style='display:block';
	   
		}
	
	}
	function submit_form(){
		//alert('jan');
		var user_type = document.getElementById('user_type').value;
		
		var fname = document.getElementById('fname').value;
		
		var phone = document.getElementById('phone').value;
		var email = document.getElementById('login_email').value;
		
		var captcha = document.getElementById('captcha').value;
		
		var field_edu = document.getElementById('field_edu').value;
		var field = document.getElementById('field').value;

	
		
		if(!document.getElementById('checkbox').checked){
            document.getElementById('checkboxError').innerHTML= 'Checkbox Not Checked!';
            return false;
		}		
		
		
		
		var checkEID = checkEmail();
		if(checkEID==false){
			var error = true;
		}
		
		
		
		
		if(captcha == ""){
			document.getElementById('cptError').innerHTML= 'Please Enter Captcha Code';
			var error = true;			
		}
		
		
		if(error!=true){
			var dataString = 'captcha=' + captcha;
            $.ajax({
                type: "POST",
                url: "/captcha/verify",
                data: 'type='+captcha,
                success: function(html) { 
				
                    if(html=="success"){
						success = "success";
						document.getElementById('loading').style.display = "block";
						str = "regForm="+user_type+"&fname="+fname+"&phone="+phone+"&email="+email+"&fld="+field+"&fldedu="+field_edu;
						register(str);
					} else {						
						alert("Wrong Captcha");
					}
                }
            });			
		}
		
		
	}
 
	function register(str) {		
	  var xhttp;	
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			 var xhttps = xhttp.responseText.split("/");
			 
			if(xhttps[3]=="otpregistraion"){
				
				window.location.href = xhttp.responseText;
				
			} else {
				document.getElementById("loginError").innerHTML = xhttp.responseText;
				document.getElementById('loginError').style.display = "block";
				document.getElementById('loading').style.display = "none";
				$("img#img").remove();
				var id = Math.random();
				$('<img id="img" src="/captcha/captcha.php?id='+id+'"/>').appendTo("#imgdiv");
				id ='';
			}
		}
	  };
	  xhttp.open("GET", "/registration-validation.php?"+str, true);
	  xhttp.send();  
	  
	}
	
	
	 $('.datepicker').datepicker();
	 
</script>
<script>
	$(document).ready(function(){
		$('#img').load('/captcha/captchareg.php');
	});
</script>
      
<?	} else { ?>

						<div class="login-box" >
							<div class="account-wall">
								<div class="" id="loading">
									<img class="profile-img" src="/images/logged.png"	alt="">
									<h4 style="text-align:center">Your Are Already Logged-in</h4>
								</div>
							</div>
						</div>

<? } ?>	


<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 $val = $_POST['cat'];
	 $post_by = $_POST['id'];
	 $userType = $_POST['userType'];
	 $title = $_POST['title'];  
		$specialisation = $_POST['specialisation']; 
		$meta_name = $_POST['meta_name'];  
		$meta_discription = $_POST['meta_discription'];  
		$description = $_POST['description']; 
		$image = $_POST['image'];
		$video = $_POST['video'];
		$insert_date = $_POST['insert_date'];
		$valid_from = $_POST['valid_from'];
		$valid_to = $_POST['valid_to'];
		$short_desc = $_POST['short_desc'];
		$deal_date = $_POST['deal_date'];
		$doctor_id = $_POST['doctor_id'];
		$hospital_id = $_POST['hospital_id'];
	    $other_id = $_POST['other_id'];
  	    $designation = $_POST['designation'];
		$address = $_POST['address'];
		$hospital_c_name = $_POST['hospital_c_name'];
	     $state = $_POST['state'];
		 $country = $_POST['country'];
		 $city = $_POST['city'];
		 $from_date = $_POST['from_date'];
		 $to_date = $_POST['to_date'];
		  $active = $_POST['active'];
		 $timestamp = $_POST['timestamp'];
		 $doc_id = $_POST['doc_id'];
		 $level = $_POST['level'];
		  $H_id = $_POST['H_id'];
		 
		 
		  $sun_FT = $_POST['sun_FT'];
  	    $sun_ST = $_POST['sun_ST'];
		$mon_FT = $_POST['mon_FT'];
		$mon_ST = $_POST['mon_ST'];
	     $tue_FT = $_POST['tue_FT'];
		 $tue_ST = $_POST['tue_ST'];
		 $wed_FT = $_POST['wed_FT'];
		 $wed_ST = $_POST['wed_ST'];
		 $thu_FT = $_POST['thu_FT'];
		  $thu_ST = $_POST['thu_ST'];
		 $fri_FT = $_POST['fri_FT'];
		 $fri_ST = $_POST['fri_ST'];
		 $sat_FT = $_POST['sat_FT'];
		$sat_ST = $_POST['sat_ST'];
		$update_date = $_POST['update_date'];
		$total_experience = $_POST['total_experience'];
        $expertise_in = $_POST['expertise_in'];
			$registration_no = $_POST['registration_no'];
        $registration_auth = $_POST['registration_auth'];
			$name = $_POST['name'];
		$mobile_no = $_POST['mobile_no'];
        $email = $_POST['email'];
			$gender = $_POST['gender'];
        $qualification = $_POST['qualification'];
		$other_medical_id = $_POST['other_medical_id'];
		
		     $advtName = $_POST['advtName'];
			$web_url = $_POST['web_url'];
        $pincode = $_POST['pincode'];
		$userid = $_POST['userid'];
		$usertype = $_POST['usertype'];
        $duration = $_POST['duration'];
		$advtImg = $_POST['advtImg'];
		
		$status = $_POST['status'];
		$comment = $_POST['comment'];
			$comment_id = $_POST['comment_id'];
		$reply_by_id = $_POST['reply_by_id'];
			$reply_by_name = $_POST['reply_by_name'];
		$reply_by_email = $_POST['reply_by_email'];
			$reply_message = $_POST['reply_message'];
			 $hos_id = $_POST['hos_id'];
			  $oth_id = $_POST['oth_id'];
			  
			  if($val == 'hospital'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addOthDocpHos($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$active,$address,$state,$city,$country,$insert_date,$update_date,$H_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  

	
	
   if($val == 'other'){
	include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addOthSpecOth($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$address,$state,$city,$country,$active,$insert_date,$update_date,$other_medical_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
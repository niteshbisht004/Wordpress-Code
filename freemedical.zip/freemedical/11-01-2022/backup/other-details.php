

<? include("include/header.php"); 

//Specialisation List
$resHD = mysqli_query($conn,"SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}


	if(isset($_POST['rsubmit']))
			{
				$rcmnt=$_POST['comnt'];
				$ridd=$_POST['rateIdd'];
				$uid=$_POST['userId'];
				$umail=$_POST['uemail'];
				$utype=$_POST['utype'];
				$urid=$_POST['urateId'];
				$urmail=$_POST['urateMail'];
				$urtype=$_POST['urateType'];
				$date=date("Y-m-d H:i:s");
				$rpId=$_POST['rplyid'];
				
				
			$rqry="insert into rnewrating(`comment`,`rating_id`,`reply_id`,`user_id`,`email`,`rateusertype`,`rating_by_userid`,`rating_by_useremail`,`user_type`,`insert_date`) values('$rcmnt','$ridd','$rpId','$uid','$umail','$utype','$urid','$urmail','$urtype','$date')";
			$run=mysqli_query($conn,$rqry);
			if($run)
			{
				?>
			<script>
			//alert('Thanks for your comment.');
			if (window.location.href.indexOf("comments") > -1) {
               var url=window.location.href;
			window.history.replaceState(null, null, url);
    }else{
			var url=window.location.href+"#comments";
			window.history.replaceState(null, null, url);
	}
		</script>
				<?
			}
			else{
				echo "error......!";
			}
			}


//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$qualifications[$data['id']] = utf8_encode($data['qualification']); 
		$c++;
	}		
}

$resHDs = fetchData(' `other_service_registration` ', " where user_id='".$oid."' ");
//echo ' `other_service_registration` ', " where user_id='".$oid."' ";
$othid = $resHDs['id'];
     if(isset($_POST['submit']))
	 {
		 $ins = "insert into comment_other set
		 `name` = '".$_POST['name']."', 
		 `email` = '".$_POST['email']."', 
		 `comment` = '".$_POST['comment']."', 
		 `oth_id` = '".$othid."', 
		 `status` = 'yes',		 
		 `insert_date` = now() 
		 ";
		 mysqli_query($conn,$ins) or die(mysqli_error());
			echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
			header('location:/'.$oid.'?openTab=commentsTab');
	 }
	 if(isset($_POST['rating']))
	 {		 echo $_POST['rating'];
			echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
			header('location:/'.$oid);
	 }
	 if(isset($_GET['id']))
	 {
		 $del = "delete from comment_other where id = '".$_GET['id']."' ";
		 mysqli_query($conn,$del) or die(mysqli_error());
			//echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
			header('location:/'.$oid.'?openTab=commentsTab');
	 }
	 if(isset($_GET['rid']))
	 {
		 $report_cmt = " UPDATE comment_other set `status`='no', `report`='report' where id = '".$_GET['rid']."' ";
		 mysqli_query($conn,$report_cmt) or die(mysqli_error());		 
		 	 
		 $Query_cmnt = mysqli_query($conn," select * from comment_other where id = '".$_GET['rid']."' ") or die(mysqli_error());		
		 $num = mysqli_num_rows($Query_cmnt);
		 $res_cmt = mysqli_fetch_array($Query_cmnt);
		
			
			// Mail to Report Abuse By...
				$report_by = $_SESSION['userEmail'];
				$comment_by = $res_cmt['email'];
				
				$subject = "FMI Report Abuse Information";

				$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>You did Report Abuse of <strong>'".$res_cmt['name']."'</strong> Comment. </br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";
				
				$message_to_comment_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>Your Comment have been Reported Abuse By <strong>'".$_SESSION['userName']."'</strong>. so we have to unpublished your comment due to the reason. </br>
						Reported By :- <strong>'".$_SESSION['userEmail']."'</strong></br>
						Reported Comment :- <strong>'".$res_cmt['comment']."'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";

				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				$headers .= 'From: <webmaster@example.com>' . "\r\n";
				$headers .= 'Cc: myboss@example.com' . "\r\n";

				$mail1 = mail($report_by,$subject,$message_to_report_by,$headers);
				$mail2 = mail($comment_by,$subject,$message_to_comment_by,$headers);
			
			// Mail to Commentor ..
			
			header('location:/'.$oid.'?openTab=commentsTab');
	 }
	if(isset($_POST['replysubmit'])){
		 $comment_id = $_POST['cmnt_id'];
		$rpy_commnt = mysqli_query($conn,"insert into comment_reply_other set 
		`comment_id`='$comment_id', 
		`reply_by_id`='".$_SESSION['userId']."',
		`reply_by_name`='".$_SESSION['userName']."',
		`reply_by_email`='".$_SESSION['userEmail']."',
		`reply_message`='".$_POST['Rcomment']."',
		`status`='yes' ") or die(mysqli_error());
		header('location:/'.$oid.'&openTab=commentsTab');
	}
?>
 <style type="text/css">
    	@media (max-width: 768px) 
         {
    	.rescontainer{
         margin-top: 176px!important;
         }
         .rate_vote {
        top: 768px!important;
           }
       }
    </style>
	
	<?		
		$resHD = fetchData(' `other_service_registration` ', " where user_id='".$oid."' ");
		$res_cmt = fetchAllData(" `newrating` ", " where user_id='".$othid."' and rateusertype='other'");
	?>
<div class="container">
	<div class="drmf-main-banner-top col-md-12">
		<div class="row">
			<? if($resHD['timeline_img']!="") {?>				
				<img class="img-responsive" src="/images/timeline/<? echo $resHD['timeline_img'] ?>">	
			<? } else { ?>	
				<img class="img-responsive" src="/images/about.png">		
			<? } ?>
		</div>
	</div>
	<div class="col-md-12 drmf-main-section1">
		<div class="row">
			<div class="col-md-4">
				<? if($resHD['pro_img']!="") {?>
					<img style="max-width: 200px;" class="fmi-profiles" src="/images/profile/<?=$resHD['pro_img']?>" />
				<? }
				else {?>
					<img src="/images/hospital.png" />
				<? } ?>
			</div>
			<div class="col-md-8">
				<h1><?=$resHD['name']?></h1>
				<div class="rating-container rating-xs rating-animate col-sm-12">
						<? $r=0; $i=0; foreach($res_cmt as $rat)
						{ 
							$r = $rat['rate'] + $r;
							$i++;
						}
						$count = $i;
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
					<a style="" href="#review-down">
						<div class="rating">
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						</div>
					</a>
				</div>
				<div class="drmf-main-describe col-sm-12">
				<!--	<p class="drmf-110"><span class="text-center">25 years</span></p> -->
				   <p class="drmf-111">
		<?
		$specialisation = explode("|", $resDD['specialisation']);
		foreach ($specialisation as $spl) {
		 echo $specialisations[$spl];
		}
			
		?></p>
				</div>
				<div class="col-sm-12">
					<? if($resHD['summary'] != "") {?>
						<div class="col-sm-12">
							<p><?= $resHD['summary']?></p>
						</div>
					<? } ?>
					
				</div>
				        <div class="col-sm-12">
				<?php 
					$User_email = $_SESSION['userEmail'];
					$copval = fetchData(" `rewards` ", " where user_email= '" . $User_email . "' ");
					$cval = $copval['coupon_point'];
					$rval = $copval['register_point'];
					$refval = $copval['reference_point'];
					$revval = $copval['review_point'];
					$cnew = $cval + $rval + $revval;
					
				?>	
				<style>
					.reward-point button {
						margin-left: 18px;
					}
				</style>
				<div class="reward-point">
						<span><b>Total Points:</b> <?php echo $cnew; ?> 
						<button type="submit" class="btn btn-primary" >Redeem Points</button></span>	
					</div>
					
				<div class="ref-url">
						<span id="nbref-url">Reference URL:<a href="<?php echo $refval;?>"> <?php echo $refval;?></a></span>
				</div>
					
					
				</div>

			</div>
		</div>
	</div>

	<div class="col-md-12" id="info-detail-single-p">
		<h2>General Information</h2>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-info-circle"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration No.</b></p>
					<p><?=$resHD['registration_no']?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-address-card"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration Authority</b></p>
					<p><?=$resHD['registration_authority']?></p>
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-12" id="info-detail-single-p">
		<h3>Contact Information</h3>
		<?php if($resHD['phone_no'] == '+91-'){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Phone No</b></p>
					<p>+<?= $resHD['phone_no'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['mobile_no'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p>+<?= $resHD['mobile_no'] ?></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['email'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-envelope"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Email</b></p>
					<p><a href="mailto:<?=$resHD['email']?>"><?=$resHD['email']?></a></p>
				</div>
			</div>
		</div>
		<? } ?>
		<?php if($resHD['website'] == ''){}else{?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-globe-asia"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Website</b></p>
					<p><a href="<?=$resHD['website']?>"><?=$resHD['website']?></a></p>
				</div>
			</div>
		</div>
		<? } ?>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-clock"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Time to call</b></p>
					<p><?=$resHD['time_to_call']?></p>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-map-marker-alt"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Address</b></p>
					<p><?= $resHD['address'] ?></p>
				</div>
			</div>
		</div>


	</div>
	
	<div class="col-md-12 info-specialise" id="info-detail-single-p">
		<p class="sp-li-title">Specialisations</p>
	
		<?
		$specialisation = explode("|", $resHD['specialisation']);
						foreach ($specialisation as $spec) {
							if($specialisations[$spec] == ''){}else{
													 
	?>
		<div class="col-md-3">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Specialisation</b></p>
					<p><?php echo $specialisations[$spec]."&nbsp;&nbsp;"; ?></p>
				</div>
			</div>
		</div>
		<?php 
			}}
		?>
	</div>
	
	<div class="col-md-12 experin-detail-p" id="main-table-sty">
		<h4>AVAILABLE FACILITY</h4>

		<div class="col-md-12 show1" id="show1">
			<table class="table">
				<?
					$available_facility = explode("-|-", $resHD['available_facility']); 
				?>
				<tbody>
					<tr>
					<?php 
					foreach($available_facility as $facility)
					
					{ 
						echo '<td>'. $facility .'</td>'; 
					}
					?>
				</tbody>
			</table>


		</div>
		
	</div>
	<? 
		$special_infra = explode("-|-", $resHD['special_infra']);
	?>
	<?php if(!empty( $resHD['special_infra'])){ ?>
	<div class="col-md-12 experin-detail-p" id="main-table-sty">
		<h4>SPECIAL INFRASTRUCTURE</h4>
		<div class="col-md-12 show1" id="show1">
			<table class="table">
				<tbody>
					<tr>
						<?
							foreach($special_infra as $infra)
							{
								echo '<td>'.$infra .'</td>';
							}
						?>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<? } ?>
	<? 
		$special_machine = explode("-|-", $resHD['special_machine']);
	?>
	<?php if(!empty( $resHD['special_machine'])){ ?>
	<div class="col-md-12 experin-detail-p" id="main-table-sty">
		<h4>SPECIAL MACHINERY</h4>

		<div class="col-md-12 show1" id="show1">
			<table class="table">
				<tbody>
					<tr>
					<?
						foreach($special_machine as $machine)
						{
							echo '<td>'.$machine . '</td>';			
						}
					?>
					</tr>

				</tbody>
			</table>


		</div>

	</div>
	<? } ?>


	<!--deals-->
<? $resdeals = fetchAllData("`deals`", " where hospital_id = '" . $resHD['id'] . "'"); ?>
<?php if(!empty($resdeals)){ ?>
	<div class="col-md-12 main-work-sl-p deal-single-p">
		<h5>Burning Deals</h5>
		<div class="deals-slider" id="recommend-deals-2">
			<? foreach ($resdeals as $rd) { ?>
			<div class="col-md-3 text-center">
				<div class="set-sider-top-img">
					<? if (!empty($rd['image'])) { ?>
					<center><img src="/admin/images/uploads/<?= $rd['image'] ?>"/></center>
					<? } else { ?>
					<center><img src="/images/hotdeals.png" /></center>
					<? } ?>
					<p class="text-left"><a class='ajax' href="/deal.php?id=<?= $rd['id'] ?>"><?= $rd['title'] ?></a></p>
					<!--<span class="deal-valid text-left"><strong>Offered By :</strong>Dr Pawan kumar</span> -->
				</div>
			</div>
			<? } ?>
		</div>
	</div>
<? } ?>

<div class="col-md-12 align-center text-sm review-slider" id="recommend-deals-1">

			<?php
			$image = $resHD['image_gallery'];
			//print_r($image);die;
		    $imagess= explode('|',$image);
			//print_r($imagess);
			//echo " `doctor_registration` ", "WHERE city = 1119 AND active='Yes' ORDER BY last_login LIMIT 0,10";die;
			foreach ($imagess as $galleryss) {
			?>
				<div class="item col-md-3 text-left">
					
						<img src="/images/gallery/<?= $galleryss; ?>">
					
				</div>

			<?php
			}
			?>

		</div>







	<!--Blogs-->
	<? $resBlog = fetchAllData("`blog`", " where  post_by = '" . $resHD['id'] . "' and userType = 'hospital' "); ?>
	<?php if(!empty($resBlog)){ ?>
	<div class="col-md-12 news-single-p">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h6>Latest News</h6>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
						<a href="/blog">View All<i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>
		<? foreach ($resBlog as $rb) { ?>
		<div class="col-md-3">
			<a href="/blog-detail.php?id=<?= $rb['id']; ?>">
				<? if ($rb['image'] != "") { ?>
				<img id="myimg" src="/admin/images/uploads/<?php echo $rb['image'];?>">
				<? } else { ?>
				<img src="/uploads/<?php echo $rb['image'];?>" class="img-responsive">
				<? } ?>
			</a>
			<div class="caption-full-main">
				<div class="caption-full-data">
					<p><a href="/blog-detail.php?id=<?= $rb['id']; ?>"><?= $rb['title'] ?></a></p>
				</div>
				<div class="ratings text-right">
					<a href="/blog-detail.php?id=<?= $rb['id'];?>">Read More <i class="fa fa-angle-right"></i></a>
				</div>
			</div>
		</div>
		<? } ?>
	</div>
<? } ?>


<? 
	$resDPI = fetchAllData(" `available_specialist_other_medical_reg` ", " WHERE other_medical_id = '" . $resHD['id'] . "' ");
	  if(!empty($resDPI)){
?> 
	   <div class="col-md-12 experin-detail-p" id="main-table-sty">
		<h4>Available Doctors</h4>
		<div class="col-md-12 show1" id="show2">
			<table class="table">
			<tbody>
			<?php 	foreach ($resDPI  as $D) {
           $DPI = fetchData(" `doctor_registration` ", " where id = '" . $D['doctor_id'] . "' "); 
		    if($DPI['name'] ==  ''){}else{
            ?>
				<tr>
				<td><?= $DPI['name'] ?></td>
					<td>
					<?php
						$specialisation = explode("|", $DPI['specialisation']);
						foreach ($specialisation as $spl) {
						$spliOther = explode(":", $spl);
						if ($spliOther[0] == "Other") {
						echo $spliOther[1] . "<br/>";
						} else {
						echo $specialisations[$spl] . "&nbsp;";
						}
						}
					?> - 
					<a class="ajax" href="/avail-specialist-in-other-service.php?id=<?= $D['id'] ?>"> View Timing</a>
					</td>
				</tr>
			<?php }} ?>
			</tbody>
		</table>
		</div>
		</div>
	<?php } ?>

	<div class="col-md-12">
		<div class="single-p-review" id="review-down">
			<div class="col-md-6">
				<div class="single-set-rating text-center">
					<p class="p-rate-1"><b>Overall Rating</b></p>
					<div class="rating-container rating-xs rating-animate col-sm-12">
					<div class="single-p-rating rating">
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
					</div>
					</div>
					<p class="p-rate-2">Based on <?php echo $count; ?> Experiences</p>
				</div>
			</div>
			<div class="col-md-6">
				<div class="single-set-rating2 text-center">
					<p class="p-rate-1"><b>Rate your experience</b></p>
					<p class="p-rate-2">How likely are you to recommend us?</p>
					<div class="single-p-rating1">
					<a href="/rating/<?= $oid ?>">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="col-md-12 tab-pane" id="comments">
	<div class="col-md-12 news-single-p">
		<div class="col-md-12" id="main-top-detail-11">
				<div class="row">
					<div class="col-md-8">
						<h6>Comments</h6>
					</div>
					<div class="col-md-4">
						<div class="special-btn-area text-right">
						
						</div>
					</div>
				</div>
		</div>
		
	<? include('comment.php'); ?>
	
	</div>
	</div>
</div>

<div class="bottom-footer-slider" id="hospital-detail-top-doct">
	<div class="container">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h4>Recommended Other Hospital <span style="color:#ed1c24;">near you</span></h4>
					<p>Private online consultations with verified Other Hospital in all specialists</p>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
						<a href="/others">View All Other Hospital <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>
<div class="col-md-12 align-center text-sm review-slider" id="recommend-deals-1">
	<?
	$sId=$oid;
     $res = hospital_detail(" `other_service_registration`", "where user_id='$sId'");
			$vars=$res[0];
			
			$x = explode("|", "$vars");
		    if(empty($x)){
				
			$specs = ' or specialisation like "%' .$vars . '%"';	
			}else{
			foreach ($x as $val) {
				$specs .= ' or specialisation like "%' . $val . '%"';
			}
            }
			
			$vars2=$res['city'];
	$res_other = fetchAllData(" `other_service_registration`", "where  active = 'Yes' AND specialisation like '%fgfgfgfgf%' $specs AND city = $vars2");			
foreach($res_other as $other ) {
	
	?>
	
		<div class="item col-md-3 text-left">
			<div class="d-details-per-column">
				<? if ($other['pro_img'] != "") { ?>
			<img src="/images/profile/<?= $other['pro_img'] ?>" class="img-responsive">
			<? } else { ?>
			<img src="/images/doctor-face.jpg" class="img-responsive ">
		    <? } ?>
				<div class="col-sm-12 in-details-main-f featured-color">
					<p class="name-d"><a href="/<?= $other['user_id'] ?>" target="_blank"><?php echo ucfirst($other['name']) ?></a></p>
					<p class="special-d">		
				<? $specialisation = explode("|", $other['specialisation']);
				foreach ($specialisation as $spec) 
				{
					echo trim($specialisations[$spec] . "&nbsp;");
				} 
			    ?>
			</p>
					<div class="rating-container rating-xs rating-animate">
			<div class="average-rating-d">
				<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");

						
                        $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
			</div>
			<div class="rating">
			<a style="" href="/rating/<?= $doct['user_id'] ?>">
				<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
					</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
					</span></span>
				<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
                    </a></div>
		</div>
				</div>
			</div>
		</div>
		
	<?php } ?>
				</div>
			</div>
		</div>
    <!-- /.container -->


    <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
    <script src="/js/star-rating.js" type="text/javascript"></script>
  <script>
  $(document).ready(function(){
  $("#nbref-url").click(function(){
    document.location.href = "https://dev.freemedicalinfo.in/register.php";
  });
  $('#nbref-url').css( 'cursor', 'pointer' );
});
</script>
	 <script>
        jssor_2_slider_init();
    </script>

	<? include('include/footer.php'); ?>
	<script>
	$('.review-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 6000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1220,
				settings: {
					slidesToShow: 3,
				},
			},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>
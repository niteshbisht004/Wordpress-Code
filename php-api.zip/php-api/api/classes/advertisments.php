<?php
class Advertisments{

        // Connection
        private $conn;

        // Table
        private $db_table = "left_advt";

          // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

  
        public function getAdvts(){
            $sqlQuery = "SELECT * FROM left_advt WHERE `status` = '1'"; 
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
        public function getSingleAdvt($id,$user){ 
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       userid = $id AND usertype = '$user'";
           
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }

    }

?>
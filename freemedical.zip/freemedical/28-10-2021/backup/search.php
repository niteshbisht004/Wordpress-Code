<?php 

if (isset($_GET['search']) && is_array($_GET['search']) && !empty($_GET['search']['type'])) {
	
	include('include/connection.php');
	include('include/function.php');
	

	
	$st_type = $_GET['search']['type'];
	
	$url = "";
	
	if ($st_type=="doctor") {
		
		$url = _MAINPATH_."doctors?";	
	}else if ($st_type=="hospital") {
		
		$url = _MAINPATH_."hospitals?";	
	}else if ($st_type=="deal") {
		
		$url = _MAINPATH_."deal-list.php?";	
	} else 	if ($st_type=="blog") {
		
		$url = _MAINPATH_."blog-list.php?";	
	} else 	if ($st_type=="Search Type") {
		
		$url = _MAINPATH_."searchresult.php?";	
	}
	else {
		
		$url = _MAINPATH_."others?";	
	}
	

	
	foreach($_GET['search'] as $k=>$v) {
		
		$url.="$k=$v&"; 
	}
	
	
	$url = substr($url,0,-1);	
	
	
	header("location: $url");
	exit;
}



include("include/header.php"); 

	
//Specialisation List
global $specialisations;
$resHD = mysqli_query($conn,"SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}

//Qualification Lists
global $qualifications;
$resHD = mysqli_query($conn,"SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$qualifications[$data['id']] = utf8_encode($data['qualification']); 
		$c++;
	}		
}

//Hospital Category List
global $hospital_cats;
$resHD = mysqli_query($conn,"SELECT * FROM hospital_cat") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$hospital_cats[$data['id']] = utf8_encode($data['category_name']); 
		$c++;
	}		
}
	
?>
<style>
.detail img{display: block; max-width: 100%; height: auto;}
</style>
<div class="container">
	<div class="row">
		
		<? include('include/sidebar.php'); ?>
		
		<div class="col-md-9">
	
			<div class="thumbnail">
				<img class="img-responsive" src="images/about.png" style="height: 199px;" alt="">
			</div>
	    </div>
		
	    <div class="col-md-9">
		
	        <div class="col-md-12" style="padding-left:0px; padding-right:0px;">
				<?php
				
				global $search_term,$exclusions;
				$search_term = $_GET['search-item'];
				$exclusions = "";
				
				include "search-code.php";
				
				
				if($_GET['search-item']!=="") {	
				
					$search_item = trim(addslashes($_GET['search-item']));
					
					//search full term
					$keyword_id = find_keyword($search_item);
					
					if ($keyword_id) {
						
						if (is_array($keyword_id)) {
							$keyword_ids[] = $keyword_id['id'];
							$keyword_ids[] = $keyword_id['parent_id'];
						} else {
							$keyword_ids[] = $keyword_id;
						}
						
						$total_keywords = count($keyword_ids);
					
					} else {
					
						if (strpos($search_item," in ")!==FALSE) {
							
							$keyword_operator = "and";
							$search_keywords = explode(" in ",$search_item);	
							
							//$search_item = str_replace("in ","",$search_item);
							//$search_item = str_replace("for ","",$search_item);
							
						} else if (strpos($search_item," for ")!==FALSE) {	
							
							$keyword_operator = "and";
							$search_keywords = explode(" for ",$search_item);
							
						} else {
							
							$keyword_operator = "or";
							
							//whole word
							$search_keywords6 = array($search_item);
							
							//break words by in;
							//$search_keywords1 = explode("in",$search_item);
							
							//break words by and;
							$search_keywords2 = explode("and",$search_item);
							
							//break words by for;
							//$search_keywords3 = explode("for",$search_item);
							
							//break words by ,;
							$search_keywords4 = explode(",",$search_item);
							
							//break words by space;
							$search_keywords5 = explode(" ",$search_item);
							
							
							$search_keywords = array_unique(array_merge($search_keywords2,$search_keywords4,$search_keywords5,$search_keywords6));						
						}
						
						$total_keywords = count($search_keywords);
						
						//var_dump($search_keywords);
						
						$keyword_ids = array(); 
						foreach ($search_keywords as $keyword) {
							$keyword_id = find_keyword(trim($keyword));
							if ($keyword_id) {
								if (is_array($keyword_id)) {
									
									//use only parent keyword for and operators
									if ($keyword_operator!="and") {
										$keyword_ids[] = $keyword_id['id'];	
									}
									
									$keyword_ids[] = $keyword_id['parent_id'];
								} else {
									$keyword_ids[] = $keyword_id;
								}
							}
						}	
					}
					
					//var_dump($keyword_ids);
					//var_dump($keyword_operator);
					
					
					//if keywords not matched search and match witihin keywords
					if (count($keyword_ids)==0) {
						
						//break words by space;
						$search_keywords = explode(" ",$search_item);
						
						//var_dump($search_keywords);
						
						$keyword_ids = array(); 
						foreach ($search_keywords as $word) {
							if ($kids = find_in_keywords(trim($word))) {
								$keyword_ids = array_merge($keyword_ids,$kids);
							}
						}
						
						//$keyword_operator = "or";
					}
					
					
					//var_dump($keyword_ids);
					
					if (count($keyword_ids)!=$total_keywords) {
						
						$hits = false;
					
					
					} else
					
					if (!$keyword_operator || $keyword_operator=="or") {
						
						$hits = array();
						foreach ($keyword_ids as $keyword_id) {
							
							$key = mysqli_query($conn,"SELECT * FROM keywords_relation WHERE keyword_id = '$keyword_id'") or print(mysqli_error()); 
							while($h = mysqli_fetch_assoc($key)) {
								
								if (isset(${$h['object_type']}[$h['object_id']])) {
									${$h['object_type']}[$h['object_id']] ++;
									$hits [$h['object_type']] ++;  	
								} else {
									${$h['object_type']}[$h['object_id']] = 1;
									$hits [$h['object_type']] = 1;
								}
							}					
						}
					
					} elseif ($keyword_operator=="and") {
						
						$hits = array();
						
						$key = mysqli_query($conn,"SELECT * FROM keywords_relation WHERE keyword_id = '".$keyword_ids[0]."'") or print(mysqli_error()); 
						while($h = mysqli_fetch_assoc($key)) {
							
							$found[$h['object_type']][$h['object_id']] = true;
							
							foreach ($keyword_ids as $keyword_id) {
								
								$key2 = mysqli_query($conn,"SELECT * FROM keywords_relation WHERE keyword_id = '".$keyword_id."' AND object_id='".$h['object_id']."' AND object_type='".$h['object_type']."' ") or print(mysqli_error());
								if (mysqli_num_rows($key2)>0) {
									$found[$h['object_type']][$h['object_id']] = true;	
								} else {
									unset($found[$h['object_type']][$h['object_id']]);
									break;
								}
							}
							 
							
							if ($found[$h['object_type']][$h['object_id']]) {
								
								if (isset(${$h['object_type']}[$h['object_id']])) {
									${$h['object_type']}[$h['object_id']] ++;
									$hits [$h['object_type']] ++;  	
								} else {
									${$h['object_type']}[$h['object_id']] = 1;
									$hits [$h['object_type']] = 1;
								}
							}
						}					
					}
					
					//var_dump($hits);
					
					//Sort results by relevance (hits);
					asort($hits);
					
					foreach ($hits as $key => $hit_count) {
						
						if ($hit_count>0) {
							
							//sort by hits
							asort(${$key});
							
							if (count(${$key})) {
								
								foreach (${$key} as ${$key."_id"} => $hit) {
									${$key."_ids"}[] = ${$key."_id"};  	
								}
								
								//var_dump(${$key."_ids"});
								
								$function_name = "show_".$key."_results";
								
								if (function_exists($function_name)) {
									${"res_".$key} = $function_name(${$key."_ids"});							
								//var_dump(${"res_".$key});
								}
								
								if ($hits[$key] = count(${"res_".$key})) {
									${"search".$key."More"} = "search_$key.php?search=".$_GET['search-item']."&submit=Search";
									include($key."_result.php");	
								}
							}
						}
					}
					
					
					
					if (!$hits['doctor']) {
					
						$not_found .= "<span style='color:red'>Doctors not matched</span><br />";
		
					}
					
					
					if (!$hits['hospital']) {
						
						$not_found .= "<span style='color:red'>Hospitals not matched</span><br />";
		
					}
					
					if (!$hits['service']) {
					
						$not_found .= "<span style='color:red'>Services not matched</span><br />";
		
					}
					
					
					if (!$hits['deal']) {
					
						$not_found .= "<span style='color:red'>Deals not matched</span><br />";
		
					}
					
					if (!$hits['blog']) {
					
						$not_found .= "<span style='color:red'>Articles not matched</span><br />";
		
					}
					
					
					echo $not_found."<br /><br /><br />";
				
				} else {
					
					header ("location: index.php");
					
				}
				
				//end if;*/
				
				?>
			</div> <!-- col end --> 
	    </div>	
	
		<div class="col-md-12">
			<div class="most-active-profile">
				<h4 class="heading">Our Associate</h4>
				<div id="jssor_2" class="jssor_2">
					<!-- Loading Screen -->
					<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
						<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
						<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
					</div>
					<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 100%; height: 100px; overflow: hidden; ">
						<?php 
						  // $queryAs=mysqli_query($conn,"select * from our_associate");
						   while($rowAs=mysqli_fetch_object($queryAs))
						   {
						 ?>
						   <div style="display: none;">
								<img data-u="image" src="admin/images/uploads/<?php echo $rowAs->image; ?>" style="margin-left:30px;"/>
							</div>
							<?php 
						   }
							?>
					</div>
				</div>
			</div>
		</div>
	</div> <!-- row end -->
</div>
<!-- /.container -->

<? include('include/footer.php'); ?>
    <script type="text/javascript" src="js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
    
	 <script>
        jssor_2_slider_init();
    </script>
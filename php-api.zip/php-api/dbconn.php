<?php 
    $conn=mysqli_connect('localhost', 'id17325649_niteshbisht004', 'l~$8o/0aQKh#Sm*9', 'id17325649_project');
    if($conn==true)
    {
        //echo "connected....";
    }
    else
    {
        echo "error....";
    }
?>
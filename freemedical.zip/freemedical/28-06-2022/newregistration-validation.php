<?
	include('include/connection.php');
	include('include/function.php');
	$current_date = date('Y/m/d h:i:s');
	function get_tiny_url($url)  {  
	$ch = curl_init();  
	$timeout = 5;  
	curl_setopt($ch,CURLOPT_URL,'http://tinyurl.com/api-create.php?url='.$url);  
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);  
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);  
	$data = curl_exec($ch);  
	curl_close($ch);  
	return $data;  
}

	 function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 6; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
	 }
	// user registration	
	if($_REQUEST['regForm']=="userForm"){
		
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
			//if($id !=""){
			
				
				
				
				
				$error[] = 'Email provided is already in use.';
							}	
		}
		//if(strlen($_REQUEST['pw']) < 6){
		//	$error[] = 'Password is too short.';
		//}
		
		if(!isset($error)){
            $email = $_REQUEST['email'];
			$a = explode('@', $email);
             $foostring = $a[0];
            $fooss = str_replace('-', '', $foostring);
            $foo = preg_replace('/[^A-Za-z0-9\-]/', '', $fooss);
//echo  $string    die;

             // Replaces all spaces with hyphens.
   //return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
            $randomPassword=randomPassword();
			$activasion = rand(100000,999999);
			$ins = "insert into users set
            `user_id` = '".$foo."',
			`first_name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."', 
			`email` = '".$_REQUEST['email']."',
			`active` = '".$activasion."',
			`password` = '".$randomPassword."',
			`insert_date` = '".$current_date."'
			";
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			//$userid = mysqli_insert_id($conn);
			
			 $id = $_REQUEST['email'];
			 	if($id !=""){
			    $desd="SELECT * FROM rewards where user_id='$id'";
			    $res= mysqli_query($conn,$desd);
			
				//echo "hello";
				if(mysqli_num_rows($res)>0){
					$resfetch = mysqli_fetch_assoc($res);
					 $register_point= $resfetch['register_point']+50;
					 $refp = $resfetch['user_id'];
					 $refurl = "https://dev.freemedicalinfo.in/$refp";
					$query1="UPDATE rewards SET register_point='$register_point', reference_point='' WHERE user_id='$id'";
					 $ress= mysqli_query($conn,$query1);
					 echo "https://dev.freemedicalinfo.in/$id";
				}else{
					echo "invalid referral code";
				}
			
				}else{

			
			$insrew = "insert into rewards set
					  `user_id` = '".$foo."',
					  `user_type` = '".$_REQUEST['regForm']."',
					  `user_email` = '".$_REQUEST['email']."',
					  `register_point` = '50'
				";
				
			$query = mysqli_query($conn,$insrew) or die(mysqli_error());
			
				}
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-user&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			
			$num = $_REQUEST['phone'];
			

	
			$fields = array(
				"sender_id" => "TXTIND",
				"message" => "Thank you for registering at freemedicalinfo site. Here is the OTP:\n ".$activasion,
				"route" => "v3",
				"numbers" => $num,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  //echo $response;
			} 
			
          	
			mysqli_query($conn,"insert into `all_users` set user_id = '".$foo."', user_type = 'user', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
			
			//echo "https://dev.freemedicalinfo.in/otpregistraion/$userid-user";
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	// doctor registration
	if($_REQUEST['regForm']=="doctorForm"){
		
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
		//if(strlen($_REQUEST['pw']) < 6){
		//	$error[] = 'Password is too short.';
		//}
		if(!isset($error)){
			$email = $_REQUEST['email'];
			$a = explode('@', $email);
             $foostring = $a[0];
            $fooss = str_replace('-', '', $foostring);
            $foo = preg_replace('/[^A-Za-z0-9\-]/', '', $fooss);
			$activasion = rand(100000,999999);
			$ins = "insert into doctor_registration set
			`user_id` = '".$foo."',
			`name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."',
			`password` = '".$randomPassword."',
			`email` = '".$email."',
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'";
			
		
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn); 
			
			$insrew = "insert into rewards set
					  `user_id` = '".$foo."',
					  `user_type` = '".$_REQUEST['regForm']."',
					  `user_email` = '".$_REQUEST['email']."',
					  `register_point` = '50'
				";
			$query = mysqli_query($conn,$insrew) or die(mysqli_error());
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-doctor&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			$num = $_REQUEST['phone'];
		
			
			$fields = array(
				"sender_id" => "TXTIND",
				"message" => "Thank you for registering at freemedicalinfo site. Here is the OTP:\n ".$activasion,
				"route" => "v3",
				"numbers" => $num,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  //echo $response;
			}
			
		
			
			mysqli_query($conn,"insert into `all_users` set user_id = '".$foo."', user_type = 'doctor', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
          	if($id !=""){	
			echo "https://dev.freemedicalinfo.in/otpregistraion/$id-doctor";
			}
				else{
					echo "doctor id not found";
				}
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	
	// hospital registration
	if($_REQUEST['regForm']=="hospitalForm"){

		
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
	
		if(!isset($error)){
			$email = $_REQUEST['email'];
			$a = explode('@', $email);
             $foostring = $a[0];
            $fooss = str_replace('-', '', $foostring);
            $foo = preg_replace('/[^A-Za-z0-9\-]/', '', $fooss);
			$activasion = rand(100000,999999);
			$activasion = rand(100000,999999);
			$ins = "insert into medical_registration set
			 `user_id` = '".$foo."',
			`name` = '".$_REQUEST['fname']."',
			`O_contact` = '".$_REQUEST['phone']."',
			`password` = '".$randomPassword."',
			`email` = '".$email."',  
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn);
			
			$insrew = "insert into rewards set
					  `user_id` = '".$foo."',
					  `user_type` = '".$_REQUEST['regForm']."',
					  `user_email` = '".$_REQUEST['email']."',
					  `register_point` = '50'
				";
			$query = mysqli_query($conn,$insrew) or die(mysqli_error());
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-hospital&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
          	
		      $num = $_REQUEST['phone'];
			
			$fields = array(
				"sender_id" => "TXTIND",
				"message" => "Thank you for registering at freemedicalinfo site. Here is the OTP:\n ".$activasion,
				"route" => "v3",
				"numbers" => $num,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  //echo $response;
			}
			
			mysqli_query($conn,"insert into `all_users` set user_id = '".$foo."',  user_type = 'hospital', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
				if($id !=""){
			echo "https://dev.freemedicalinfo.in/otpregistraion/$id-hospital";
				}
				else{
					echo "hospital";
				}
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	// Other Medical Service registration
	if($_REQUEST['regForm']=="other-medical"){
	
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
	
		if(!isset($error)){
		    if($_REQUEST['fld'] == 'other')
		    {
		    
		   $fld =    $_REQUEST['fldedu'];
		        
		    }else{
		    
		    $fld =    $_REQUEST['fld'];    
		        
		    }
		    $email = $_REQUEST['email'];
		   $a = explode('@', $email);
             $foostring = $a[0];
            $fooss = str_replace('-', '', $foostring);
            $foo = preg_replace('/[^A-Za-z0-9\-]/', '', $fooss);
			$activasion = rand(100000,999999);
			$ins = "insert into other_service_registration set
			`user_id` = '".$foo."',
            `name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."',			
			`password` = '".$randomPassword."',
			`email` = '".$email."',  
			`service` = '".$fld."',  
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn);
			
			$insrew = "insert into rewards set
					  `user_id` = '".$foo."',
					  `user_type` = '".$_REQUEST['regForm']."',
					  `user_email` = '".$_REQUEST['email']."',
					  `register_point` = '50'
				";
			$query = mysqli_query($conn,$insrew) or die(mysqli_error());
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-other&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			$num = $_REQUEST['phone'];
			$fields = array(
				"sender_id" => "TXTIND",
				"message" => "Thank you for registering at freemedicalinfo site. Here is the OTP:\n ".$activasion,
				"route" => "v3",
				"numbers" => $num,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			$response = curl_exec($curl);
			$err = curl_error($curl);

			curl_close($curl);

			if ($err) {
			  echo "cURL Error #:" . $err;
			} else {
			  //echo $response;
			}
			
			mysqli_query($conn,"insert into `all_users` set user_id = '".$foo."', user_type = 'other', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
          		if($id !=""){	
			echo "https://dev.freemedicalinfo.in/otpregistraion/$id-other";
				}
				else{
					
					echo "other id not found";
				}
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
?>
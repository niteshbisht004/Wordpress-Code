<?php
class Blogs{

        // Connection
        private $conn;

        // Table
        private $db_table = "blog";
        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getBlogs(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " order by id desc"; 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		 public function getcommentBlogs($id){
            $sqlQuery = "SELECT * FROM comment_table WHERE topic_id='".$id."' AND status='0'"; 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }

       





        // READ single
        public function getSingleBlogs($id,$user){ 

            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       post_by = $id AND userType = '$user'";
          
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }
         

        public function getSingleBlog($id){ 
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id";
           
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }   

       public function getBlogComment($id){ 
            $sqlQuery = "SELECT  * FROM comment_table WHERE topic_id = $id";
           
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }  

        
       public function getRplyBlogComment($id){ 
            $sqlQuery = "SELECT  * FROM comment_reply_blog WHERE comment_id = $id";
           
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        } 		

     public function blogCmntByUser($topic_id,$name,$email,$comment,$insert_date,$status)
	 {
			$blogQuery="insert into comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='$status'";
						$stmt=$this->conn->query($blogQuery);
						return $stmt;
	 }
	 
	 
	 public function blogCmntEditUser($topic_id,$name,$email,$comment,$insert_date,$status,$id)
	 {
			$blogQuery="UPDATE comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'
						WHERE id = '$id'";
						$stmt=$this->conn->query($blogQuery);
						
						if($stmt)
						{
							return $stmt;
						} 
	 }
	 
	 public function blogCmntEditHospital($topic_id,$name,$email,$comment,$insert_date,$status,$id)
	 {
			$blogQuery="UPDATE comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'
						WHERE id = '$id'";
						$stmt=$this->conn->query($blogQuery);
						
						if($stmt)
						{
							return $stmt;
						} 
	 }
	 
	 public function blogCmntEditDoctor($topic_id,$name,$email,$comment,$insert_date,$status,$id)
	 {
			$blogQuery="UPDATE comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'
						WHERE id = '$id'";
						$stmt=$this->conn->query($blogQuery);
						
						if($stmt)
						{
							return $stmt;
						} 
	 }
	 
	 public function blogCmntEditOther($topic_id,$name,$email,$comment,$insert_date,$status,$id)
	 {
			$blogQuery="UPDATE comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'
						WHERE id = '$id'";
						$stmt=$this->conn->query($blogQuery);
						
						if($stmt)
						{
							 
							return $stmt;
						} 
	 }
	 
	 public function deleteCmntTable($id)
		{
            $sqlQuery = "DELETE FROM comment_table WHERE id=$id"; 
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
	 
        // DELETE
        public function deleteBlogs($id)
		{
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id=$id"; 
			
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function addBlogCmntByDoc($topic_id,$name,$email,$comment,$insert_date,$status)
		{
			$sqlQuery="insert into comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'";
					
						$stmt=$this->conn->query($sqlQuery);
						 $this->id = $this->conn->insert_id; 
						return $stmt;
		}
		
		public function addBlogCmntByHos($topic_id,$name,$email,$comment,$insert_date,$status)
		{
			$sqlQuery="insert into comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'";
						
						$stmt=$this->conn->query($sqlQuery);
						 $this->id = $this->conn->insert_id; 
						return $stmt;
		}
		
		
		public function addBlogCmntByOther($topic_id,$name,$email,$comment,$insert_date,$status)
		{
			$sqlQuery="insert into comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'";
						
						$stmt=$this->conn->query($sqlQuery);
						 $this->id = $this->conn->insert_id; 
						return $stmt;
		}
		
		
		public function addBlogCmntByUser($topic_id,$name,$email,$comment,$insert_date,$status)
		{
			$sqlQuery="insert into comment_table set
						topic_id='$topic_id',
						name='$name',
						email='$email',
						comment='$comment',
						insert_date='$insert_date',
						status='0'";
					
						$stmt=$this->conn->query($sqlQuery);
						 $this->id = $this->conn->insert_id; 
						return $stmt;
		}
		
		public function addrplyBlogCmntByUser($comment_id, $reply_by_name,$reply_by_email,$reply_message,$insert_date,$status)
		{
			$sqlQuery="insert into  comment_reply_blog set
						comment_id='$comment_id',
						reply_by_name='$reply_by_name',
						reply_by_email='$reply_by_email',
						reply_message='$reply_message',
						date='$insert_date',
						status='0'";
					
						$stmt=$this->conn->query($sqlQuery);
						 $this->id = $this->conn->insert_id; 
						return $stmt;
		}
		
		
		public function delDocBlogComment($id){ 
		   $sqlQueryd = "DELETE FROM comment_reply_blog WHERE comment_id = $id";
           
            $stmtd = $this->conn->query($sqlQueryd);
            $sqlQuery = "DELETE FROM comment_table WHERE id = $id";
           
            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }  

    }
?>
<? include("include/header.php"); 

//Specialisation List
$resHD = mysqli_query($conn,"SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}

//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$qualifications[$data['id']] = utf8_encode($data['qualification']); 
		$c++;
	}		
}

//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM cities") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$cities[$data['id']] = utf8_encode($data['name']); 
		$c++;
	}		
}	
	
if(isset($_POST['submit'])){
	$conn = db();
	
	$id = $_GET['userid'];
    $res = fetchData(" `all_users` ", " where `user_id`= '".$id."'");
	$remail = $res['email'];
	$ruserid = $res['userId'];
	$rusertype = $res['user_type'];
	
	
	
	$rate = $_POST['rate'];
	$recommend = $_POST['highlyrecommend'];
	$comment = $_POST['comment'];

	$userid = $_SESSION['userId'];
	$email = $_SESSION['userEmail'];
	$usertype =	$_SESSION['userType'];
	if($rate == 5){
		
		$star5 = '5';
	}
	if($rate == 4){
		
		$star4 = '4';
	}
    if($rate == 3){
		
		$star3 = '3';
	}
    if($rate == 2){
		
		$star2 = '2';
	}
    if($rate == 1){
		
		$star1 = '1';
	}	
	$ins = "INSERT INTO newrating set 
	 `user_id` = '".$ruserid."',
	 `rateusertype` = '".$rusertype."',
	 `email` = '".$remail."',
	 `rate` = '".$rate."',
	 `5star`='".$star5."',
	 `4star`='".$star4."',
	 `3star`='".$star3."',
	 `2star`='".$star2."',
	 `1star`='".$star1."',
	 `recommend`='".$recommend."',
	 `comment`='".$comment."',
	 `rating_by_userid`='".$userid."',
	 `rating_by_useremail`='".$email."',
	 `user_type`='".$usertype."',
	 `insert_date`='".date("Y-m-d H:i:s")."',
	 `timestamp`='".date("Y-m-d H:i:s")."'";

	$sql= mysqli_query($conn,$ins);		
	if($sql)
	{
		?>
		<script>
			//alert('https://dev.freemedicalinfo.in/<?php echo $rusertype; ?>/<?php echo $id; ?>');
			window.location.href = 'https://dev.freemedicalinfo.in/<?php echo $id; ?>#comments';
			// window.history.go(-2);
		</script>
		<?
	}
	else{
		echo 'error';
	}
		
	$copval = fetchData(" `rewards` ", " where user_email= '" . $email . "' ");
		$cval = $copval['review_point'];
		$cnew = $cval + 10;
		
		$insrew = "update rewards set
					  `review_point` = '".$cnew."' where `user_email` = '".$email."'
				";
		$query = mysqli_query($conn,$insrew) or die(mysqli_error());	
	
}
if(isset($_POST['rsubmit'])){
	$conn = db();
	$eid=$_POST['ratingid'];
	
	$id = $_GET['userid'];

	$remail = $_POST['email'];
	$ruserid = $_POST['userId'];
	$rusertype = $_POST['user_type'];
	
	
	$rate = $_POST['rate'];
	$recommend = $_POST['highlyrecommend'];
	$comment = $_POST['comment'];

	$userid = $_SESSION['userId'];
	$email = $_SESSION['userEmail'];
	$usertype =	$_SESSION['userType'];
	if($rate == 5){
		
		$star5 = '5';
	}
	if($rate == 4){
		
		$star4 = '4';
	}
    if($rate == 3){
		
		$star3 = '3';
	}
    if($rate == 2){
		
		$star2 = '2';
	}
    if($rate == 1){
		
		$star1 = '1';
	}	
	$update = "update newrating set 
	 `user_id` = '".$ruserid."',
	 `rateusertype` = '".$rusertype."',
	 `email` = '".$remail."',
	 `rate` = '".$rate."',
	 `5star`='".$star5."',
	 `4star`='".$star4."',
	 `3star`='".$star3."',
	 `2star`='".$star2."',
	 `1star`='".$star1."',
	 `recommend`='".$recommend."',
	 `comment`='".$comment."',
	 `rating_by_userid`='".$userid."',
	 `rating_by_useremail`='".$email."',
	 `user_type`='".$usertype."',
	 `insert_date`='".date("Y-m-d H:i:s")."',
	 `timestamp`='".date("Y-m-d H:i:s")."'
	 where `id`='".$eid."'";
	$sql= mysqli_query($conn,$update);		
	if($sql)
	{
		?>
		<script>
			//alert("Record has been updated...!");
			window.location.href = 'https://dev.freemedicalinfo.in/<?php echo $id; ?>#comments';
		</script>
		<?
	}
	
	
}
?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">
			<!-- Slider Start -->
			<div class="col-md-12">

				<div class="thumbnail">
					<img class="img-responsive" src="/images/about.png" style="height: 199px;" alt="">
				</div>
            </div>
			
            <div class="col-md-12" id="rating-main-login">
			
				<? if(!empty($_SESSION['userEmail'])) { ?>
			<style>
			*{
    margin: 0;
    padding: 0;
}
.rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > input {
    position:absolute;
    top:-9999px;
}
.rate:not(:checked) > label {
    float:right;
    width:5em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
   font-size: 25px;
    color: #333;
	font-weight:400 !important;
}
.rate:not(:checked) > label:before {
    content: '★ ';
}
.rate > input:checked ~ label {
    color: #ffc700;    
}
.rate:not(:checked) > label:hover,
.rate:not(:checked) > label:hover ~ label {
    color: #deb217;  
}
.rate > input:checked + label:hover,
.rate > input:checked + label:hover ~ label,
.rate > input:checked ~ label:hover,
.rate > input:checked ~ label:hover ~ label,
.rate > label:hover ~ input:checked ~ label {
    color: #c59b08;
}

.rating-radio {
    font-size: 20px;
    font-weight: 500;
}
</style>
<?php 
   $id = $_GET['userid'];

    $res = fetchData(" `all_users` ", " where `user_id`= '".$id."'");

	$remail = $res['email'];
	$email = $_SESSION['userEmail'];
	
	$qry="select * from newrating where `email`='$remail' AND `rating_by_useremail`='$email'";
	$run=mysqli_query($conn,$qry);
	$count=mysqli_num_rows($run);
	if($count > 0)
	{ ?>
		<div class="rating-radio">
			<input type="radio" name="edit" value="1" id="edit-rate"> Edit Rating
			<input type="radio" name="edit" value="2" id="edit-cmnt"> Edit Comment
		</div>	
		<br>
<form style="border: 1px solid; border-radius: 5px;background: #f9f9f9;display: inline-block;height: auto;" method="POST" action=""> 
<div class="col-md-12 myedit" style="display: none;"> 
<h2 class="">How would rate your experience?</h2>	
 
 <?php 
   $email = $_SESSION['userEmail'];
	$eres = fetchData(" `newrating` ", "where `email`= '".$remail."' AND `rating_by_useremail`= '".$email."'");
	//echo " `rating` ", " where `id`= '".$eid."'";
	$eid=$eres['id'];
	$erate=$eres['rate'];
	$ecomnt=$eres['comment'];
	$rec=$eres['recommend'];
	$rmail=$eres['email'];
	$rtype=$eres['rateusertype'];
	$u_id=$eres['user_id']
	//echo $rec;
?>	
 <div class="rate">
    <input type="radio" id="star5" name="rate" value="5" <?php if($erate==5){ echo 'checked';} ?>/>
    <label for="star5" title="text">5 stars</label>
    <input type="radio" id="star4" name="rate" value="4" <?php if($erate==4){ echo 'checked';} ?>/>
    <label for="star4" title="text">4 stars</label>
    <input type="radio" id="star3" name="rate" value="3" <?php if($erate==3){ echo 'checked';} ?>/>
    <label for="star3" title="text">3 stars</label>
    <input type="radio" id="star2" name="rate" value="2" <?php if($erate==2){ echo 'checked';} ?>/>
    <label for="star2" title="text">2 stars</label>
    <input type="radio" id="star1" name="rate" value="1" <?php if($erate==1){ echo 'checked';} ?>/>
    <label for="star1" title="text">1 star</label>
  </div> 
  </div> 
  <div class="col-md-12 myedit" style="display: none;">
	<h2 class="">Would you like this to recommend to others? </h2>
 <p class=""><input type="radio" id="" name="highlyrecommend" value="2" <?php if($rec == 2){echo 'checked';} ?> /> HIghly Recommended</p>
<p class=""><input type="radio" id="" name="highlyrecommend" value="1" <?php if($rec == 1){echo 'checked';} ?> /> Recommended</p>
<p class=""><input type="radio" id="" name="highlyrecommend" value="0" <?php if($rec == 0){echo 'checked';} ?>/> Not Recommended</p>
 </div> 
<div class="col-md-12 cmntshow" style="display: none;">
    <h2 class="">comments</h2>
	<textarea style="padding:5px;" name="comment" placeholder="Your Thoughts" rows="4" cols="50"><?php echo $ecomnt;?></textarea>
	<input type="hidden" name="ipadd" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
	 </div> 
	 <div class="col-md-12">
	<input type="submit" style="margin-top:15px;margin-bottom:15px;max-width:250px;background:red;color:#fff; display: none;" class="form-control" value="Update" name="rsubmit" >
	</div>
	
	<input type="hidden" name="email" value="<?php echo $rmail;?>">
	<input type="hidden" name="userId" value="<?php echo $u_id; ?>">
	<input type="hidden" name="user_type" value="<?php echo $rtype; ?>">
	<input type="hidden" name="ratingid" value="<?php echo $eid; ?>">
	<input type="submit" style="display: none; margin-top:15px;margin-bottom:15px;max-width:250px;background:red;color:#fff;" class="form-control myedit" value="Update" name="rsubmit" id="showbtn">
	</div>
</form>
				<?  } else 
				{?>
<form style="border: 1px solid; border-radius: 5px;background: #f9f9f9;display: inline-block;height: auto;" method="POST" action=""> 
<div class="col-md-12"> 
<h2 class="">How would rate your experience?</h2>	
<div class="rate">
    <input type="radio" id="star5" name="rate" value="5" />
    <label for="star5" title="text">5 stars</label>
    <input type="radio" id="star4" name="rate" value="4" />
    <label for="star4" title="text">4 stars</label>
    <input type="radio" id="star3" name="rate" value="3" />
    <label for="star3" title="text">3 stars</label>
    <input type="radio" id="star2" name="rate" value="2" />
    <label for="star2" title="text">2 stars</label>
    <input type="radio" id="star1" name="rate" value="1" />
    <label for="star1" title="text">1 star</label>
  </div>  </div> 
  <div class="col-md-12">
	<h2 class="">Would you like this to recommend to others? </h2>
 <p class=""><input type="radio" id="" name="highlyrecommend" value="2" /> HIghly Recommended</p>
<p class=""><input type="radio" id="" name="highlyrecommend" value="1" /> Recommended</p>
<p class=""><input type="radio" id="" name="highlyrecommend" value="0" /> Not Recommended</p>
 </div> 
<div class="col-md-12">
    <h2 class="">comments</h2>
	<textarea style="padding:5px;" name="comment" placeholder="Your Thoughts" rows="4" cols="50"></textarea>
	<input type="hidden" name="ipadd" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
	 </div> 
	 <div class="col-md-12">
	<input type="submit" style="margin-top:15px;margin-bottom:15px;max-width:250px;background:red;color:#fff;" class="form-control" value="SUBMIT" name="submit" >
	</div>
</form>
					<?
					
				}
 } else 
	{ ?>
		<div class="col-sm-12 text-center">
			<div class="row">
			<a class="btn btn-success ajax" href="/login.php">Please Login First</a>
		</div>

			</div>
						<? } ?>								
						
            </div>
			

			<div class="col-md-12">
				<div class="most-active-profile">
					<h4 class="heading">Our Associate</h4>
					<div id="jssor_2" class="jssor_2">
					<!-- Loading Screen -->
					<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
						<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
						<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
					</div>
					<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 100%; height: 100px; overflow: hidden; ">
						<?php 
						   $queryAs=mysqli_query($conn,"select * from our_associate");
						   while($rowAs=mysqli_fetch_object($queryAs))
						   {
						 ?>
						   <div style="display: none;">
								<img data-u="image" src="/admin/images/uploads/<?php echo $rowAs->image; ?>" style="margin-left:30px;"/>
							</div>
							<?php 
						   }
							?>
						
					</div>
					</div>
				</div>
			</div>
			
        </div>

    </div>
</div>
    <!-- /.container -->

<? include('include/footer.php'); ?>
    <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
        <script src="/js/star-rating.js" type="text/javascript"></script>
	 <script>
        jssor_2_slider_init();
		$('.rating').rating({'showCaption':false});
		
		

$(document).ready(function(){
    $('#edit-rate').click(function(){
		$(".myedit").show();
		$(".cmntshow").hide();
});

$('#edit-cmnt').click(function(){
		$(".myedit").hide();
		$(".cmntshow").show();
		$("#showbtn").show();
});

});
    </script>
	
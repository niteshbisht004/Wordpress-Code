<?php

error_reporting(0);

    header("Access-Control-Allow-Origin: *");

    header("Content-Type: application/json; charset=UTF-8");

       header("HTTP/1.1 200 OK");

  header('Access-Control-Allow-Methods: POST');

  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  

    include_once 'config/database.php';

	$database = new Database();

    $db = $database->getConnection();

	$data = json_decode(file_get_contents("php://input"));

	

	$val = $_POST['cat'];

	$id = $_POST['id'];

	//$usertype = $_POST['usertype'];

	 include_once 'classes/city.php';

	$cityitems = new Cities($db);

	

	include_once 'classes/states.php';

	$stateitems = new States($db);

  

    include_once 'classes/country.php';

	$countryitems = new Countries($db);

	

	include_once 'classes/special.php';

	$specialitems = new Special($db);

	

	

	include_once 'classes/qual.php';

	$qualitems = new Qual($db); 

	

	   include_once 'classes/rating.php';
$rateitems = new Ratings($db);

	

	if($val == 'user'){

    include_once 'classes/users.php';

	$items = new Users($db);

    $stmt = $items->getSingleUsers($id);

	

	$itemCount = mysqli_num_rows($stmt);

	if($itemCount > 0){

        

        $userArr = array();
		$userCon = array();





        while ($row = $stmt->fetch_assoc()){

           //$userArr[] = $row;

												

		 $cityArr['cat'] = $val;

			 

						if($row['pro_img'] == ''){

			

			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];

			

		}

		

			if($row['timeline_img'] == ''){

			

			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];

			

		}

		$userArr['first_name'] = $row['first_name'];

			$userArr['last_name'] = $row['last_name'];

			$userArr['date_birth'] = $row['date_birth'];

			$userArr['gender'] = $row['gender'];

			$userArr['blood_group'] = $row['blood_group'];

			$userArr['interested'] = $row['interested'];

			$userArr['qualification'] = $row['qualification'];

				

			 $citystmt = $cityitems->getSingleCity($row['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($row['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($row['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];						

		 

			 

			 $allArr = array_merge($row,$cityArr);

		   
			 

			 $userCont['mobile_no'] = $row['mobile_no'];	 
 
			 $userCont['phone_no'] = $row['phone_no'];
 
			 $userCont['address'] = $row['address'];

			 $userCont['country'] = $row['country'];
 
			 $userCont['state'] = $row['state'];
 
			 $userCont['city'] = $row['city'];

			 $userCont['district'] = $row['district'];

			 $userCont['zipe_code'] = $row['zipe_code'];
 
			
 
			      $citystmt = $cityitems->getSingleCity($row['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $userCont['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($row['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $userCont['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($row['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $userCont['countryname'] = $sname[0];
 
			
 
			 
			
 
       

		 }	

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	$response['geninfo']=$userArr;

	$response['contactinfo']=$userCont;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

    }

	
	

	

	if($val == 'doctor'){

		

    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getSingleDoctors($id);
	$itemCount = mysqli_num_rows($stmt);
    
	if($itemCount > 0){

        

        $userArr = array();

		$userCon = array();

		$userPr = array();

		$userblog = array();







        while ($row = $stmt->fetch_assoc()){

           //$userArr[] = $row;

				$cityArr['cat'] = $val;

				if($row['pro_img'] == ''){

			

			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];

			

		}

		

			if($row['timeline_img'] == ''){

			

			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];

			

		}

		

		   $statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			//$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = "$r";
				
			}else{
			//$cityArr['is_rating'] = '0';	
			$cityArr['rating'] = "0";	
			}
		  
		  //$cityArr['rating'] = "4";		

				

		     $citystmt = $cityitems->getSingleCity($row['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($row['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($row['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];
			
           $valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];
				}

			 

	 $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArr['specialisationname'] = $specialname[0];	
           
				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArr12['specialisationname'] .= $specialname[0].',';
                $cityArr['specialisationname'] = trim($cityArr12['specialisationname'],",");
			}

			}									

		 

			 

			 $allArr = array_merge($row,$cityArr);

		   

		   

		   

		    $userArr['name'] = $row['name'];

			$userArr['gender'] = $row['gender'];

			//$userArr['qualification'] = $row['qualification'];

			$userArr['date_birth'] = $row['date_birth'];

			$userArr['specialisation'] = $row['specialisation'];

			$userArr['registration_no'] = $row['registration_no'];

			$userArr['registration_auth'] = $row['registration_auth'];

			$userArr['expertise_in'] = $row['expertise_in'];

			$userArr['summary'] = $row['summary'];

			$valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$userArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$userArr['qualificationname'] = $qualname[0];
			
				}

	 
			 

			 $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArr['specialisationname'] = $specialname[0];	

				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArr1['specialisationname'] .= $specialname[0].',';
            $userArr['specialisationname'] = trim($userArr1['specialisationname'],",");
			}

			}	

			$userCon['phone_no'] = $row['phone_no'];

			$userCon['mobile_no'] = $row['mobile_no'];

			$userCon['other_phone'] = $row['other_phone'];

			$userCon['fax_no'] = $row['fax_no'];

			$userCon['email'] = $row['email'];

			$userCon['address'] = $row['address'];

			$userCon['country'] = $row['country'];

			$userCon['state'] = $row['state'];

			$userCon['city'] = $row['city'];

			$userCon['district'] = $row['district'];

 			$userCon['zipe_code'] = $row['zipe_code'];

			 $citystmt = $cityitems->getSingleCity($row['city']);

			 $ffdsf = mysqli_fetch_row($citystmt);
			 
			 $userCon['cityname'] = $ffdsf[0];
						
		
		  
		    $statestmt = $stateitems->getSingleState($row['state']);
		   $snames =  mysqli_fetch_row($statestmt);
		  $userCon['statename'] = $snames[0];
		  
		  $countrystmt = $countryitems->getSingleCountry($row['country']);
		   $sname =  mysqli_fetch_row($countrystmt);
		   $userCon['countryname'] = $sname[0];


        
			$userPr['personalAddress'] = $row['personalAddress'];

			$userPr['personalPhone'] = $row['personalPhone'];

			$userPr['personalMobile'] = $row['personalMobile'];

			$userPr['personalEmail'] = $row['personalEmail'];

			$userPr['personalUrl'] = $row['personalUrl'];
		   
          
		    			
			
			$userblog['title'] = $row['title'];

			$userblog['specialisation'] = $row['specialisation'];

			$userblog['meta_name'] = $row['meta_name'];

			$userblog['meta_description'] = $row['meta_description'];

			$userblog['description'] = $row['description'];

			$userblog['image'] = $row['image'];
		   
          include_once 'classes/blog.php';
	$itemsb = new Blogs($db);
	$stmtb = $itemsb->getSingleBlogs($_POST['id'],'doctor');
	$itemCountb = mysqli_num_rows($stmtb);
       
     include_once 'classes/deals.php';
	$itemsd = new Deals($db);

	$stmtd = $itemsd->getSingleDealsbydoctorid($_POST['id']);
	
	
	$itemCountd = mysqli_num_rows($stmtd);
		 }	



	

		

	$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	$response['docgeninfo']=$userArr;

	$response['doccontactinfo']=$userCon;

	$response['docpersinfo']=$userPr;
	
    //$response['docbloginfo']=$userblog;
	
	$response['blog_count']=$itemCountb;
    $response['deal_count']=$itemCountd;
	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    } 

    }

	
	

	

	

	if($val == 'hospital'){

	include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $stmt = $items->getSingleHospitals($id);

	$itemsp = new HospitalsPersonal($db);

    $stmtp = $itemsp->getHospitals($id);

	$itemCount = mysqli_num_rows($stmt);

	if($itemCount > 0){

        

        $userArr = array();
		$userCont = array();
        $userPr = array();




        while ($row = $stmt->fetch_assoc()){

           //$userArr[] = $row;

			$cityArr['cat'] = $val;	

			 if($row['pro_img'] == ''){

			

			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];

			

		}

		

			if($row['timeline_img'] == ''){

			

			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];

			

		}

		

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			//$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = "$r";
				
			}else{
			//$cityArr['is_rating'] = '0';	
			$cityArr['rating'] = "0";	
			}
		  
		  //$cityArr['rating'] = "4";		

				

		     $citystmt = $cityitems->getSingleCity($row['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

				$cityArr['cityname'] = $ffdsf[0];

			  			  

			 $statestmt = $stateitems->getSingleState($row['state']);

			  $snames =  mysqli_fetch_row($statestmt);

			  $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($row['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

			  $cityArr['countryname'] = $sname[0];

			 

			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);

			 $qualname =  mysqli_fetch_row($qalistmtr);

		    $cityArr['qualificationname'] = $qualname[0];

			 

		 $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArr['specialisationname'] = $specialname[0];	

				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArr112['specialisationname'] .= $specialname[0].',';
            $cityArr['specialisationname'] = trim($cityArr112['specialisationname'],",");
			}

			}									

		 

			 

			 $allArr = array_merge($row,$cityArr);

		   

		   $userArr['name'] = $row['name'];

			$userArr['specialisation'] = $row['specialisation'];

			$userArr['registration_no'] = $row['registration_no'];

			$userArr['registration_auth'] = $row['registration_auth'];

			$userArr['noOfBeds'] = $row['noOfBeds'];

			$userArr['private_room'] = $row['private_room'];

			

			$userArr['hospital_category'] = $row['hospital_category'];

			$userArr['clinical_test'] = $row['clinical_test'];

			$userArr['ambulance'] = $row['ambulance'];

			$userArr['summary'] = $row['summary'];

			$userArr['heyear'] = $row['heyear'];
			

			$userArr['extra_feature'] = $row['extra_feature'];

			$userArr['update_date'] = $row['update_date'];

			$userArr['id'] = $row['id'];

	

					 

 $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArr['specialisationname'] = $specialname[0];	

				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArr1r['specialisationname'] .= $specialname[0].',';
            $userArr['specialisationname'] = trim($userArr1r['specialisationname'],",");
			}

			}							

		   
			$userCont['phone_no'] = $row['phone_no'];

			$userCont['mobile_no'] = $row['mobile_no'];	

			$userCont['O_contact'] = $row['O_contact'];

			$userCont['O_time_to_call'] = $row['O_time_to_call'];

			$userCont['email'] = $row['email'];

			$userCont['O_website'] = $row['O_website'];

			$userCont['address'] = $row['address'];

			$userCont['country'] = $row['country'];

			$userCont['state'] = $row['state'];

			$userCont['city'] = $row['city'];

			
		   
			$citystmt = $cityitems->getSingleCity($row['city']);

			$ffdsf = mysqli_fetch_row($citystmt);
			
			$userCont['cityname'] = $ffdsf[0];
					   
		  $statestmt = $stateitems->getSingleState($row['state']);
		  $snames =  mysqli_fetch_row($statestmt);
		 $userCont['statename'] = $snames[0];
		 
		 $countrystmt = $countryitems->getSingleCountry($row['country']);
		  $sname =  mysqli_fetch_row($countrystmt);
		  $userCont['countryname'] = $sname[0];
		   
		  
		  
		  while ($rowp = $stmtp->fetch_assoc()){
			  
			 $userPr['Name'] = $rowp['Name'];

			$userPr['phone'] = $rowp['phone'];

			$userPr['mobile'] = $rowp['mobile'];

			$userPr['website'] = $rowp['website'];

			$userPr['email'] = $rowp['email']; 
			
			
			$citystmt = $cityitems->getSingleCity($rowp['city']);

			$ffdsf = mysqli_fetch_row($citystmt);
			
			$userPr['cityname'] = $ffdsf[0];
					   
		  $statestmt = $stateitems->getSingleState($rowp['state']);
		  $snames =  mysqli_fetch_row($statestmt);
		 $userPr['statename'] = $snames[0];
		 
		 $countrystmt = $countryitems->getSingleCountry($rowp['country']);
		  $sname =  mysqli_fetch_row($countrystmt);
		  $userPr['countryname'] = $sname[0];
			
			
			
			
			$userPr['address'] = $rowp['address'];
			
			$userPr['zipcode'] = $rowp['zipcode'];
			
			  
		  }
		  
		      include_once 'classes/blog.php';
	$itemsb = new Blogs($db);
	$stmtb = $itemsb->getSingleBlogs($_POST['id'],'doctor');
	$itemCountb = mysqli_num_rows($stmtb);
       
     include_once 'classes/deals.php';
	$itemsd = new Deals($db);
	
	
	$stmtd = $itemsd->getSingleDealsbyhospitalid($_POST['id']);
	
	
	$itemCountd = mysqli_num_rows($stmtd);
       

		 }	

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	$response['hosgeninfo']=$userArr;

	$response['hoscontactinfo']=$userCont;
	
	$response['hospersonalinfo']=$userPr;

	$response['blog_count']=$itemCountb;
    $response['deal_count']=$itemCountd;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

    }

	

	

	

	if($val == 'other'){

    include_once 'classes/others.php';

	$items = new Others($db);

	$stmt = $items->getSingleOthers($id);

	
	$itemso = new OthersPersonal($db);

    $stmto = $itemso->getHospitals($id);
	

	$itemCount = mysqli_num_rows($stmt);

	if($itemCount > 0){

        

        $userArr = array();
		$userCont = array();
		$userPr = array();
 




        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

				

			$cityArr['cat'] = $val;	

		     if($row['pro_img'] == ''){

			

			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];

			

		}

		

			if($row['timeline_img'] == ''){

			

			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];

			

		}

		

		$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			//$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = "$r";
				
			}else{
			//$cityArr['is_rating'] = '0';	
			$cityArr['rating'] = "0";	
			}
		  
		  //$cityArr['rating'] = "4";

		     $citystmt = $cityitems->getSingleCity($row['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($row['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($row['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];

			 

			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);

			 $qualname =  mysqli_fetch_row($qalistmtr);

		    $cityArr['qualificationname'] = $qualname[0];

			 

		 $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArr['specialisationname'] = $specialname[0];	

				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$cityArra['specialisationname'] .= $specialname[0].',';
            $cityArr['specialisationname'] = trim($cityArra['specialisationname'],",");
			}

			};									

		 

			 

			 $allArr = array_merge($row,$cityArr);

		   

		   $userArr['name'] = $row['name'];

			$userArr['specialisation'] = $row['specialisation'];

			$userArr['registration_no'] = $row['registration_no'];

			$userArr['registration_auth'] = $row['registration_auth'];

		

			$userArr['extra_feature'] = $row['extra_feature'];

	

	





            $spec = explode("|",$row['specialisation']);

			if(empty($spec)){

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArr['specialisationname'] = $specialname[0];	

				

			}else{

			foreach($spec as $val){

			$specialstmt = $specialitems->getSingleSpecial($val);

			 $specialname =  mysqli_fetch_row($specialstmt);

			$userArra['specialisationname'] .= $specialname[0].',';
            $userArr['specialisationname'] = trim($userArra['specialisationname'],",");
			}

			}				

		   

		   

			$userCont['phone_no'] = $row['phone_no'];

			$userCont['mobile_no'] = $row['mobile_no'];	 

			$userCont['contact_no'] = $row['contact_no'];

			$userCont['time_to_call'] = $row['time_to_call'];

			$userCont['website'] = $row['website'];

			$userCont['email'] = $row['email'];

			$userCont['country'] = $row['country'];

			$userCont['state'] = $row['state'];

			$userCont['city'] = $row['city'];

			$userCont['address'] = $row['address'];
		   
			$citystmt = $cityitems->getSingleCity($row['city']);

			$ffdsf = mysqli_fetch_row($citystmt);
			
			$userCont['cityname'] = $ffdsf[0];
					   
		  $statestmt = $stateitems->getSingleState($row['state']);
		  $snames =  mysqli_fetch_row($statestmt);
		  $userCont['statename'] = $snames[0];
		 
		 $countrystmt = $countryitems->getSingleCountry($row['country']);
		  $sname =  mysqli_fetch_row($countrystmt);
		  $userCont['countryname'] = $sname[0];
       
	   
	   
	   
	   $userPr['Name'] = $row['O_name'];

			$userPr['phone'] = $row['O_phone'];

			$userPr['mobile'] = $row['O_mobile'];

			$userPr['website'] = $row['O_website'];

			$userPr['email'] = $row['O_email']; 
			
			
			$citystmt = $cityitems->getSingleCity($row['O_city']);

			$ffdsf = mysqli_fetch_row($citystmt);
			
			$userPr['cityname'] = $ffdsf[0];
					   
		  $statestmt = $stateitems->getSingleState($row['O_state']);
		  $snames =  mysqli_fetch_row($statestmt);
		 $userPr['statename'] = $snames[0];
		 
		 $countrystmt = $countryitems->getSingleCountry($row['O_country']);
		  $sname =  mysqli_fetch_row($countrystmt);
		  $userPr['countryname'] = $sname[0];
			
			
			
			
			$userPr['address'] = $row['O_address'];
			
			$userPr['zipcode'] = $row['O_zip'];
	   
	   
	       include_once 'classes/blog.php';
	$itemsb = new Blogs($db);
	$stmtb = $itemsb->getSingleBlogs($_POST['id'],'doctor');
	$itemCountb = mysqli_num_rows($stmtb);
       
     include_once 'classes/deals.php';
	$itemsd = new Deals($db);
	
	
	$stmtd = $itemsd->getSingleDealsbyotherid($_POST['id']);
	
	$itemCountd = mysqli_num_rows($stmtd);
	   

		 }	

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	$response['othgeninfo']=$userArr;

	$response['othcontactinfo']=$userCont;
	
	$response['othpersonalinfo']=$userPr;
	
	$response['blog_count']=$itemCountb;
    $response['deal_count']=$itemCountd;

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

    }

	

		

	

	

	
 
	

	if($val == 'pastexpdoctors'){

    include_once 'classes/doctors.php';

	$items = new Doctors($db);

    $stmt = $items->getPastExperience($id);

	

	$itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        $userArr = array();

       $cityArr = array();

       

        while ($row = $stmt->fetch_assoc()){

	$userArr[] = $row['hospital_id'];

	

	include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $userexp = $items->getSingleHospitals($row['hospital_id']);



		 while ($rows = $userexp->fetch_assoc()){   

		  

			 $cityArr['hospitalid'] = $row['hospital_id'];

		     $cityArr['hospitalname'] = $rows['name'];

		 

		   $citystmt = $cityitems->getSingleCity($rows['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($rows['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($rows['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];

		 }

		

		$allArr = array_merge($row,$cityArr);

        }

		

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }

    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    

	}

	

  }

	

  	if($val == 'currentexpdoctors'){

    include_once 'classes/doctors.php';

	$items = new Doctors($db);

    $stmt = $items->getCurrentExperience($id);

	

	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){

        

        $userArr = array();

       $cityArr = array();

       

        while ($row = $stmt->fetch_assoc()){

	$userArr[] = $row['hospital_id'];

	

	include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $userexp = $items->getSingleHospitals($row['hospital_id']);



		 while ($rows = $userexp->fetch_assoc()){   

		  

			 $cityArr['hospitalid'] = $row['hospital_id'];

		     $cityArr['hospitalname'] = $rows['name'];

		 

		   $citystmt = $cityitems->getSingleCity($rows['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($rows['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($rows['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];

		 }

		

		$allArr = array_merge($row,$cityArr);

        }

		

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }

    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    

	}

	

  }



  	if($val == 'getavailabledoctorsinhospitals'){

    include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $stmt = $items->getAvailableDoctors($id);

	

	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){

        

        $userArr = array();

       $cityArr = array();

       

        while ($row = $stmt->fetch_assoc()){

	$userArr[] = $row['doctor_id'];

	

	include_once 'classes/doctors.php';

	$items = new Doctors($db);

    $userexp = $items->getSingleDoctors($row['doctor_id']);



		 while ($rows = $userexp->fetch_assoc()){   

		if($rows['pro_img'] == ''){

			

			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';

		}else{

			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rows['pro_img'];

			

		}

		

		 $cityArr['doctorname'] = $rows['name'];

		   $citystmt = $cityitems->getSingleCity($rows['city']);

		        $ffdsf = mysqli_fetch_row($citystmt);

				

		     $cityArr['cityname'] = $ffdsf[0];

			  			 

			 $statestmt = $stateitems->getSingleState($rows['state']);

			  $snames =  mysqli_fetch_row($statestmt);

		     $cityArr['statename'] = $snames[0];

			 

			 $countrystmt = $countryitems->getSingleCountry($rows['country']);

			  $sname =  mysqli_fetch_row($countrystmt);

		    $cityArr['countryname'] = $sname[0];

			

				 $qalistmtr = $qualitems->getSingleQual($rows['qualification']);

			 $qualname =  mysqli_fetch_row($qalistmtr);

		    $cityArr['qualificationname'] = $qualname[0];

			 

			$specialstmt = $specialitems->getSingleSpecial($rows['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

		     $cityArr['specialisationname'] = $specialname[0];

		 }

		

		$allArr = array_merge($row,$cityArr);

        }

		

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }

    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    

	}

	

  }

  

  if($val == 'availablefacilityinhospitals'){

    include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $stmt = $items->getSingleHospitals($id);

	

	   $itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        //$allArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr = explode("-|-",$row['available_facility']);

		  foreach($userArr as $facility){

				

		     $allArr .= $facility.",";

			  			 

		  }

			 

			 

		   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

	if($val == 'specialinfrainhospitals'){

    include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $stmt = $items->getSingleHospitals($id);

	

	   $itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        //$allArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr = explode("-|-",$row['special_infra']);

		  foreach($userArr as $facility){

				

		     $allArr .= $facility.",";

			  			 

		  }

			 

			 

		   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

		if($val == 'specialmachineinhospitals'){

    include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

    $stmt = $items->getSingleHospitals($id);

	

	   $itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        //$allArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr = explode("-|-",$row['special_machine']);

		  foreach($userArr as $facility){

				

		     $allArr .= $facility.",";

			  			 

		  }

			 

			 

		   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

	

	

	

	

	

	

	

	

	if($val == 'deals'){

    include_once 'classes/deals.php';

	$items = new Deals($db);

	if($usertype == 'doctor'){

		

	$stmt = $items->getSingleDealsbydoctorid($id);

	}

	if($usertype == 'hospital'){

		

	$stmt = $items->getSingleDealsbyhospitalid($id);

	}

	if($usertype == 'other'){

		

	$stmt = $items->getSingleDealsbyotherid($id);

	}

	$itemCount = mysqli_num_rows($stmt);

	if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

				

				

		     $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image'];

			    $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image']; 

			  $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);

			 $specialname =  mysqli_fetch_row($specialstmt);

		     $cityArr['specialisationname'] = $specialname[0];									

		 

			 

			 $allArr[] = array_merge($cityArr,$row);

		   
			 $userArr['title'] = $row['title'];

			 $userArr['valid_from'] = $row['valid_from'];
 
			 $userArr['valid_to'] = $row['valid_to'];
 
			 $userArr['description'] = $row['description'];

			 $userArr['short_desc'] = $row['short_desc'];

			 $userArr['image'] = $row['image'];

       

		 }	

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;

	$response['doctor-deals']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    

	

    }

	

    

	if($val == 'blogs'){

    include_once 'classes/blog.php';

	$items = new Blogs($db);

	$stmt = $items->getSingleBlogs(19,$usertype );


	$itemCount = 1;




    if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;
				

		     $cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image'];

			  			 
              
	

			 

			 $allArr[] = array_merge($row,$cityArr);

			 $userArr['title'] = $row['title'];

			 $userArr['specialisation'] = $row['specialisation'];
 
			 $userArr['meta_name'] = $row['meta_name'];
 
			 $userArr['meta_description'] = $row['meta_description'];

			 $userArr['description'] = $row['description'];

			 $userArr['image'] = $row['image'];
		

        }

		

	$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$allArr;
	
	$response['BlogsInfo']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";
	

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

     

	 

	 if($val == 'coupan'){

    include_once 'classes/coupan.php';

	$items = new Coupans($db);

	if($usertype == 'doctor'){

		

	$stmt = $items->getCoupansbyDoctor($id);

	}

	if($usertype == 'hospital'){

		

	$stmt = $items->getCoupansbyHospital($id);

	}

	if($usertype == 'other'){

		

	$stmt = $items->getCoupansbyOther($id);

	}

	$itemCount = mysqli_num_rows($stmt);

	if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

									

		 

			 

			 //$allArr[] = array_merge($cityArr,$row);

		   

       

		 }	

	$response['message']="Data Found";


	$response['status']=1;

	$response['data']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    

	

    }

	 





	

	

		if($val == 'getCommentsbyDoc'){

    include_once 'classes/doctors.php';

	$items = new Doctors($db);

	$stmt = $items->getCommentsbyDoc($id);

	$itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

				

		     	   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

	

	if($val == 'getCommentsbyHos'){

    include_once 'classes/hospitals.php';

	$items = new Hospitals($db);

	$stmt = $items->getCommentsbyHos($id);

	$itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

				

		     	   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

	

	if($val == 'getCommentsbyOth'){

    include_once 'classes/others.php';

	$items = new Others($db);

	$stmt = $items->getCommentsbyOth($id);

	$itemCount = mysqli_num_rows($stmt);







    if($itemCount > 0){

        

        $userArr = array();





        while ($row = $stmt->fetch_assoc()){

           $userArr[] = $row;

				

		     	   

        }

		

		$response['message']="Data Found";

	$response['status']=1;

	$response['data']=$userArr;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;			

    }



    else{

    $response['message'] = "No Record Found";

	$response['status'] = 0;

	

	$json_response = json_encode($response);

	echo $json_response;

	exit;

    }

	

    }

	

	

?>
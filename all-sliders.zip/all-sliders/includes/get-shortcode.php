<?php 
function als_myplugins_smart_testi_slider()
{	_e("<br>", 'all-sliders' );	_e("<h1>Short Code</h1>", 'all-sliders' );	$terms = get_terms('slider-cat');	foreach($terms as $taxonomy){				$term_name = $taxonomy->name;  		$term_slug = $taxonomy->slug;        _e("<p style='font-size: 22px;'>Use <strong>[smart-testimonial-slider name = '$term_name']</strong> short code to access all the smart testimonial slider in any page of your website.</p>", 'all-sliders' );		}
	
	
	
}
?>
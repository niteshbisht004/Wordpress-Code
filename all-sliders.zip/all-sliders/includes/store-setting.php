<style>
	.term-slug-wrap, .term-parent-wrap{
		display: none;
	}
</style>
<?php
register_post_type( 'smart-testimonials',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'All Sliders' ),
                'singular_name' => __( 'All Sliders' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'smart-testimonials'),
            'show_in_rest' => true,
             'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'custom-fields', ),
        )
    );
	
	$labels = array(
    'name' => _x( 'Slider Category', 'taxonomy general name' ),
    'singular_name' => _x( 'Slider Category', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Slider Category' ),
    'all_items' => __( 'All Slider Category' ),
    'parent_item' => __( 'Parent Slider Category' ),
    'parent_item_colon' => __( 'Parent Slider Category:' ),
    'edit_item' => __( 'Edit Slider Category' ), 
    'update_item' => __( 'Update Slider Category' ),
    'add_new_item' => __( 'Add New Slider Category' ),
    'new_item_name' => __( 'New Slider Category Name' ),
    'menu_name' => __( 'Slider Category' ),
  ); 
  
	register_taxonomy('slider-cat',array('smart-testimonials'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_in_rest' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'slider-cat' ),
  ));
	
	function als_add_event_metaboxes() {
	add_meta_box(
		'als_events_location',
		'Rating Star',
		'als_events_location',
		'smart-testimonials',
		'side',
		'default'
	);
	}
	
	function als_events_location() {
	global $post;

	// Nonce field to validate form request came from current site
	wp_nonce_field( ALS_STS_PLUGIN_DIR_URL, 'event_fields' );

	// Get the location data if it's already been entered
	$location = get_post_meta( $post->ID, 'rating', true );

	// Output the field
	_e('<input type="text" name="rating" value="' . $location . '" class="widefat">');		//esc_html("<input type='text' name='rating' value='' class='widefat'>");	//_e("<input type='text' name='rating' value='$location' class='widefat'>", 'all-sliders' );

}

function als_save_events_meta( $post_id, $post ) {

	// Return if the user doesn't have edit permissions.
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return $post_id;
	}

	// Verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times.     $rating = sanitize_text_field( $_POST['rating'] );    //update_post_meta( $post->ID, 'title', $title );
	if ( ! isset($rating) || ! wp_verify_nonce( $_POST['event_fields'], ALS_STS_PLUGIN_DIR_URL ) ) {
		return $post_id;
	}

	// Now that we're authenticated, time to save the data.
	// This sanitizes the data from the field and saves it into an array $events_meta.
	$events_meta['rating'] = esc_textarea($rating);

	// Cycle through the $events_meta array.
	// Note, in this example we just have one item, but this is helpful if you have multiple.
	foreach ( $events_meta as $key => $value ) {

		// Don't store custom data twice
		if ( 'revision' === $post->post_type ) {
			return;
		}

		if ( get_post_meta( $post_id, $key, false ) ) {
			// If the custom field already has a value, update it.
			update_post_meta( $post_id, $key, $value );
		} else {
			// If the custom field doesn't have a value, add it.
			add_post_meta( $post_id, $key, $value);
		}

		if ( ! $value ) {
			// Delete the meta key if there's no value
			delete_post_meta( $post_id, $key );
		}

	}

}
add_action( 'save_post', 'als_save_events_meta', 1, 2 );	

    <footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-3 f-col text-left">
						<p class="heading">Important Links</p>
						<ul>
							<li><a href="/">Home</a></li>
							<li><a href="/page/id/6">About Us</a></li>
							<li><a href="/page/id/7">Certificate</a></li>
							<li><a href="/page/id/11">Privacy</a></li>
							<li><a href="/blog">Blog</a></li>
							<li><a href="/contact-us">Contact Us</a></li>
							
						</ul>
					</div>
					<div class="col-md-3 f-col text-left">
						<p class="heading">BROWSE BY SPECIALITY</p>
						<ul>
							<li>
                        <a href="<?=_MAINPATH_?>doctors/speci/12">Homeopathy</a>
                    </li>
					<li>
                        <a href="<?=_MAINPATH_?>doctors/speci/70">Ayurvedic</a>
                    </li>
							<li><a href="/hospital-cat-list/CId/10">Fitness Centre</a></li>
							<li><a href="/hospital-cat-list/CId/9">Test/Path Lab</a></li>
							<li><a href="/hospital-cat-list/CId/14">Blood Bank</a></li>
						</ul>
					</div>
					<div class="col-md-3 f-col text-left">
						<p class="heading">Contact</p>
						<ul class="contact-info">
							<li><i class="fa fa-map-marker"></i> LIIT Campus, Opp. Govt. Girls School, Tigaon Road, Ballabhgarh, Faridabad, Harayana, India, Pin-121004.</li>
							<li><i class="fa fa-phone"></i> +91 9555114730, 9811436692, 9818253275</li>
							<li><i class="fa fa-envelope"></i>  contact@freemedicalinfo.in </li>
						</ul>
						<p class="heading">Stay Connected</p>
						<div class="social-icon">
							<a href="/#"><img src="/images/t.png"></a>
							<a href="/#"><img src="/images/f.png"></a>
							<a href="/#"><img src="/images/l.png"></a>
							
						</div>
					</div>
					<div class="col-md-3 f-col text-left">
					<div class="facebook-responsives">
							<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffreemedicalinfo&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="350" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
						</div>
						
					</div>
				</div>
			</div>
		</div>
                    <p class="copyright">Copyright &copy;  2016-2021 FreeMedicalInfo.in - All rights Reserved | Designed & Developed by <a href="/https://smartinfosystem.com/">Smart infosystem</a></p>
                
            
        </footer>

    
    <!-- /.container -->

    
    
  
    <script src="<?=_MAINPATH_?>ckeditor/ckeditor.js"></script>
	<script src="<?=_MAINPATH_?>ckeditor/js/sample.js"></script> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
	<script>
		$(document).ready(function(){
			$('select').selectpicker();
			$(".ajax").colorbox();
			$(".datatable").DataTable({
				ordering : true,
				/*initComplete: function () {
		            this.api().columns().every( function () {
		                var column = this;
		                if ($(column.header()).text()=="Image" || $(column.header()).text()=="Name" ) return;
		                
		                var select = $('<select class="datatable_filters"><option value="">'+$(column.header()).text()+'</option></select>')
		                    .appendTo( $(column.header()).empty() )
		                    .on( 'change', function () {
		                        var val = $.fn.dataTable.util.escapeRegex(
		                            $(this).val()
		                        );
		 
		                        column
		                            .search( val ? '^'+val+'$' : '', true, false )
		                            .draw();
		                    } );
		 
		                column.data().unique().sort().each( function ( d, j ) {
		                    select.append( '<option value="'+d+'">'+d+'</option>' )
		                });
						
					} );
		        }*/
				
			});
			
		});
		
		
      
			
        </script>
	
	<style>
		/*.datatable_filters {
			width: 100px;
		}*/
		.facebook-responsive {
    overflow:hidden;
    padding-bottom:62.25%;
    position:relative;
    height:0;
}

.facebook-responsive iframe {
    left:0;
    top:0;
    height:100%;
    width:100%;
    position:absolute;
}
	</style>

	 <!--fonts google-->
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
	<script type="text/javascript" src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
</body>

</html>

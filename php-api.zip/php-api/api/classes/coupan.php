<?php
class Coupans{

        // Connection
        private $conn;

        // Table
        private $db_table = "coupan";

        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }
           public function getCoupan(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		  public function getCoupanbydeal($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE deal_id=$id";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function getSinglessReward($email){
       $sqlQuery = "SELECT * FROM rewards where user_email= '$email'";
        $stmt = $this->conn->query($sqlQuery);
			return $stmt;
             }
		public function createcoupanbyuser($deal_id, $doctor_id,$hospital_id, $other_id, $patient_name, $email, $gender, $appointment_date, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status){ 
   $sqlQuery = "INSERT INTO coupan SET deal_id = '$deal_id' ,
                           doctor_id = '$doctor_id', 
                         hospital_id = '$hospital_id', 
                         other_id = '$other_id', 
                        patient_name = '$patient_name',
						email = '$email', 
                        gender = '$gender', 
                        appointment_date = '$appointment_date',
						appointment_time = '$appointment_time',
						purpose = '$purpose',
						address = '$address',
						coupan_id = '$coupan_id',
						contact_number = '$contact_number',
						status = '$status'
						";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		public function updatecoupanbyReward($email,$coupon_point){
            $sqlQuery = "update rewards set
			`coupon_point` = '".$coupon_point."' where `user_email` = '".$email."'";
		    $stmt1 = $this->conn->query($sqlQuery);
            return $stmt1;
				}
				
			public function insertCbyReward($user_id,$utype,$email,$reward_point){
            $sqlQuery = "INSERT INTO rewards SET user_id = '$user_id',
                        user_type = '$utype', 
                        user_email = '$email', 
                        coupon_point = '$reward_point' "; 
		     $stmt11 = $this->conn->query($sqlQuery); 
            return $stmt11;
		}
		
		  public function createnewappointment($id, $patient_name, $email, $gender, $appointment_date, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status){ 
   $sqlQuery = "INSERT INTO coupan SET doctor_id = '$id',  
                        patient_name = '$patient_name',
						email = '$email', 
                        gender = '$gender', 
                        appointment_date = '$appointment_date',
						appointment_time = '$appointment_time',
						purpose = '$purpose',
						address = '$address',
						coupan_id = '$coupan_id',
						contact_number = '$contact_number',
						status = '$status'
						";
     // echo  $sqlQuery;
            $stmt = $this->conn->query($sqlQuery);
           
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
		 public function createnewappointmenthaspitals($id, $patient_name, $email, $gender, $appointment_date, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status){ 
   $sqlQuery = "INSERT INTO coupan SET hospital_id = '$id',  
                        patient_name = '$patient_name',
						email = '$email', 
                        gender = '$gender', 
                        appointment_date = '$appointment_date',
						appointment_time = '$appointment_time',
						purpose = '$purpose',
						address = '$address',
						coupan_id = '$coupan_id',
						contact_number = '$contact_number',
						status = '$status'
						";
     // echo  $sqlQuery;
            $stmt = $this->conn->query($sqlQuery);
           
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		 public function createnewappointmentother($id, $patient_name, $email, $gender, $appointment_date, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status){ 
   $sqlQuery = "INSERT INTO coupan SET other_id = '$id',  
                        patient_name = '$patient_name',
						email = '$email', 
                        gender = '$gender', 
                        appointment_date = '$appointment_date',
						appointment_time = '$appointment_time',
						purpose = '$purpose',
						address = '$address',
						coupan_id = '$coupan_id',
						contact_number = '$contact_number',
						status = '$status'
						";
     // echo  $sqlQuery;
            $stmt = $this->conn->query($sqlQuery);
           
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
        // GET ALL
        public function getCoupansbyDoctor($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE doctor_id=$id";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getCoupansbyHospital($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE hospital_id=$id";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }

		
		public function getCoupansbyOther($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE other_id=$id";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getCoupansbyUser($email){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE email='$email'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		public function searchcoupan($type,$coupan,$usertype,$userid){
			
			
			if($type=="coupan"){
			$search = " and coupan_id like '%$coupan%' ";
			}
			if($type=="mobile"){
			$search = " and contact_number like '%$coupan%' ";
		    }
			if($type=="patient"){
				$search = " and patient_name like '%$coupan%' ";
			}
			
			if($usertype == 'doctor'){
			$deal_by = "doctor_id = '".$userid."' ";
			}
			if($usertype == 'hospital'){
			$deal_by = "`hospital_id` = '".$userid."' ";
			}
			if($usertype == 'user'){
			$deal_by = "`doctor_id` = '".$userid."' ";
			}
			if($usertype == 'other-medical'){
			$deal_by = "`other_id` = '".$userid."' ";
			}
						
            $sqlQuery = "SELECT * FROM " . $this->db_table . " where ".$deal_by. $search." order by id DESC";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
        // CREATE
        public function createUsers(){
              $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                       SET
                        user_id = :user_id, 
                        first_name = :fname, 
                        phone_no = :phone, 
                        password = :pw, 
                        email = :email,
						date_birth = :dob, 
                        active = :active, 
                        insert_date = :email
						";
        
            $stmt = $this->conn->query($sqlQuery);
        
            // sanitize
            $this->name=htmlspecialchars(strip_tags($this->name));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->age=htmlspecialchars(strip_tags($this->age));
            $this->designation=htmlspecialchars(strip_tags($this->designation));
            $this->created=htmlspecialchars(strip_tags($this->created));
        
            // bind data
            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":age", $this->age);
            $stmt->bindParam(":designation", $this->designation);
            $stmt->bindParam(":created", $this->created);
        
            if($stmt){
               return true;
            }
            return false;
        }

        // READ single
        public function getSingleDeals($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
			
			return $stmt;
            
        }        
        
		
	public function updatecoupanbydoctor($deal_id, $id,$coupanid,$status){ 
			
			
   $sqlQuery = "UPDATE  coupan SET status = $status WHERE
                            deal_id = '$deal_id' AND
                           doctor_id = '$id' AND
						   coupan_id = '$coupanid'";
					
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
        
			public function updatecoupanbyhospital($deal_id, $id,$coupanid,$status){ 
			
		
			
   $sqlQuery = "UPDATE  coupan SET status = $status WHERE
                            deal_id = '$deal_id' AND
                           hospital_id = '$id' AND
                           coupan_id = '$coupanid'";
		
				
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
			public function updatecoupanbyother($deal_id, $id,$coupanid,$status){ 
			
		
				
   $sqlQuery = "UPDATE  coupan SET status = $status WHERE
                            deal_id = '$deal_id' AND  other_id = '$id' AND coupan_id = '$coupanid'";
			
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }

    }

?>
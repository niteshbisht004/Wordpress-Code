<?php
class Getauseridapi
{

    // Connection
    private $conn;

    // Table
    private $db_table = "rnewrating";


    // Db connection
    public function __construct($db)
    {
        $this->conn = $db;
    }

public function getratingid($ratingid)
    {
        $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE id = '".$ratingid."'  ";
		
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }





public function updateratingid($ratingid)
    {
        $sqlQuery1 = "UPDATE rnewrating set `status` = 1 where id = '".$ratingid."'";
         
        $stmt = $this->conn->query($sqlQuery1);

        if ($stmt) {
            return $stmt;
        }
    }
	
	public function getcommentid($commentid)
    {
        $sqlQueryc = "SELECT * FROM newrating  WHERE id = '".$commentid."'  ";
		
        $stmt = $this->conn->query($sqlQueryc);
        return $stmt;
    }





public function updatecommentid($commentid)
    {
        $sqlQueryc = "UPDATE newrating set `status` = 1 where id = '".$commentid."'";
         
        $stmt = $this->conn->query($sqlQueryc);

        if ($stmt) {
            return $stmt;
        }
    }
	
	
}
<?php
	//ini_set('display_errors', 1);
	//ini_set('display_startup_errors', 1);
	//error_reporting(E_ALL);
	
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	    // get posted data
	$data = file_get_contents("php://input");
	
	$cat = $_POST['cat'];
	$userId = $_POST['user_id'];
	$otp = $_POST['otp'];
	if($cat == 'user')
	{
		
		include_once 'classes/users.php';
		$items = new Users($db);
		$stmt = $items->getUserActive($userId,$otp);
		if($stmt)
		{
			$response['message']="user Activated Successfully";
			$response['status']=1;
			$json_response = json_encode($response);
			echo $json_response;
			exit;
		}
   
		else
		{
			$response['message'] = "User not Activate";
			$response['status'] = 0;
			
			$json_response = json_encode($response);
			echo $json_response;
		}
	
	}
	 
	
?>
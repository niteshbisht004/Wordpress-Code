<?php
class Database{
  
    // specify your own database credentials
    private $host = "localhost";
    private $db_name = "freeemed_new";
    private $username = "freeemed_new";
    private $password = "m~RnX?x;F45m";
    public $conn;
  
    // get the database connection
  public function getConnection()
	{
		$this->conn = null;
		$this->conn = new mysqli("localhost","freeemed_new","m~RnX?x;F45m","freeemed_new");
		if (!$this->conn) 
		{
		  die("Connection failed: " . mysqli_connect_error());
		}
		return $this->conn;
		
	}
	
	
}
?>
<?php 

		if($ustype == 'doctor'){
			
		 include 'adocsearchinclude.php';	
		 
		}
		
		if($ustype == 'hospital'){
			
			 include 'ahossearchinclude.php';
			 
			}
			
		if($ustype == 'other'){
			
			 include 'aothsearchinclude.php';
		}


?>
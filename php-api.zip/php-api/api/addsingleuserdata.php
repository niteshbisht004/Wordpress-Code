<?php
error_reporting(E_All);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 $val = $_POST['cat'];
	 $post_by = $_POST['id'];
	 $userType = $_POST['userType'];
	 $title = $_POST['title'];  
		$specialisation = $_POST['specialisation']; 
		$meta_name = $_POST['meta_name'];  
		$meta_discription = $_POST['meta_discription'];  
		$description = $_POST['description']; 
		$image = $_POST['image'];
		$video = $_POST['video'];
		$insert_date = $_POST['insert_date'];
		$valid_from = $_POST['valid_from'];
		$valid_to = $_POST['valid_to'];
		$short_desc = $_POST['short_desc'];
		$deal_date = $_POST['deal_date'];
		$doctor_id = $_POST['doctor_id'];
		$hospital_id = $_POST['hospital_id'];
	    $other_id = $_POST['other_id'];
  	    $designation = $_POST['designation'];
		$address = $_POST['address'];
		$hospital_c_name = $_POST['hospital_c_name'];
	     $state = $_POST['state'];
		 $country = $_POST['country'];
		 $city = $_POST['city'];
		 $from_date = $_POST['from_date'];
		 $to_date = $_POST['to_date'];
		  $active = $_POST['active'];
		 $timestamp = $_POST['timestamp'];
		 $doc_id = $_POST['doc_id'];
		 $level = $_POST['level'];
		  $H_id = $_POST['H_id'];
		 
		 
		  $sun_FT = $_POST['sun_FT'];
  	    $sun_ST = $_POST['sun_ST'];
		$mon_FT = $_POST['mon_FT'];
		$mon_ST = $_POST['mon_ST'];
	     $tue_FT = $_POST['tue_FT'];
		 $tue_ST = $_POST['tue_ST'];
		 $wed_FT = $_POST['wed_FT'];
		 $wed_ST = $_POST['wed_ST'];
		 $thu_FT = $_POST['thu_FT'];
		  $thu_ST = $_POST['thu_ST'];
		 $fri_FT = $_POST['fri_FT'];
		 $fri_ST = $_POST['fri_ST'];
		 $sat_FT = $_POST['sat_FT'];
		$sat_ST = $_POST['sat_ST'];
		$update_date = $_POST['update_date'];
		$total_experience = $_POST['total_experience'];
        $expertise_in = $_POST['expertise_in'];
			$registration_no = $_POST['registration_no'];
        $registration_auth = $_POST['registration_auth'];
			$name = $_POST['name'];
		$mobile_no = $_POST['mobile_no'];
        $email = $_POST['email'];
			$gender = $_POST['gender'];
        $qualification = $_POST['qualification'];
		$other_medical_id = $_POST['other_medical_id'];
		
		     $advtName = $_POST['advtName'];
			$web_url = $_POST['web_url'];
        $pincode = $_POST['pincode'];
		$userid = $_POST['userid'];
		$usertype = $_POST['usertype'];
        $duration = $_POST['duration'];
		$advtImg = $_POST['advtImg'];
		
		$status = $_POST['status'];
		$comment = $_POST['comment'];
			$comment_id = $_POST['comment_id'];
		$reply_by_id = $_POST['reply_by_id'];
			$reply_by_name = $_POST['reply_by_name'];
		$reply_by_email = $_POST['reply_by_email'];
			$reply_message = $_POST['reply_message'];
			 $hos_id = $_POST['hos_id'];
			  $oth_id = $_POST['oth_id'];


	 
	 	if($val == 'addcommentbydoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addcommentbydoc($name,$email,$comment,$doc_id,$status,$insert_date);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	 
	 
	 if($val == 'addrplycommentbydoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addrplycommentbydoc($comment_id,$reply_by_id,$reply_by_name,$reply_by_email,$reply_message,$status);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	 
	 
	 
	 
	if($val == 'addBlogbydoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addBlogbydoc($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$insert_date,$userType,$post_by);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  if($val == 'addAdvbydoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addAdvbydoc($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	  if($val == 'addAdvbyoth'){
    include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addAdvbyoth($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'addAdvbyhos'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addAdvbyhos($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	
		if($val == 'addBlogbyhos'){
			include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addBlogbyhos($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$insert_date,$userType,$post_by);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  
		if($val == 'addcommentbyhos'){
			include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addcommentbyhos($name,$email,$comment,$hos_id,$status,$insert_date);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  
		if($val == 'addrplycommentbyhos'){
			include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addBlogbyhos($comment_id,$reply_by_id,$reply_by_name,$reply_by_email,$reply_message,$status);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  	if($val == 'addBlogbyoth'){
    include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addBlogbyoth($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$insert_date,$userType,$post_by);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'addcommentbyoth'){
    include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addcommentbyoth($name,$email,$comment,$oth_id,$status,$insert_date);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  if($val == 'addrplycommentbyoth'){
    include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addrplycommentbyoth($comment_id,$reply_by_id,$reply_by_name,$reply_by_email,$reply_message,$status);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
	
		if($val == 'addDealbydoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addDealbydoc($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$doctor_id);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	

		if($val == 'addDealbyhos'){
			include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addDealbyhos($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$hospital_id);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  	if($val == 'addDealbyoth'){
    include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addDealbyoth($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$other_id);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }	
  
  
  	if($val == 'addProexpDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addProexpDoc($doctor_id,$hospital_id,$designation,$address,$hospital_c_name,$country,$state,$city,$from_date,$to_date);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'addothProexpDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addothProexpDoc($doctor_id,$active,$designation,$address,$hospital_c_name,$country,$state,$city,$from_date,$to_date,$insert_date,$timestamp);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  	if($val == 'addCurexpDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addCurexpDoc($doc_id,$hospital_id,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'addothCurexpDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->addothCurexpDoc($doc_id,$active,$address,$hospital_c_name,$country,$state,$city,$insert_date,$timestamp,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  if($val == 'addDocpHos'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addDocpHos($H_id,$doctor_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	
	
   if($val == 'addOthDocpHos'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->addOthDocpHos($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$active,$insert_date,$update_date,$H_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  if($val == 'addSpecOth'){
	include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addSpecOth($other_medical_id,$doctor_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	
	
   if($val == 'addOthSpecOth'){
	include_once 'classes/others.php';
	$items = new Others($db);
    $stmt = $items->addOthSpecOth($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$active,$insert_date,$update_date,$other_medical_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST);
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
?>
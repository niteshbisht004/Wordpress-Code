<?php
    error_reporting (0);  
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	 $val = $_POST['cat'];
		$topic_id = $_POST['topic_id']; 
		$name = $_POST['name'];  
		$email = $_POST['email']; 
		$comment = $_POST['comment'];  
		$insert_date = $_POST['insert_date'];
		$status = $_POST['status'];
		$id = $_POST['id'];
		
	if($val == 'doctor'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->blogCmntByUser($topic_id,$name,$email,$comment,$insert_date,$status);
    if($stmt){
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	$json_response = json_encode($response);
	echo $json_response;
	exit;
	}
  }
  
  if($val == 'edit'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
   $stmt = $items->blogCmntEditUser($topic_id,$name,$email,$comment,$insert_date,$status,$id);
   
    if($stmt){
             $usr[] =  array('id' => $id);
                $response['data']=$usr;
                $response['message']="Data Updated";
            $response['status']=1;
        
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            }
  }
  
  
  if($val == 'delete'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
   $stmt = $items->deleteCmntTable($id);
   
    if($stmt){
             $usr[] =  array('id' => $id);
                $response['data']=$usr;
                $response['message']="Data Deleted";
            $response['status']=1;
        
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Deleted";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            }
  }
  
  
<?php 

error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 $val = $_POST['cat'];
	
	 $comment_id = $_POST['commentid'];
	 $reply_by_name = $_POST['rplyuname'];
	 $reply_by_email = $_POST['rplyumail']; 
	 $reply_message = $_POST['ucmnt'];
	 $insert_date = date("Y-m-d H:i:s");
	 $status = "0"; 
	 
		 
	if($val == 'doctor'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->addrplyBlogCmntByUser($comment_id, $reply_by_name,$reply_by_email,$reply_message,$insert_date,$status);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  
  if($val == 'hospital'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
   $stmt = $items->addrplyBlogCmntByUser($comment_id, $reply_by_name,$reply_by_email,$reply_message,$insert_date,$status);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'other'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
   $stmt = $items->addrplyBlogCmntByUser($comment_id, $reply_by_name,$reply_by_email,$reply_message,$insert_date,$status);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'user'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
   $stmt = $items->addrplyBlogCmntByUser($comment_id, $reply_by_name,$reply_by_email,$reply_message,$insert_date,$status);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $items->id;
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  	
?>
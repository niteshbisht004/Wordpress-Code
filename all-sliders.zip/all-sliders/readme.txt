=== All Sliders ===
Tags: Simple sliders, Testimonial sliders
Requires at least: 4.6
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
== Description ==
All Sliders
All Sliders. This plugin has helped websites worldwide to boost Slides. This Smart features plugin helps you websites to use the sliders.;
DON’T LET YOUR COMPETITORS WIN;
   - Options to add Simple Slides.
   - Options to add Testimonials slides with star rating.



* Initial release.
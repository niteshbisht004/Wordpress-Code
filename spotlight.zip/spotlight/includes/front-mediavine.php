<?php
	
	defined( 'ABSPATH' ) || exit;

	if( !function_exists('smart_mediavine') )
	{
	function smart_mediavine()		
		{

				/*
					$custom = get_post_custom();
					foreach($custom as $value) {
						echo '<pre>';
						 print_r($value);
					}
				*/
				$options = get_option( 'mediavine_smart_fields' );
		
?>
        <p>Trigger Class: <?php echo $options['trigger']; ?></p>
        <p>Color: <?php echo $options['color']; ?></p>
		<p>Opacity: <?php echo $options['opacity']; ?></p>
		<p>Active Times In Seconds: <?php echo $options['atime']; ?></p>
		
<?php 
	}
	add_shortcode('smart-mediavine-brandclever','smart_mediavine');
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		  //alert('hello world');
		<?php 
			$options = get_option( 'mediavine_smart_fields' );
			$triger_class = $options['trigger'];
			$color = $options['color'];
			$opacity = $options['opacity'];
			$atime = $options['atime'];
			$tout = $atime * 1000;
		?>
		var triger_class = '<?php echo "spotlight"; ?>';
		var color = '<?php echo $color; ?>';
		var opacity = '<?php echo $opacity; ?>';
		var atime = '<?php echo $tout; ?>';
		var paused = false;
		
		  
		$(window).scroll(function() {
        if (($(this).scrollTop() > 200) && ($(this).scrollTop() < 205)){
			if(!paused){
            $('.spotlight').css("background-color", "#fff");
			var something = $("body,.header,.stricky,#page-wrapper")
			.css({backgroundColor: color,"opacity": opacity})
			.show()
			paused = true;
		setTimeout(function(){
			something.css({backgroundColor: '',"opacity": ''});
		},atime);
			}	
        }
		else {
            if(paused)
			{
				
			}
        }
    });
  
	});
	
</script>
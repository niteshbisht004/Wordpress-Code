<?
	include('../include/connection.php');
	include('../include/function.php');
?>
<?
	if ($_GET['edit']==1) {
		$resDD = fetchData(' `prof_exp_doc` ', " where doctor_id='".$_SESSION['userId']."' and id='".$_GET['id']."' ");
	}
?>
<style>
#hosp ul>li:hover{
	background: #ccc;
	cursor: pointer;
	padding-left:2px;
}
#hosp ul>li{ padding-left:2px; }
#hosp{
max-height: 100px;
overflow-y: scroll;
position: absolute;
z-index: 11;
width: 92%;
display: none;
border: 1px solid #eee;
background: #fff;
padding: 5px;
}
</style>
<script>
// Select State 
function select_state(str) {
  var xhttp;

  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("states").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "/ajax-file/select_states.php?id="+str, true);
  xhttp.send();  
  
}
function select_city(str) {
	
  var xhttp;

  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
	if (xhttp.readyState == 4 && xhttp.status == 200) {
	  document.getElementById("cities").innerHTML = xhttp.responseText;
	}
  };
  xhttp.open("GET", "/ajax-file/select_cities.php?id="+str, true);
  xhttp.send();  
  
}
function hosp_name(str){
	
	if(str==""){
		document.getElementById("result").innerHTML = "";
		document.getElementById("hosp").style.display  = "none";
	} else {
		document.getElementById("hosp").style.display  = "block";
		var xhttp;
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (xhttp.readyState == 4 && xhttp.status == 200) {
				document.getElementById("result").innerHTML = xhttp.responseText;			
			}
		  };
		  xhttp.open("GET", "/ajax-file/autosug_hosp_name.php?str="+str, true);
		  xhttp.send(); 
	}
	
}
function hosp_list(listId){
	var list = document.getElementById(listId);
	var txt = list["innerText" in list ? "innerText" : "textContent"];
	document.getElementById('inp').value = txt;
	document.getElementById("result").innerHTML = "";
	document.getElementById("hosp").style.display  = "none";
}
</script>
<div class="popup-form">
            <form class="form-horizontal" role="form" action="/doctor-profile" method="post">
				<h4>Past Experiece</h4>
				<hr style="margin-top: 0px;"/>
                
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Hospital/ Poly/ Clinic</label>
                    <div class="col-sm-9">
                        
                        <select name="hospital_id" class="choosen-select" required>
                        	<option value="">Select one</option>
                        	<?php 
	                        	
	                        	$resDPI = fetchAllData(" `medical_registration` ", " ORDER BY name ASC");
	                        	foreach ($resDPI as $hos) {
		                        	
		                        	$selected = "";
		                        	if ($hos['id']==$resDD['hospital_id']) { $selected = "selected='selected'"; }
		                        	
		                        	$country = fetchData(" `countries`", " where id = '".$hos['country']."'"); 
									$state = fetchData(" `states`", " where id = '".$hos['state']."'");
									$city = fetchData(" `cities`", " where id = '".$hos['city']."'");
									$option_name = $hos['name'].", ".$city['name'].", ".$state['name'].", ".$country['name'];
		                        	echo "<option $selected value='".$hos['id']."' >".$option_name.", "."</option>";
	                        	}
	                        	
                        	?>
                        	<option value="other">Other</option> 
                        </select>
                        
                    </div>
                </div>
                
                <div class="other_hospital" >
	                
	                <div class="form-group">
	                    <label for="firstName" class="col-sm-3 control-label">Hospital/ Poly/ Clinic</label>
	                    <div class="col-sm-9">
	                        <input type="text" value="<?=$resDD['hospital_c_name']?>" name="hospital_c_name" class="form-control" id="inp" >
	                        
	                    </div>
	                </div>
					
					
					<? $add = explode("-|-",$resDD['address']); 
					  
					?>
	                <div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">Address</label>
	                    <div class="col-sm-9">
	                        <textarea class="form-control" name="address" ><?=$add[0]?></textarea>
	                    </div>
	                </div>
	                <div class="form-group">
						<label class="col-sm-3 control-label" for="heading">Country</label>
						<div class="col-sm-9">
							<? $country = fetchAllData(" `countries`", " order by name"); ?>
							<select class="form-control input-md" onChange="select_state(this.value);" id="country" name ="country" >
							<? 
								if(empty($resDD['country'])){
									$countryId = 101;
								} else {
									$countryId = $resDD['country'];
								}
								
								foreach($country as $coun)
								{ 
								?>
								
									<option  value="<?=$coun['id']?>" <?php if($coun['id'] == $countryId){ echo 'selected';} ?>><?=$coun['name']?> </option> 
									<?php } ?>
							</select>
						</div>
						
					</div>
					<div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">State</label>
	                    <div class="col-sm-9">
							<? $states_res = fetchAllData(" `states`", " where country_id = '".$countryId."'  order by name"); ?>
	                        <select class="form-control input-md" id="states" onchange="select_city(this.value)" name ="state" >
									<option value="" selected disabled>Choose a State</option>
									<? foreach($states_res as $sta)
									{
									?>
									<option  <?php if($sta['id'] == $resDD['state']){ echo 'selected';} ?>  value="<?=$sta['id']?>" ><?=$sta['name']?> </option> 
									<?php } ?>
							</select>
	                    </div>
	                </div>
					
					<div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">City</label>
	                    <div class="col-sm-9">
	                        <? $city_res = fetchAllData(" `cities`", " where state_id = '".$resDD['state']."' order by name"); ?>
	                        <select class="form-control input-md" id="cities" name ="city" >
									<option value="" selected disabled>Choose a City</option>
									<? foreach($city_res as $ct)
									{
									?>
									<option  <?php if($ct['id'] == $resDD['city']){ echo 'selected';} ?>  value="<?=$ct['id']?>" ><?=$ct['name']?> </option> 
									<?php } ?>
							</select>
	                    </div>
	                </div>
					<!-- <div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">Zip</label>
	                    <div class="col-sm-9">
	                        <input type="text" name="zip" onkeyup="validateNumber(this)" id="zip" class="form-control" value="<?=$add[4]?>" />
	                    </div>
	                </div> -->
	            </div>
                
                
                
                
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Designation</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['designation']?>" name="designation" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">From</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['from_date']?>" name="from_date" class="form-control datepicker" placeholder="dd/mm/yyyy">
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">To</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['to_date']?>" name="to_date" class="form-control datepicker" placeholder="dd/mm/yyyy">
                    </div>
                </div>
                
                
                
                
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                    	<?php if ($_GET['edit']==1): ?>
                    		<input type="hidden" name="proId" value="<?=$_GET['id']?>"/>
                        	<button type="submit" name="update_pro_exp_edit" class="btn btn-primary btn-block">Update</button>
                        <?php else: ?>
	                        <button type="submit" name="update_pro_exp" class="btn btn-primary btn-block">Add</button>
                        <?php endif; ?>
                    </div>
                </div>
                
            </form> <!-- /form -->
</div>
    <script src="/js/bootstrap-datepicker.js"></script>
	 <script>
	 $('.datepicker').datepicker();
	 	 function validateNumber(evt) {
			var temVal = evt.value.replace(/[^0-9]/g, '');
			if(temVal!=evt.value){
				
				evt.value = temVal;
				return false;
			}
			if(!evt.value.match(/^[0-9]/g)) {
			  
			  return false;
			}
			return true;
	}
	
	$(".choosen-select").chosen({ width:300 });
	$(".choosen-select").change(function() {
		
		toggle_other_hospital_fields ();
	});
	
	function toggle_other_hospital_fields () {
    	
    	if($(".choosen-select").val()=="other") {
    		$(".other_hospital").fadeIn(300);
    		$(".other_hospital input").attr("required",true);
    		$(".other_hospital select").attr("required",true);
		} else {
    		$(".other_hospital").fadeOut(300);
    		$(".other_hospital input").removeAttr("required");
    		$(".other_hospital select").removeAttr("required");
		}
    	
	}
	
	toggle_other_hospital_fields ();
    </script>
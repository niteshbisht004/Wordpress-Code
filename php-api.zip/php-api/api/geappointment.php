<?php

  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
    include_once 'classes/coupan.php';
	$coupan = new Coupans($db);
	
	include_once 'classes/deals.php';
	$deals = new Deals($db);  
	
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	
	$email = $_POST['email'];
	$rusertype = $_POST['usertype'];
	$id = $_POST['id'];
    if($val == 'coupan'){
    $stmt = $coupan->getCoupansbyUser($email);
	
	$itemCount = mysqli_num_rows($stmt);
    $userArrs = array();
    if($itemCount > 0){
        
        
          while ($row = $stmt->fetch_assoc()){
			
            $dealid = $row['deal_id'];
		
			$stmtd = $deals->getDealsbyid($dealid); 		
		    $rows = mysqli_fetch_row($stmtd);
			
	           // print_r($rows);
			 $userArrs['dealtitle'] = $rows[1];
			 $userArrs['validfrom'] = $rows[2];
			 $userArrs['validto'] = $rows[3];
			 $userArrs['description'] = $rows[9];
			 $userArrs['fullimageurl'] = 'https://freemedicalinfo.in/admin/images/uploads/'.$rows[10];
			 
			  if($row['doctor_id'] != '')
			  {
		 
				include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($row['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$userArrs['offerby'] = $rowd[3];
	          }
	           if($row['hospital_id'] != '')
			  {
		 
				include_once 'classes/hospitals.php';
				$itemst = new Hospitals($db);
				$stmtt = $itemst->getSingleHospitals($row['hospital_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$userArrs['offerby'] = $rowd[4];
	          }
			   if($row['other_id'] != '')
			  {
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($row['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$userArrs['offerby'] = $rowd[5];
	          }
			
	 
 $all[] = array_merge($row,$userArrs);

	}	
	
		
			
	$response['totalnumberofcoupans'] = $itemCount;	
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $all;
	
	$json_response = json_encode($response);
	echo $json_response;
		exit;		
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;	
    }
	
	}
	
		 if($val == 'appoinments'){
    include_once 'classes/coupan.php';
	$items = new Coupans($db);
	if($rusertype == 'doctor'){
		
	$stmt = $items->getCoupansbyDoctor($id);
	}
	if($rusertype == 'hospital'){
		
	$stmt = $items->getCoupansbyHospital($id);
	}
	if($rusertype == 'other'){
		
	$stmt = $items->getCoupansbyOther($id);
	}
	
		
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $cityArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
			 $dealid = $row['deal_id'];
		
			$stmtd = $deals->getDealsbyid($dealid); 		
		    $rows = mysqli_fetch_row($stmtd);
			
	           // print_r($rows);
			 $cityArr['dealtitle'] = $rows[1];
			 $cityArr['validfrom'] = $rows[2];
			 $cityArr['validto'] = $rows[3];
			 $cityArr['description'] = $rows[9];
			 $cityArr['fullimageurl'] = 'https://freemedicalinfo.in/admin/images/uploads/'.$rows[10];
			 
			  if($row['doctor_id'] != '')
			  {
		 
				include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($row['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[3];
	          }
	           if($row['hospital_id'] != '')
			  {
		 
				include_once 'classes/hospitals.php';
				$itemst = new Hospitals($db);
				$stmtt = $itemst->getSingleHospitals($row['hospital_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[4];
	          }
			   if($row['other_id'] != '')
			  {
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($row['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[5];
	          }						
		 
			 
			 $allArr[] = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	
    }
	
?>
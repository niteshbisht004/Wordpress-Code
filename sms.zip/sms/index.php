<!DOCTYPE html>
<html>
<head>
<title>Student Management System</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>
<h3 align="right" style="margin-right: 20px"><a href="login.php">Admin login</a></h3>
<h2 align="center">Welcome To Student Management System</h2>
<form method="post" action="index.php">
	<table style="width: 50%" align="center" border="1" class="table table-dark table-hover">
	<tr>
		<td align="center" colspan="2">View Student Information</td>
	</tr>
	<tr>
		<td align="left">Choose Standerd</td>
		<td>
			<select name="std" required />
				<option value="6">6th</option>
				<option value="7">7th</option>
				<option value="8">8th</option>
				<option value="9">9th</option>
				<option value="10">10th</option>
			</select>
		</td>
	</tr>
	<tr>
		<td align="left">Enter Roll No</td>
		<td><input type="text" name="rollno" placeholder="Roll No" required /></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input type="submit" name="submit" value="show Info" ></td>
	</tr>
	</table>
</form>
</body>
</html>
<?php
	include('dbcon.php');
	if(isset($_POST['submit']))
	{
		$stuRoll = $_POST['rollno'];
		$stuClass = $_POST['std'];
		//echo "The Roll Number is : ".$stuRoll;
		//echo "The class is : ".$stuClass;
		
		$qry="SELECT * FROM student where rollno = '$stuRoll' AND standerd = '$stuClass' ";
		$result=mysqli_query($con,$qry);
		echo "<table style='width: 60%' align=center class='table table-dark table-hover'>";
		echo "<tr>";
		echo "<th>Student Id</th>";
		echo "<th>Roll no</th>";
		echo "<th>Name</th>";
		echo "<th>City</th>";
		echo "<th>Class</th>";
		echo "<th>Mobile</th>";
		echo "</tr>";
		while($row=mysqli_fetch_array($result,MYSQLI_BOTH))//MYSQLI_ASSOC, MUSQLI_BOTH
			{
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "<td>".$row[3]."</td>";
				echo "<td>".$row[4]."</td>";
				echo "<td>".$row[5]."</td>";
				echo "</tr>";
				
			}
	}

 ?>
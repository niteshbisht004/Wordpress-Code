<?php
class Ratings
{

    // Connection
    private $conn;

    // Table
    private $db_table = "newrating";


    // Db connection
    public function __construct($db)
    {
        $this->conn = $db;
    }

    // GET ALL
    public function getRatings()
    {
        $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE status = 0";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }
    
    public function getSingleComment($id)
    {
        $sqlQuery = "SELECT * FROM rnewrating WHERE id = '".$id."' AND status = 0";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }

    public function getRatingsbyuserid($userid,$usertype)
    {
        $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE status = 0 AND
         user_id = '" . $userid . "' AND rateusertype = '" . $usertype . "'";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }
	
	public function getRatingsbyauserid($userid,$usertype,$ruid,$rutype)
    {
        $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE status = 0 AND
         user_id = '" . $userid . "' AND rateusertype = '" . $usertype . "' AND rating_by_userid = '" . $ruid . "' AND user_type = '" . $rutype . "'";
		
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }

    public function deleteComment($id){ 
        //$sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id='" . $id . "'"; 
        //$stmt = $this->conn->query($sqlQuery);
        $sqlQueryc = "DELETE FROM rnewrating WHERE id ='" . $id . "'"; 
        $stmts = $this->conn->query($sqlQueryc);
        return $stmt;
    }


    public function getcommentssbyratingrid($id)
    {
        $sqlQuery = "SELECT * FROM rnewrating WHERE status = 0 AND
         rating_id = '" . $id . "'";
		
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }
    
    public function getlikebyid($id)
    {
        $sqlQuery = "SELECT * FROM cmnt_like_dislike WHERE likes = 1 AND
         rating_id = '" . $id . "'";		
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }

    public function getdislikebyid($id)
    {
        $sqlQuery = "SELECT * FROM cmnt_like_dislike WHERE dislike = 1 AND
         rating_id = '" . $id . "'";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }

    public function getrlikebyid($id)
    {
        $sqlQuery = "SELECT * FROM rcmnt_like_dislike WHERE likes = 1 AND
         rating_id = '" . $id . "'";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }

    public function getrdislikebyid($id)
    {
        $sqlQuery = "SELECT * FROM rcmnt_like_dislike WHERE dislike = 1 AND
         rating_id = '" . $id . "'";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }


    public function getRatingsbylimit($skiprow,$row)
    {
        $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE status = 0 LIMIT $skiprow,$row";
        $stmt = $this->conn->query($sqlQuery);
        return $stmt;
    }



    public function updateRating($user_id,
    $rateusertype,
    $email,
    $rate,
    $recommend,
    $comment,
    $rating_by_userid,
    $rating_by_useremail,
    $user_type,$id)
    {
        if ($rate == 5) {

            $star5 = '5';
        }
        if ($rate == 4) {

            $star4 = '4';
        }
        if ($rate == 3) {

            $star3 = '3';
        }
        if ($rate == 2) {

            $star2 = '2';
        }
        if ($rate == 1) {

            $star1 = '1';
        }

        $sqlQuery = "update " . $this->db_table . " SET  
        `user_id` = '" . $user_id . "',
        `rateusertype` = '" . $rateusertype . "',
        `email` = '" . $email . "',
        `rate` = '" . $rate . "',
        `5star`='" . $star5 . "',
        `4star`='" . $star4 . "',
        `3star`='" . $star3 . "',
        `2star`='" . $star2 . "',
        `1star`='" . $star1 . "',
        `recommend`='" . $recommend . "',
        `comment`='" . $comment . "',
        `rating_by_userid`='" . $rating_by_userid . "',
        `rating_by_useremail`='" . $rating_by_useremail . "',
        `user_type`='" . $user_type . "',
        `insert_date`='" . date("Y-m-d H:i:s") . "',
        `timestamp`='" . date("Y-m-d H:i:s") . "'
		WHERE id = '$id'";
         
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            return $stmt;
        }
    }
    

    public function abusecomment($id,$userid,$usertype)
    {
       
        $sqlQuery = "update rnewrating SET  status = 1 WHERE id = '$id'";
         
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            return $stmt;
        }
    }
    

    public function updateComment($comment,$id)
    {
        

        $sqlQuery = "update rnewrating SET `comment`='" . $comment . "'
       	WHERE id = '$id'";
         
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            return $stmt;
        }
    }



    public function insertRating(
        $user_id,
        $rateusertype,
        $email,
        $rate,
        $recommend,
        $comment,
        $rating_by_userid,
        $rating_by_useremail,
        $user_type
    ) {

        if ($rate == 5) {

            $star5 = '5';
        }
        if ($rate == 4) {

            $star4 = '4';
        }
        if ($rate == 3) {

            $star3 = '3';
        }
        if ($rate == 2) {

            $star2 = '2';
        }
        if ($rate == 1) {

            $star1 = '1';
        }
		
		$sqlQuerys = "SELECT * FROM " . $this->db_table . " WHERE status = 0 AND
         user_id = '" . $user_id . "' AND rateusertype = '" . $rateusertype . "' AND rating_by_userid = '" . $rating_by_userid . "' AND user_type = '" . $user_type . "'";
		 $stmts = $this->conn->query($sqlQuerys);
		    	 
		$count = $stmts->num_rows;
		if($count == 0){
        $sqlQuery = "INSERT INTO " . $this->db_table . " set 
   `user_id` = '" . $user_id . "',
   `rateusertype` = '" . $rateusertype . "',
   `email` = '" . $email . "',
   `rate` = '" . $rate . "',
   `5star`='" . $star5 . "',
   `4star`='" . $star4 . "',
   `3star`='" . $star3 . "',
   `2star`='" . $star2 . "',
   `1star`='" . $star1 . "',
   `recommend`='" . $recommend . "',
   `comment`='" . $comment . "',
   `rating_by_userid`='" . $rating_by_userid . "',
   `rating_by_useremail`='" . $rating_by_useremail . "',
   `user_type`='" . $user_type . "',
   `insert_date`='" . date("Y-m-d H:i:s") . "',
   `timestamp`='" . date("Y-m-d H:i:s") . "'";

        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            $this->id = $this->conn->insert_id;


            return $stmt;
        }
		}else{
			 return false;
			
		}
    }




    public function insertComment($rating_id,$rply_id,$user_id,
        $rateusertype,
        $email,
        $comment,
        $rating_by_userid,
        $rating_by_useremail,
        $user_type
    ) {

    
	
        $stmt = $this->conn->query($sqlQuery);
	
        $sqlQuery = "INSERT INTO rnewrating set 
                `rating_id` = '" . $rating_id . "',
            `reply_id` = '" . $rply_id . "',
            `user_id` = '" . $user_id . "',
            `rateusertype` = '" . $rateusertype . "',
            `email` = '" . $email . "',
            `comment`='" . $comment . "',
            `rating_by_userid`='" . $rating_by_userid . "',
            `rating_by_useremail`='" . $rating_by_useremail . "',
            `user_type`='" . $user_type . "',
            `insert_date`='" . date("Y-m-d H:i:s") . "',
            `timestamp`='" . date("Y-m-d H:i:s") . "'";

        
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            $this->id = $this->conn->insert_id;


            return $stmt;
        }
    }

    public function insertratinglike($rating_id,$user_id) {
    
        $rqry="select * from `cmnt_like_dislike` where `user_id`='$user_id' AND `rating_id`='$rating_id'";		
        $stmt = $this->conn->query($rqry);
        $itemCount = $stmt->num_rows;
    
        if($itemCount > 0){
          
            return false; 

        }else{

        $sqlQuery = "INSERT INTO cmnt_like_dislike set 
        `likes`=1, `user_id`='$user_id', `rating_id`='$rating_id'";
        
         $stmt = $this->conn->query($sqlQuery);

        if ($stmt) { 
            $this->id = $this->conn->insert_id;
            return $stmt;
        }
    }
    }

    public function insertratingdislike($rating_id,$user_id) {

        $rqry="select * from `cmnt_like_dislike` where `user_id`='$user_id' AND `rating_id`='$rating_id'";
        $stmt = $this->conn->query($rqry);
       $itemCount = $stmt->num_rows;
        
        if($itemCount > 0){
          
            return false; 

        }else{
        $sqlQuery = "INSERT INTO cmnt_like_dislike set 
        `dislike`=1, `user_id`='$user_id', `rating_id`='$rating_id'";
         $stmt = $this->conn->query($sqlQuery);
        if ($stmt) {
            $this->id = $this->conn->insert_id;
            return $stmt;
        }

    }
    }

    public function insertcommentlike($rating_id,$user_id){
    

        $rqry="select * from `rcmnt_like_dislike` where `user_id`='$user_id' AND `rating_id`='$rating_id'";
        $stmt = $this->conn->query($rqry);
        $itemCount = $stmt->num_rows;
        
        if($itemCount > 0){
          
            return false; 

        }else{

        $sqlQuery = "INSERT INTO rcmnt_like_dislike set 
        `likes`=1, `user_id`='$user_id', `rating_id`='$rating_id'";
       
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            $this->id = $this->conn->insert_id;
            return $stmt;
        }

    }
    }

    public function insertcommentdislike($rating_id,$user_id) {

        $rqry="select * from `rcmnt_like_dislike` where `user_id`='$user_id' AND `rating_id`='$rating_id'";
        $stmt = $this->conn->query($rqry);
        $itemCount = $stmt->num_rows;
        
        if($itemCount > 0){
          
            return false; 

        }else{

        $sqlQuery = "INSERT INTO rcmnt_like_dislike set 
        `dislike`=1, `user_id`='$user_id', `rating_id`='$rating_id'";
        $stmt = $this->conn->query($sqlQuery);

        if ($stmt) {
            $this->id = $this->conn->insert_id;
            return $stmt;
        }

    }
}

public function getAllRating($uid,$utype,$ruid,$rutype)
 {
    $rqry="select * from `newrating` where `user_id`='$uid' AND `rateusertype`='$utype' AND
	`rating_by_userid`='$ruid' AND `user_type`='$rutype'";

    $stmt = $this->conn->query($rqry);  
	return $stmt;
}




}
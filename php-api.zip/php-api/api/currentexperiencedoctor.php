<?php
//error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	//$usertype = $_POST['usertype'];
	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db);

	if($val == 'doctor'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getCurrentExperience($id);
	
	$itemCount = mysqli_num_rows($stmt);

    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $userexp = $items->getSingleHospitals($row['hospital_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		  
			 $cityArr['hospitalid'] = $row['hospital_id'];
		     $cityArr['hospitalname'] = $rows['name'];
		    $cityArr['fulladdress'] = $rows['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
		 }
		
		$allArr[] = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
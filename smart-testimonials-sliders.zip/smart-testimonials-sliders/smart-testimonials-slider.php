<?php
/**
 * Plugin Name: Smart Testimonials Sliders
 * Plugin URI: https://ecompundit.com/all-in-one-smart-features-for-woocommerce-plugin/
 * Description: All-in-one smart Testimonials Sliders.
 * Version: 1.0.0
 * Author: Ecom Pundit
 * Author URI: https://ecompundit.com/
 * Text Domain: smart-testimonials-slider
 * Domain Path: /translations/
 * License: GPL2
 */
 
defined( 'ABSPATH' ) || exit;

if(! function_exists('add_action')){
exit;
}


if ( ! class_exists( 'Smart_Testi', false ) ) {
Class Smart_Testi {


	/*
	 * The Constructor
	 *
	 */
	public function __construct() 
	{
  
     
		// Defining constants
		define('STS_VERSION', '1.0.0');
		define('STS_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . dirname( plugin_basename(__FILE__) ) );
		define('STS_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );

		add_action( 'admin_menu', array( $this, 'add_main_menu_page' ), 10 );
	
		add_action( 'wp_enqueue_scripts', array( $this, 'init_front_end_scripts' ) );
		add_action( 'init', array( $this, 'load_resources_admin' ) );
		add_action( 'add_meta_boxes', 'wpt_add_event_metaboxes' );
      
	}

/*
	 * Add the main menu page
	 *
	 */
	public function add_main_menu_page() 
	{
	
		add_menu_page('Smart Testimonials', 'Smart Testimonials', '','sts-smart-testi', '', plugin_dir_url( __FILE__).'uploads/plugin-icon.png',48 );
		add_submenu_page('sts-smart-testi',  'Testimonials Settings', 'Testimonials Settings',   'manage_options', 'smart-testimonials','sts_myplugins_smart_testi_slider');
        	
		 
		flush_rewrite_rules();
	}



	/*
	 * Enqueue scripts for the front-end
	 *
	 */
	public function init_front_end_scripts() 
	{
		
		 wp_enqueue_script( 'js-slider', plugin_dir_url( _FILE_ ) . 'assets/js/slick.min.js', array( 'jquery' ), '', true );
          
		wp_register_style( 'swp-frontends-style', plugin_dir_url( __FILE__ ) . 'assets/css/slick.css' );
		wp_enqueue_style( 'swp-frontends-style' );
        
		if( file_exists( STS_PLUGIN_DIR . '/includes/testimonials-setting.php' ) )
			include_once( STS_PLUGIN_DIR . '/includes/testimonials-setting.php' );
	}

   
	/*
	 * Include plugin files for the admin area
	 *
	 */
	public function load_resources_admin() 
	{

		if( file_exists( STS_PLUGIN_DIR . '/includes/store-setting.php' ) )
			include_once( STS_PLUGIN_DIR . '/includes/store-setting.php' );	
		
		if( file_exists( STS_PLUGIN_DIR . '/includes/get-shortcode.php' ) )
			include_once( STS_PLUGIN_DIR . '/includes/get-shortcode.php' );	
	}
	
	public function my_plugin_uninstall() {
          // Uninstallation stuff here
             unregister_post_type( 'smart-testimonials' );
        }
	

}

}
// Let's get the party started
$smartwoo = new Smart_Testi;

 register_activation_hook( __FILE__, 'add_main_menu_page' );
 register_deactivation_hook( __FILE__, 'add_main_menu_page' );
register_uninstall_hook( __FILE__, 'my_plugin_uninstall' );
	 


	

	
	
	

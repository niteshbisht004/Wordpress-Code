<!DOCTYPE html>
<html>
<head><title>Admin Login</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="container text-center">
	
<div class="row">
 <div class="col-sm-4" style="margin-top: 35px"><a href="index.php"><h3>Back To Index</a></h3></div>
 <div class="col-sm-4" style="margin-top: 25px">
	<h1>Admin Login</h1>
	<form class="text-left" method="post" action="login.php">
           <div class="form-group">
        	<label for="Username">Username:</label>
            <input type="text" name="uname" class="form-control" id="Username" placeholder="Enter username" required />
           </div>
           <div class="form-group">
              <label for="Password">Password:</label>
            	<input type="password" name="pass" class="form-control" id="password" placeholder="Enter password" required />
           </div>
        <button type="submit" value="Login" name="login" class="btn btn-primary">Submit</button>
    </form>
	</div>
<div class="col-sm-4"></div>
	</div>
	</div>
</body>
</html>
<?php 
	include('dbcon.php');
	if(isset($_POST['login']))
	{
		$username=$_POST['uname'];
		$password=$_POST['pass'];
		$qry="SELECT * FROM admin_master WHERE admin_usrname = '$username' AND admin_pass = '$password'";
		$run=mysqli_query($con,$qry);
		$rowNum = mysqli_num_rows($run);
		$row = mysqli_fetch_array($run);
//		echo $rowNum;

		if($rowNum == 0)
		{
			echo "<p>Login Failed..!</p>";
		}
		else
		{
			session_start();
			$_SESSION['user_id'] = $row['id'];
			header('location:admin/dashboard.php');	
		
		}
	}
?>
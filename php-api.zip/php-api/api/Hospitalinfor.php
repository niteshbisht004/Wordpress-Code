<?php
//error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	//$usertype = $_POST['usertype'];
	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db);

    if($val == 'hospital'){
        include_once 'classes/hospitals.php';
        $items = new HospitalsPersonal($db);
        $stmt = $items->getSingleDoctors($id);
        $itemCount = mysqli_num_rows($stmt);
        
        if($itemCount > 0){
    
    
            $userPr = array();
    
    
            while ($row = $stmt->fetch_assoc()){
    
               //$userArr[] = $row;
    
                    $cityArr['cat'] = $val;
    
                    if($row['pro_img'] == ''){
    
                
    
                $cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
    
            }else{
    
                $cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
    
                
    
            }
    
            
    
                if($row['timeline_img'] == ''){
    
                
    
                $cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';
    
            }else{
    
                $cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
    
                
    
            }
    
            
    
                    
    
                    
    
                 
                 
    
              									
    
             
    
                 
    
                 $allArr = array_merge($row,$cityArr);
    
    
            
                $userPr['Name'] = $row['Name'];

                $userPr['mobile'] = $row['mobile'];
    
                $userPr['email'] = $row['email'];
    
                $userPr['website'] = $row['website'];             
    
                $userPr['country'] = $row['country'];
    
                $userPr['state'] = $row['state'];

                $userPr['city'] = $row['city'];

                $citystmt = $cityitems->getSingleCity($row['city']);
    
                    $ffdsf = mysqli_fetch_row($citystmt);
    
                    
    
                 $userPr['cityname'] = $ffdsf[0];
    
                               
    
                 $statestmt = $stateitems->getSingleState($row['state']);
    
                  $snames =  mysqli_fetch_row($statestmt);
    
                 $userPr['statename'] = $snames[0];
    
                 
    
                 $countrystmt = $countryitems->getSingleCountry($row['country']);
    
                  $sname =  mysqli_fetch_row($countrystmt);
    
                $userPr['countryname'] = $sname[0];
    
    
                $userPr['phone'] = $row['phone'];                          
               
                $userPr['address'] = $row['address'];
    
                $userPr['zipcode'] = $row['zipcode']; 
    
    
               
    
           
    
             }	
    
    
    
        
    
            
    
        $response['message']="Data Found";
    
        $response['status']=1;
    
        $response['Hospersinfo']=$userPr; 
    
        $json_response = json_encode($response);
    
        echo $json_response;
    
        exit;			
    
        }
    
    
    
        else{
    
        $response['message'] = "No Record Found";
    
        $response['status'] = 0;
    
        
    
        $json_response = json_encode($response);
    
        echo $json_response;
    
        exit;
    
        } 
    
        }

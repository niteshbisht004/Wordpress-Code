<?php
error_reporting(0);
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

include_once 'classes/city.php';
$cityitems = new Cities($db);

include_once 'classes/states.php';
$stateitems = new States($db);

include_once 'classes/rating.php';
$rateitems = new Ratings($db);

include_once 'classes/country.php';
$countryitems = new Countries($db);

include_once 'classes/special.php';
$specialitems = new Special($db);


include_once 'classes/qual.php';
$qualitems = new Qual($db);

$data = json_decode(file_get_contents("php://input"));

$val = $_POST['cat'];
$spec = $_POST['specialisation'];
$srow = $_POST['skiprow'];
$rows = $_POST['row'];
$ctyid=$_POST['city'];

	$statename = $_POST['statename'];
	$statestmtn = $stateitems->getStatesbyname($statename);
	$snamesn =  mysqli_fetch_row($statestmtn);
	$stateid = $snamesn[0];
	
	$cityname = $_POST['cityname'];
	$citynamen = $cityitems->getCitiesbyname($cityname);
	$citynamensn =  mysqli_fetch_row($citynamen);
	$cityid = $citynamensn[0];



if ($val == 'slider') {
	include_once 'classes/slider.php';
	$items = new Slider($db);
	$stmt = $items->getSlider();
	$userArr = array();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {


		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/home-slider/' . $row['image1'];

			$allArr['slider'][] = array_merge($row, $cityArr);
		}
		
		
	include_once 'classes/advertisments.php';
		
	$itemsa = new Advertisments($db);
		
    $stmta = $itemsa->getAdvts();	
	
	$itemCounta = mysqli_num_rows($stmta);

	if ($itemCounta > 0) {

		$userArra = array();
		$cityArra = array();
	

		while ($rowa = $stmta->fetch_assoc()) {
			$userArra[] = $rowa;
	$cityArra['fullimgurl'] = 	'https://dev.freemedicalinfo.in/admin/images/uploads/Advertisement/' . $rowa['advtImg'];
		
     $allArr['ads'][] = array_merge($rowa, $cityArra);
		}
		
	}		
	
	
	include_once 'classes/doctors.php';
	$itemsd = new Doctors($db);
	$stmtsd = $itemsd->getRecDoctors($cityid,$stateid);
	$itemCountsd = mysqli_num_rows($stmtsd);
    if($itemCountsd == 0){
	$stmtsd = $itemsd->getRecDoctorsbystate($stateid);
	$itemCountsd = mysqli_num_rows($stmtsd);	
	$itemCountsds = mysqli_num_rows($stmtsd);	
	}
    if($itemCountsds == 0){
	$stmtsd = $itemsd->getRecDoctorsbycountry();
	$itemCountsd = mysqli_num_rows($stmtsd);	
		
	}
	if ($itemCountsd > 0) {

		$userArrd = array();
		$cityArrd = array();
		

		while ($rowd = $stmtsd->fetch_assoc()) {
			$userArrd[] = $rowd;

			$citystmt = $cityitems->getSingleCity($rowd['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArrd['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($rowd['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArrd['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($rowd['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArrd['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($rowd['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArrd['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($rowd['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArrd['specialisationname'] = $specialname[0];

			if ($rowd['pro_img'] == '') {

				$cityArrd['profileimg'] = 'https://dev.freemedicalinfo.in/images/doctor-face.jpg';
			} else {
				$cityArrd['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $rowd['pro_img'];
			}

			if ($rowd['timeline_img'] == '') {

				$cityArrd['bannerimg'] = 'https://dev.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArrd['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $rowd['timeline_img'];
			}
			$cityArrd['usertype'] = 'doctor';

			$statestmts = $rateitems->getRatingsbyuserid('slider', $rowd['id']);
			$rating =  mysqli_fetch_row($statestmts);
								$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArrd['rating'] = $rating[4];

			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($rowd['id'], 'doctor');
			$cityArrd['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($rowd['id']);
			$cityArrd['deal_count']  = mysqli_num_rows($stmtd);
            
            
           $itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($rowd['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArrd['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($rowd['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArrd['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			
			
			
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($rowd['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArrd['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($rowd['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArrd['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}




			$allArr['doctors'][] = array_merge($rowd, $cityArrd);
			
			
			
			
		}
	}
	
		
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;
		$response['content'] = '<h4 class="heading">Free Medical Info</h4>
                        <p>We provides a platform to the Patients, Doctors, Clinics, Hospitals, Pharma Companies and other organizations related to medical sector, who want to share the information online. The website allows the patients/ visitors to also search the information about:</p><ul class="list-unstyled about-medical">
                            <li>Doctor for a particular disease/ Specialisation (Filtered on the basis of Place, 
							Qualification, Experience Methods like Homeopathy, Ayurved, Unani, Vaidya etc.and star ratings)</li>
                            <li>Clinics / Hospitals with specific facility to treat a particular disease</li>
                            <li>Finding the pathology labs for a particular medical test (X Ray, CT Scan, MRI Scan etc, Blood Test),
							Filtered on the basis of Place, Qualification, Experience, cost and star ratings</li>
                            <li>Blood Bank/ Eye Banks in the region</li>
                            <li>Fitness Centre / PhysioTherapist/ Yoga Classes, Acupuncture etc. special treatment methods</li>
                        </ul>';
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'partner') {
	include_once 'classes/partner.php';
	$items = new Partner($db);
	$stmt = $items->getPartner();
	$userArr = array();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {


		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$cityArr['imgfullurl'] = 'https://dev.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

			$allArr[] = array_merge($row, $cityArr);
		}
	
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;
		
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'privacy') {

	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(11);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'homeopathy') {
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory(12);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
			
			$statestmts = $rateitems->getRatingsbyuserid($rowd['id'], 'doctor');
			
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			
             $itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);
 


    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	

	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			

   include_once 'classes/blog.php';
	$itemsbo = new Blogs($db);
	
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);

			 
			

    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}
			 
			 
			 
			 
			 
			
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'ayurevdic') {
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory(70);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
			
			$statestmts = $rateitems->getRatingsbyuserid($rowd['id'], 'doctor');
			
			$rating =  mysqli_fetch_row($statestmts);
			$cityArr['rating'] = $rating[4];
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			
			
	include_once 'classes/blog.php';		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}


			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'testpathlab') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategory(61);
    $stmto = $items->getOhersbyCategory(61);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';
			
			$itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}


                
                

            include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}
			
			
			$allArr[] = array_merge($row, $cityArr);
		}


        while ($row = $stmto->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';
			
				include_once 'classes/others.php';
			$itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}






          include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}
			
			
			
			$allArr[] = array_merge($row, $cityArr);
		}



		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'fitnesscenter') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategory(111);
    $stmto = $items->getOhersbyCategory(111);
	$itemCount = mysqli_num_rows($stmto);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'hospital';
			
			$statestmts = $rateitems->getRatingsbyuserid($rowd['id'], 'other');
			
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			
			
			$itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}






           include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}
			
			
			
			
			
			
			$allArr[] = array_merge($row, $cityArr);
		}
		
		
		while ($row = $stmto->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'other';
			
				include_once 'classes/others.php';
			$itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}






            include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}
			
			
			
			
			
			$allArr[] = array_merge($row, $cityArr);
		}
		
		
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'bloodbank') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategorys(14);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'hospital';
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'aboutus') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(6);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'certification') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(7);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'certification') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(7);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'advertise') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(8);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'terms') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(10);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'user') {
	include_once 'classes/users.php';
	$items = new Users($db);
	$stmt = $items->getUsers();

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'user';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['blog_count'] = 0;
		$response['deal_count'] = 0;

		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}



if ($val == 'doctor' && $spec != '') {

	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'hospitals' && $spec != '') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbySpeclisation($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'others' && $spec != '') {
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getOthersbySpeclisation($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'doctor') {
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmts = $items->getDoctors();
	$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getDoctorsbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
            
	$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			
			
			
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}

	
    include_once 'classes/deals.php';
	
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde); 
		 }	
		 
	}


	
	
	
	include_once 'classes/rating.php';
        $items = new Ratings($db);
        $stmt = $items->getRatingsbyuserid($row['id'],$val);
        $itemCount = mysqli_num_rows($stmt);
        
        if ($itemCount > 0) { 
    
            $userArr = array();
            $cityArr = array();
            $allArr  = array();
    
            while ($rowr = $stmt->fetch_assoc()) {
                
               $userArr[] = $rowr;
            
               $uid=$rowr['user_id'];
               $utype=$rowr['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
               
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArr['name']=$rowd['name'];
            }
       
       
           $rid=$rowr['rating_by_userid'];
           $rtype=$rowr['user_type'];
    
           if($rtype=='user')
           {
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['first_name'];
                    }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['name'];
                    }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
    
           $cityArr['rate'] = $row['rate'];
            
           $stmtl = $items->getlikebyid($rowr['id']);
           $cityArr['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $items->getdislikebyid($rowr['id']);
           $cityArr['dislike'] = mysqli_num_rows($stmtd);
		   
		   
		 
		   
		    $stmtco = $items->getcommentssbyratingrid($rowr['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
        if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
    
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                        $cityArrco['username'] = $rowuco['first_name'];
                    }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                        $cityArrco['username'] = $rowuco['name'];
                    }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['username'] = $rowuco['name'];
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['username'] = $rowuco['name'];
                }
           }
            
          
		   $stmtlco = $items->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $items->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
                $cityArr['comments'][] = array_merge($rowco, $cityArrco);
            }
		   
		   
		}
			}
	
		}
	
	
			
			
		$allArr[] = array_merge($row, $cityArr);	
	
		}

		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'hospital') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmts = $items->getHospitals();
	$stmt = $items->getHospitalsbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://dev.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://dev.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			
			$cityArr['rating'] = $rating[4];

			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyhospitalid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);

    $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}

    

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'other') {
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmts = $items->getOthers();
	$stmt = $items->getOthersbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://dev.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://dev.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/sisdev/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$rating =  mysqli_fetch_row($statestmts);
	
			$cityArr['rating'] = $rating[4];

			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other-medical');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				if(!empty($val)){
				foreach($val as $key){
				$specialstmt = $specialitems->getSingleSpecial($key);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] .= $specialname[0].",";
					
				}	
					
				}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}

			

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}













if ($val == 'deal'){
	
	include_once 'classes/deals.php';
	$items = new Deals($db);
	if($spec == ''){
	
	$stmt = $items->getdeals();
	
	}else{
	
    $stmt = $items->getDealsbyCategory($spec);	
		
	}
	
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
			$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/' . $row['image'];
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['doctor_id'] != '') {

				include_once 'classes/doctors.php';
				$itemsd = new Doctors($db);
				$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
				$rowd = $stmtd->fetch_assoc();

				$cityArr['offerby'] = $rowd['name'];
			}
			if ($row['hospital_id'] != '') {

				include_once 'classes/hospitals.php';
				$itemsh = new Hospitals($db);
				$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
				$rowh = $stmth->fetch_assoc();

				$cityArr['offerby'] = $rowh['name'];
			}
			if ($row['other_id'] != '') {

				include_once 'classes/others.php';
				$itemso = new Others($db);
				$stmto = $itemso->getSingleOthers($row['other_id']);
				$rowo = $stmto->fetch_assoc();

				$cityArr['offerby'] = $rowo['name'];
			}

			include_once 'classes/coupan.php';
			$itemsc = new Coupans($db);
			$stmtc = $itemsc->getCoupanbydeal($rowo['id']);
			$itemCountc = mysqli_num_rows($stmtc);
			$cityArr['total_coupons'] = "$itemCountc";
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;


		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if($val == 'blog') {
	include_once 'classes/blog.php';
	$items = new Blogs($db);
	$stmt = $items->getBlogs();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
			$cityArr['fullimgurl'] = 'https://www.freemedicalinfo.in/sisdev/admin/images/uploads/' . $row['image'];
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {

        $response['message'] = "Data Not Found";
		$response['status'] = 0;
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'ads'){

	include_once 'classes/advertisments.php';
		
	$items = new Advertisments($db);
		
    $stmt = $items->getAdvts();	
	
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
	$cityArr['fullimgurl'] = 	'https://dev.freemedicalinfo.in/admin/images/uploads/Advertisement/' . $row['advtImg'];
		
     $allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;


		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if($val == 'rating') {
    
	include_once 'classes/rating.php';
	$items = new Ratings($db);
	$stmt = $items->getRatings();
	$itemCount = mysqli_num_rows($stmt);
    $stmts = $items->getRatingsbylimit($srow, $rows);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCounts > 0) { 

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmts->fetch_assoc()) {
			
		   $userArr[] = $row;
		
           $uid=$row['user_id'];
           $utype=$row['rateusertype'];
           
           if($utype == 'doctor')
           {
				include_once 'classes/doctors.php';
				$itemd = new Doctors($db);
				$stmtd = $itemd->getSingleDoctors($uid);
		   }

           if($utype == 'hospital')
           {
			
				include_once 'classes/hospitals.php';
				$itemd = new Hospitals($db);
				$stmtd = $itemd->getSingleHospitals($uid);   
		
		   }

          if($utype == 'other')
          {
				include_once 'classes/others.php';
				$itemd = new Others($db);
				$stmtd = $itemd->getSingleOthers($uid);   
               
          }
           
		while ($rowd = $stmtd->fetch_assoc())
		{
				if($rowd['pro_img'] == ''){
					
					$cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
				}else{
					$cityArr['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowd['pro_img'];
					
				}
				$cityArr['name']=$rowd['name'];
		}
   
   
       $rid=$row['rating_by_userid'];
       $rtype=$row['user_type'];

       if($rtype=='user')
       {
         	include_once 'classes/users.php';
			$itemu = new Users($db);
			$stmtu = $itemu->getSingleUsers($rid); 

			while ($rowu = $stmtu->fetch_assoc())

				{
					$cityArr['username']=$rowu['first_name'];
				}
		}

       if($rtype=='doctor')
       {
			include_once 'classes/doctors.php';
			$itemu = new Doctors($db);
			$stmtu = $itemu->getSingleDoctors($rid);

            while ($rowu = $stmtu->fetch_assoc())

				{
					$cityArr['username']=$rowu['name'];
				}
       }

       if($rtype=='hospital')
       {
            include_once 'classes/hospitals.php';
			$itemu = new Hospitals($db);
			$stmtu = $itemu->getSingleHospitals($rid);

			while ($rowu = $stmtu->fetch_assoc())

			{
				$cityArr['username']=$rowu['name'];
			}
       }
       
       if($rtype=='other')
       {
			include_once 'classes/others.php';
			$itemu = new Others($db);
			$stmtu = $itemu->getSingleOthers($rid);

			while ($rowu = $stmtu->fetch_assoc())
			{
				$cityArr['username']=$rowu['name'];
			}
       }

       $cityArr['rate'] = $row['rate'];
        

			$allArr[] = array_merge($row, $cityArr);
		}
        $response['totalcount'] =  $itemCount;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {

        $response['message'] = "Data Not Found";
		$response['status'] = 0;
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'city') {
	include_once 'classes/city.php';
	$items = new Cities($db);
	$stmt = $items->getAllCities();

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $userArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "Data Not Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	$post_by = $_POST['post_by'];
	$usertype = $_POST['usertype'];
	$name = $_POST['name'];  
		$gender = $_POST['gender']; 
		$qualification = $_POST['qualification'];  
		$date_birth = $_POST['date_birth'];  
		$specialisation = $_POST['specialisation']; 
		$registration_no = $_POST['registration_no'];
		$registration_auth = $_POST['registration_auth'];
		$expertise_in = $_POST['expertise_in'];
		$summary = $_POST['summary'];
		$total_experience = $_POST['total_experience'];
		$update_date = $_POST['date'];
		
		$phone_no = $_POST['phone_no'];
        $other_phone = $_POST['other_phone']; 
        $fax_no = $_POST['fax_no']; 
        $mobile_no = $_POST['mobile_no']; 
        $address = $_POST['address'];
		$country = $_POST['country']; 
        $otherEmail = $_POST['otherEmail']; 
        $city = $_POST['city'];
		$district = $_POST['district']; 
        $zipe_code = $_POST['zipe_code']; 
        $update_date = $_POST['update_date'];
		
	    $perName = $_POST['Name'];
		$peremail = $_POST['email'];
        $peraddress = $_POST['address']; 
        $percountry = $_POST['country']; 
        $perstate = $_POST['state']; 
        $percity = $_POST['city'];
		$perphone = $_POST['phone'];
		$permobile = $_POST['mobile'];
		$perwebsite = $_POST['website'];
		$perzipcode = $_POST['zipcode'];
	 
	 
	$noOfBeds = $_POST['noOfBeds'];
	$private_room = $_POST['private_room'];
	$hospital_category = $_POST['hospital_category'];
	$clinical_test = $_POST['clinical_test'];
	$ambulance = $_POST['ambulance'];
    $heyear = $_POST['heyear'];
	$extra_feature = $_POST['extra_feature'];
	$O_contact = $_POST['O_contact'];
	$O_time_to_call = $_POST['O_time_to_call'];
	$O_email = $_POST['O_email'];
	$O_website = $_POST['O_website'];
	$O_message = $_POST['O_message'];
	$available_facility = $_POST['available_facility'];
	$special_infra = $_POST['special_infra'];
	$special_machine = $_POST['special_machine'];
	
	$O_extra_feature = $_POST['O_extra_feature'];
	$contact_no = $_POST['contact_no'];
	$time_to_call = $_POST['time_to_call'];
	$website = $_POST['website'];
	$state = $_POST['state'];
	
		$doctor_id = $_POST['doctor_id'];
	$hospital_id = $_POST['hospital_id'];
	
	$designation = $_POST['designation'];
	$hospital_c_name = $_POST['hospital_c_name'];
		$from_date = $_POST['from_date'];
	$to_date = $_POST['to_date'];
		$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];

	
	 $title = $_POST['title'];  
		
		$meta_name = $_POST['meta_name'];  
		$meta_discription = $_POST['meta_discription'];  
		$description = $_POST['description']; 
		$image = $_POST['image'];
		$video = $_POST['video'];
		$insert_date = $_POST['insert_date'];
		$valid_from = $_POST['valid_from'];
		$valid_to = $_POST['valid_to'];
		$short_desc = $_POST['short_desc'];
		$deal_date = $_POST['deal_date'];
	 
	    $other_id = $_POST['other_id'];
        $personalPhone = $_POST['personalPhone'];
		$personalMobile = $_POST['personalMobile'];
		$personalEmail = $_POST['personalEmail'];
		$personalUrl = $_POST['personalUrl'];
		$personalAddress = $_POST['personalAddress'];
		$update_date = $_POST['update_date'];
	     $O_name = $_POST['O_name'];
		 $O_phone = $_POST['O_phone'];
		 $O_mobile = $_POST['O_mobile'];
		 $O_website = $_POST['O_website'];
		 $O_email = $_POST['O_email'];
		 $O_country = $_POST['O_country'];
		 $O_state = $_POST['O_state'];
		 $O_city = $_POST['O_city'];
		 $O_address = $_POST['O_address'];
		 $O_zip = $_POST['O_zip'];
        	
		if($val == 'doctor'){
            include_once 'classes/doctors.php';
            $items = new Doctors($db);

            $stmt = $items->updatePersonalinformation($personalPhone,$personalMobile,$personalEmail,$personalUrl,$personalAddress,$update_date,$id);
            //$allArr = array();
     
            if($stmt){
                $allArr[] = array('personalPhone' => $_POST['personalPhone'],'personalMobile' => $_POST['personalMobile'],'personalEmail' => $_POST['personalEmail'],'personalUrl' => $_POST['personalUrl'],'personalAddress' => $_POST['personalAddress'],'update_date' => $_POST['update_date'],'id' => $_POST['id']); 
                $response['message']="Data Found";
            $response['status']=1;
            $response['data']=$allArr;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
		  if($val == 'hospital'){
            include_once 'classes/hospitals.php';
            $items = new HospitalsPersonal($db);
            $stmt = $items->updatePersonalinformation($perName,$peremail,$peraddress,$percountry ,$perstate,$percity,$perphone,$permobile,$perwebsite,$perzipcode,$id);
  

           // $allArr = array();
            if($stmt){ 
                $allArr[] = array('Name' => $_POST['Name'],'email' => $_POST['email'],'address' => $_POST['address'],'country' => $_POST['country'],'state' => $_POST['state'],'city' => $_POST['city'],'phone' => $_POST['phone'],'mobile' => $_POST['mobile'],'website' => $_POST['website'],'zipcode' => $_POST['zipcode'],'id' => $_POST['id']);     

            
            $response['message']="Data Found";
            $response['status']=1;
            $response['data']=$allArr;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
          if($val == 'other'){
            include_once 'classes/others.php'; 
            $items = new Others($db);
            $stmt = $items->updatePersonalinformation($O_name,$O_phone,$O_mobile,$O_website ,$O_email,$O_country,$O_state,$O_city,$O_address,$O_zip,$id);
            

            //$allArr = array();
            if($stmt){ 
                $allArr[] = array('O_name' => $_POST['O_name'],'O_phone' => $_POST['O_phone'],'O_mobile' => $_POST['O_mobile'],
                'O_website' => $_POST['O_website'],
                'O_email' => $_POST['O_email'],'O_country' => $_POST['O_country'],'O_state' => $_POST['O_state'],
                'O_city' => $_POST['O_city'],'O_address' => $_POST['O_address'],'O_zip' => $_POST['O_zip'],'id' => $_POST['id']);     

            
                $response['message']="Data Updated";
            $response['status']=1;
            $response['data']=$allArr;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;			
            }
            else{
            $response['message'] = "Data Not Updated";
            $response['status'] = 0;
            
            $json_response = json_encode($response);
            echo $json_response;
            exit;
            
            }
            
          }
		 
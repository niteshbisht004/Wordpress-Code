<style>
.glyphicon-thumbs-up,.glyphicon-thumbs-down{cursor: pointer;}
</style>

<?php 
	include('doc_comment.php');
	include('hos_comment.php');
	include('other_comment.php');
?>
<script> 
	$(document).ready(function(){
	
		$(".cmnt-btn").click(function(){
		
			var val=$(this).attr('id');
			$("."+val).toggle();
		});
		
		$(".cmnt-btn-x").click(function(){
			var val=$(this).attr('id');
			$("."+val).toggle();
		});
	});
						
function report1(cmtid) {
	var answer = confirm("Are your sure, you want to Report this Comment..?");
      if(answer){
		  
		 	var dataString = 'id=' + cmtid;
            $.ajax({
                type: "POST",
                url: "/abusecomment",
                data: dataString,
                success: function(html) {
                    if(html=="success"){
						    location.reload();

				
					} else {
						    location.reload();
					}
                }
            }); 
	  }
	}

function report(cmtid) {
	var answer = confirm("Are your sure, you want to Report this Comment..?");
      if(answer){
		 	var dataString = 'idn=' + cmtid;
            $.ajax({
                type: "POST",
                url: "/abusecomment",
                data: dataString,
                success: function(html) {
                    if(html=="success"){
						    location.reload();
					} else {
						    location.reload();

						
					}
                }
            }); 
		  
	
	  }
	}

function cmnt_delt(delId)
{
	//alert(delId);
	var cmntdel = confirm("Are your sure, you want to Delete this Comment..?");
	if(cmntdel)
	{
	jQuery.ajax({
		url:'/delcomment',
		type:'post',
		data:'dId='+delId,
		success:function(result){
			location.reload();
		}
		
	}); 
	}
}

function rcmnt_delt(delId)
{
	//alert(delId);
	var cmntdel = confirm("Are your sure, you want to Delete reply Comment..?");
	if(cmntdel)
	{
	jQuery.ajax({
		url:'/rdelcomment',
		type:'post',
		data:'dId='+delId,
		success:function(result){
			location.reload();
		}
		
	}); 
	}
}


function setLikeDislike(type,id,uld)
	{
		jQuery.ajax({
			  url:'/setLikeDislike',
			  type:'post',
			  data:'type='+type+'&id='+id+'&uid='+uld,
			  success:function(result)
			{
				//alert(result);
				location.reload();
			}
		});
	}  
	
	
	function reply_like(type,id,uld)
	{
		//alert(type);
		//alert(id);
		
		jQuery.ajax({
			  url:'/reply_like',
			  type:'post',
			  data:'type='+type+'&id='+id+'&uid='+uld,
			  success:function(result)
			{
				//alert(result);
				location.reload();
			}
		});
	} 

function check_login(ckid)
{
	$(".clc"+ckid).toggle();
}

function check_login_x(xckid)
{
	$(".clc-x"+xckid).toggle();
}	
								
</script>





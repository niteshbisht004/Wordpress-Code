<?php
error_reporting(E_ALL);
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
	$val = $_POST['countryid'];
	
	include_once 'classes/states.php';
	
	$items = new States($db);
	
    $stmt = $items->getStates($val);
    
    $itemCount = mysqli_num_rows($stmt);
    
	
	
    if($itemCount > 0){
        $allArr = array();
     while ($row = $stmt->fetch_assoc()){
				$allArr[] = $row;		 
					 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
				
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
    }
?>
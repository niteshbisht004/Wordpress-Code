<?php 

error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 $val = $_POST['cat'];
	 $id = $_POST['id'];
	 $topic_id = $_POST['tid'];
	 $name = $_POST['uname'];
	 $email = $_POST['umail']; 
	 $comment = $_POST['ucmnt'];
	 $insert_date = date("Y-m-d H:i:s");
	 $status = "1"; 
	 
		 
	if($val == 'user'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->blogCmntEditUser($topic_id,$name,$email,$comment,$insert_date,$status,$id);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $id;
		$response['data']=$usr;
		$response['message']="Data Updated";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Updated";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'hospital'){
	 
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->blogCmntEditHospital($topic_id,$name,$email,$comment,$insert_date,$status,$id);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $id;
		$response['data']=$usr;
		$response['message']="Data Updated";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Updated";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }if($val == 'doctor'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->blogCmntEditDoctor($topic_id,$name,$email,$comment,$insert_date,$status,$id);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $id;
		$response['data']=$usr;
		$response['message']="Data Updated";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Updated";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }if($val == 'other'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
    $stmt = $items->blogCmntEditOther($topic_id,$name,$email,$comment,$insert_date,$status,$id);
	
	//$allArr = array();
    if($stmt){
	
	$usr = array(); 
     $usr['id'] =  $id;
		$response['data']=$usr;
		$response['message']="Data Updated";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Updated";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  	
?>
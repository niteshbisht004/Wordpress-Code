<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 
	// $usertype=$_POST['usertype'];
	    $id = $_POST['id'];
	 
		$contact_number = $_POST['contact_number']; 
		$address = $_POST['address'];  
		$purpose = $_POST['purpose']; 
		$appointment_time = $_POST['appointment_time'];
		$appointment_date = $_POST['appointment_date'];
		$arr = explode('/', $appointment_date);
       $newDate = $arr[1].'/'.$arr[0].'/'.$arr[2];
	   
		$newDate = date("Y-m-d", strtotime($newDate));
		
		
		$usertype = $_POST['usertype'];
   
		$gender = $_POST['gender'];
		$email = $_POST['email'];
		$patient_name = $_POST['patient_name'];
		$status = 'Unused';	   
	   $ap1='FMI';
		$ap2=date("dmY");
		
	include_once 'classes/coupan.php';
	$items = new Coupans($db);
	$stmt = $items->getCoupan();
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount == 0 or $itemCount<0)
		{ 
			$apCounter=1;
		} else {
			$apCounter = $itemCount+1;
		}
		
	   $coupan_id=$ap1.$ap2.$apCounter;
	  
	  
	  
	  




if($usertype == 'doctor'){
		include_once 'classes/doctors.php';
		$itemsd = new Doctors($db);
		$stmtd = $itemsd->getSingleDoctors($id);
		$itemCountd = mysqli_num_rows($stmtd);
		if($itemCountd > 0){
			   while ($rowd = $stmtd->fetch_assoc()){
			  
			  $serviename = $rowd['name'];
			   }
			  }	

		include_once 'classes/coupan.php';
	$items = new Coupans($db);
  $stmt = $items->createnewappointment($id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status);	  
				}	

		if($usertype == 'hospital'){
					include_once 'classes/hospitals.php';
			$itemsd = new Hospitals($db);
			$stmtd = $itemsd->getSingleHospitals($id);
			
			$itemCountd = mysqli_num_rows($stmtd);
			if($itemCountd > 0){
				   while ($rowd = $stmtd->fetch_assoc()){
				
				  
				   $serviename = $rowd['name'];
				  
			}	
		}
		
		include_once 'classes/coupan.php';
	$items = new Coupans($db);
  $stmt = $items->createnewappointmenthaspitals($id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status);
		}
	
	if($usertype == 'other'){
		include_once 'classes/others.php';
	$itemsd = new Others($db);
    $stmtd = $itemsd->getSingleOthers($id);
	$itemCountd = mysqli_num_rows($stmtd);
	if($itemCountd > 0){
           while ($rowd = $stmtd->fetch_assoc()){
        
		
		   $serviename = $rowd['name'];
		   }
	      }

include_once 'classes/coupan.php';
	$items = new Coupans($db);
  $stmt = $items->createnewappointmentother($id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status);		  
	}
			
            	
	 
	
	





	
		 
   if($stmt){
	   
	   		$to      = $email;
		//$to1     = $email;
		$subject = 'FMI Coupon Generation Detail';
		$message = '<html>
<head>
<title>GET A QUOTE</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#333337">
<tbody>
<tr>
<td align="center" valign="top"  style="height:100%;margin:0;padding:10px;width:100%;border-top:0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;border:0;max-width:600px!important">
<tbody>
<tr>
<td valign="top"  style="background:#fff none no-repeat center/cover;background-color:#fff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
<td valign="top" style="padding:9px">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                        <tbody>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
	<p><img src="https://www.freemedicalinfo.in/images/free_medical_info.gif"></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p><strong>Exclusive Deal for <a href="https://www.freemedicalinfo.in/">www.FreeMedicalInfo.in</a> users!</strong></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p>Coupon Code: '.$coupan_id.'</p>
							   <p>'.$name.'</p>
							 <br> </td>
                        </tr>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:left">
							
							<p><strong>Dear Mr. / Ms. '.$patient_name.'</strong></p>



<p>Congratulations for availing the Exclusive Discount Coupon on <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> !</p>

<p>Visit the Clinic and redeem it by simply showing your coupon.</p>


<p><strong>Your discount coupon is here:</strong> '.$coupan_id.'</p>



<p>Patients need to show this coupon in advance at the billing counter before treatment.</p>



<p><strong>'.$name.'</strong></p>

<p><strong>Offered by:</strong> '.$serviename.' </p>


<p><strong>Coupon Code:</strong> '.$coupan_id.'</p>

<p><strong>Name:</strong> '.$patient_name.'</p>

<p><strong>Gender:</strong> '.$gender.' </p>

<p><strong>Date of Visit:</strong> '.$newDate.'</p> 

<p><strong>Time of Visit:</strong> '.$appointment_time.'</p>

<p><strong>Treatment:</strong> '.$purpose.'</p>





<p>Discount applicable will be informed at the Billing Counter prior to Conducting the Treatment.</p>


<p>Visit and Register at <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> for generating more Coupons for future requirements.</p>

<p><strong>Best Wishes</strong></p>

<p>Team <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a></p>

<p><a target="_blank" href="https://www.freemedicalinfo.in/term.php">Terms & Conditions</a></p>
							 <br> </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
 <td valign="top" id="m_7045481687344905526m_8011562112826686489templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
 <td valign="top" style="padding-top:9px">
<table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%">
<tbody>
<tr>
<td valign="top" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
<p dir="ltr" style="margin:30px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">




                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td></tr></tbody></table>

					</td>
                </tr>
            </tbody></table></body>
</html>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";


mail($to, $subject, $message, $headers);
	$fields = array(
				"sender_id" => "TXTIND",
				"message" => "You have an appointment on $newDate in $serviename. Please show coupon number $coupan_id on counter before consultation. Best wishes from freemedicalinfo.in.",
				"route" => "v3",
				"numbers" => $contact_number,
			);
			

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_SSL_VERIFYHOST => 0,
			  CURLOPT_SSL_VERIFYPEER => 0,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($fields),
			  CURLOPT_HTTPHEADER => array(
				"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
				"accept: */*",
				"cache-control: no-cache",
				"content-type: application/json"
			  ),
			));

			 curl_exec($curl);
			curl_error($curl);

			curl_close($curl);  
	   
	
	$usr = array(); 
     $usr['id'] =  $items->id;
	  $downloadpdfid= $items->id;
	 $usr['patient_name']  = $patient_name;
	 $usr['offerby']  = $serviename;
	 $usr['email']  = $email;
	 $usr['gender']  = $gender;
	 $usr['appointment_date']= $newDate;
	 $usr['appointment_time']= $appointment_time;
	 
	 $usr['purpose']  = $purpose;
	 $usr['address']= $address;
	 $usr['coupan_id']= $coupan_id;
	 $usr['contact_number']= $contact_number;
	 $usr['status']= $status;
	 $usr['download_pdf']="https://www.freemedicalinfo.in/download_mypdf.php?couponid=$coupan_id";
	 $response['data']=$usr;
		$response['message']="Coupon generated successfully";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Coupon Not generated successfully";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	

	
	
	
	
	
	
	
	
		   
	   
	   
		
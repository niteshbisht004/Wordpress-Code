<?php 
session_start();
include('include/connection.php');
	$_SESSION['city']=$_POST['city'];
	$_SESSION['add']=$_POST['address'];
?>
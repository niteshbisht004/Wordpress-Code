<style>
	.rating {
		font-size: 22px;

	}

	.rating-md {
		font-size: 0px;
	}

	.pagini .dpaginations {
		text-align: right;
		float: right;
		margin-bottom: 20px;
	}
</style>
<link href="/css/simplePagination.css" type="text/css" rel="stylesheet">
<div class="container">
	<div class="col-md-5 all-result-sort-title">
		<h2>ALL doctors available</h2>
		<p>Book appointments with minimum wait-time & verified doctor details</p>


	</div>
	
	<div class="col-md-4" style="padding-top: 45px;">
		<input id="txtSearchPagess" type="search" class="form-control" placeholder="Search" /><br/>
	</div>
	<div class="" id="result"></div>
	<div class="col-md-9 dproduct1 detail-doc-grids" id="results">
		<div class="row">
			<? $j = 1;
			foreach ($res_doctor as $doct) { ?>
				<div  class="item itemd <?if ($j<=12){echo "showfirst"; } ?> col-md-4 col-lg-3 text-left">
					<div class="d-details-per-column">
						<? if ($doct['pro_img'] != "") { ?>
							<img src="/images/profile/<?= $doct['pro_img'] ?>" class="">
						<? } else { ?>
							<img src="/images/doctor-face.jpg">
						<? } ?>
						<div class="col-sm-12 in-details-main-f featured-color">
							<p class="name-d"><a href="/<?= $doct['user_id'] ?>" target="_blank"><?php echo ucfirst($doct['name']) ?></a></p>
							<p class="special-d">
								<? 
								$specialisation = explode(",", $doct['specialisation']);
								$x=0;
								foreach ($specialisation as $spec)
								{
									if($x==0)
									{
										echo $specialisations[$spec];
									}
									else{}
								$x++;
								}
								?>
							</p>
							<div class="rating-container rating-xs rating-animate">
								<div class="average-rating-d">
									<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");


									$r = 0;
									$i = 0;
									foreach ($res_cmt as $rat) {
										$r = $rat['rate'] + $r;
										$i++;
									}
									$r = $r / $i;
									if (is_nan($r)) {
										$r = 0;
									}
									$r = round($r, 1);
									if ($r == 0) {
										$var = '0%';
									}
									if ($r >= 1 && $r <= 1.5) {
										$var = '20%';
									}
									if ($r >= 1.5 && $r <= 2) {
										$var = '30%';
									}
									if ($r >= 2 && $r <= 2.5) {
										$var = '40%';
									}
									if ($r >= 2.5 && $r <= 3) {
										$var = '50%';
									}
									if ($r >= 3 && $r <= 3.5) {
										$var = '60%';
									}
									if ($r >= 3.5 && $r <= 4) {
										$var = '70%';
									}
									if ($r >= 4 && $r <= 4.5) {
										$var = '80%';
									}
									if ($r >= 4.5 && $r <= 5) {
										$var = '90%';
									}
									if ($r == 5) {
										$var = '100%';
									}
									?>
									<? if ($r == 0) {
									} else { ?><span><?php 
									$uid = $doct['id'];
								$sel = "Update doctor_registration SET arate='$r' WHERE id = $uid";
									
									$que_sel = mysqli_query($conn,$sel);
									echo $r; 
									
									
									?></span><? } ?>
								</div>
								<div class="rating">
									<a style="" href="/rating/<?= $doct['user_id'] ?>">
										<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span></span>
										<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
									</a>
								</div>
							</div>
							<p class="special-add"><?php echo $doct['address']; ?></p>
							<?php $apdatecou = fetchAllData(" `deals` ", " where 	doctor_id = '" . $doct['id'] . "'");
								
							echo $apdatecou[0][0];	
								
								?>
						</div>
						
						
					</div>
				
				</div>
			<?
			$j++;
			}
			?>
		</div>
	</div>
	<div class="col-md-12 pagini">
		<div class="dpaginations">
		</div>
		<ul class="pagination">
    
	<li <?php if($page_no <= 1){ echo "class='disabled'"; } ?>>
	<a <?php if($page_no > 1){ echo "href='?page_no=$previous_page'"; } ?>>Previous</a>
	</li>
       
    <?php 
	if ($total_no_of_pages <= 10){  	 
		for ($counter = 1; $counter <= $total_no_of_pages; $counter++){
			if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}
        }
	}
	elseif($total_no_of_pages > 10){
		
	if($page_no <= 4) {			
	 for ($counter = 1; $counter < 8; $counter++){		 
			if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}
        }
		echo "<li><a>...</a></li>";
		echo "<li><a href='?page_no=$second_last'>$second_last</a></li>";
		echo "<li><a href='?page_no=$total_no_of_pages'>$total_no_of_pages</a></li>";
		}
 
	 elseif($page_no > 4 && $page_no < $total_no_of_pages - 4) {		 
		echo "<li><a href='?page_no=1'>1</a></li>";
		echo "<li><a href='?page_no=2'>2</a></li>";
        echo "<li><a>...</a></li>";
        for ($counter = $page_no - $adjacents; $counter <= $page_no + $adjacents; $counter++) {			
           if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}                  
       }
       echo "<li><a>...</a></li>";
	   echo "<li><a href='?page_no=$second_last'>$second_last</a></li>";
	   echo "<li><a href='?page_no=$total_no_of_pages'>$total_no_of_pages</a></li>";      
            }
		
		else {
        echo "<li><a href='?page_no=1'>1</a></li>";
		echo "<li><a href='?page_no=2'>2</a></li>";
        echo "<li><a>...</a></li>";
 
        for ($counter = $total_no_of_pages - 6; $counter <= $total_no_of_pages; $counter++) {
          if ($counter == $page_no) {
		   echo "<li class='active'><a>$counter</a></li>";	
				}else{
           echo "<li><a href='?page_no=$counter'>$counter</a></li>";
				}                   
                }
            }
	}
?>
    
	<li <?php if($page_no >= $total_no_of_pages){ echo "class='disabled'"; } ?>>
	<a <?php if($page_no < $total_no_of_pages) { echo "href='?page_no=$next_page'"; } ?>>Next</a>
	</li>
    <?php if($page_no < $total_no_of_pages){
		echo "<li><a href='?page_no=$total_no_of_pages'>Last &rsaquo;&rsaquo;</a></li>";
		} ?>
</ul>
		
	</div>
</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <script type="text/javascript" src="https://flaviusmatis.github.io/simplePagination.js/jquery.simplePagination.js"></script>

<script>
$(document).ready(function(){
$("#txtSearchPagess").keyup(function() {
	
  var search_item = $(this).val();
  
   $.ajax({
   url:"fetch",
   method:"POST",
   data:{searchss:search_item},
   success:function(data)
   {
    $('#result').html(data);
	
   }
  });
  
  
 });

});
</script>

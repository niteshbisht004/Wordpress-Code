<?php
class Users{

        // Connection
        private $conn;

        // Table
        private $db_table = "users";
     
        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getUsers(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		  public function setUsers($userid,$password){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE `user_id` = '$userid' AND `password` = '$password' AND `active` = 'Yes'";
		
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
            
        }
        
		  public function getbloguserbyid($email){
            $sqlQuery = "SELECT * FROM all_users WHERE `email` = '$email'";
		
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
            
        }
		
		  public function getUsersbyemail($email){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE email = '$email'";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function getUsersPasswordBymail($otp, $email){
            $sqlQuery = "SELECT `email`, `password` FROM users WHERE `email` = '$email' AND `login_code` = $otp";
			
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function getUsersbyphone($phone){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE phone_no = '$phone'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function getUserbyphone($phone){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE phone_no = '$phone'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function updateLoginCodeByphone($rnd, $phone){
            $sqlQuery = "UPDATE users SET `login_code` = '$rnd' WHERE `phone_no` = '$phone'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getUsersPasswordByphone($otp, $phone){
            $sqlQuery = "SELECT `email`, `password` FROM users WHERE `phone_no` = '$phone' AND `login_code` = $otp";
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function getVerifyUsersbyphone($phone)
		{
			$sqlQuery = "select * from users WHERE phone_no = '$phone'";
			$stmt = $this->conn->query($sqlQuery);
		    return $stmt;
		}
		public function updateLoginCodeBymail($rnd, $email){
            $sqlQuery = "UPDATE users SET `login_code` = '$rnd' WHERE `email` = '$email'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getUserActive($userId,$otp)
		{
			
				
				$msql = "select * from users WHERE id = '".$userId."' AND active = '".$otp."'";
				
				$reslt = $this->conn->query($msql);
				$count = mysqli_num_rows($reslt);
				
				if($count > 0)
				{
					$sqlQuery = "UPDATE users SET active = 'Yes' WHERE id = '".$userId."' AND active = '".$otp."'";
					$stmt = $this->conn->query($sqlQuery);
					//echo $sqlQuery;die;
					return $stmt;
				}
			
			
		}
		public function getActiveuser($id)
		{
			
				
				$msql = "select * from users WHERE id = '".$id."' AND active = 'Yes'";
				
				$stmt = $this->conn->query($msql);
				return $stmt;	
		}
		
		public function getSinglesAllUserReward($id){
            $sqlQuery = "SELECT  * FROM all_users WHERE userId = '$id'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
         }
		public function getSinglesAllUser($email){
         $sqlQuery = "SELECT  * FROM all_users WHERE email = '$email'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
         }
        // CREATE
        public function createUsers($foo,$first_name,$phone_no,$password,$email,$active,$insert_date){
			
			
   $sqlQuery = "INSERT INTO ". $this->db_table ." SET user_id = '$foo' ,
            first_name = '$first_name', 
			name = '$first_name',
                        phone_no = '$phone_no', 
                        password = '$password', 
                        email = '$email',
                        active = '$active', 
                        insert_date = '$insert_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt)
			 $this->id = $this->conn->insert_id; 
			$sqlQuerys ="insert into `all_users` set user_id = '".$foo."', user_type = 'user', userId = '".$this->id."', email = '".$email."'";
      		$stmtt = $this->conn->query($sqlQuerys);
			
               return $stmt;
			 
        }

        // READ single
        public function getSingleUsers($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
         }        
         
		   public function getVerifyUsersbyid($id){ 
            $sqlQuery = "SELECT * FROM all_users WHERE user_id = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		   public function getVerifyUsersbyemail($id){
            $sqlQuery = "SELECT * FROM all_users WHERE email = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
        // UPDATE
       
		
		 public function setPassworduser($id,$oldpassword,$newpassword){
            $sqlQuerys = "SELECT * FROM users WHERE password = '$oldpassword' AND id='$id'";
         
            $stmts = $this->conn->query($sqlQuerys);
			$itemCounts = mysqli_num_rows($stmts);
		    if($itemCounts > 0){
			$sqlQuery =	"UPDATE users set password='$newpassword' where id='$id'"; 
		  
				$stmt = $this->conn->query($sqlQuery);
				return $stmt;
			}else{
				
				return false;
				
			}
         }
		
        // DELETE
        public function deleteUsers(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }


	
	
	 public function updateGeneralinformation($first_name,$last_name,$date_birth,$security_ques,$answer,$gender,$qualification,$interested,$update_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET first_name = '$first_name' ,
                        last_name = '$last_name', 
                        qualification = '$qualification', 
                        date_birth = '$dob', 
                        date_birth = '$date_birth',
						security_ques = '$security_ques', 
                        answer = '$answer', 
                        gender = '$gender',
						qualification = '$qualification', 
                        interested = '$interested', 
                        update_date = '$date'
						WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		
		public function updateproimg($fileName,$current_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET pro_img = '$fileName' ,
                        update_date = '$current_date'
						WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updatetimeimg($fileName,$current_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET timeline_img = '$fileName' ,update_date = '$current_date' WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		
		        // UPDATE
        public function updateContactinformation($phone_no,$mobile_no,$address,$country,$state,$city,$district,$zipe_code,$update_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET phone_no = '$phone_no' ,
                        mobile_no = '$mobile_no', 
                        address = '$address',
						country = '$country', 
                        state = '$state', 
                        city = '$city',
						district = '$district', 
                        zipe_code = '$zipe_code', 
                        update_date = '$update_date'
						WHERE id = '$id'";
           
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
      }
?>
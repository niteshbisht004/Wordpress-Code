<?php 
    include("dbconn.php");
    $qry="select * from user";
    $run=mysqli_query($conn,$qry);
    $count=mysqli_num_rows($run);
    if($count>0)
    {
        while($row=mysqli_fetch_assoc($run))
        {
            $arry[]=$row;
        }
        echo json_encode(['status'=>'true', 'data'=>$arry, 'result'=>'found data']);
    }
?>
<?php
class Hospitals{

        // Connection
        private $conn;

        // Table
        private $db_table = "medical_registration";

        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender; 
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getHospitals(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
          public function getHospitalsbylimit($skiprow,$row){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC LIMIT $skiprow,$row";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		public function getHospitalsbyCategorys($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' AND hospital_category = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getHospitalsbyCategory($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' AND specialisation = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		public function getOhersbyCategory($id){
            $sqlQuery = "SELECT * FROM other_service_registration WHERE active='Yes' AND specialisation = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getHospitalsbyCategoryid($id){
            $sqlQuery = "SELECT * FROM hospital_cat WHERE id = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getHospitalsbySpeclisation($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE specialisation = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getSingleHReward($hospital_id){
           $sqlQuery = "SELECT  * FROM hospital_reward WHERE hospital_id = $hospital_id ";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
             } 
		public function getRecommendHospital($specid,$specity){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE specialisation LIKE '%$specid%' OR city = '$specity' order by case when specialisation like '%$specid%' then 0 else 1 end, specialisation LIMIT 0,10";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		  public function getHospitalsbyemail($email){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE email = '$email'";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function getHPasswordBymail($otp, $email){
            $sqlQuery = "SELECT `email`, `password` FROM medical_registration WHERE `email` = '$email' AND `login_code` = $otp";
			
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function getHPasswordByphone($otp, $phone){
            $sqlQuery = "SELECT `email`, `password` FROM medical_registration WHERE `phone_no` = '$phone' AND `login_code` = $otp";
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function getHospitalsbyphone($phone){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE phone_no = '$phone'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		
		public function updateLoginCodeBymail($rnd, $email){
            $sqlQuery = "UPDATE medical_registration SET `login_code` = '$rnd' WHERE `email` = '$email'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function updatehLoginCodeByphone($rnd, $phone){
            $sqlQuery = "UPDATE medical_registration SET `login_code` = '$rnd' WHERE `phone_no` = '$phone'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		  public function getCommentsbyHos($id){
            $sqlQuery = "SELECT * FROM comment_hospital WHERE hos_id = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function setHospitals($userid,$password){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE `user_id` = '$userid' AND `password` = '$password' AND `active` = 'Yes'";
			
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
             
        }
		
		 public function getVerifyHospitalsbyPhone($id){ 
            $sqlQuery = "SELECT * FROM all_users WHERE user_id = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
		  
	     	public function getHospitalActive($userId,$otp)
		{
			
				
				$msql = "select * from medical_registration WHERE id = '".$userId."' AND active = '".$otp."'";
				
				$reslt = $this->conn->query($msql);
				$count = mysqli_num_rows($reslt);
				
				if($count > 0)
				{
					$sqlQuery = "UPDATE medical_registration SET active = 'Yes' WHERE id = '".$userId."' AND active = '".$otp."'";
					$stmt = $this->conn->query($sqlQuery);
					//echo $sqlQuery;die;
					return $stmt;
				}
			
			
		}
	  
	  
	    public function getActiveuser($id)
		{
			
				
				$msql = "select * from medical_registration WHERE id = '".$id."' AND active = 'Yes'";
				
				$stmt = $this->conn->query($msql);
				return $stmt;
			
			
			
		}
		
		
           // CREATE
       public function createHospitals($foo,$first_name,$phone_no,$password,$email,$active,$insert_date){
   $sqlQuery = "INSERT INTO ". $this->db_table ." SET user_id = '$foo' ,
            name = '$first_name', 
                        phone_no = '$phone_no', 
                        password = '$password', 
                        email = '$email',
						active = '$active', 
                        insert_date = '$insert_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
			$sqlQuerys ="insert into `all_users` set user_id = '".$foo."', user_type = 'hospital', userId = '".$this->id."', email = '".$email."'";
      		$stmtt = $this->conn->query($sqlQuerys);
			
               return $stmt;
		} 
        }
        
		public function addcommentbyhos($name,$email,$comment,$hos_id,$status,$insert_date){ 
   $sqlQuery = "INSERT INTO comment_hospital set
		 `name` = '$name', 
		 `email` = '$email', 
		 `comment` = '$comment', 
		 `hos_id` = '$hos_id', 
		 `status` = '$status',		 
		 `insert_date` = '$insert_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 

			
               return $stmt;
		} 
        }
		
		
		public function addrplycommentbyhos($comment_id,$reply_by_id,$reply_by_name,$reply_by_email,$reply_message,$status){ 
   $sqlQuery = "INSERT INTO comment_reply_hospital set 
		`comment_id`='$comment_id', 
		`reply_by_id`='$reply_by_id',
		`reply_by_name`='$reply_by_name',
		`reply_by_email`='$reply_by_email',
		`reply_message`='$reply_message',
		`status`='$status'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 

			
               return $stmt;
		} 
        }
		
		
		
		 public function getVerifyHospitalsbyid($id){ 
            $sqlQuery = "SELECT * FROM all_users WHERE user_id = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
		 
		public function getVerifyHospitalsbyemail($id){
            $sqlQuery = "SELECT * FROM all_users WHERE email = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
        // READ single
        public function getSingleHospitals($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
            
        }        
        
		   public function getAvailableDoctors($id){
            $sqlQuery = "SELECT  * FROM available_doc_info_hospital_reg WHERE H_id = $id";
            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
        	public function addBlogbyhos($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$val,$post_by){ 
   $sqlQuery = "INSERT INTO blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
						image = '$image', 
                        video = '$video', 
                        insert_date = now(),
						userType = '$val',
						post_by = '$post_by'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
		public function updateBlogbyhos($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$val,$post_by,$id){ 
   $sqlQuery = "UPDATE blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
						image = '$image', 
                        video = '$video', 
                        updated_date = now(),
						userType = '$val',
						post_by = '$post_by' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
               return $stmt;
		} 
        }
		
		public function updateBlogbyhoss($title,$specialisation,$meta_name,$meta_discription,$description,$video,$val,$post_by,$id){ 
   $sqlQuery = "UPDATE blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
                        video = '$video', 
                        updated_date = now(),
						userType = '$val',
						post_by = '$post_by' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
               return $stmt;
		} 
        }
		
		
				public function addDealbyhos($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$hospital_id){ 
   $sqlQuery = "INSERT INTO deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description', 
                        image = '$image', 
                        deal_date = '$deal_date',
						hospital_id = '$hospital_id'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
			public function updateDealbyhos($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$hospital_id,$id){ 
   $sqlQuery = "UPDATE deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description', 
                        image = '$image', 
                        deal_date = '$deal_date',
						hospital_id = '$hospital_id' WHERE id = '$id'";
      
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 
		
               return $stmt;
		} 
        }
		
		
		public function updateDealbyhospital($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$deal_date,$hospital_id,$id){ 
   $sqlQuery = "UPDATE deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description', 
                        
                        deal_date = '$deal_date',
						hospital_id = '$hospital_id' WHERE id = '$id'";
      
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 
		
               return $stmt;
		} 
        }
		
		  public function updateGeneralinformationhos($name,$registration_no,$registration_authority,$specialisation,$noOfBeds,$private_room,$hospital_category,$clinical_test,$ambulance,$summary,$metaTitle,$metaDesc,$heyear,$extra_feature,$update_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET name = '$name' ,
                        registration_no = '$registration_no', 
                        registration_authority = '$registration_authority', 
                        specialisation = '$specialisation',
						noOfBeds = '$noOfBeds', 
                        private_room = '$private_room', 
                        hospital_category = '$hospital_category',
						clinical_test = '$clinical_test', 
                        summary = '$summary',
						meta_title = '$metaTitle',
						meta_description = '$metaDesc',
                        heyear = '$heyear',
						extra_feature = '$extra_feature', 
                        update_date = '$update_date'
						WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		
		        // UPDATE
        public function updateContactinformationhos($phone_no,$mobile_no,$address,$country,$state,$city,$O_contact,$O_time_to_call,$O_email,$O_website,$O_message,$update_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET phone_no = '$phone_no' ,
                        mobile_no = '$mobile_no', 
                        address = '$address', 
                        country = '$country', 
                        state = '$state',
						city = '$city', 
                        O_contact = '$O_contact', 
                        O_time_to_call = '$O_time_to_call',
						O_email = '$O_email', 
                        O_website = '$O_website', 
                        O_message = '$O_message',
						 update_date = '$update_date'
						WHERE id = '$id'";
                        
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
        
		public function updatefacilityhos($available_facility,$update_date,$id){
			$afcility =  explode("," , $available_facility);
			
			foreach($afcility as  $val){
				
				$avafacility .= $val."-|-";
				
			}
			$avafacility = rtrim($avafacility, "-|-");

          $sqlQuery = "update ". $this->db_table ." SET available_facility = '$avafacility' ,update_date = '$update_date' WHERE id = '$id'";
       
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updateinfrahos($special_infra,$update_date,$id){
			
			$sinfra =  explode("," , $special_infra);
			
			foreach($sinfra as  $val){
				
				$speinfrafacility .= $val."-|-";
				
			}
			$speinfrafacility = rtrim($speinfrafacility, "-|-");
			
          $sqlQuery = "update ". $this->db_table ." SET special_infra = '$speinfrafacility' ,update_date = '$update_date' WHERE id = '$id'";
           
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updatemachinehos($special_machine,$update_date,$id){
			$smachine =  explode("," , $special_machine);
			
			foreach($smachine as  $val){
				
				$spsmachine .= $val."-|-";
				
			}
			$spsmachine = rtrim($spsmachine, "-|-");
			
          $sqlQuery = "update ". $this->db_table ." SET special_machine = '$spsmachine' ,update_date = '$update_date' WHERE id = '$id'";
           
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function addDocpHos($H_id,$doctor_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST){ 
   $sqlQuery = "INSERT INTO available_doc_info_hospital_reg SET H_id = '$H_id' ,
            doctor_id = '$doctor_id', 
                     sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		
		
		
		public function updateDocpHos($H_id,$doctor_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST,$id){ 
   $sqlQuery = "update available_doc_info_hospital_reg SET H_id = '$H_id' ,
            doctor_id = '$doctor_id', 
                     sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		
		
		
		public function updateOthDocpHos($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$address,$state,$city,$country,$active,$insert_date,$update_date,$H_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST,$id,$docid){ 
		
		$query_doc = "update doctor_registration SET 
		             name = '$name',
				    mobile_no = '$mobile_no',  
				email = '$email',  
				gender = '$gender', 
				qualification = '$qualification',  
				specialisation = '$specialisation',
				registration_no = '$registration_no',
				registration_auth = '$registration_auth',
				expertise_in = '$expertise_in',
				total_experience = '$total_experience',
				address = '$address', 
                country = '$country', 
                state = '$state',
				city = '$city',
				active = '$active',
				insert_date = '$insert_date',
				update_date = '$update_date' WHERE id = '$docid'";
				
		      $stmts = $this->conn->query($query_doc);
		
		if($stmts){
			
		
		
   $sqlQuery = "update available_doc_info_hospital_reg SET H_id = '$H_id' ,
            doctor_id = '$docid', 
			  mobile = '$mobile_no',  
				email = '$email',  
				gender = '$gender', 
				qualification = '$qualification',  
				specialisation = '$specialisation',
				reg_no = '$registration_no',
				reg_auth = '$registration_auth',
				expertise = '$expertise_in',
				total_exp = '$total_experience',
                       sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST'  WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
						
               return $stmt;
		} 
        }
		}
        
		
			public function addOthDocpHos($name,$mobile_no,$email,$gender,$qualification,$specialisation,$registration_no,$registration_auth,$expertise_in,$total_experience,$address,$state,$city,$country,$active,$insert_date,$update_date,$H_id,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST){ 
		
		$query_doc = "INSERT INTO doctor_registration SET 
		             name = '$name',
				    mobile_no = '$mobile_no',  
				email = '$email',  
				gender = '$gender', 
				qualification = '$qualification',  
				specialisation = '$specialisation',
				registration_no = '$registration_no',
				registration_auth = '$registration_auth',
				expertise_in = '$expertise_in',
				total_experience = '$total_experience',
				address = '$address',
				country = '$country',
				state = '$state',
				city = '$city',
				active = '$active',
				insert_date = '$insert_date',
				update_date = '$update_date'";
				
		      $stmts = $this->conn->query($query_doc);
		
		if($stmts){
			 $doc_id = $this->conn->insert_id; 
		
		
   $sqlQuery = "INSERT INTO available_doc_info_hospital_reg SET H_id = '$H_id' ,
            doctor_id = '$doc_id', 
                       sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		}
		
			public function addAdvbyhos($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg){ 
   $sqlQuery = "INSERT INTO left_advt SET advtName = '$advtName' ,
                         web_url = '$web_url', 
                        city = '$city', 
                        pincode = '$pincode', 
                        userid = '$userid',
						usertype = '$usertype', 
                        duration = '$duration', 
                        advtImg = '$advtImg'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
			public function updateAdvbyhos($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg,$id){ 
   $sqlQuery = "UPDATE left_advt SET advtName = '$advtName' ,
                         web_url = '$web_url', 
                        city = '$city', 
                        pincode = '$pincode', 
                        userid = '$userid',
						usertype = '$usertype', 
                        duration = '$duration', 
                        advtImg = '$advtImg' WHERE id = '$id'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
					
               return $stmt;
		} 
        }
		
		
		 public function setPasswordhos($id,$oldpassword,$newpassword){
            $sqlQuerys = "SELECT * FROM medical_registration WHERE password = '$oldpassword' AND id='$id'";
         
            $stmts = $this->conn->query($sqlQuerys);
			$itemCounts = mysqli_num_rows($stmts);
		    if($itemCounts > 0){
			$sqlQuery =	"UPDATE medical_registration set password='$newpassword' where id='$id'"; 
		
				$stmt = $this->conn->query($sqlQuery);
				return $stmt;
			}else{
				
				return false;
				
			}
         }
        // DELETE
     
	  public function getavailabledoc($id){
            $sqlQuery = "SELECT  * FROM
                       available_doc_info_hospital_reg
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
         public function deleteavailabledoc($id){
            $sqlQuery = "DELETE FROM available_doc_info_hospital_reg WHERE id=$id"; 
            $stmt = $this->conn->query($sqlQuery);
             
                return true;
           
        }
	 
	 	 public function updateproimg($fileName,$current_date,$id){
          $sqlQuery = "update medical_registration SET pro_img = '$fileName' ,
                        update_date = '$current_date'
						WHERE id = '$id'";
       
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updatetimeimg($fileName,$current_date,$id){
          $sqlQuery = "update medical_registration SET timeline_img = '$fileName' ,update_date = '$current_date' WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }

    }
    class HospitalsPersonal{ 

        // Connection
        private $conn;

        // Table
        private $db_table = "hospital_private_info";

        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getHospitals(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
        
		public function getHospitalsbyCategory($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE hospital_category = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		  public function getCommentsbyHos($id){
            $sqlQuery = "SELECT * FROM comment_hospital WHERE hos_id = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function setHospitals($userid,$password){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE `user_id` = '$userid' AND `password` = '$password' AND `active` = 'Yes'";
			
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
             
        }
        public function getSingleDoctors($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        } 
        public function updatePersonalinformation($Name,$email,$address,$country ,$state,$city,$phone,$mobile,$website,$zipcode,$id)
        {
            $sqlQuery = "update " . $this->db_table . "  SET 
                          Name = '$Name' ,
                          email= '$email', 
                          address = '$address', 
                          country = '$country', 
                          state = '$state',
                          city = '$city',
                          phone = '$phone ',
                          mobile = '$mobile',
                          website = '$website',
                          zipcode= '$zipcode'
                          WHERE id = '$id'";
              
              $stmt = $this->conn->query($sqlQuery);
              
          if($stmt){
                         return $stmt;
          }
          }
		
		
		 public function getVerifyHospitalsbyid($id){ 
            $sqlQuery = "SELECT * FROM all_users WHERE user_id = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
	
	
		}
?>
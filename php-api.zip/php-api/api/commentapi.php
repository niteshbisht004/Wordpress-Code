<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	//$usertype = $_POST['usertype'];
	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db);

	
   if($val == 'doctor'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getCommentsbyDoc($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'hospital'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getCommentsbyHos($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'other'){
    include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getCommentsbyOth($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	

    
    
	
    
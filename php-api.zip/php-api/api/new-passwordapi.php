<?php 
	header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("HTTP/1.1 200 OK");
	header('Access-Control-Allow-Methods: POST');
	header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
	// get posted data
	$data = file_get_contents("php://input");

	$val = $_POST['cat'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$otp = $_POST['otp'];
	
	
	
	if($val == 'user')
	{
		
		include_once 'classes/users.php';
		$items = new Users($db);
		
		if($email != "")
		{	  
			
			$stmt = $items->getUsersbyemail($email);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				
			 $userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
            
				$email = $row['email'];
				$upassword = $row['password'];
				$phone = $row['phone_no'];
				$otp = $_POST['otp'];
				
				$qry = $items->getUsersPasswordBymail($otp, $email);

				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			   
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Password Reset details for Doctor at freemedicalinfo site.",
					"route" => "v3",
					"numbers" => $phone,
				);
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

			   curl_exec($curl);
				//$err = curl_error($curl);
			
				 $id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Email is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			} 
			
		}
		
		
			
			
		if($phone != "")
		{
			$stmt = $items->getUsersbyphone($phone);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				 $upassword = $row['password'];
				//$password = $row['password'];
				$phone = $row['phone_no'];
				$user_id = $row['user_id'];
				
				$rnd = rand(100000,999999);
				$qry = $items->getUsersPasswordByphone($rnd, $phone);
				
				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			  
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Your Credential at freemedicalinfo site." .$user_id."\r\n". "Password: ". $upassword,
					"route" => "v3",
					"numbers" => $phone,
				);
				
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				$response['message']="Email Sent Successfuly";
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Phone Number is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			}
		}	
	}
	
	
	
	
	if($val == 'doctor')
	{
		
		include_once 'classes/doctors.php';
		$items = new Doctors($db);
		
		if($email != "")
		{	  
			
			$stmt = $items->getDoctorsbyemail($email);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				$upassword = $row['password'];
				$phone = $row['phone_no'];
				$otp = $_POST['otp'];
				
				$qry = $items->getPasswordBymail($otp, $email);

				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			   
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Password Reset details for Doctor at freemedicalinfo site.",
					"route" => "v3",
					"numbers" => $phone,
				);
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Email is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			} 
			
		}
		
		
			
			
		if($phone != "")
		{
			$stmt = $items->getDoctorsbyphone($phone);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				 $upassword = $row['password'];
				//$password = $row['password'];
				$phone = $row['phone_no'];
				$user_id = $row['user_id'];
				
				$rnd = rand(100000,999999);
				$qry = $items->getPasswordByphone($rnd, $phone);
				
				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			  
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Your Credential at freemedicalinfo site." .$user_id."\r\n". "Password: ". $upassword,
					"route" => "v3",
					"numbers" => $phone,
				);
				
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Phone Number is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			}
		}	
	}
	
	
	if($val == 'hospital')
	{
		
		include_once 'classes/hospitals.php';
		$items = new Hospitals($db);
		
		if($email != "")
		{	  
			
			$stmt = $items->getHospitalsbyemail($email);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				$upassword = $row['password'];
				$phone = $row['phone_no'];
				$otp = $_POST['otp'];
				
				$qry = $items->getHPasswordBymail($otp, $email);

				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			   
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Password Reset details for Doctor at freemedicalinfo site.",
					"route" => "v3",
					"numbers" => $phone,
				);
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Email is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			} 
			
		}
		
		
			
			
		if($phone != "")
		{
			$stmt = $items->getHospitalsbyphone($phone);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				 $upassword = $row['password'];
				//$password = $row['password'];
				$phone = $row['phone_no'];
				$user_id = $row['user_id'];
				
				$rnd = rand(100000,999999);
				$qry = $items->getHPasswordByphone($rnd, $phone);
				
				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			  
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Your Credential at freemedicalinfo site." .$user_id."\r\n". "Password: ". $upassword,
					"route" => "v3",
					"numbers" => $phone,
				);
				
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Phone Number is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			}
		}	
	}
	
	
	
	if($val == 'other')
	{
		
		include_once 'classes/others.php';
		$items = new Others($db);
		
		if($email != "")
		{	  
			
			$stmt = $items->getOthersbyemail($email);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				$upassword = $row['password'];
				$phone = $row['phone_no'];
				$otp = $_POST['otp'];
				
				$qry = $items->getOPasswordBymail($otp, $email);

				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			   
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Password Reset details for Doctor at freemedicalinfo site.",
					"route" => "v3",
					"numbers" => $phone,
				);
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				 curl_exec($curl);
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Email is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			} 
			
		}
		
		
			
			
		if($phone != "")
		{
			$stmt = $items->getOtherbyphone($phone);
			$itemCount = mysqli_num_rows($stmt);
			if($itemCount > 0)
			{
				$userArr = array();
			
			$row = $stmt->fetch_array();
		     $userArr = $row;
			
				$email = $row['email'];
				 $upassword = $row['password'];
				//$password = $row['password'];
				$phone = $row['phone_no'];
				$user_id = $row['user_id'];
				
				$rnd = rand(100000,999999);
				$qry = $items->getOPasswordByphone($rnd, $phone);
				
				$to = $email;
				$subject = "Forget Password Details";
				$body = "Email: ".$email."\r\n"."Password: ".$upassword;
				$additionalheaders = "From: FMI <contact@freemedicalinfo.in>\r\n";
				$additionalheaders .= "Reply-To: contact@freemedicalinfo.in";
				mail($to, $subject, $body, $additionalheaders);
			  
				$fields = array(
					"sender_id" => "TXTIND",
					"message" => "Your Credential at freemedicalinfo site." .$user_id."\r\n". "Password: ". $upassword,
					"route" => "v3",
					"numbers" => $phone,
				);
				
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_SSL_VERIFYHOST => 0,
				  CURLOPT_SSL_VERIFYPEER => 0,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => json_encode($fields),
				  CURLOPT_HTTPHEADER => array(
					"authorization: Lxe7BXV3AQP4EvR6ifdgmjwSNsZ0Jp9Ka1bDFtIkzG2WUCYylr3zEglyHacxfKjR0UCFIB7GV8MXbv1Y",
					"accept: */*",
					"cache-control: no-cache",
					"content-type: application/json"
				  ),
				));

				curl_exec($curl);
				
				$id=$userArr[0];
			 $email=$userArr[13];
			 $phone=$userArr[14];
			 
			 $usr =  array('cat'=>$val,'Id' => $id,'Phone' => $phone, 'Email' =>$email);
			
				$response['message']="Email Sent Successfuly";
				$response['status']=1;
				$response['data']= $usr;
				
				$json_response = json_encode($response);
				echo $json_response;
					exit;
			}
			else
			{
				$response['message'] = "Phone Number is not valid";
				$response['status'] = 0;
				
				$json_response = json_encode($response);
				echo $json_response;
				exit;
			}
		}	
	}
	
	
	
?>
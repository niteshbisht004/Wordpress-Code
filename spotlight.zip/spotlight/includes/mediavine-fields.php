
<?php

defined( 'ABSPATH' ) || exit;

if( !function_exists('bcm_myplugins_mediavine') ){
function bcm_myplugins_mediavine()			
	{
	?>	

<!-- Mediavine Fields	-->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"  class="mediavine-forms">	
 <?php 
 
  settings_fields( 'mediavine_smart_fields' );
  do_settings_sections( 'bcm_myplugins_mediavine_fields' ); 
 
 ?> 
<input type="submit" name="submit_form" class="button button-primary smart-woo-button" value="<?php esc_attr_e( ' SUBMIT ' ); ?>" />

</form>


<?php 
}
}	


function mediavine_tracking_settings() {
	register_setting( 'mediavine_smart_fields', 'mediavine_smart_fields', '' );

    add_settings_section( 'smart_tracking_settingss', '', 'swp_myplugins_smart_tracking_texts3', 'bcm_myplugins_mediavine_fields' );

    add_settings_field( 'smart_head_tracking_settings3', '', 'smart_head_tracking_settings3', 'bcm_myplugins_mediavine_fields', 'smart_tracking_settingss' );
   
}
add_action( 'admin_init', 'mediavine_tracking_settings' );

function swp_myplugins_smart_tracking_texts3() {
    echo '<h2 class="mediavine_mainheading">Spotlight Fields Settings</h2>';
}

function smart_head_tracking_settings3() {
    $option4 = get_option( 'mediavine_smart_fields' );
	?>
	Trigger Class: <input type="text" id="headeditor" name='mediavine_smart_fields[trigger]' value="<?php echo "spotlight";?>" disabled><br>
	
	Color:<input type="text" id="headeditor" name='mediavine_smart_fields[color]' value="<?php echo $option4['color'];?>">
	<input type="color" id="headeditor" name='mediavine_smart_fields[color]' value="<?php echo $option4['color'];?>">
	
	<br>
	
	Opacity: <input type="text" id="headeditor" name='mediavine_smart_fields[opacity]' value="<?php echo $option4['opacity'];?>"><br>
	
	Active Times In Seconds: <input type="text" id="headeditor" name='mediavine_smart_fields[atime]' value="<?php echo $option4['atime'];?>"><br>
		
<?php
}






?>

<style>
	

.form-table td {
    display: grid !important;
    width: 35% !important;
}
#wpbody-content > form > table > tbody > tr > th {
    display: none !important;
}
input.button.button-primary.smart-woo-button {
   margin: -15px 0px 0px 10px !important;
}
.wp-core-ui .button, .wp-core-ui .button-primary, .wp-core-ui .button-secondary {
    min-height: 35px !important;
    width: 90px !important;
}
#headeditor {
    margin-top: 5px;
}
#wpbody-content > form > h2 {
    font-size: 23px;
    font-weight: 500;
    margin-left: 10px;
}
</style>
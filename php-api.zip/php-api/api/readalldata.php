<?php
error_reporting(0);

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

include_once 'classes/city.php';
$cityitems = new Cities($db);

include_once 'classes/states.php';
$stateitems = new States($db);

include_once 'classes/rating.php';
$rateitems = new Ratings($db);

include_once 'classes/country.php';
$countryitems = new Countries($db);

include_once 'classes/special.php';
$specialitems = new Special($db);


include_once 'classes/qual.php';
$qualitems = new Qual($db);

$data = json_decode(file_get_contents("php://input"));

$val = $_POST['cat'];
$term = $_POST['term'];
$spec = $_POST['specialisation'];
$specid = $_POST['specialization'];
$srow = $_POST['skiprow'];
$rows = $_POST['row'];
$ctyid =$_POST['city'];


	$statename = $_POST['statename'];
	$statestmtn = $stateitems->getStatesbyname($statename);
	$snamesn =  mysqli_fetch_row($statestmtn);
	$stateid = $snamesn[0];
	
	$cityname = $_POST['cityname'];
	$citynamen = $cityitems->getCitiesbyname($cityname);
	$citynamensn =  mysqli_fetch_row($citynamen);
	$cityid = $citynamensn[0];



if ($val == 'slider') {
	include_once 'classes/slider.php';
	$items = new Slider($db);
	$stmt = $items->getSlider();
	$userArr = array();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {


		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/home-slider/' . $row['image1'];

			$allArr['slider'][] = array_merge($row, $cityArr);
		}
		
		
	include_once 'classes/advertisments.php';
		
	$itemsa = new Advertisments($db);
		
    $stmta = $itemsa->getAdvts();	
	
	$itemCounta = mysqli_num_rows($stmta);

	if ($itemCounta > 0) {

		$userArra = array();
		$cityArra = array();
	

		while ($rowa = $stmta->fetch_assoc()) {
			$userArra[] = $rowa;
	$cityArra['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/Advertisement/' . $rowa['advtImg'];
		
     $allArr['ads'][] = array_merge($rowa, $cityArra);
		}
		
	}		
	
	
	include_once 'classes/doctors.php';
	$itemsd = new Doctors($db);
	$stmtsd = $itemsd->getRecDoctors($cityid,$stateid);
	$itemCountsd = mysqli_num_rows($stmtsd);
    if($itemCountsd == 0){
	$stmtsd = $itemsd->getRecDoctorsbystate($stateid);
	$itemCountsd = mysqli_num_rows($stmtsd);	
	$itemCountsds = mysqli_num_rows($stmtsd);	
	}
    if($itemCountsds == 0){
	$stmtsd = $itemsd->getRecDoctorsbycountry();
	$itemCountsd = mysqli_num_rows($stmtsd);	
		
	}
	if ($itemCountsd > 0) {

		$userArrd = array();
		$cityArrd = array();
		

		while ($rowd = $stmtsd->fetch_assoc()) {
			$userArrd[] = $rowd;

			$citystmt = $cityitems->getSingleCity($rowd['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArrd['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($rowd['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArrd['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($rowd['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArrd['countryname'] = $sname[0];

				 $valq =  explode("|",$rowd['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArrd['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($rowd['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArrd['qualificationname'] = $qualname[0];
				}



          $val =  explode("|",$rowd['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrd['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowd['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrd['specialisationname'] = $specialname[0];
				}


		

			if ($rowd['pro_img'] == '') {

				$cityArrd['profileimg'] = 'https://www.freemedicalinfo.in/images/doctor-face.jpg';
			} else {
				$cityArrd['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $rowd['pro_img'];
			}

			if ($rowd['timeline_img'] == '') {

				$cityArrd['bannerimg'] = 'https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArrd['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $rowd['timeline_img'];
			}
			$cityArrd['usertype'] = 'doctor';

			$statestmts = $rateitems->getRatingsbyuserid($rowd['id'],'doctor');
		     $cityArrd['rating'] = 0;
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArrd['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArrd['rating'] = $r;
				
			}else{
			$cityArrd['is_rating'] = '0';	
				
			}
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($rowd['id'], 'doctor');
			$cityArrd['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($rowd['id']);
			$cityArrd['deal_count']  = mysqli_num_rows($stmtd);
            
            
           $itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($rowd['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       $cityArrd['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArrd['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		$cityArrd['pastexperience'] = array();
		
	}
	
	
	
	
$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($rowd['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
        $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArrd['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		$cityArrd['currentexperience'] = array();
	}
			
			
			
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($rowd['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
          $cityArrd['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArrd['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		 $cityArrd['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($rowd['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
         $cityArrd['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
			$dealimgs =  explode("|",$rowde['image']);
			
				if(count($dealimgs) > 1){
				   
				  $dealimg =  $dealimgs[0];
				}else{
				    
				   $dealimg =  $rowde['image'];  
				}	
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$dealimg;
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$dealimg; 
				
				
			$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
		    include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowds = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowds[3];
			 
			  $cityArrd['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArrd['deals'] = array();
		
	}
	
	
		    include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($rowd['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
            $cityArrd['allreview'] = array();
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArrd['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArrd['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArrd['allreview'] = array();
		
	}









			$allArr['doctors'][] = array_merge($rowd, $cityArrd);
			
			
			
			
		}
	}
	
		
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;
		$response['content'] = '<h4 class="heading">Free Medical Info</h4>
                        <p>We provides a platform to the Patients, Doctors, Clinics, Hospitals, Pharma Companies and other organizations related to medical sector, who want to share the information online. The website allows the patients/ visitors to also search the information about:</p><ul class="list-unstyled about-medical">
                            <li>Doctor for a particular disease/ Specialisation (Filtered on the basis of Place, 
							Qualification, Experience Methods like Homeopathy, Ayurved, Unani, Vaidya etc.and star ratings)</li>
                            <li>Clinics / Hospitals with specific facility to treat a particular disease</li>
                            <li>Finding the pathology labs for a particular medical test (X Ray, CT Scan, MRI Scan etc, Blood Test),
							Filtered on the basis of Place, Qualification, Experience, cost and star ratings</li>
                            <li>Blood Bank/ Eye Banks in the region</li>
                            <li>Fitness Centre / PhysioTherapist/ Yoga Classes, Acupuncture etc. special treatment methods</li>
                        </ul>';
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}





if ($val == 'partner') {
	include_once 'classes/partner.php';
	$items = new Partner($db);
	$stmt = $items->getPartner();
	$userArr = array();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {


		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

			$allArr[] = array_merge($row, $cityArr);
		}
	
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;
		
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}





if ($val == 'privacy') {

	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(11);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}



/***************homeopathy*********/



if ($val == 'homeopathy') {
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory(12);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			

	
				 $valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];
				}
	
	
			
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
			 $cityArr['rating'] = 0;
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			
             $itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);
 


    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);
$itemCountpcur = mysqli_num_rows($userexpa); 
	if($itemCountpcur > 0){
		 while ($rowspa = $userexpa->fetch_assoc()){   
		 
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		}}else{
			
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowpa['hospital_c_name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowpa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowpa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowpa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];	
			
		}
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		$cityArr['pastexperience'] = array();
		
	}
	

	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
			

   include_once 'classes/blog.php';
	$itemsbo = new Blogs($db);
	
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);
	

    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
$cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		    $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
            $val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			$cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/doctors.php';
			$itemst = new Doctors($db);
			$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
			$rowd = mysqli_fetch_row($stmtt);	
			$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		 $cityArr['deals'] = array();
	}
			 
			 
			 
		
          include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
         $cityArr['allreview'] = array();
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		
		$cityArr['allreview'] = array();
	}


		
			 
			
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['totalcount'] =  $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'ayurevdic') {
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory(70);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			 $valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];
				}

			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
			
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			 $cityArr['rating'] = 0;
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}				
			$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		$itemCountpcur = mysqli_num_rows($userexpa); 
	if($itemCountpcur > 0){
		 while ($rowspa = $userexpa->fetch_assoc()){   
		 
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		}}else{
			
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowpa['hospital_c_name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowpa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowpa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowpa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];	
			
		}
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		
		$cityArr['pastexperience'] = array();
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
			
			
	include_once 'classes/blog.php';		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
         $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
			$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		         include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($row['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}

		     include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
           $cityArr['allreview'] = array();
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
	}


			

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['totalcount'] =  $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'testpathlab') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategory(61);
    $stmto = $items->getOhersbyCategory(61);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

	


			
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
			 $cityArr['rating'] = 0;
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			
			$itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			 
			 	$val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}


                
                

            include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}	
				
			include_once 'classes/hospitals.php';
			$itemst = new Hospitals($db);
			$stmtt = $itemst->getSingleHospitals($rowde['hospital_id']);
			$rowd = mysqli_fetch_row($stmtt);	
			$cityArrde['offerby'] = $rowd[4];
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}
			
			
			$allArr[] = array_merge($row, $cityArr);
		}


        while ($row = $stmto->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];



			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';
			
				include_once 'classes/others.php';
			$itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}






          include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
          $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
			$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 	 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
				
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}
			
		
            include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
            
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		
		$cityArr['allreview'] = array();
	}

		
			
			$allArr[] = array_merge($row, $cityArr);
		}



		$response['message'] = "Data Found";
		$response['totalcount'] =  $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'fitnesscenter') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategory(111);
    $stmto = $items->getOhersbyCategory(111);
	$itemCount = mysqli_num_rows($stmto);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

	

		$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'hospital';
			
			$statestmts = $rateitems->getRatingsbyuserid($rowd['id'], 'hospital');
			 $cityArr['rating'] = 0;
		$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			
			$itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
	
			 
			 $val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
			 
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}






           include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
         $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}							
		 
		        include_once 'classes/hospitals.php';
				$itemst = new Hospitals($db);
				$stmtt = $itemst->getSingleHospitals($rowde['hospital_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[4];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
		
	}
			
			
			
			
			
			
			$allArr[] = array_merge($row, $cityArr);
		}
		
		
		while ($row = $stmto->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

		$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'other';
			
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			
				include_once 'classes/others.php';
			$itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
		$val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}






            include_once 'classes/blog.php';
			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
		
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}							
		 
			  include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
			 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}
			
			
		   include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		
		$cityArr['allreview'] = array();
	}
			
			
			$allArr[] = array_merge($row, $cityArr);
		}
		
		
		$response['message'] = "Data Found";
		$response['totalcount'] =  $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'bloodbank') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbyCategorys(14);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];



			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}

			$cityArr['usertype'] = 'hospital';
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['totalcount'] =  $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'aboutus') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(6);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();
		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;
			$str = $row['description'];
			
			$new_str = str_replace('<img src="/', '<img src="https://www.freemedicalinfo.in/', $str);

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			
		
			$cityArr['description_with_full_image_url'] = $new_str; 
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'certification') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(7);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'certification') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(7);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'advertise') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(8);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'terms') {
	include_once 'classes/page.php';
	$items = new Page($db);
	$stmt = $items->getpages(10);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {

			$userArr[] = $row;

			$cityArr['imgfullurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['header_img'];
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'user') {
	include_once 'classes/users.php';
	$items = new Users($db);
	$stmt = $items->getUsers();

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'user';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['blog_count'] = 0;
		$response['deal_count'] = 0;

		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}



if ($val == 'doctor' && $spec != '') {

	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getDoctorsbyCategory($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'hospitals' && $spec != '') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getHospitalsbySpeclisation($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'others' && $spec != '') {
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getOthersbySpeclisation($id);

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'doctor') {
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmts = $items->getDoctors();
	$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getDoctorsbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			


			 $valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];
				}
				
			
			
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			 $cityArr['rating'] = 0;
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
            
	$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);


    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
          $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		
		$cityArr['pastexperience'] = array();
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
        $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
			
			
			
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
   $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		$cityArr['blogs'] = array();
		
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
     $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			    include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}

    

        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
            $cityArr['allreview'] = array(); 
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		 
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
        
        if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
		              
    
                
            }
	}else{
		
		$cityArr['allreview']= array();
		
	}




			$allArr[] = array_merge($row, $cityArr);
			
			
			
			
		}

		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'recommenddoctor'){
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
      if($specid == '')
	  {
	  $specid = $_POST['specialisationid'];
	  }
	$stmt = $items->getRecommendDoctors($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();
       $k = 1;
		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

          
		//$cityArr['specialisationname'] = $row['specialisation'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
       
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			 $cityArr['rating'] = 0;
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
		
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
            
	$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		
		$cityArr['pastexperience'] = array();
	}

	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
         $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
         $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		 $cityArr['deals'] = array();
	}
  
  	     
          include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
		
	}
   
	

			$allArr[] = array_merge($row, $cityArr);
		
		$k++;
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}





if ($val == 'recommendhospital') {
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getRecommendHospital($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

	

		


            	$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
				
				
			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
		     $cityArr['rating'] = 0;
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
 $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}
	 
	 
	 
	 
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
         $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
				
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		
		$cityArr['deals'] = array();
	}
      
	     include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'hospital');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
	
	
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}






if ($val == 'recommendother') {
	
	include_once 'classes/others.php';
	$items = new Others($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getRecommendOther($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];



			
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';
             $cityArr['rating'] = 0;
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
  
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}
  
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
			
			    include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}
   
   
        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
			$cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
	
	
	
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}






if ($val == 'hospital') {
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmts = $items->getHospitals();
	$stmt = $items->getHospitalsbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

	


			
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';
             $cityArr['rating'] = 0;
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyhospitalid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);

    $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		  $cityArrad['name'] = $rowsado['name'];
		 $cityArrad['gender'] = $rowsado['gender'];
		 $cityArrad['reg_no'] = $rowsado['registration_no'];
		 $cityArrad['reg_auth'] = $rowsado['registration_auth'];
		  $cityArrad['email'] = $rowsado['email'];
		 $cityArrad['mobile'] = $rowsado['mobile_no'];
		 $cityArrad['expertise'] = $rowsado['expertise_in'];
		 $cityArrad['total_exp'] = $rowsado['total_experience'];
		 
		 
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
         $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/hospitals.php';
				$itemst = new Hospitals($db);
				$stmtt = $itemst->getSingleHospitals($rowde['hospital_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[4];
			 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		 $cityArr['deals'] = array();
	}

    
	
	        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'hospital');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
			  
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
   if ($itemCountco > 0) { 
        $cityArr['allreview'] = array();
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
            /* 
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		} 
		    
		   
		   
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
	
	
	
	

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}
if ($val == 'other') {
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmts = $items->getOthers();
	$stmt = $items->getOthersbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];



			
			
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				$cityspecial = $special;
				if(is_string($cityspecial) == 61){
				 $cityArr['usertype'] = 'pathology';
				 
				}
				elseif(is_string($cityspecial) == 160){
				 $cityArr['usertype'] = 'medicalstore';
				 
				}
				elseif(is_string($cityspecial) == 162){

				$cityArr['usertype'] = 'medicalequipment';	
				}
				elseif(is_string($cityspecial) == 163){
					
				$cityArr['usertype'] = 'ambulance';	
				}
				else{
				$cityArr['usertype'] = 'other';	
				}
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
			 $specialn = $row['specialisation'];
			  if($specialn == 61){
				$cityArr['usertype'] = 'pathology';	
				}
			 elseif($specialn == 160){
				
				$cityArr['usertype'] = 'medicalstore';	
				}
				elseif($specialn == 162){
				$cityArr['usertype'] = 'medicalequipment';	
				}
				elseif($specialn == 163){
				$cityArr['usertype'] = 'ambulance';	
				}else{
				$cityArr['usertype'] = 'other';	
				}
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
		
             $cityArr['rating'] = 0;
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}

			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        $cityArr['availabledoctors'] = array();
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
         $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		 $cityArr['deals'] = array();
	}

			
		        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
   if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
            /* 
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc,$cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
		              
    
                $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
			
			
			

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}




if ($val == 'medicalstore'){
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getOthersbySpeclisation(160);
	//$stmt = $items->getOthersbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

	

			
			
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			 $cityArr['rating'] = 0;
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}

			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}

			
		        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
   if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
			$cityArr['allreview'] = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
            /* 
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc,$cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
		              
    
                $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
            }
	}else{
		
		$cityArr['allreview'] = array();
	}	
			
			
			

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}





if ($val == 'medicalequipment'){
	include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getOthersbySpeclisation(162);
	//$stmt = $items->getOthersbylimit($srow, $rows);
	$itemCount = mysqli_num_rows($stmt);
	$itemCounts = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];



			
			
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';
              $cityArr['rating'] = 0;
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = '1';
			$r = 0;
			$a = 0;
			 while($rating = $statestmts->fetch_assoc()){
			
		     
			   
			   $r = $rating['rate'] + $r;
				$a++;
			 }
			$r = $r / $a;
		
			$cityArr['rating'] = $r;
				
			}else{
			$cityArr['is_rating'] = '0';	
				
			}
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 
						 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		$cityArr['blogs'] = array();
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}

			
		        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
   if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
			$cityArr['allreview'] = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
            /* 
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc,$cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
		              
    
                $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
			

			$allArr[] = array_merge($row, $cityArr);
		}
		$response['totalcount'] =  $itemCounts;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}












if ($val == 'deal'){
	
	include_once 'classes/deals.php';
	$items = new Deals($db);
	if($spec == ''){
	
	$stmt = $items->getdeals();
	
	}else{
	
    $stmt = $items->getDealsbyCategory($spec,$term);	
		
	}
	
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
			
			$dealimgs =  explode("|",$row['image']);
			
				if(count($dealimgs) > 1){
				   
				  $dealimg =  $dealimgs[0];
				}else{
				    
				   $dealimg =  $row['image'];  
				}
				
				
			$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' .  $dealimg;
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];
			
			
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0]." ";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
			
			

			if ($row['doctor_id'] != '') {

				include_once 'classes/doctors.php';
				$itemsd = new Doctors($db);
				$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
				$rowd = $stmtd->fetch_assoc();

				$cityArr['offerby'] = $rowd['name'];
			}
			if ($row['hospital_id'] != '') {

				include_once 'classes/hospitals.php';
				$itemsh = new Hospitals($db);
				$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
				$rowh = $stmth->fetch_assoc();

				$cityArr['offerby'] = $rowh['name'];
			}
			if ($row['other_id'] != '') {

				include_once 'classes/others.php';
				$itemso = new Others($db);
				$stmto = $itemso->getSingleOthers($row['other_id']);
				$rowo = $stmto->fetch_assoc();

				$cityArr['offerby'] = $rowo['name'];
			}

			include_once 'classes/coupan.php';
			$itemsc = new Coupans($db);
			$stmtc = $itemsc->getCoupanbydeal($rowo['id']);
			$itemCountc = mysqli_num_rows($stmtc);
			$cityArr['total_coupons'] = "$itemCountc";
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;


		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		
		$stmt = $items->getAllDealsbyCategory($spec,$term);
		
		$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$stmt = $items->getAllDealsbyCategory($spec,$term);
	}
	else
	{
		$stmt = $items->getdeals();
	}
	$itemCount = mysqli_num_rows($stmt);
	
	
		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
			
			$dealimgs =  explode("|",$row['image']);
			
				if(count($dealimgs) > 1){
				   
				  $dealimg =  $dealimgs[0];
				}else{
				    
				   $dealimg =  $row['image'];  
				}
				
				
			$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' .  $dealimg;
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];
			
			
					$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0]." ";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
			
			

			if ($row['doctor_id'] != '') {

				include_once 'classes/doctors.php';
				$itemsd = new Doctors($db);
				$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
				$rowd = $stmtd->fetch_assoc();

				$cityArr['offerby'] = $rowd['name'];
			}
			if ($row['hospital_id'] != '') {

				include_once 'classes/hospitals.php';
				$itemsh = new Hospitals($db);
				$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
				$rowh = $stmth->fetch_assoc();

				$cityArr['offerby'] = $rowh['name'];
			}
			if ($row['other_id'] != '') {

				include_once 'classes/others.php';
				$itemso = new Others($db);
				$stmto = $itemso->getSingleOthers($row['other_id']);
				$rowo = $stmto->fetch_assoc();

				$cityArr['offerby'] = $rowo['name'];
			}

			include_once 'classes/coupan.php';
			$itemsc = new Coupans($db);
			$stmtc = $itemsc->getCoupanbydeal($rowo['id']);
			$itemCountc = mysqli_num_rows($stmtc);
			$cityArr['total_coupons'] = "$itemCountc";
			$allArr[] = array_merge($row, $cityArr);
		}

		
		  $specialstmts = $specialitems->getSingleSpecial($spec);
			$specialnames =  mysqli_fetch_row($specialstmts);
		   $terms = $specialnames[0];
		if($spec == ""){
		$response['message'] = "$term not found, please have a look on suggestive deals";
		}
		else if($term != "" && $spec != ""){
		$response['message'] = "$term  and $terms not found, please have a look on suggestive deals";	
		}
		else{
	   $response['message'] = "$terms not found, please have a look on suggestive deals";	
		}
		
		$response['count'] = $itemCount;
		$response['status'] = 2;
		$response['data'] = $allArr;


		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if($val == 'blog') {
	include_once 'classes/blog.php';
	$items = new Blogs($db);
	$stmt = $items->getBlogs();
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
			$cityArr['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
			$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];
			$video = explode("/",$row['embed_video']);
		
			 $cityArr['video_id'] = $video[4];

			$allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {

        $response['message'] = "No Record Found";
		$response['status'] = 0;
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if ($val == 'ads'){

	include_once 'classes/advertisments.php';
		
	$items = new Advertisments($db);
		
    $stmt = $items->getAdvts();	
	
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
	$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/Advertisement/' . $row['advtImg'];
		
     $allArr[] = array_merge($row, $cityArr);
		}

		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;


		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}


if($val == 'rating') {
    
	include_once 'classes/rating.php';
	$items = new Ratings($db);
	$stmt = $items->getRatings();
	$itemCount = mysqli_num_rows($stmt);
    $stmts = $items->getRatingsbylimit($srow, $rows);
	$itemCounts = mysqli_num_rows($stmts);

	if ($itemCounts > 0) { 

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmts->fetch_assoc()) {
			
		   $userArr[] = $row;
		
           $uid=$row['user_id'];
           $utype=$row['rateusertype'];
           
           if($utype == 'doctor')
           {
				include_once 'classes/doctors.php';
				$itemd = new Doctors($db);
				$stmtd = $itemd->getSingleDoctors($uid);
		   }

           if($utype == 'hospital')
           {
			
				include_once 'classes/hospitals.php';
				$itemd = new Hospitals($db);
				$stmtd = $itemd->getSingleHospitals($uid);   
		
		   }

          if($utype == 'other')
          {
				include_once 'classes/others.php';
				$itemd = new Others($db);
				$stmtd = $itemd->getSingleOthers($uid);   
               
          }
           
		while ($rowd = $stmtd->fetch_assoc())
		{
				if($rowd['pro_img'] == ''){
					
					$cityArr['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
				}else{
					$cityArr['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
					
				}
				$cityArr['name']=$rowd['name'];
		}
   
   
       $rid=$row['rating_by_userid'];
       $rtype=$row['user_type'];

       if($rtype=='user')
       {
         	include_once 'classes/users.php';
			$itemu = new Users($db);
			$stmtu = $itemu->getSingleUsers($rid); 

			while ($rowu = $stmtu->fetch_assoc())

				{
					$cityArr['username']=$rowu['first_name'];
				}
		}

       if($rtype=='doctor')
       {
			include_once 'classes/doctors.php';
			$itemu = new Doctors($db);
			$stmtu = $itemu->getSingleDoctors($rid);

            while ($rowu = $stmtu->fetch_assoc())

				{
					$cityArr['username']=$rowu['name'];
				}
       }

       if($rtype=='hospital')
       {
            include_once 'classes/hospitals.php';
			$itemu = new Hospitals($db);
			$stmtu = $itemu->getSingleHospitals($rid);

			while ($rowu = $stmtu->fetch_assoc())

			{
				$cityArr['username']=$rowu['name'];
			}
       }
       
       if($rtype=='other')
       {
			include_once 'classes/others.php';
			$itemu = new Others($db);
			$stmtu = $itemu->getSingleOthers($rid);

			while ($rowu = $stmtu->fetch_assoc())
			{
				$cityArr['username']=$rowu['name'];
			}
       }

       $cityArr['rate'] = $row['rate'];
        

			$allArr[] = array_merge($row, $cityArr);
		}
        $response['totalcount'] =  $itemCount;
		$response['skiprow'] =  $srow;
		$response['row'] =  $rows;
		$response['message'] = "Data Found";
		$response['count'] = $itemCount;
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {

        $response['message'] = "No Record Found";
		$response['status'] = 0;
		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

if ($val == 'city') {
	include_once 'classes/city.php';
	$items = new Cities($db);
	$stmt = $items->getAllCities();

	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;
		}

		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $userArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}

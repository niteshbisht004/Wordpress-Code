<? include("include/header.php"); ?>
    <!-- Page Content -->
<?
	$x = explode('-',$_GET['x']);
	$id = $x[0];
	$active_type = $x[1];
	$active = $_GET['y'];
	$msg = "";
	if($active_type=="user"){
		if(is_numeric($id) && !empty($active)){
			$count = countRow(" `users` ", " WHERE id = '".$id."' AND active = '".$active."'");
			if($count>0){
				$update = "UPDATE users SET active = 'Yes' WHERE id = '".$id."' AND active = '".$active."'";
				mysqli_query($conn,$update) or die(mysqli_error());
				$msg = "Your account has been successfully activated <a class='ajax cboxElement' href='/login.php'>Click To Login</a>";
			} else {
				$msg1 = "Invalid Activation Link !";
			}
			
		}
	} else if($active_type=="doctor"){
		if(is_numeric($id) && !empty($active)){
			$count = countRow(" `doctor_registration` ", " WHERE id = '".$id."' AND active = '".$active."'");
			if($count>0){
				$update = "UPDATE doctor_registration SET active = 'Yes' WHERE id = '".$id."' AND active = '".$active."'";
				mysqli_query($conn,$update) or die(mysqli_error());
				$msg = "Your account has been successfully activated <a class='ajax' href='/login.php'>Click To Login</a>";
			} else {
				$msg1 = "Invalid Activation Link !";
			}
		}
		else{
			echo"False condition";
		}
	} else if($active_type=="hospital"){
		if(is_numeric($id) && !empty($active)){
			$count = countRow(" `medical_registration` ", " WHERE id = '".$id."' AND active = '".$active."'");
			if($count>0){
				$update = "UPDATE medical_registration SET active = 'Yes' WHERE id = '".$id."' AND active = '".$active."'";
				mysqli_query($conn,$update) or die(mysqli_error());
				$msg = "Your account has been successfully activated <a class='ajax' href='/login.php'>Click To Login</a>";
			} else {
				$msg1 = "Invalid Activation Link !";
			}
		}
	} else if($active_type=="other"){
		if(is_numeric($id) && !empty($active)){
			$count = countRow(" `other_service_registration` ", " WHERE id = '".$id."' AND active = '".$active."'");
			if($count>0){
				$update = "UPDATE other_service_registration SET active = 'Yes' WHERE id = '".$id."' AND active = '".$active."'";
				mysqli_query($conn,$update) or die(mysqli_error());
				$msg = "Your account has been successfully activated <a class='ajax' href='/login.php'>Click To Login</a>";
			} else {
				$msg1 = "Invalid Activation Link !";
			}
		}
	} else {
		$msg1 = "Invalid Activation Link !";
	}
	
?>
    <div class="container">

        <div class="row">
			<div class="col-md-2"></div>
            <div class="col-md-8" style="min-height:200px;">
				
				<? if(!empty($msg)){ ?>
				<center><img src="/images/activate.jpg" style="height: 55px;"></center>
				<h2 class='bg-success' style='font-size:14px; padding-top:8px; padding-bottom:8px; text-align:center;'><?=$msg?></h2>
				<? } ?>
				<? if(!empty($msg1)){ ?>
				<center><img src="/images/invalid.jpg" style="height: 55px;"></center>
				<h2 class='bg-danger' style='font-size:14px; padding-top:8px; padding-bottom:8px; text-align:center;'><?=$msg1?></h2>
				<? } ?>
            </div>
			<div class="col-md-2"></div>
		</div>
	</div>

<? include('include/footer.php'); ?>
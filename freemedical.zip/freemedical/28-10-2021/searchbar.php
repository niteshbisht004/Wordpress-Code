<?php
$st_type = ['doctor'=>'Doctors','hospital'=>'Hospitals','service'=>'services','blood bank'=>'Blood Bank','pathology'=>'Pathology','extra'=>'Other Services','deal'=>'Deal','blog'=>'Blog'];

$conn = db();
//Specialisation List
$resHD = mysqli_query($conn,"SELECT * FROM specialisation ORDER BY specialisation ASC");
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$specialisations[$data['id']] = utf8_encode($data['specialisation']); 
		$c++;
	}		
}


//Qualification Lists
$resHD = mysqli_query($conn,"SELECT * FROM cities ORDER BY name ASC");
if (mysqli_num_rows($resHD)) {
	
	$c = 0; 
	while($data = mysqli_fetch_assoc($resHD)) {
		
		$cities[$data['id']] = utf8_encode($data['name']); 
		$c++;
	}		
}
// $resHD = mysqli_query($conn,"SELECT * FROM disease ORDER BY name ASC");
// if (mysqli_num_rows($resHD)) {
	
// 	$c = 0; 
// 	while($data = mysqli_fetch_assoc($resHD)) {
		
// 		$disease[$data['id']] = utf8_encode($data['name']); 
// 		$c++;
// 	}		
// }
// $resHD = mysqli_query($conn,"SELECT * FROM doctor_registration ORDER BY name ASC");
// if (mysqli_num_rows($resHD)) {
	
// 	$c = 0; 
// 	while($data = mysqli_fetch_assoc($resHD)) {
		
// 		$doctor_registration[$data['id']] = utf8_encode($data['name']); 
// 		$c++;
// 	}		
// }






?>

<form class="header-table" method="GET" action="<?=_MAINPATH_?>search.php" >
	
	<table cellpadding="1" cellspacing="1">
		
		<tr>
			<td style="text-align:right;" class="search-set-11">Search:</td>
			<td class="city-data-ad-01">
				 <input style="width:100%;" type="text" class="form-control" value="<?=$_GET['term']?>" id='search_top' name="search[term]" placeholder="Search By doctor and hospital" /> 
				
			</td>
				<td style="width:25%;" class="search-set-12"><select id="city" style="width:95%;" class="form-control" name="search[city]" Required data-live-search="true">
					<? if($_GET['city'] == "") {?>
						<option value="" >Select City</option>
					<? } else{?>
						<option value="<?= $_GET['city']?>" ><?= $_GET['city']?></option>
					<?}?>
					<option value="" >Any City</option>
	        		<?php
					foreach ($cities as $ke=>$spe)
						{
					        $selected = "";
					        $selected = ($ke == $_GET['city']) ? "selected" : "";
					        echo "<option value='$spe' $selected>".$spe."</option>";
					        echo $ke;
				        }			
	        		?>
	    		</select>
			</td>
			<td id='search_tops' class="fineaddress" style="display:none">
			
			<?php if($_GET['saddress'] == ''){ ?>
				<input style="width:100%;" type="text" class="form-control" id="searchadd" value="<?=$_GET['saddress']?>"  name="search[saddress]" placeholder="Search By Address" />
				
			<?php }else{ ?>
				
				<input style="width:100%;" type="text" class="form-control" id="searchadd" value="<?=$_GET['saddress']?>" name="search[saddress]" placeholder="Search By Address" />
				
			<?php }?>
			</td>
			
		</tr>
		</table>
			<table cellpadding="1" cellspacing="1">
		<tr>
			
			<td style="text-align:right;" class="search-set-11">in:</td>
			
			<td class="city-data-ad-01">
                <select style="width:95%;" class="form-control" name="search[type]" data-live-search="true">
				<? if($_GET['search']['type'] == ""){ 	?>
					<option value="Search Type">Search Type</option>
				<? } else {
					if($_GET['search']['type']=="1"){?>
						<option value="Search Type">Search Type</option>
					<?}else{
					?>
					<option value="<?= $_GET['search']['type'] ?>"><?= $_GET['search']['type'] ?></option>
				<? }}?>
				
	        		<?php	        			        		
	        		foreach ($st_type as $ke=>$st) {
	            		$selected = "";
	            		$selected = ($ke == $_GET['type'] || $ke == $_GET['search']['type']) ? "selected" : "";
	            		echo "<option value='$ke' $selected>".$st."</option>";	            		
	        		}
	        		?>
	        					<?php 
                                      
								$sel = "select DISTINCT service from  other_service_registration";
								$que_sel = mysqli_query($conn,$sel);
									while ($res = mysqli_fetch_array($que_sel)) {
									   print_r($res['service']);
								?>
								<option value="<?php echo $res['service']; ?>"><?php echo $res['service']; ?></option>
								<?php } ?>
	    		</select>
			</td>
			<td class="city-data-ad-01"><select style="width:95%;" class="form-control" name="search[speci]" data-live-search="true">
					<? if($_GET['search']['speci'] == ""){ ?>
						<option value="Any Specialisation" >Any Specialisation</option>
					<? } else{
						if($_GET['search']['speci']=="1"){?>
							<option value="Any Specialisation" >Any Specialisation</option>
						
						<?}else{?>
						<option value="<?= $_GET['search']['speci'] ?>" ><?= $_GET['search']['speci'] ?></option>
					<? }}?>
	        		<?php
	        		foreach ($specialisations as $ke=>$spe) {
	            		$selected = "";
	            		$selected = ($ke == $_GET['speci'] || $ke == $_GET['search']['speci']) ? "selected" : "";
	            		echo "<option value='$ke' $selected>".$spe."</option>";
	            		
	        		}
	        		?>
	    		</select>
			</td>
			
		
			
			
			<td style="width:200px;" class="find-btnn"><button style="width:95%;" type="submit" class="form-control" name="search[search]" value="1">Find</button></td>
		</tr>
	</table>
	
	
	<!-- <div class="input-group">											         
		<input type="text" class="form-control" id='search_top' name="search-item" placeholder="Search" value="<? echo $_GET['search-item']?>" required>
		
		
		
		
		<span class="input-group-btn">
			<button class="btn btn-default" name="submit" type="submit"><span class="glyphicon glyphicon-search"></span></button>
		</span>
	</div> -->
	
	
</form>
<script src="https://cdn.jsdelivr.net/npm/jquery.session@1.0.0/jquery.session.js"></script>


<script>
	$(document).ready(function(){
	$('select').on('change', function() {
	$("#search_tops").css("display","block");
 	$.session.set("compareLeftContent",this.value);
	//alert($.session.get("compareLeftContent"));
	
    //alert($.session.get("compareLeftContent"));

});	
	

	});
	
	var hospitals = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('hospital'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=hospitals'
	});
	
	var doctors = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('doctor'), 
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=doctors'
	});
	var services = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('service'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=services'
	});
	
	
	var address = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('address'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata?type=address&city='+$.session.get("compareLeftContent")
	});
	
	var haddress = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('haddress'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata?type=haddress&city='+$.session.get("compareLeftContent")
	});
	var oaddress = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('oaddress'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata?type=oaddress&city='+$.session.get("compareLeftContent")
	});
	
	/*var specialisations = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('specialisation'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=specialisations'
	});*/
	
	/*var cities = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('city'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=cities'
	});
	*/

	
	/*var diseases = new Bloodhound({
	  datumTokenizer: Bloodhound.tokenizers.obj.whitespace('disease'),
	  queryTokenizer: Bloodhound.tokenizers.whitespace,
	  prefetch: '<?=_MAINPATH_?>searchdata.php?type=diseases'
	});
	*/
	
	$("#searchadd").typeahead({
	  highlight: true,
	  hint: true,
	  minLength: 3,
	},
	{
	  name: 'address',
	  display: 'address',
	  limit: 10,
	  source: address,
	  templates: {
	    header: '<h3 class="league-name">Addresses</h3>'
	  }
	},
	{
	  name: 'haddress',
	  display: 'haddress',
	  limit: 10,
	  source: haddress,
	  templates: {
	    header: ''
	  }
	},
	{
	  name: 'oaddress',
	  display: 'oaddress',
	  limit: 10,
	  source: oaddress,
	  templates: {
	    header: ''
	  }
	},
	
	
	);
	
	
	
	
	$("#search_top").typeahead({
	  highlight: true,
	  hint: true,
	  minLength: 3,
	},
	{
	  name: 'hospitals',
	  display: 'hospital',
	  limit: 10,
	  source: hospitals,
	  templates: {
	    header: '<h3 class="league-name">Hospital / Clinics</h3>'
	  }
	},
	{
	  name: 'doctors',
	  display: 'doctor',
	  limit: 10,
	  source: doctors,
	  templates: {
	    header: '<h3 class="league-name">Doctors</h3>'
	  }
	},
	{ 
	  name: 'services',
	  display: 'service',
	  limit: 10,
	  source: services,
	  templates: { 
	    header: '<h3 class="league-name">Services</h3>' 
	  }
	},
	/*{
	  name: 'specialisations',
	  display: 'specialisation',
	  source: specialisations,
	  templates: {
	    header: '<h3 class="league-name">Specialisations</h3>'
	  }
	},
	{
	  name: 'cities',
	  display: 'city',
	  source: cities,
	  templates: {
	    header: '<h3 class="league-name">Cities</h3>'
	  }
	},*/
	
	
	/*{
	  name: 'diseases',
	  display: 'disease',
	  source: diseases,
	  templates: {
	    header: '<h3 class="league-name">Diseases</h3>'
	  }
	},*/
	
	);
	
</script>

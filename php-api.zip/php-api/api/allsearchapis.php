<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
include('connection.php');
include('function.php');
global $specialisations;
global $qualifications;
global $hospital_cats;
global $cities;
$conn = db();

include 'config/database.php';
$database = new Database();
$db = $database->getConnection();

include 'classes/city.php';
$cityitems = new Cities($db);

include 'classes/states.php';
$stateitems = new States($db);

include 'classes/country.php';
$countryitems = new Countries($db);

include 'classes/special.php';
$specialitems = new Special($db);

include 'classes/rating.php';
$rateitems = new Ratings($db);

include 'classes/qual.php';
$qualitems = new Qual($db);

include 'classes/doctors.php';
include 'classes/hospitals.php';
include 'classes/others.php';

$data = json_decode(file_get_contents("php://input"));

$val = $_POST['cat'];
$srow = $_POST['skiprow'];
$rows = $_POST['row'];
$allArr  = array();
if ($val == 'all') {

	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];
	
	 $docterms = "( doctor_registration.name LIKE '%$term%' )";
	$hosterms = "( medical_registration.name LIKE '%$term%' )";
    $othterms = "( other_service_registration.name LIKE '%$term%' )";
   
	$searchTermsn = explode(' ', $term);
	
    $removevalue = array('Dr','Doctors','Hospitals','doctor','hospital','Doctor','Hospital','and','in','is','kumar');
	
    $searchTermsn = array_diff($searchTermsn, $removevalue );
	
	foreach ($searchTermsn as $terms) {
    $terms = trim($terms);
    if (!empty($terms)) {
        
		$searchTermBitsplsn[] = "( name LIKE '%$terms%' )";

		
	    }
		
    }
	
	$orderbydatas = implode( ' + ' , $searchTermBitsplsn );

	
	foreach($searchTermsn as $val){
		
		$add .=" OR name like '%$val%' ";
	}
	
	$ads = mysqli_query($conn,"SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active` FROM `doctor_registration` UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active` FROM `medical_registration` UNION ALL SELECT `id`, `user_id`, `name`, `pro_img`, `address`, `email`, `specialisation`,`active` FROM `other_service_registration` WHERE active = 'Yes' AND (name like '%$term%' $add) ORDER BY ((name LIKE '%$term%') + $orderbydatas) DESC Limit 0,20");


	$allrows = mysqli_num_rows($ads);
	 while ($ress = mysqli_fetch_array($ads))
		{
			
			
			
		$res_all[] = $ress;
	  
	
		}
	
	foreach($res_all as $row){
		
		    $uid = $row['user_id'];
			$ads = mysqli_query($conn,"SELECT user_type from all_users WHERE user_id = '$uid'");
		$utype = mysqli_fetch_array($ads);
		$ustype = $utype[0];
      include 'allresults.php';
	}
	
	
	

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar', 'Dr.', 'dr.');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}
     
	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	$term = str_replace('Dr. ', '', $term);
	$term = str_replace('dr. ', '', $term);

	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
	
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq ");
		$tcount = count($res_doctorc);
		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {

            include 'adocsearchinclude.php';
		
			}


			
		} else {



			$res_doctor = fetchAllDatas(" `doctor_registration` LIMIT $srow,$rows");
			$res_doctorc = fetchAllDatas(" `doctor_registration`");
			$tcount = count($res_doctorc);
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		$sps = $_POST['specialisation'];
		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  specialisation = '$sps' LIMIT $srow,$rows");
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  specialisation = '$sps'");
		$tcount = count($res_doctorc);
		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		} else {

			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq");
			$tcount = count($res_doctorc);
			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {


					   include 'adocsearchinclude.php';
				}


			
			} else {

				$res_doctor = fetchAllDatas(" `doctor_registration` LIMIT $srow,$rows");
				$res_doctorc = fetchAllDatas(" `doctor_registration`");
				$tcount = count($res_doctorc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {


					   include 'adocsearchinclude.php';
				}


			
			}
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");


		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $addressq");
		$tcount = count($res_doctorc);

		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {


				   include 'adocsearchinclude.php';
			}


			
		} else {

			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq");
			$tcount = count($res_doctorc);
			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

				 include 'adocsearchinclude.php';
				}


			
			} else {

				$res_doctor = fetchAllDatas(" `doctor_registration` LIMIT $srow,$rows");
				$res_doctorc = fetchAllDatas(" `doctor_registration`");
				$tcount = count($res_doctorc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

						   include 'adocsearchinclude.php';
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");
		$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE   $cityq AND $addressq AND $specq ");
		$tcount = count($res_doctorc);
		if (!empty($res_doctor)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_doctor as $row) {

               include 'adocsearchinclude.php';
				
			}


			
		} else {

			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");
			$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE  $cityq AND $specq");
			$tcount = count($res_doctorc);
			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

				   include 'adocsearchinclude.php';
					
				}


			
			} else {

				$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE $specq LIMIT $srow,$rows");
				$res_doctorc = fetchAllData(" `doctor_registration` ", "WHERE $specq ");
				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {

							   include 'adocsearchinclude.php';
					}


				
				} else {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval";
				}
			}

			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {

					$redp .= " or specialisation = $svalq";
				}
			}


				


			if ($addressq == '') {

				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) LIMIT $srow,$rows");
		

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp )");
				$tcount = count($res_doctorc);
			} else {

				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $addressq LIMIT $srow,$rows");
				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redp ) AND $addressq");
				$tcount = count($res_doctorc);
			}



			if (!empty($res_doctor)) {
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {

 
					   include 'adocsearchinclude.php';
	
				}


			
			} else {



				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  specialisation = 79878979  $redp LIMIT $srow,$rows");

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE  specialisation = 79878979  $redp");

				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				} else {


					$res_doctor = fetchAllDatas(" `doctor_registration` LIMIT $srow,$rows");
					$res_doctorc = fetchAllDatas(" `doctor_registration`");
					$tcount = count($res_doctorc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		} else {


			$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name = '$term' OR name like %$term% $searchTermBits  ORDER BY ( " . $orderbydata . " ) DESC LIMIT $srow,$rows");

			$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE  name = '$term' OR name like %$term% $searchTermBits  ORDER BY ( " . $orderbydata . " ) DESC ");

			$tcount = count($res_doctorc);

			if (!empty($res_doctor)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_doctor as $row) {


					   include 'adocsearchinclude.php';
				}


			
			} else {


				$res_doctor = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' $searchTermBits ORDER BY ( " . $orderbydata . " ) DESC LIMIT $srow,$rows");

				$res_doctorc = fetchAllData(" `doctor_registration` ", " WHERE  name like '%$term%' $searchTermBits ORDER BY ( " . $orderbydata . " ) DESC");


				$tcount = count($res_doctorc);
				if (!empty($res_doctor)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				} else {



					$res_doctor = fetchAllDatas(" `doctor_registration` LIMIT $srow,$rows");
					$res_doctorc = fetchAllDatas(" `doctor_registration`");
					$tcount = count($res_doctorc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_doctor as $row) {


						   include 'adocsearchinclude.php';
					}


				
				}
			}
		}
	}



	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC ") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	if ($hosnamerows > 0 or $othnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}









	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  $cityq");
		$tcount = count($res_hospitalc);
		if (!empty($res_hospital)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		} else {



			$res_hospital = fetchAllDatas(" `medical_registration` LIMIT $srow,$rows");
			$res_hospitalc = fetchAllDatas(" `medical_registration`");
			$tcount = count($res_hospitalc);
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		$sps = $_POST['specialisation'];
		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  specialisation = '$sps' LIMIT $srow,$rows");
		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  specialisation = '$sps'");

		$tcount = count($res_hospitalc);
		if (!empty($res_hospital)) {

			include("hospital_result.php");
		} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  $cityq");
			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
			} else {

				$res_hospital = fetchAllDatas(" `medical_registration` LIMIT $srow,$rows");
				$res_hospitalc = fetchAllDatas(" `medical_registration`");
				$tcount = count($res_hospitalc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
				}


			
			}
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  $cityq AND $addressq");

		$tcount = count($res_hospitalc);

		if (!empty($res_hospital)) {
			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
				
			}


			
		} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  $cityq LIMIT $srow,$rows");

			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  $cityq ");

			$tcount = count($res_hospitalc);

			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				
				}


			
			} else {

				$res_hospital = fetchAllDatas(" `medical_registration` LIMIT $srow,$rows");
				$res_hospitalc = fetchAllDatas(" `medical_registration`");
				$tcount = count($res_hospitalc);
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_hospital = fetchAllData(" `medical_registration` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");

		$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE   $cityq AND $addressq AND $specq");

		$tcount = count($res_hospitalc);

		if (!empty($res_hospital)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_hospital as $row) {

				include('ahossearchinclude.php');
			}


			
		} else {

			$res_hospital = fetchAllData(" `medical_registration` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE  $cityq AND $specq ");
			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				}


			
			} else {

				$res_hospital = fetchAllData(" `medical_registration` ", "WHERE $specq LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", "WHERE $specq");
				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				} else {


					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					}


				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redps .= " or specialisation = $sval";
				}
			}

			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {

					$redps .= " or specialisation = $svalq";
				}
			}

			if ($addressq == '') {

				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redps ) LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redps )");
				$tcount = count($res_hospitalc);
			} else {

				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redps ) AND $addressq LIMIT $srow,$rows");
				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redps ) AND $addressq");
				$tcount = count($res_hospitalc);
			}



			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
				
				}


			
			} else {


				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  specialisation = 79878979  $redps LIMIT $srow,$rows");

				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  specialisation = 79878979  $redps");

				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
						
					}


				
				} else {


					$res_hospital = fetchAllDatas(" `medical_registration` LIMIT $srow,$rows");
					$res_hospitalc = fetchAllDatas(" `medical_registration`");
					$tcount = count($res_hospitalc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				}
			}
		} else {


			$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitsh ORDER BY ( " . $orderbydatah . " ) DESC LIMIT $srow,$rows");
			$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitsh ORDER BY ( " . $orderbydatah . " ) DESC");

			$tcount = count($res_hospitalc);
			if (!empty($res_hospital)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_hospital as $row) {

					include('ahossearchinclude.php');
					
				}


			
			} else {


				$res_hospital = fetchAllData(" `medical_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitsh ORDER BY ( " . $orderbydatah . " ) DESC LIMIT $srow,$rows");

				$res_hospitalc = fetchAllData(" `medical_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitsh ORDER BY ( " . $orderbydatah . " ) DESC");

				$tcount = count($res_hospitalc);
				if (!empty($res_hospital)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				} else {



					$res_hospital = fetchAllDatas(" `medical_registration` LIMIT $srow,$rows");
					$res_hospitalc = fetchAllDatas(" `medical_registration`");
					$tcount = count($res_hospitalc);
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_hospital as $row) {

						include('ahossearchinclude.php');
					
					}


				
				}
			}
		}
	}

   
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {

		$specq = "specialisation = '$sp'";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}

       


	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {
            
		$res_om = fetchAllData(" `other_service_registration` ", "WHERE  $cityq LIMIT $srow,$rows");
      
		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

     
				include('aothsearchinclude.php');
				
			}


			
		} else {



			$res_om = fetchAllData(" `other_service_registration` LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

			include('aothsearchinclude.php');
				
			}


			
		}
	} elseif ($_POST['term']  == '' && $_POST['address'] == '') {
		
		$sps = $_POST['specialisation'];
		$res_om = fetchAllData(" `other_service_registration` ", "WHERE  specialisation = '$sps' LIMIT $srow,$rows");
             
		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {
                
			include('aothsearchinclude.php');
				
			}


			
		} else {
             $sps = $_POST['specialisation'];
			$res_om = fetchAllData(" `other_service_registration` ", "WHERE  specialisation like '%$sps%' LIMIT $srow,$rows");
            

			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {
                 
				$res_om = fetchAllDatas(" `other_service_registration` LIMIT $srow,$rows");
               
				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {
					
					

                include('aothsearchinclude.php');
				
				
				}


			
			}
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_om = fetchAllData(" `other_service_registration` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

			include('aothsearchinclude.php');
			
			}


			
		} else {

			$res_om = fetchAllData(" `other_service_registration` ", "WHERE  $cityq LIMIT $srow,$rows");


			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {

				$res_om = fetchAllData(" `other_service_registration` LIMIT $srow,$rows");

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_om = fetchAllData(" `other_service_registration` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");


		if (!empty($res_om)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			foreach ($res_om as $row) {

            include('aothsearchinclude.php');
				
			}


			
		} else {

			$res_om = fetchAllData(" `other_service_registration` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");

			if (!empty($res_om)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {

				$res_om = fetchAllData(" `other_service_registration` ", "WHERE $specq LIMIT $srow,$rows");

				if (!empty($res_om)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
						
					}


				
				} else {



					$res_om = fetchAllData(" `other_service_registration` ", "WHERE $specq LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redpw .= " or specialisation = $sval";
				}
			}


			foreach (array_unique($specidq) as $svalq) {

				if ($svalq == '') {
				} else {

					$redpw .= " or specialisation = $svalq";
				}
			}

      
  
  
			if ($addressq == '') {

				$res_om = fetchAllData(" `other_service_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redpw ) LIMIT $srow,$rows");
			} else {

				$res_om = fetchAllData(" `other_service_registration` ", " WHERE  name like '%$term%' OR (specialisation = 79878979  $redpw ) AND $addressq LIMIT $srow,$rows");
			}



			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {

				include('aothsearchinclude.php');
				
				}


			
			} else {



				$res_om = fetchAllData(" `other_service_registration` ", " WHERE  specialisation = 79878979  $redpw LIMIT $srow,$rows");


				if (!empty($res_om)) {


					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				} else {


					$res_om = fetchAllDatas(" `other_service_registration` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
				
					}


				
				}
			}
		} else {


			$res_om = fetchAllData(" `other_service_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitso LIMIT $srow,$rows ORDER BY ( " . $orderbydatao . " ) DESC");



			if (!empty($res_om)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				foreach ($res_om as $row) {


				include('aothsearchinclude.php');
				}


			
			} else {


				$res_om = fetchAllData(" `other_service_registration` ", " WHERE  name = '$term' or name like '%$term%' $searchTermBitso  LIMIT $srow,$rows ORDER BY ( " . $orderbydatao . " ) DESC ");



				if (!empty($res_om)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				} else {



					$res_om = fetchAllDatas(" `other_service_registration` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					foreach ($res_om as $row) {

					include('aothsearchinclude.php');
					
					}


				
				}
			}
		}
	}



	
	
  
	
	
	
	
	

	$tcount = 30;
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {
		$sp = explode("|", $sp);
		$specq = "(specialisation like '%dfdfdfd%'";
		foreach ($sp as $vsp) {
			$specq .= "or specialisation like '%$vsp%' or specialisation = '$vsp'";
		}
		$specq .= ")";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}



	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq LIMIT $srow,$rows");

		if (!empty($res_deal)) {


			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

			
		} else {



			$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

		
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		if (!empty($res_deal)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq LIMIT $srow,$rows");


			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_deal = fetchAllData(" `deals` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");


		if (!empty($res_deal)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row = array();
			$itemCount = count($res_deal);

			foreach ($res_deal as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				if ($row['doctor_id'] != '') {

					
					$itemsd = new Doctors($db);
					$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
					$rowd = $stmtd->fetch_assoc();

					$cityArr['offerby'] = $rowd['name'];
				}
				if ($row['hospital_id'] != '') {

					
					$itemsh = new Hospitals($db);
					$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
					$rowh = $stmth->fetch_assoc();

					$cityArr['offerby'] = $rowh['name'];
				}
				if ($row['other_id'] != '') {

					
					$itemso = new Others($db);
					$stmto = $itemso->getSingleOthers($row['other_id']);
					$rowo = $stmto->fetch_assoc();

					$cityArr['offerby'] = $rowo['name'];
				}
				$allArr['deal'][] = array_merge($row, $cityArr);
			}

			
		} else {

			$res_deal = fetchAllData(" `deals` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");

			if (!empty($res_deal)) {


				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_deal = fetchAllData(" `deals` ", "WHERE $specq LIMIT $srow,$rows");

				if (!empty($res_deal)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_deal = fetchAllData(" `deals` ", "WHERE $specq LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval";
				}
			}

             
			$res_deal = fetchAllData(" `deals` ", " WHERE  title like '%$term%' OR (specialisation = 79878979  $redp ) LIMIT $srow,$rows");

			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];
           
					if ($row['doctor_id'] != '') {
                       
						
					
						$itemsd = new Doctors($db);
						
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
				
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {



				$res_deal = fetchAllData(" `deals` ", " WHERE  specialisation = 79878979  $redp OR city =  $city LIMIT $srow,$rows");


				if (!empty($res_deal)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {
					$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		} else {


			$res_deal = fetchAllData(" `deals` ", " WHERE  title = '$term' LIMIT $srow,$rows");



			if (!empty($res_deal)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row = array();
				$itemCount = count($res_deal);

				foreach ($res_deal as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					if ($row['doctor_id'] != '') {

						
						$itemsd = new Doctors($db);
						$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
						$rowd = $stmtd->fetch_assoc();

						$cityArr['offerby'] = $rowd['name'];
					}
					if ($row['hospital_id'] != '') {

						
						$itemsh = new Hospitals($db);
						$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
						$rowh = $stmth->fetch_assoc();

						$cityArr['offerby'] = $rowh['name'];
					}
					if ($row['other_id'] != '') {

						
						$itemso = new Others($db);
						$stmto = $itemso->getSingleOthers($row['other_id']);
						$rowo = $stmto->fetch_assoc();

						$cityArr['offerby'] = $rowo['name'];
					}
					$allArr['deal'][] = array_merge($row, $cityArr);
				}

			
			} else {


				$res_deal = fetchAllData(" `deals` ", " WHERE  title = '$term' LIMIT $srow,$rows");


				if (!empty($res_deal)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_deal = fetchAllDatas(" `deals` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row = array();
					$itemCount = count($res_deal);

					foreach ($res_deal as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];
						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						if ($row['doctor_id'] != '') {

							
							$itemsd = new Doctors($db);
							$stmtd = $itemsd->getSingleDoctors($row['doctor_id']);
							$rowd = $stmtd->fetch_assoc();

							$cityArr['offerby'] = $rowd['name'];
						}
						if ($row['hospital_id'] != '') {

							
							$itemsh = new Hospitals($db);
							$stmth = $itemsh->getSingleHospitals($row['hospital_id']);
							$rowh = $stmth->fetch_assoc();

							$cityArr['offerby'] = $rowh['name'];
						}
						if ($row['other_id'] != '') {

							
							$itemso = new Others($db);
							$stmto = $itemso->getSingleOthers($row['other_id']);
							$rowo = $stmto->fetch_assoc();

							$cityArr['offerby'] = $rowo['name'];
						}
						$allArr['deal'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	}
	
	


	$tcount = 30;
	$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$specialisations[$data['id']] = utf8_encode($data['specialisation']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM qualification");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$qualifications[$data['id']] = utf8_encode($data['qualification']);
			$c++;
		}
	}

	//Qualification Lists
	$resHD = mysqli_query($conn, "SELECT * FROM cities");
	if (mysqli_num_rows($resHD)) {

		$c = 0;
		while ($data = mysqli_fetch_assoc($resHD)) {

			$cities[$data['id']] = utf8_encode($data['name']);
			$c++;
		}
	}


	$term = $_POST['term'];

	$address = $_POST['address'];

	$city = $_POST['city'];

	$sp = $_POST['specialisation'];

	$docname = mysqli_query($conn, "select * from `doctor_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$docnamerows = mysqli_num_rows($docname);

	$hosname = mysqli_query($conn, "select * from `medical_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());

	$hosnamerows = mysqli_num_rows($hosname);

	$othname = mysqli_query($conn, "select * from `other_service_registration` where name like '%$term%' order by id DESC") or die(mysqli_error());



	$othnamerows = mysqli_num_rows($othname);



	$searchTerms = explode(' ', $term);

	$removevalue = array('Dr', 'Doctors', 'Hospitals', 'doctor', 'hospital', 'Doctor', 'Hospital', 'and', 'in', 'is', 'kumar');

	$searchTerms = array_diff($searchTerms, $removevalue);

	foreach ($searchTerms as $terms) {
		$terms = trim($terms);
		if (!empty($terms)) {
			$searchTermBits .= "or name LIKE '%$terms%'";
			$searchTermBitspls[] = "( doctor_registration.name LIKE '%$terms%' )";


			$searchTermBitsplsh[] = "( medical_registration.name LIKE '%$terms%' )";


			$searchTermBitsplso[] = "( other_service_registration.name LIKE '%$terms%' )";
		}
	}

	$orderbydata = implode(' + ', $searchTermBitspls);
	$orderbydatah = implode(' + ', $searchTermBitsplsh);
	$orderbydatao = implode(' + ', $searchTermBitsplso);

	if (strpos(trim($term), ' ') !== false) {
		$term = $term;
	} else {

		$term =	rtrim($term, ',');
		$term =  str_replace(' ', '', trim($term, ','));
	}


	if ($docnamerows > 0) {
	} else {


		$speciliationqs = mysqli_query($conn, "select * from `specialisation` where specialisation like '%$term%' order by id DESC") or die(mysqli_error());



		$num_specs = mysqli_num_rows($speciliationqs);

		if ($num_specs > 0) {

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationqs)) {

				$specidq[] = $rowq['id'];
			}
		} else {


			$search_item = addslashes($term);

			$string = explode(" ", $search_item);

			$omit_words = array('the', 'for', 'in', 'or', 'to', 'and', 'doctors', 'hospitals', 'others', 'deals', 'Dr', 'Skin', 'Problems', 'doctor', 'sector', 'Sector', 'Hospital');

			$result = array_diff($string, $omit_words);

			foreach ($result as $val) {

				if ($val == '') {
				} else {

					$keywordsq .= " or keywords like '%$val%' OR keywords = '$val'";

					$keywordsqs .= " or keyword like '%$val%' OR keyword = '$val'";

					$speckeywords[] = "( specialisation.keyword LIKE '%$val%' )";

					$diseasekeywords[] = "( disease.keywords LIKE '%$val%' )";
				}
			}


			$orderbydataspeci = implode(' + ', $speckeywords);
			$orderbydatahdise = implode(' + ', $diseasekeywords);


			$speciliationq = mysqli_query($conn, "select * from `specialisation` where keyword like '%$term%' $keywordsqs ORDER BY ( " . $orderbydataspeci . " ) DESC") or die(mysqli_error());


			$num_spec = mysqli_num_rows($speciliationq);

			$specidq = array();

			while ($rowq = mysqli_fetch_array($speciliationq)) {

				$specidq[] = $rowq['id'];
			}



			$query_disease = mysqli_query($conn, "select * from `disease` where keywords like '%$term%' $keywordsq ORDER BY ( " . $orderbydatahdise . " ) DESC") or die(mysqli_error());



			$num_disease = mysqli_num_rows($query_disease);

			$specid = array();

			while ($row = mysqli_fetch_array($query_disease)) {

				$specid[] = $row['spec_id'];
			}
		}
	}

	$City = fetchData(" `cities` ", "where name='%" . $city . "%' ");

	$cityn = $City['name'];

	if ($sp != '') {
		$sp = explode("|", $sp);
		$specq = "(specialisation like '%dfdfdfd%'";
		foreach ($sp as $vsp) {
			$specq .= "or specialisation like '%$vsp%' or specialisation = '$vsp'";
		}
		$specq .= ")";
	}

	if ($city != '') {

		$cityq = " (city like '%$city%' or city = '$city' OR address like '%$city%')";
	}

	if ($address != '') {
		//$str = 'In My Cart : 11 12 items';
		preg_match_all('!\d+!', $address, $matches);

		foreach ($matches[0] as $val) {
			if (preg_match('/^\d{2}$/', $string)) {
				// pass
			} else {
				$fadd = "or address like '%Sector -$val%'";
				$fadd .= "or address like '%SEC-$val%'";
				$fadd .= "or address like '%Sector-$val%'";
				$fadd .= "or address like '%Sector $val%'";
			}
		}
		$addressq = "(address like '%$address%' or address = '$address' $fadd)";
	}


	if ($_POST['term']  == '' && $_POST['address'] == '' && $_POST['specialisation'] == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq LIMIT $srow,$rows");

		if (!empty($res_blog)) {


			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {



			$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

			
		}
	} elseif ($_POST['term']  == '' && $_POST['specialisation'] == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq AND $addressq LIMIT $srow,$rows");

		if (!empty($res_blog)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq LIMIT $srow,$rows");


			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			}
		}
	} elseif ($_POST['term']  == '') {

		$res_blog = fetchAllData(" `blog` ", "WHERE   $cityq AND $addressq AND $specq LIMIT $srow,$rows");


		if (!empty($res_blog)) {

			$cityArr = array();
			
			$allArrs  = array();
			$row  = array();
			$itemCount = count($res_blog);
			foreach ($res_blog as $row) {
				$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
				$specialname =  mysqli_fetch_row($specialstmt);
				$cityArr['specialisationname'] = $specialname[0];

				$allArr['blog'][] = array_merge($row, $cityArr);
			}

		
		} else {

			$res_blog = fetchAllData(" `blog` ", "WHERE  $cityq AND $specq LIMIT $srow,$rows");

			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {

				$res_blog = fetchAllData(" `blog` ", "WHERE $specq LIMIT $srow,$rows");

				if (!empty($res_blog)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

				
				} else {



					$res_blog = fetchAllData(" `blog` ", "WHERE $specq LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	} else {


		if ($num_disease > 0 or $num_spec > 0 or $num_specs > 0) {

			foreach (array_unique($specid) as $sval) {

				if ($sval == '') {
				} else {

					$redp .= " or specialisation = $sval";
				}
			}


			$res_blog = fetchAllData(" `blog` ", " WHERE  title like '%$term%' OR (specialisation = 79878979  $redp ) LIMIT $srow,$rows");

			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {



				$res_blog = fetchAllData(" `blog` ", " WHERE  specialisation = 79878979  $redp LIMIT $srow,$rows");
				if (!empty($res_blog)) {
					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				} else {
					$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		} else {


			$res_blog = fetchAllData(" `blog` ", " WHERE  title = '$term' LIMIT $srow,$rows");



			if (!empty($res_blog)) {

				$cityArr = array();
				
				$allArrs  = array();
				$row  = array();
				$itemCount = count($res_blog);
				foreach ($res_blog as $row) {
					$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

					$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
					$specialname =  mysqli_fetch_row($specialstmt);
					$cityArr['specialisationname'] = $specialname[0];

					$allArr['blog'][] = array_merge($row, $cityArr);
				}

			
			} else {


				$res_blog = fetchAllData(" `blog` ", " WHERE  title = '$term' LIMIT $srow,$rows");


				if (!empty($res_blog)) {

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				} else {




					$res_blog = fetchAllDatas(" `blog` LIMIT $srow,$rows");

					$cityArr = array();
					
					$allArrs  = array();
					$row  = array();
					$itemCount = count($res_blog);
					foreach ($res_blog as $row) {
						$cityArr['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/' . $row['image'];

						$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
						$specialname =  mysqli_fetch_row($specialstmt);
						$cityArr['specialisationname'] = $specialname[0];

						$allArr['blog'][] = array_merge($row, $cityArr);
					}

					
				}
			}
		}
	}
	

	
	
	
	
	
	
	
}
            $specialstmt = $specialitems->getSingleSpecials($_POST['specialisation']);
			$specialname =  mysqli_fetch_row($specialstmt);
				$allArr['specialisationname'] = $specialname[1];
			$allArr['specialisationdescription'] = $specialname[3];
			if($specialname[4] == ''){
			$allArr['specialisationbannerimageurl'] = "https://www.freemedicalinfo.in/images/home-icons/doctor-banner.jpg";
			
            }else{
				
			$allArr['specialisationbannerimageurl'] = "https://www.freemedicalinfo.in/admin/images/uploads/".$specialname[4];	
			}
			
			    $pecid = $_POST['specialisation'];
				
			$res_diease = fetchAllData("disease"," WHERE spec_id = $pecid");
			foreach ($res_diease as $des) {
		
			$allArr['specialisationkeywords'][] = $des;
			}
			//print_r($specialname);
            $response['message'] = "Data Found";
			//$response['totalcount'] = $tcount;
			$response['skiprow'] =  $srow;
			$response['row'] =  $rows;
			$response['status'] = 1;
			$response['data'] = $allArr;
		
			$json_response = json_encode($response);
			echo $json_response;
			exit;
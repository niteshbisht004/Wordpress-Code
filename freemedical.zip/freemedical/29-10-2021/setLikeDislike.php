 <?php 
 session_start();
include('include/connection.php');
	//print_r($_POST);
if(isset($_POST['type']) && $_POST['type']!='' && isset($_POST['id']) && $_POST['id']>0)
{
	$type=mysqli_real_escape_string($conn,$_POST['type']);
	$id=mysqli_real_escape_string($conn,$_POST['id']);
	$uld=mysqli_real_escape_string($conn,$_POST['uid']);
	if($type=='like')
	{
		$rqry="select * from `cmnt_like_dislike` where `user_id`='$uld' AND `rating_id`='$id'";
		$exe=mysqli_query($conn,$rqry);
		$count=mysqli_num_rows($exe);
		if($count>0)
		{
			
		}
		else{
		$qr="insert into `cmnt_like_dislike` set `like`=1, `user_id`='$uld', `rating_id`='$id'";
		
		}
	}
	
	if($type=='dislike')
	{
		
		$dqry="select * from `cmnt_like_dislike` where `user_id`='$uld' AND `rating_id`='$id'";
		$dexe=mysqli_query($conn,$dqry);
		$dcount=mysqli_num_rows($dexe);
		if($dcount>0)
		{
			
		}
		else{
		$qr="insert into `cmnt_like_dislike` set `dislike`=1, `user_id`='$uld', `rating_id`='$id'";
		
		}
	}
	mysqli_query($conn,$qr);
}


 ?>
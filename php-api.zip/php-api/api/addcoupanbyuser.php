<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	 $val = 'user';
	    $id = $_POST['id'];
		$contact_number = $_POST['contact_number']; 
		$address = $_POST['address'];  
		$purpose = $_POST['purpose']; 
		$appointment_time = $_POST['appointment_time'];
		$appointment_date = $_POST['appointment_date'];
		$arr = explode('/', $appointment_date);
       $newDate = $arr[1].'/'.$arr[0].'/'.$arr[2];
	   
		$newDate = date("Y-m-d", strtotime($newDate));
		
		$gender = $_POST['gender'];
		$email = $_POST['email'];
		
		$patient_name = $_POST['patient_name'];
		$status = 'Unused';	   
	   $ap1='FMI';
		$ap2=date("dmY");
		
	include_once 'classes/coupan.php';
	$items = new Coupans($db);
	$stmt = $items->getCoupan();
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount == 0 or $itemCount<0)
		{ 
			$apCounter=1;
		} else {
			$apCounter = $itemCount+1;
		}
		
	   $coupan_id=$ap1.$ap2.$apCounter;
	  
	if($val == 'user'){
	include_once 'classes/deals.php';
	$items = new Deals($db);	
	$stmts = $items->getDealsbyid($id);
	$itemCount = mysqli_num_rows($stmts);
	if($itemCount > 0){
        
        $userArr = array();


        while($row = $stmts->fetch_assoc())
		{
			
           $userArr[] = $row;
			$doctor_id = $row['doctor_id'];
			$hospital_id = $row['hospital_id'];
			$other_id = $row['other_id'];
			
			
			
				if($doctor_id != ''){
				
			include_once 'classes/doctors.php';
		$itemsd = new Doctors($db);
		$stmtd = $itemsd->getSingleDoctors($doctor_id);
		$itemCountd = mysqli_num_rows($stmtd);
		if($itemCountd > 0){
			   while ($rowd = $stmtd->fetch_assoc()){
			
			   $serviename = $rowd['name'];
			   }
			  }		   
					}

		if($hospital_id != ''){
					include_once 'classes/hospitals.php';
			$itemsd = new Hospitals($db);
			$stmtd = $itemsd->getSingleHospitals($hospital_id);
			$itemCountd = mysqli_num_rows($stmtd);
			if($itemCountd > 0){
				   while ($rowd = $stmtd->fetch_assoc()){
				
				   $serviename = $rowd['name'];
				   }
			}	
		}
		
		if($other_id != ''){
		include_once 'classes/others.php';
	$itemsd = new Others($db);
    $stmtd = $itemsd->getSingleOthers($other_id);
	$itemCountd = mysqli_num_rows($stmtd);
	if($itemCountd > 0){
           while ($rowd = $stmtd->fetch_assoc()){
        
		   $serviename = $rowd['name'];
		   }
	      }		
		}
		
		
			
            $name = $row['title'];				
		    $validto = $row['valid_to'];
	include_once 'classes/coupan.php';
	
	$items = new Coupans($db);
    $stmt = $items->createcoupanbyuser($id, $doctor_id,$hospital_id, $other_id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status); 
    } 	   
		 
   if($stmt){
	   
	   		$to      = $email;
		//$to1     = $email;
		$subject = 'FMI Coupon Generation Detail';
		$message = '<html>
<head>
<title>GET A QUOTE</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#333337">
<tbody>
<tr>
<td align="center" valign="top"  style="height:100%;margin:0;padding:10px;width:100%;border-top:0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;border:0;max-width:600px!important">
<tbody>
<tr>
<td valign="top"  style="background:#fff none no-repeat center/cover;background-color:#fff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
<td valign="top" style="padding:9px">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                        <tbody>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
	<p><img src="https://www.freemedicalinfo.in/images/free_medical_info.gif"></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p><strong>Exclusive Deal for <a href="https://www.freemedicalinfo.in/">www.FreeMedicalInfo.in</a> users!</strong></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p>Coupon Code: '.$coupan_id.'</p>
							   <p>'.$name.'</p>
							 <br> </td>
                        </tr>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:left">
							
							<p><strong>Dear Mr. / Ms. '.$patient_name.'</strong></p>



<p>Congratulations for availing the Exclusive Discount Coupon on <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> !</p>

<p>Visit the Clinic and redeem it by simply showing your coupon.</p>


<p><strong>Your discount coupon is here:</strong> '.$coupan_id.'</p>



<p>Patients need to show this coupon in advance at the billing counter before treatment.</p>



<p><strong>'.$name.'</strong></p>

<p><strong>Offered by:</strong> '.$serviename.' </p>


<p><strong>Coupon Code:</strong> '.$coupan_id.'</p>

<p><strong>Name:</strong> '.$patient_name.'</p>

<p><strong>Gender:</strong> '.$gender.' </p>

<p><strong>Date of Visit:</strong> '.$newDate.'</p> 

<p><strong>Time of Visit:</strong> '.$appointment_time.'</p>

<p><strong>Treatment:</strong> '.$purpose.'</p>

<p><strong>Valid till:</strong> '.$validto.'</p>



<p>Discount applicable will be informed at the Billing Counter prior to Conducting the Treatment.</p>


<p>Visit and Register at <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> for generating more Coupons for future requirements.</p>

<p><strong>Best Wishes</strong></p>

<p>Team <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a></p>

<p><a target="_blank" href="https://www.freemedicalinfo.in/term.php">Terms & Conditions</a></p>
							 <br> </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
 <td valign="top" id="m_7045481687344905526m_8011562112826686489templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
 <td valign="top" style="padding-top:9px">
<table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%">
<tbody>
<tr>
<td valign="top" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
<p dir="ltr" style="margin:30px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">




                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td></tr></tbody></table>

					</td>
                </tr>
            </tbody></table></body>
</html>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";


mail($to, $subject, $message, $headers);
	   
	   
	
	$usr = array(); 
     $usr['id'] =  $items->id;
	 $downloadpddealfid= $items->id;
	 $usr['download_pdf']="https://www.freemedicalinfo.in/dealdownload_pdf.php?dealcouponid=$downloadpddealfid";
		$response['data']=$usr;
		
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
    }
		
	}
	if($val == 'hospital'){
		
	$stmt = $items->getSingleDealsbyhospitalid($id);
	
	
	  include_once 'classes/deals.php';
	$items = new Deals($db);	
	$stmts = $items->getDealsbyid($id);
	$itemCount = mysqli_num_rows($stmts);
	if($itemCount > 0){
        
        $userArr = array();


        while($row = $stmts->fetch_assoc()){
           $userArr[] = $row;
			$hospital_id = $row['hospital_id'];
			
		include_once 'classes/hospitals.php';
	$itemsd = new Hospitals($db);
    $stmtd = $itemsd->getSingleHospitals($hospital_id);
	$itemCountd = mysqli_num_rows($stmtd);
	if($itemCountd > 0){
           while ($rowd = $stmtd->fetch_assoc()){
        
		   $serviename = $rowd['name'];
		   }
	}		   
			
			
            $name = $row['title'];				
		    $validto = $row['valid_to'];
	include_once 'classes/coupan.php';
	$items = new Coupans($db);
    $stmt = $items->createcoupanbyuser($id, $doctor_id,$hospital_id, $other_id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status); 
       
	  	   
		 }	
   if($stmt){
	   
	   		$to      = $email;
		//$to1     = $email;
		$subject = 'FMI Coupon Generation Detail';
		$message = '<html>
<head>
<title>GET A QUOTE</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#333337">
<tbody>
<tr>
<td align="center" valign="top"  style="height:100%;margin:0;padding:10px;width:100%;border-top:0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;border:0;max-width:600px!important">
<tbody>
<tr>
<td valign="top"  style="background:#fff none no-repeat center/cover;background-color:#fff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
<td valign="top" style="padding:9px">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                        <tbody>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
	<p><img src="https://www.freemedicalinfo.in/images/free_medical_info.gif"></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p><strong>Exclusive Deal for <a href="https://www.freemedicalinfo.in/">www.FreeMedicalInfo.in</a> users!</strong></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p>Coupon Code: '.$coupan_id.'</p>
							   <p>'.$name.'</p>
							 <br> </td>
                        </tr>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:left">
							
							<p><strong>Dear Mr. / Ms. '.$patient_name.'</strong></p>



<p>Congratulations for availing the Exclusive Discount Coupon on <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> !</p>

<p>Visit the Clinic and redeem it by simply showing your coupon.</p>


<p><strong>Your discount coupon is here:</strong> '.$coupan_id.'</p>



<p>Patients need to show this coupon in advance at the billing counter before treatment.</p>



<p><strong>'.$name.'</strong></p>

<p><strong>Offered by:</strong> '.$serviename.' </p>


<p><strong>Coupon Code:</strong> '.$coupan_id.'</p>

<p><strong>Name:</strong> '.$patient_name.'</p>

<p><strong>Gender:</strong> '.$gender.' </p>

<p><strong>Date of Visit:</strong> '.$newDate.'</p> 

<p><strong>Time of Visit:</strong> '.$appointment_time.'</p>

<p><strong>Treatment:</strong> '.$purpose.'</p>

<p><strong>Valid till:</strong> '.$validto.'</p>



<p>Discount applicable will be informed at the Billing Counter prior to Conducting the Treatment.</p>


<p>Visit and Register at <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> for generating more Coupons for future requirements.</p>

<p><strong>Best Wishes</strong></p>

<p>Team <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a></p>

<p><a target="_blank" href="https://www.freemedicalinfo.in/term.php">Terms & Conditions</a></p>
							 <br> </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
 <td valign="top" id="m_7045481687344905526m_8011562112826686489templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
 <td valign="top" style="padding-top:9px">
<table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%">
<tbody>
<tr>
<td valign="top" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
<p dir="ltr" style="margin:30px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">




                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td></tr></tbody></table>

					</td>
                </tr>
            </tbody></table></body>
</html>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";


mail($to, $subject, $message, $headers);
	   
	   
	
	$usr = array(); 
     $usr['id'] =  $items->id;
	 $downloadpddealfid= $items->id;
	 $usr['download_pdf']="https://dev.freemedicalinfo.in/dealdownload_pdf.php?dealcouponid=$downloadpddealfid";
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
    }
	
	
	
	
	
	
	
	
	
	}
	if($val == 'other'){
		
	$stmt = $items->getSingleDealsbyotherid($id);
	
	
	
	
	  include_once 'classes/deals.php';
	$items = new Deals($db);	
	$stmts = $items->getDealsbyid($id);
	$itemCount = mysqli_num_rows($stmts);
	if($itemCount > 0){
        
        $userArr = array();


        while($row = $stmts->fetch_assoc()){
           $userArr[] = $row;
			$other_id = $row['other_id'];
			
		include_once 'classes/others.php';
	$itemsd = new Others($db);
    $stmtd = $itemsd->getSingleOthers($other_id);
	$itemCountd = mysqli_num_rows($stmtd);
	if($itemCountd > 0){
           while ($rowd = $stmtd->fetch_assoc()){
        
		   $serviename = $rowd['name'];
		   }
	}		   
			
			
            $name = $row['title'];				
		    $validto = $row['valid_to'];
	include_once 'classes/coupan.php';
	$items = new Coupans($db);
    $stmt = $items->createcoupanbyuser($id, $doctor_id,$hospital_id, $other_id, $patient_name, $email, $gender, $newDate, $appointment_time, $purpose, $address, $coupan_id,$contact_number, $status); 
       
	  	   
		 }	
   if($stmt){
	   
	   		$to      = $email;
		//$to1     = $email;
		$subject = 'FMI Coupon Generation Detail';
		$message = '<html>
<head>
<title>GET A QUOTE</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%;background-color:#333337">
<tbody>
<tr>
<td align="center" valign="top"  style="height:100%;margin:0;padding:10px;width:100%;border-top:0">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse;border:0;max-width:600px!important">
<tbody>
<tr>
<td valign="top"  style="background:#fff none no-repeat center/cover;background-color:#fff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:9px">
<table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
<td valign="top" style="padding:9px">
                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                        <tbody>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
	<p><img src="https://www.freemedicalinfo.in/images/free_medical_info.gif"></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p><strong>Exclusive Deal for <a href="https://www.freemedicalinfo.in/">www.FreeMedicalInfo.in</a> users!</strong></p>
							   
							 <br> </td>
                        </tr>
						
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">
							
							  <p>Coupon Code: '.$coupan_id.'</p>
							   <p>'.$name.'</p>
							 <br> </td>
                        </tr>
						<tr>
                            <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:left">
							
							<p><strong>Dear Mr. / Ms. '.$patient_name.'</strong></p>



<p>Congratulations for availing the Exclusive Discount Coupon on <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> !</p>

<p>Visit the Clinic and redeem it by simply showing your coupon.</p>


<p><strong>Your discount coupon is here:</strong> '.$coupan_id.'</p>



<p>Patients need to show this coupon in advance at the billing counter before treatment.</p>



<p><strong>'.$name.'</strong></p>

<p><strong>Offered by:</strong> '.$serviename.' </p>


<p><strong>Coupon Code:</strong> '.$coupan_id.'</p>

<p><strong>Name:</strong> '.$patient_name.'</p>

<p><strong>Gender:</strong> '.$gender.' </p>

<p><strong>Date of Visit:</strong> '.$newDate.'</p> 

<p><strong>Time of Visit:</strong> '.$appointment_time.'</p>

<p><strong>Treatment:</strong> '.$purpose.'</p>

<p><strong>Valid till:</strong> '.$validto.'</p>



<p>Discount applicable will be informed at the Billing Counter prior to Conducting the Treatment.</p>


<p>Visit and Register at <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a> for generating more Coupons for future requirements.</p>

<p><strong>Best Wishes</strong></p>

<p>Team <a target="_blank" href="https://www.freemedicalinfo.in/">www.freemedicalinfo.in</a></p>

<p><a target="_blank" href="https://www.freemedicalinfo.in/term.php">Terms & Conditions</a></p>
							 <br> </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
 <td valign="top" id="m_7045481687344905526m_8011562112826686489templateHeader" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:9px;padding-bottom:0"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
<tbody>
<tr>
 <td valign="top" style="padding-top:9px">
<table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%">
<tbody>
<tr>
<td valign="top" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
<p dir="ltr" style="margin:30px 0;padding:0;color:#202020;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">




                        </td>
                    </tr>
                </tbody></table>
				

				
            </td>
        </tr>
    </tbody>
</table></td></tr></tbody></table>

					</td>
                </tr>
            </tbody></table></body>
</html>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: freemedicalinfo <contact@freemedicalinfo.in>' . "\r\n";


mail($to, $subject, $message, $headers);
	   
	   
	
	$usr = array(); 
     $usr['id'] =  $items->id;
	 $downloadpddealfid= $items->id;
	 $usr['download_pdf']="https://dev.freemedicalinfo.in/dealdownload_pdf.php?dealcouponid=$downloadpddealfid";
		$response['data']=$usr;
		$response['message']="Data Inserted";
	$response['status']=1;

	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "Data Not Inserted";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
    }
	
	
	}
	
	   
	   
	   
		
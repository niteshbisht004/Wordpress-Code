<?php
session_start();
if(!isset($_SESSION['user_id']))
{
	header("Location:../index.php");
}
?>
<!DOCTYPE html>
<html>
<head><title>Admin Dashboard</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>
<?php
//include 'admin-Navbar.php';
?>
	<div class="admindash" align="center" style="padding-top: 35px">
		<h1>Welcome To Admin Dashboard</h1>
        <div class="logout" style="float:right; padding-right: 14px;">
        	<h4><a href="logout.php" >Logout</a></h4>
        </div>
	</div>
    <div class="dashboard" align="center">
    	<table border="2" style="width:50%" class="table table-dark table-hover">
        	<tr>
            	<td>1.</td>
                <td><a href="addstudent.php">Insert Student Details</a></td>
            </tr>
            <tr>
            	<td>2.</td>
                <td><a href="updatestudent.php">Update Student Details</a></td>
            </tr>
            <tr>
            	<td>3.</td>
                <td><a href="deletestudent.php">Delete Student Details</a></td>
            </tr>
        </table>
    </div>
</body>
</html>
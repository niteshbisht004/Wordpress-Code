<?php 

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

		    
			
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$userid = $row['user_id'];
			
		    $adse = mysqli_query($conn,"SELECT  `user_type` FROM `all_users` WHERE user_id = '$userid' ");
			$rert = mysqli_fetch_array($adse);
		
			
			$cityArr['usertype'] = $rert[0];
            
			if($cityArr['usertype'] == 'doctor'){
			
			$uid = $row['id'];
			
		    $adset = mysqli_query($conn,"SELECT * FROM `doctor_registration` WHERE id = '$uid' ");
			$rertt = mysqli_fetch_array($adset);
			//print_r($rertt);
			$cityArr['gender'] = $rertt['gender'];
			$cityArr['registration_auth'] = $rertt['registration_auth'];
			$cityArr['date_birth'] = $rertt['date_birth'];
			$cityArr['expertise_in'] = $rertt['expertise_in'];
			$cityArr['total_experience'] = $rertt['total_experience'];
			$cityArr['O_zip'] = $rertt['O_zip'];
			$valq =  explode("|",$rertt['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
         $qalistmtr = $qualitems->getSingleQual($rertt['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];
			
				}
			}
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], $rert[0]);
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
				
			$cityArr['is_rating'] = 0;	
			}
			
			
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], $rert[0]);
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
      if($cityArr['usertype'] == 'doctor'){      
	$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
        $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		
		$cityArr['pastexperience'] = array();
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
			
	  }	
			
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$rert[0]);
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
          $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		$cityArr['blogs'] = array();
		
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
        $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/images/uploads/'.$rowde['image'];
		
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
		 			include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}

    

        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],$rert[0]);
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
            $cityArr['allreview'] = array(); 
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://dev.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://dev.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		 
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
        
        if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://dev.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://dev.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
		              
    
                
            }
	}else{
		
		$cityArr['allreview']= array();
		
	}




			$allArr['all'][] = array_merge($row, $cityArr);
			
			
			
			
	
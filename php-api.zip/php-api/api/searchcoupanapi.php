<?php
error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("HTTP/1.1 200 OK");
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$usertype = $_POST['usertype'];
	$userid = $_POST['userid'];
	$value = $_POST['value'];

	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db);

	
    include_once 'classes/coupan.php';
	$items = new Coupans($db);
	
		$stmt = $items->searchcoupan($val,$value,$usertype,$userid);
		
     $itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
			
											
		$allArr = array_merge($row,$userArr);
		 
       
		 }	

		$response['message']="Status Updated";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }else{
    $response['message'] = "Status Not Updated";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	

    
    
	
    
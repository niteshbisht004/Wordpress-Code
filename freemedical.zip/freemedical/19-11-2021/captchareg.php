<?php
	session_start();
	
	$captcha = "";
	$digit1 = rand(1, 100);
	$digit2 = rand(1, 100);
	$array = ["+", "-"];
	$random = array_rand($array);

	switch($array[$random]){
		case "+":
			$_SESSION['captcha'] = $digit1." + ".$digit2;
			$_SESSION['answer'] = $digit1+$digit2;
			break;
		case "-":
			$_SESSION['captcha'] = $digit1." - ".$digit2;
			$_SESSION['answer'] = $digit1-$digit2;
			break;
	}
	
	echo "<center>".$_SESSION['captcha']."</center>";
		
?>
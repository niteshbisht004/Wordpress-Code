<? include('connection.php'); ?>
<? include('function.php');
$conn = db();
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Free Medical Info provides a platform to the Patients, Doctors, Clinics, Hospitals, Pharma Companies and other organizations related to medical sector, who want to share the information online. The website also allows the patients/ visitors to consults with Doctors of particular specialisation.">
	<meta name="google-site-verification" content="vKNJ80iwI5tf3aG81hgtSaUF_J9PfTkcUQHw_Y83jvo" />
	

    <meta name="author" content="">
 <?php if($_GET['cityid'] == 1119){ ?>
    <title>Best Doctors and Hospitals in Faridabad</title>
 <?php }else{?>
	 <title>Free Medical Info - Find Doctors Online</title>
	
<?php 	
}?>
   <style>
	#magnifier 
	{
		color: #07931F;
		font-size: 20px;
		padding-left: 20px;
	}
   </style>
  
    
    <!-- Bootstrap Core CSS -->
    <link href="<?=_MAINPATH_?>css/bootstrap.css" rel="stylesheet">
	<link href="<?=_MAINPATH_?>css/bootstrap3.min.css" rel="stylesheet">
	<!-- CKEditor --> 
	
	

    <!-- Custom CSS -->
    <link href="<?=_MAINPATH_?>css/style.css" rel="stylesheet">
    
    <link href="<?=_MAINPATH_?>font-awesome/css/font-awesome.css" rel="stylesheet">
	
	<link href="<?=_MAINPATH_?>css/site.css" rel="stylesheet" type="text/css" />
	
	<link rel="stylesheet" href="<?=_MAINPATH_?>css/datepicker.css" />
	<link rel="stylesheet" href="<?=_MAINPATH_?>css/colorbox.css" />

	<link rel="stylesheet" href="<?=_MAINPATH_?>css/star-rating.css" media="all" type="text/css"/>
	<link rel="stylesheet" href="<?=_MAINPATH_?>css/bootstrap-select.css">
	<link rel="stylesheet" href="<?=_MAINPATH_?>css/typehead/typehead.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs/dt-1.10.16/datatables.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.6/chosen.min.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"/>

	<link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick.css ">
<link rel="stylesheet" type="text/css" href="https://kenwheeler.github.io/slick/slick/slick-theme.css ">
	
	<!-- jQuery -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="<?=_MAINPATH_?>js/jquery.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
<!-- <script src="<?=_MAINPATH_?>js/owl.carousel.min.js"></script> -->
<script src="<?=_MAINPATH_?>js/jquery.bootstrap.newsbox.js" type="text/javascript"></script>
<script src="<?=_MAINPATH_?>js/typehead/dist/typeahead.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.6/chosen.jquery.min.js"></script>
<script src="<?=_MAINPATH_?>js/bootstrap.min.js"></script>
<script src="<?=_MAINPATH_?>js/jquery.colorbox.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs/dt-1.10.16/datatables.min.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KRP2L32K35"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KRP2L32K35');
</script>
<meta name="google-site-verification" content="OLl8LApLn-HI99ZAIdoRVEM2M3bzj57tOLqilVtH5Ts" />
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMHKRDh51c9_wdg0sOdH95VWgVD5ZOHdM&libraries=places">
</script>
<script >
(function () {
    navigator.geolocation.getCurrentPosition(function (position) {
       console.log(position.coords.latitude)
       console.log(position.coords.longitude)
    },
    function (error) {
        console.log("The Locator was denied. :(")
    })
})();


(function () {
    navigator.geolocation.getCurrentPosition(function (position) {
            displayLocation(position.coords.latitude, position.coords.longitude)
        },
        function (error) {
            console.log("The Locator was denied :(")
        })

     function displayLocation(latitude,longitude){
    var geocoder;
    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(latitude, longitude);

    geocoder.geocode(
        {'latLng': latlng}, 
        function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    var add= results[0].formatted_address ;
                    var  value=add.split(",");

                    count=value.length;
                    country=value[count-1];
                    state=value[count-2];
                    city=value[count-3];
                   
                }
                else  {
                   // x.innerHTML = "address not found";
                }
            }
            else {
                //x.innerHTML = "Geocoder failed due to: " + status;
            }
        }
    );
}

})();



var x=document.getElementById("demo");
function getLocation(){
    if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showPosition,showError);
    }
    else{
        x.innerHTML="Geolocation is not supported by this browser.";
    }
}

function showPosition(position){
    lat=position.coords.latitude;
    lon=position.coords.longitude;
    displayLocation(lat,lon);
}

function showError(error){
    switch(error.code){
        case error.PERMISSION_DENIED:
            x.innerHTML="User denied the request for Geolocation."
        break;
        case error.POSITION_UNAVAILABLE:
            x.innerHTML="Location information is unavailable."
        break;
        case error.TIMEOUT:
            x.innerHTML="The request to get user location timed out."
        break;
        case error.UNKNOWN_ERROR:
            x.innerHTML="An unknown error occurred."
        break;
    }
}

function displayLocation(latitude,longitude){
    var geocoder;
    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(latitude, longitude);

    geocoder.geocode(
        {'latLng': latlng}, 
        function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    var add= results[0].formatted_address ;
                    var  value=add.split(",");

                    count=value.length;
                    country=value[count-1];
                    state=value[count-2];
                    city=value[count-3];
                    x.innerHTML = "city name is: " + city;
                }
                else  {
                    x.innerHTML = "address not found";
                }
            }
            else {
                x.innerHTML = "Geocoder failed due to: " + status;
            }
        }
    );
}

</script>

</head>

<body class="main-home-fmi">
	
	
	<!--  Header Middle  -->
	<div class="container">
		
        <div class="row">
			<div id="header-main" class="col-md-12 col-sm-12 col-lg-12 header header-main-top-p">
				<div class="col-sm-3 col-md-3 col-lg-4 logo"> 
					<a href="<?=_MAINPATH_?>index">
					<img src="<?=_MAINPATH_?>images/free_medical_info.gif" style="width: 100%;height: auto; margin: 0px 0 0;"></a>
					<i class="fas fa-search" id="magnifier" ></i>
				</div>
				<div class="col-sm-9 col-md-9 col-lg-8 top-search ">
					<nav class="col-sm-12">
						<div class="row">
			<ul class="col-sm-12 nav top-menu" id="set-menu-1">
				<li>
					<a href="<?=_MAINPATH_?>">Home</a>
				</li>
				<?
				$res_tm = fetchAllDatas(" `top_menu` "); 
				foreach($res_tm as $v ){
				?>
				<li class="datab-get-menus get-menu-pp">
					<a href="<?=_MAINPATH_?>page/id/<?=$v['id']?>"><?=$v['title']?></a>
				</li>
				
				<? } ?>
				<li>
					<a href="<?=_MAINPATH_?>blog">Blog</a>
				</li>
				<li>
					<a href="<?=_MAINPATH_?>deal-list">Deals</a>
				</li>
				
			</ul>
			<ul class="col-sm-12 nav top-menu pull-right simple-sign-login">
			<? if(empty($_SESSION['userId'])){ ?>
			 <li><i class="fa fa-sign-in"></i><a class='ajax' href="/registration">Register</a>/<a class='ajax' href="/login">Login</a></li>
			 <? } else { ?>
			 <li>  
				<a href="<?=_MAINPATH_?>profile"><strong>Welcome:</strong> <?if(!empty($_SESSION['userName'])){ echo ucwords($_SESSION['userName']); } else { echo $_SESSION['uid']; } ?></a>
				<a href="<?=_MAINPATH_?>logout">Logout</a>
			  </li>
			<? } ?>
			</ul>
			<!--
			<ul class="nav top-menu pull-right">
			<? if(empty($_SESSION['userId'])){ ?>
			  <li class="text-uppercase"><a class='ajax' href="/registration">Register</a></li>
			  <li class="text-uppercase"><a class='ajax' href="/login">Login</a></li>
			<? } else { ?>
				<li>  
				<a href="<?=_MAINPATH_?>profile"><strong>Welcome:</strong> <?if(!empty($_SESSION['userName'])){ echo ucwords($_SESSION['userName']); } else { echo $_SESSION['uid']; } ?></a>
			  </li>
			  <li><a href="<?=_MAINPATH_?>logout">Logout</a></li>
			<? } ?>
			</ul>
			-->
			</div>
		</nav>
		
				</div>
			</div>
		</div>
	</div>
	

	
	<!-- End  Header Middle  -->
	
    <!-- Navigation -->
    <nav class="navbar navbar-inverse category-link-header-p" role="navigation">
        
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<div class="container">
                <ul class="nav navbar-nav">
					<li class="browse-more-in-f">
                        <a>BROWSE</a>
                    </li>
                    <li>
                        <a href="<?=_MAINPATH_?>doctors">Doctors</a>
                    </li>
                    <li>
                        <a href="<?=_MAINPATH_?>hospitals">Hospitals / Clinics</a>
                    </li>
                    <?
					$res_mm = fetchAllDatas(" `main_menu` " ); 
					foreach($res_mm as $v ){
					?>
					<li>
						<a href="<?=_MAINPATH_?>hospital-cat-list/CId/<?=$v['host_cat']?>"><?=$v['menu_title']?></a>
					</li>
					
					<? } ?>
					<li>
                        <a href="<?=_MAINPATH_?>doctors/speci/12">Homeopathy</a>
                    </li>
					<li>
                        <a href="<?=_MAINPATH_?>doctors/speci/70">Ayurvedic</a>
                    </li>
					<li>
                        <a href="<?=_MAINPATH_?>others">Others</a>
                    </li>
					
	
				<li class="mobilem">
					<a href="<?=_MAINPATH_?>">Home</a>
				</li>
				<?
				$res_tm = fetchAllDatas(" `top_menu` "); 
				foreach($res_tm as $v ){
				?>
				<li class="mobilem datab-get-menus get-menu-pp">
					<a href="<?=_MAINPATH_?>page/id/<?=$v['id']?>"><?=$v['title']?></a>
				</li>
				
				<? } ?>
				<li class="mobilem">
					<a href="<?=_MAINPATH_?>blog">Blog</a>
				</li>
				<li class="mobilem">
					<a href="<?=_MAINPATH_?>deal-list">Deals</a>
				</li>
				
					
                </ul>
				</div>
				<!-- /.container -->
            </div>
            <!-- /.navbar-collapse -->
        
        
    </nav>
<?php 
	$url="https://dev.freemedicalinfo.in/";
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	
	if($url == $actual_link)
	{
		
	}
	else{
?>
<div class="main-banner-top-h" id="inner-page-banner" style="display:none;">
	<div class="container">
		<div class="row">
			<div id="header-main" class="col-md-12 header2-bottom-banner">
				<div class="col-sm-12  col-md-12 caption-full">
					<h1 class="heading text-uppercase">Medical <span style="color:#ed1c24;">Services</span></h1>
					<p>The Largest online database of patient reviews for doctors, facilities and online Appointment.</p>
				</div>

				<div class="col-sm-12 col-md-12 top-search search-by-home">
					<?php include("include/searchbar.php"); ?>
				</div>
			</div>
		</div>
	</div>
</div>
<? } ?>
<script>
	$(document).ready(function(){
		$("#magnifier").click(function(){
			$("#inner-page-banner").show();
		});
	});
</script>
	
<?
	include('include/connection.php');
	include('include/function.php');
	$current_date = date('Y/m/d h:i:s');
	
	 
	// user registration	
	if($_REQUEST['regForm']=="userForm"){
		if(!empty($_REQUEST['user_id'])) {
			$countU = countRow(" all_users ", " where user_id = '".$_REQUEST['user_id']."' ");
			if($countU>0){
				$error[] = 'User Id provided is already in use.';
			}	
		}
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
		if(strlen($_REQUEST['pw']) < 6){
			$error[] = 'Password is too short.';
		}
		if(!isset($error)){
			$activasion = md5(uniqid(rand(),true));
			$ins = "insert into users set
			`user_id` = '".$_REQUEST['user_id']."',  
			`first_name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."',
			`password` = '".$_REQUEST['pw']."', 
			`email` = '".$_REQUEST['email']."',
			`date_birth` = '".$_REQUEST['dob']."',
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn);
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-user&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			
          	
			mysqli_query($conn,"insert into `all_users` set user_id = '".$_REQUEST['user_id']."', user_type = 'user', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
			
			echo "success";
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	// doctor registration
	if($_REQUEST['regForm']=="doctorForm"){
		if(!empty($_REQUEST['user_id'])) {
			$countU = countRow(" all_users ", " where user_id = '".$_REQUEST['user_id']."' ");
			if($countU>0){
				$error[] = 'User Id provided is already in use.';
			}	
		}
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
		if(strlen($_REQUEST['pw']) < 6){
			$error[] = 'Password is too short.';
		}
		if(!isset($error)){
			$activasion = md5(uniqid(rand(),true));
			$ins = "insert into doctor_registration set
			`user_id` = '".$_REQUEST['user_id']."',
			`name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."',
			`password` = '".$_REQUEST['pw']."', 
			`email` = '".$_REQUEST['email']."',
			`date_birth` = '".$_REQUEST['dob']."',
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			
		
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn); 
					
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-doctor&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			mysqli_query($conn,"insert into `all_users` set user_id = '".$_REQUEST['user_id']."', user_type = 'doctor', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
          			
			echo "success";
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	
	// hospital registration
	if($_REQUEST['regForm']=="hospitalForm"){

		if(!empty($_REQUEST['user_id'])) {
			$countU = countRow(" all_users ", " where user_id = '".$_REQUEST['user_id']."' ");
			if($countU>0){
				$error[] = 'User Id provided is already in use.';
			}	
		}
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
		if(strlen($_REQUEST['pw']) < 6){
			$error[] = 'Password is too short.';
		}
		if(!isset($error)){
			$activasion = md5(uniqid(rand(),true));
			$ins = "insert into medical_registration set
			`user_id` = '".$_REQUEST['user_id']."',  
			`name` = '".$_REQUEST['fname']."',
			`O_contact` = '".$_REQUEST['phone']."',
			`password` = '".$_REQUEST['pw']."', 
			`email` = '".$_REQUEST['email']."',  
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn);
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-hospital&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
          	
			mysqli_query($conn,"insert into `all_users` set user_id = '".$_REQUEST['user_id']."', user_type = 'hospital', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
			
			echo "success";
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
	
	// Other Medical Service registration
	if($_REQUEST['regForm']=="other-medical"){
		if(!empty($_REQUEST['user_id'])) {
			$countU = countRow(" all_users ", " where user_id = '".$_REQUEST['user_id']."' ");
			if($countU>0){
				$error[] = 'User Id provided is already in use.';
			}	
		}
		if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)){
			$error[] = 'Please enter a valid email address';
		} else {
			$countE = countRow(" `all_users` ", " where email = '".$_REQUEST['email']."' ");
			if($countE>0){
				$error[] = 'Email provided is already in use.';
			}	
		}
		if(strlen($_REQUEST['pw']) < 6){
			$error[] = 'Password is too short.';
		}
		if(!isset($error)){
		    if($_REQUEST['fld'] == 'other')
		    {
		    
		   $fld =    $_REQUEST['fldedu'];
		        
		    }else{
		    
		    $fld =    $_REQUEST['fld'];    
		        
		    }
		   
			$activasion = md5(uniqid(rand(),true));
			$ins = "insert into other_service_registration set
			`user_id` = '".$_REQUEST['user_id']."', 
            `name` = '".$_REQUEST['fname']."',
			`phone_no` = '".$_REQUEST['phone']."',			
			`password` = '".$_REQUEST['pw']."', 
			`email` = '".$_REQUEST['email']."',  
			`service` = '".$fld."',  
			`active` = '".$activasion."',
			`insert_date` = '".$current_date."'
			";
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id($conn);
			
			$to = $_REQUEST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-other&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
			
			mysqli_query($conn,"insert into `all_users` set user_id = '".$_REQUEST['user_id']."', user_type = 'other', userId = '".$id."', email = '".$_REQUEST['email']."' ") or die(mysqli_error());
          			
			echo "success";
		} else {
				foreach($error as $er)
				if(!empty($er)){
					$msg .= '<div class="alert alert-warning">
					  <strong>Warning! </strong>' . $er . '
					</div>';
				}
				$msg .= "<center><span class='btn btn-warning' onclick=\"document.getElementById('loginError').style.display = 'none';\" >Clear Error!</span></center>";
				echo "<br/><br/><br/>".$msg;
		}
	}
?>
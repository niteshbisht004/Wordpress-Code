<style>
	.rating {
		font-size: 22px;

	}

	.rating-md {
		font-size: 0px;
	}

	.pagini .dpaginations {
		text-align: right;
		float: right;
		margin-bottom: 20px;
	}
</style>
<link href="/css/simplePagination.css" type="text/css" rel="stylesheet">
<div class="">
	<div class="col-md-6 all-result-sort-title">
		<h2>ALL doctors available</h2>
		<p>Book appointments with minimum wait-time & verified doctor details</p>


	</div>
	
	<div class="col-md-6 multi-dr-search-r">
		<input id="txtSearchPage" type="search" class="form-control" placeholder="Search" /><br/>
	</div>
	<div class="col-md-12 col-lg-12 dproduct1 detail-doc-grids pc-dr-sm" id="results">
		<div class="row">
			<? 
			$spec = $_GET['speci'];
			if($spec == ''){
			$j = 1;
			foreach ($res_doctor as $doct) { ?>
				<div  class="item itemd <?if ($j<=12){echo "showfirst"; } ?> col-xs-6 col-md-4 col-lg-4 col-xl-4 text-left">
				<a href="/<?= $doct['user_id'] ?>" target="_blank">
					<div class="d-details-per-column">
						<? if ($doct['pro_img'] != "") { ?>
							<img src="/images/profile/<?= $doct['pro_img'] ?>" class="">
						<? } else { ?>
							<img src="/images/doctor-face.jpg">
						<? } ?>
						<div class="col-sm-12 in-details-main-f featured-color">
							<p class="name-d"><?php echo ucfirst($doct['name']) ?><?php if($doct['featured'] == 1){ ?><svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="aUHaEe" style="width:20px !important; padding-left:6px;"><path fill="#1A73E8" d="M17.6261 9.70416L17.914 9.375L17.6261 9.04584L15.9373 7.1148L16.1726 4.56088L16.2129 4.12449L15.7855 4.02742L13.2882 3.46016L11.9803 1.24573L11.7566 0.867028L11.3525 1.04057L8.99975 2.05085L6.64704 1.04057L6.24347 0.867267L6.01959 1.24514L4.71213 3.4519L2.21529 4.01213L1.78666 4.10831L1.82685 4.54575L2.06228 7.10776L0.372801 9.04651L0.0860338 9.37559L0.373384 9.70416L2.06223 11.6353L1.82685 14.1967L1.78676 14.633L2.214 14.7301L4.71174 15.2974L6.01959 17.5049L6.24403 17.8837L6.64818 17.7089L9.00043 16.6919L11.3525 17.7019L11.756 17.8752L11.9799 17.4974L13.2878 15.2899L15.7855 14.7226L16.2129 14.6255L16.1726 14.1891L15.9373 11.6352L17.6261 9.70416ZM5.82649 9.65537L7.21294 11.0478L7.5671 11.4035L7.92141 11.048L11.9554 7.00021L12.1562 7.20105L12.3581 7.40298L7.56724 12.2069L5.4239 10.058L5.82649 9.65537Z" stroke="white"></path></svg><?php } ?></p>
							<p class="special-d">
								<? 
								$specialisation = explode("|", $doct['specialisation']);
								$x=0;
								foreach ($specialisation as $spec)
								{
									if($x==0)
									{
										echo $specialisations[$spec];
									}
									else{}
								$x++;
								}
								?>
							</p>
							<div class="rating-container rating-xs rating-animate">
								<div class="average-rating-d">
									<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");


									$r = 0;
									$i = 0;
									foreach ($res_cmt as $rat) {
										$r = $rat['rate'] + $r;
										$i++;
									}
									$r = $r / $i;
									
									if (is_nan($r)) {
										$r = 0;
									}
									$r = round($r, 1);
									if ($r == 0) {
										$var = '0%';
									}
									if ($r >= 1 && $r <= 1.5) {
										$var = '20%';
									}
									if ($r >= 1.5 && $r <= 2) {
										$var = '30%';
									}
									if ($r >= 2 && $r <= 2.5) {
										$var = '40%';
									}
									if ($r >= 2.5 && $r <= 3) {
										$var = '50%';
									}
									if ($r >= 3 && $r <= 3.5) {
										$var = '60%';
									}
									if ($r >= 3.5 && $r <= 4) {
										$var = '70%';
									}
									if ($r >= 4 && $r <= 4.5) {
										$var = '80%';
									}
									if ($r >= 4.5 && $r <= 5) {
										$var = '90%';
									}
									if ($r == 5) {
										$var = '100%';
									}
									?>
									<? if ($r == 0) {
									} else { ?><span><?php 
									
								$uid = $doct['id'];
								$sel = "Update doctor_registration SET arate='$r' WHERE id = $uid";
									
									$que_sel = mysqli_query($conn,$sel);
									
									echo $r; ?></span><? } ?>
								</div>
								<div class="rating">
									<a style="" href="/rating/<?= $doct['user_id'] ?>">
										<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span></span>
										<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
									</a>
								</div>
							</div>
							</a>
							<p class="special-add"><?php echo $doct['address']; ?></p>
							<?php 
							
							$apdatecou = fetchAllData(" `deals` ", " where 	doctor_id = '" . $doct['id'] . "'");
							$num = count($apdatecou);
							 $titd =  $apdatecou[0]['1'];
				$divider = '-';
                	$texts = preg_replace('~[^\pL\d]+~u', $divider, $titd);
							  // transliterate
							  $texts = iconv('utf-8', 'us-ascii//TRANSLIT', $texts);
							  // remove unwanted characters
							  $texts = preg_replace('~[^-\w]+~', '', $texts);
							  // trim
							  $texts = trim($texts, $divider);
							  // remove duplicate divider
							  $texts = preg_replace('~-+~', $divider, $texts);
							  // lowercase
							  $texts = strtolower($texts);
							$dealid = $apdatecou[0][0];	
							if($num >= 1){ ?>
							<a class="btn btn-success bookapp gc ajax cboxElement" href="/deallist/?id=<?= $doct['id']; ?>&usertype=doctor">Book Appointment</a>		
								
							<?php }else{
							?>
							<a class="btn btn-success bookapp gc" href="/generate-coupon.php?userid=<?= $doct['id'] ?>&usertype=doctor">Book Appointment</a>
							<?php } ?>
						</div>
						
					</div>
				
				
				
				
				
				</div>
			<?
			$j++;
			}
			}else{
				
				$j = 1;
				
			foreach ($res_doctor as $doct) {
				
			$specialisation = explode("|", $doct['specialisation']);
           			
            if ($specialisation[0] == $doct['specialisation'] || $spec == $doct['specialisation'] || $specialisation[1] == $doct['specialisation'])
			  {
			 
				?>
				<div  class="item itemd <?if ($j<=12){echo "showfirst"; } ?> col-xs-6 col-md-4 col-lg-4 col-xl-4 text-left">
				<a href="/<?= $doct['user_id'] ?>" target="_blank">
					<div class="d-details-per-column">
						<? if ($doct['pro_img'] != "") { ?>
							<img src="/images/profile/<?= $doct['pro_img'] ?>" class="">
						<? } else { ?>
							<img src="/images/doctor-face.jpg">
						<? } ?>
						<div class="col-sm-12 in-details-main-f featured-color">
							<p class="name-d"><?php echo ucfirst($doct['name']) ?><?php if($doct['featured'] == 1){ ?><svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="aUHaEe" style="width:20px !important; padding-left:6px;"><path fill="#1A73E8" d="M17.6261 9.70416L17.914 9.375L17.6261 9.04584L15.9373 7.1148L16.1726 4.56088L16.2129 4.12449L15.7855 4.02742L13.2882 3.46016L11.9803 1.24573L11.7566 0.867028L11.3525 1.04057L8.99975 2.05085L6.64704 1.04057L6.24347 0.867267L6.01959 1.24514L4.71213 3.4519L2.21529 4.01213L1.78666 4.10831L1.82685 4.54575L2.06228 7.10776L0.372801 9.04651L0.0860338 9.37559L0.373384 9.70416L2.06223 11.6353L1.82685 14.1967L1.78676 14.633L2.214 14.7301L4.71174 15.2974L6.01959 17.5049L6.24403 17.8837L6.64818 17.7089L9.00043 16.6919L11.3525 17.7019L11.756 17.8752L11.9799 17.4974L13.2878 15.2899L15.7855 14.7226L16.2129 14.6255L16.1726 14.1891L15.9373 11.6352L17.6261 9.70416ZM5.82649 9.65537L7.21294 11.0478L7.5671 11.4035L7.92141 11.048L11.9554 7.00021L12.1562 7.20105L12.3581 7.40298L7.56724 12.2069L5.4239 10.058L5.82649 9.65537Z" stroke="white"></path></svg><?php } ?></p>
							<p class="special-d">
								<? 
								$specialisation = explode("|", $doct['specialisation']);
								$x=0;
								foreach ($specialisation as $spec)
								{
									if($x==0)
									{
										echo $specialisations[$spec];
									}
									else{}
								$x++;
								}
								?>
							</p>
							<div class="rating-container rating-xs rating-animate">
								<div class="average-rating-d">
									<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");


									$r = 0;
									$i = 0;
									foreach ($res_cmt as $rat) {
										$r = $rat['rate'] + $r;
										$i++;
									}
									$r = $r / $i;
									if (is_nan($r)) {
										$r = 0;
									}
									$r = round($r, 1);
									if ($r == 0) {
										$var = '0%';
									}
									if ($r >= 1 && $r <= 1.5) {
										$var = '20%';
									}
									if ($r >= 1.5 && $r <= 2) {
										$var = '30%';
									}
									if ($r >= 2 && $r <= 2.5) {
										$var = '40%';
									}
									if ($r >= 2.5 && $r <= 3) {
										$var = '50%';
									}
									if ($r >= 3 && $r <= 3.5) {
										$var = '60%';
									}
									if ($r >= 3.5 && $r <= 4) {
										$var = '70%';
									}
									if ($r >= 4 && $r <= 4.5) {
										$var = '80%';
									}
									if ($r >= 4.5 && $r <= 5) {
										$var = '90%';
									}
									if ($r == 5) {
										$var = '100%';
									}
									?>
									<? if ($r == 0) {
									} else { ?><span><?php echo $r; ?></span><? } ?>
								</div>
								<div class="rating">
									<a style="" href="/rating/<?= $doct['user_id'] ?>">
										<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
											</span></span>
										<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span>
											<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
									</a>
								</div>
							</div>
							</a>
							<p class="special-add"><?php echo $doct['address']; ?></p>
								<?php 
							
							$apdatecou = fetchAllData(" `deals` ", " where 	doctor_id = '" . $doct['id'] . "'");
							$num = count($apdatecou);
							 $titd =  $apdatecou[0]['1'];
				$divider = '-';
                	$texts = preg_replace('~[^\pL\d]+~u', $divider, $titd);
							  // transliterate
							  $texts = iconv('utf-8', 'us-ascii//TRANSLIT', $texts);
							  // remove unwanted characters
							  $texts = preg_replace('~[^-\w]+~', '', $texts);
							  // trim
							  $texts = trim($texts, $divider);
							  // remove duplicate divider
							  $texts = preg_replace('~-+~', $divider, $texts);
							  // lowercase
							  $texts = strtolower($texts);
							$dealid = $apdatecou[0][0];	
							if($num >= 1){ ?>
							<a class="btn btn-success bookapp gc ajax cboxElement" href="/deallist/?id=<?= $doct['id']; ?>&usertype=doctor">Book Appointment</a>		
								
							<?php }else{
							?>
							<a class="btn btn-success bookapp gc" href="/generate-coupon.php?userid=<?= $doct['id'] ?>&usertype=doctor">Book Appointment</a>
							<?php } ?>
						</div>
						
					</div>
				
				</div>
			  <?
			  
			  $j++;
			  }else{
				  
				  
			  }
			
			}	
				
				
			}
			
			?>
		</div>
	</div>
	<div class="col-md-12 pagini">
		<div class="dpaginations">
		</div>
		
	</div>
</div>
<script>$(".ajax").colorbox();</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <script type="text/javascript" src="https://flaviusmatis.github.io/simplePagination.js/jquery.simplePagination.js"></script>
   
<script>

      jQuery(function(jQuery) {
                var items = jQuery(".itemd");

                var numItems = items.length;
                var perPage = 9;

                // Only show the first 2 (or first `per_page`) items initially.
                items.slice(perPage).hide();

                // Now setup the pagination using the `#pagination` div.
                jQuery(".dpaginations").pagination({ 
                    items: numItems,
                    itemsOnPage: perPage,
					displayedPages:2,
					edges:2, 
                    cssStyle: "light-theme",

                    // This is the actual page changing functionality.
                    onPageClick: function(pageNumber) {
						//jQuery(window).scrollTop(0);
						jQuery("html, body").animate({ scrollTop: "200" }, 1000);

                        // We need to show and hide `tr`s appropriately.
                        var showFrom = perPage * (pageNumber - 1);
                        var showTo = showFrom + perPage;

                        // We'll first hide everything...
                        items.hide()
                             // ... and then only show the appropriate rows.
                             .slice(showFrom, showTo).show();
							 
                    }
                });
            });
			
			
$("#txtSearchPage").keyup(function() {

        var search = $(this).val();
   
		if(search == ''){
			 $(".itemd").hide();
	    $('#results .showfirst').show();
				
		}else{
		     $(".itemd").show();
		
        if (search)
            $(".itemd").not(":containsNoCase(" + search + ")").hide();	
			
		}
		
});

$.expr[":"].containsNoCase = function (el, i, m) {
    var search = m[3];
    if (!search) return false;
      return new RegExp(search,"i").test($(el).text());
};



</script>

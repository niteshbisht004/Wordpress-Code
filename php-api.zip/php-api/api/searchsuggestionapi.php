<?php
error_reporting(0);
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
   header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
    
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	
     include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db); 
	
	include_once 'classes/city.php';
	$cityitems = new Cities($db);

	include_once 'classes/states.php';
	$stateitems = new States($db);

	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['search'];
	$vals = $_POST['cat'];
	
	
	
    if($vals == 'doctor'){
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getdoctorsuggestions($val);
	
	$itemCount = mysqli_num_rows($stmt);
      $cityArr = array();
       $allArr = array();
    if($itemCount > 0){
        
        
          while ($row = $stmt->fetch_assoc()){
			
			           $userArr[] = $row;
			 	 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
	 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}

            $citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);
			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];			
					 
			 $allArr[] = array_merge($row,$cityArr);	 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
		exit;		
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;	
    }
	}else if($vals == 'hospital'){
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->gethospitalsuggestions($val);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
          $cityArr = array();
          $allArr = array();
          while ($row = $stmt->fetch_assoc()){
			
            $userArr[] = $row;
			 		
			 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}		
			
			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);
			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];	

			
			 $allArr[] = array_merge($row,$cityArr);			 
				 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
		exit;		
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;	
    }
	}else{
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getsearchsuggestions($val);
	
	$itemCount = mysqli_num_rows($stmt);
    
    if($itemCount > 0){
        
        
          while ($row = $stmt->fetch_assoc()){
			
            $userArr[] = $row;
			 $spec = explode("|",$row['specialisation']);
			if(empty($spec)){
				$specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] = $specialname[0];	
				
			}else{
			foreach($spec as $val){
			$specialstmt = $specialitems->getSingleSpecial($val);
			 $specialname =  mysqli_fetch_row($specialstmt);
			$cityArr['specialisationname'] .= $specialname[0].',';
			}
			}		
			
			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);
			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];	

			
			 $allArr[] = array_merge($row,$cityArr);	
			 		
					 
				 
        }
		
	$response['message']="Data Found";
	$response['status']=1;
	$response['data']= $allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
		exit;		
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;	
    }
	}
	
	
	
?>
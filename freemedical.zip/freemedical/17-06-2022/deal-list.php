<? include("include/header.php");

//Specialisation List
$resHD = mysqli_query($conn, "SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$specialisations[$data['id']] = utf8_encode($data['specialisation']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM cities") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$cities[$data['id']] = utf8_encode($data['name']);
		$c++;
	}
}


?>

<div class="detail-list-front">
	<div class="container">
		<div class="col-md-12 col-xs-12 col-sm-2 in-filter-sets">
			<div class="row">
				<form method="get" id="form1" name="special" action="">
					<div class="col-md-6 col-sm-12 col-xs-12 fiter-top-mainp" id="form-set-filter1">
						<select name="speci" id="specsdr" class="form-control" onchange="doSelect(this)" data-live-search="true">
							<option value="">All Specialisations</option>
							<?php
							foreach ($specialisations as $ke => $spe) {
								$selected = "";
								$selected = ($ke == $_GET['speci']) ? "selected" : "";
								echo "<option value='$ke' $selected>" . $spe . "</option>";
							}
							?>
						</select>
					</div>
                    	<div class="col-md-6">
					<input id="txtSearchPagee"  value="<?php echo $_GET['term']; ?>" name="term" type="search" class="form-control" placeholder="Search By Doctor/Hospital/Other/Deal" />
					</div>
					
				
				</form>
			</div>
		</div>
		
		
		
		
		
		
		
		
		
		
	</div>
</div>
<div class="container" style="padding-left:0px; padding-right:0px;">
			<div class="col-md-9">
<!--deals-->

				<?php
				/*
				$res_deal = fetchAllDatas(" `deals` ");
				foreach ($res_deal as $deal) {
					$image = $deal['image'];
					if ($image != "") {

						$image = "/admin/images/uploads/$image";
					} else {

						$image = "/images/hot-deals-demo.jpg";
					}

					$doctor = $deal['doctor_id'];
					$hospital = $deal['hospital_id'];
					$other = $deal['other_id'];
					if ($doctor != "") {
						$offer_by = fetchData(" `doctor_registration` ", " where id= '" . $doctor . "' ");
					}
					if ($hospital != "") {
						$offer_by = fetchData(" `medical_registration` ", " where id= '" . $hospital . "' ");
					}
					if ($other != "") {
						$offer_by = fetchData(" `other_service_registration` ", " where id= '" . $other . "' ");
					}
					$offerby =  ucwords($offer_by['name']);

				?>
					<div class="col-md-3 text-center">
						<div class="set-sider-top-img">

							<img src="<?php echo $image; ?>">

							<p class="text-left"><a href="/deal/id/<?= $deal['id']; ?>"><?php echo $deal['title']; ?></a></p>
							<span class="deal-valid text-left"><strong>Offered By : </strong><?php echo $offerby; ?></span>

						</div>
					</div>
				<?php
				}
				*/?>
				
				<?php
						/*
						if($_GET['term'] != "")
						{
						
							$cond = '';
					if (isset($_GET['speci']) && !empty($_GET['speci']) ) {
										
							$cond .= "or specialisation LIKE '%".$_GET['speci']."%'";
									
									}
									
							
										
									if (isset($_GET['city']) && !empty($_GET['city']) ) {
										
										$cond .= " or city like '%".$_GET['city']."%' ";
										
									}
									
									//var_dump($cond);
									
								
				
				
						
								$search_item=addslashes($_GET['term']);
								
								$string = explode(" ", $search_item);  
				 
								$omit_words = array('the','for','in','or','to','and','doctors','hospitals','others','deals','Dr');  
								$result = array_diff($string,$omit_words);
							
								 foreach($result as $val){
									 if($val == ''){
											 
										 
									 }else{
									 $res .= "or keywords like '%$val%'";				
									 }
								 }
											
						
								$query_disease=mysqli_query($conn,"select * from `disease` where keywords like 'sfsdfdsf' $res order by id DESC") or die(mysqli_error());
								$num_disease = mysqli_num_rows($query_disease);	
								$specid = array();
								while($row = mysqli_fetch_array($query_disease)){
								  $specid[] = $row['spec_id'];
								}
												
										
								
								?>
				<!-- ***** Deals code Start****-->
					
				<?
					
					
					
									
					if($num_disease>0){	
				
				foreach($specid as $sval){
					if($sval == ''){
						
						
					}else{
					$redp .= " or specialisation = $sval";
					}
				}
				     $term =  $_GET['term'];
					 $res_deal = fetchAllData(" `deals` ", " WHERE title like '%$term%' or specialisation = 79878979  $redp");
						
					if(!empty($res_deal)){		
			
				include("deal_result.php");	 	
				}else{
				$res_deal = fetchAllDatas(" `deals` ");	
				include("deal_result.php");	 					
				}
                  		

					
					
				}else{
					
				$string = explode(" ", $search_item);  

				$omit_words = array('the','for','in','or','to','and','doctors','hospitals','others','deals','Dr');  
				$result = array_diff($string,$omit_words);
                 foreach($result as $val){
					 if($sval == ''){
						 
					 }else{
					 $rest .= " or specialisation like '%$val%'";
					 }
				 }
		       		
			     $querySP = mysqli_query($conn,"select * from `specialisation` WHERE specialisation like '%doctors%' $rest ");
					
				$num_SP = mysqli_num_rows($querySP);
				
				$sp_id = mysqli_fetch_array($querySP);
				$specid = $sp_id['id']; 	 
				
				$res_deal = fetchAllData(" `deals` ", " where specialisation = $specid ");
				if(!empty($res_deal)){	
					include("deal_result.php");
				}else{
					
					
				$string = explode(" ", $search_item);  

				$omit_words = array('the','for','in','or','to','and','doctors','hospitals','others','deals','Dr');  
				$result = array_diff($string,$omit_words);
				
                 foreach($result as $val){
					 if($val == ''){
						 
					 }else{
					 $drest .= " or title like '%$val%'";
					 }
				 }
		       		
		       
				$res_deal = fetchAllData(" `deals` ", " WHERE title = 'doctors' $drest");	
				if(!empty($res_deal)){		
			
				include("deal_result.php");	 	
				}else{
				$res_deal = fetchAllDatas(" `deals` ");	
				include("deal_result.php");	 					
				}	
				}
				
					
				}
					
			}else{ 
				
				if (isset($_GET['speci']) && !empty($_GET['speci']) ) {
							$res_deal = fetchAllData(" `deals` ","WHERE specialisation LIKE '%".$_GET['speci']."%'");	
				
							
				include("deal_result.php");
				}else{
				$res_deal = fetchAllDatas(" `deals` ");	
				include("deal_result.php");	
				}
			}					
			*/		 
				
			if (isset($_GET['speci']) && !empty($_GET['speci']) ) {			
				$res_deal=fetchAllData("`deals`", "WHERE specialisation = '".$_GET['speci']."' OR specialisation LIKE '%|".$_GET['speci']."|%' OR specialisation LIKE '%".$_GET['speci']."|%' OR specialisation LIKE '%|".$_GET['speci']."%' order by deal_date DESC");	
			     //echo "`deals`", "WHERE specialisation = '".$_GET['speci']."' OR specialisation LIKE '%|".$_GET['speci']."|%' OR specialisation LIKE '%".$_GET['speci']."|%' OR specialisation LIKE '%|".$_GET['speci']."%' order by deal_date DESC";
					if(!empty($res_deal))
					{
						
						
						include("deal_result.php");
					}
					else
					{
						$res_deal = fetchAllDatas(" `deals` order by deal_date DESC ");	
						include("deal_result.php");	
					}
							
				}
				else
				{	
					$res_deal = fetchAllDatas(" `deals` order by deal_date DESC");	
					include("deal_result.php");	
				}	
				
				
					?>
		</div>
		<div style="padding-top:45px;" class="col-md-3">

<script src="https://lab.iamrohit.in/demo/jquery-bootstrap-news-ticker/jquery.bootstrap.newsbox.min.js" type="text/javascript"></script>
		<?php include("include/advertisement.php"); ?>
		</div>

				</div>
		
<script>


function doSelect(el){
sel = el.options[el.selectedIndex].value;
	if(sel == "-"){
		alert("Please choose an option");
	}
	else{
		el.form.submit();
	}
}
</script>	
<script>
	$(document).ready(function(){
		$("#magnifier").click(function(){
			
			$("#inner-page-banner").show();
		});
	});
</script>	
<? include('include/footer.php'); ?>


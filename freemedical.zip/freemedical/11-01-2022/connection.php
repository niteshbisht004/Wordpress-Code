<?
session_start();
ob_start();
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
$conn = mysqli_connect("localhost","freeemed_sisdev","MWA13Bw6t)PB","freeemed_sisdev");

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";
 
//If the HTTPS is not found to be "on"
if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on")
{
    //Tell the browser to redirect to the HTTPS URL.
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"], true, 301);
    //Prevent the rest of the script from executing.
    exit;
}




date_default_timezone_set("Asia/Calcutta"); 
/************************************************Redirect Page***************************************************/

function admin_redirect()
 {
	if($_SESSION[admin_type]=="")
	 {
			//header("location:index.php");
			echo "<script>window.location.replace('index.php')</script>";
	 }
 }
 
  function isadmin()
 {
	if($_SESSION['admin_type']!="Admin")
	 {
			//header("location:home.php");
			echo "<script>window.location.replace('home.php')</script>";
	 }
 }

/************************************************ USER Redirect Page***************************************************/

function user_redirect()
 {
	if($_SESSION['id']=="")
	 {
	 	if($_SESSION['tempid']=='')
		 {
			header("location:"._MAINPATH_);
		 }
	 }
	 
 }

/************************ Maximum Execution Time **************/
ini_set("max_execution_time",3600); 

/*********************** Admin Title **************************/


/************* GET FILE EXTENSION ***********************/
function getFileExtension($str)
{
$i = strrpos($str,".");
if (!$i) { return "";
}
$l = strlen($str) - $i;
$ext = substr($str,$i+1,$l);
return $ext;
}


define("_MAINPATH_","https://dev.freemedicalinfo.in/");
define("_MAIL_"," contact@freemedicalinfo.in");


?>

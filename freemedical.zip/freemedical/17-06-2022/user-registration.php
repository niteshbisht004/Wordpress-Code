<? include("include/header.php"); ?>
<? if(!empty($_SESSION['userEmail'])) {  header('location:/profile.php');  } ?>
<?
	if(isset($_POST['user']) && $_POST['user'] != ""){
		
	$userId = $_POST['user'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$gender = $_POST['gender'];
	$qualification = implode("|",$_POST["qualification"]);
	$interested = implode("|",$_POST["interested"]);
    $dateBirth = $_POST['dateBirth'];
	$countryCode = $_POST['countryCode'];
	$stdCode = $_POST['stdCode'];
	$phoneNo = $_POST['phoneNo'];
	$cphoneNo = $countryCode."-".$stdCode."-".$phoneNo;
	$mobileNo = $_POST['mobileNo'];
	$address = $_POST['address'];
	$country = $_POST['country'];
	$states = $_POST['state'];
	$city = $_POST['city'];
	$yLikeRecieved = implode("|",$_POST["yLikeRecieved"]);
	$secuirtyQ = $_POST['secuirtyQ'];
	$answer = $_POST['answer'];
	$password = $_POST['password'];
		
	if(!empty($userId)) {
		$countU = countRow(" `users` ", " where user_id = '".$userId."' ");
		if($countU>0){
			$error[] = 'User Id provided is already in use.';
		}	
	}
	
	if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
	    $error[] = 'Please enter a valid email address';
	} else {
		$countE = countRow(" `users` ", " where email = '".$_REQUEST['email']."' ");
		if($countE>0){
			$error[] = 'Email provided is already in use.';
		}	
	}
	
	if(strlen($_POST['password']) < 6){
		$error[] = 'Password is too short.';
	}

		if(!isset($error)){
			
			if(!empty($_FILES['photo']['name'])){
				$img = fileUpload("images/profile/", $_FILES['photo'], "jpg|png|jpeg", true);
			} else {
				$img = "";
			}
			
			$activasion = md5(uniqid(rand(),true));
			
			$ins = "insert into users set
			`user_id` = '".$userId."', 
			`first_name` = '".$fname."', 
			`last_name` = '".$lname."', 
			`pro_img` = '".$img."', 
			`gender` = '".$gender."', 
			`qualification` = '".$qualification."', 
			`interested` = '".$interested."', 
			`date_birth` = '".$dateBirth."', 
			`password` = '".$password."', 
			`security_ques` = '".$secuirtyQ."', 
			`answer` = '".$answer."', 
			`email` = '".$_POST['email']."', 
			`phone_no` = '".$cphoneNo."', 
			`mobile_no` = '".$mobileNo."', 
			`address` = '".$address."', 
			`country` = '".$country."', 
			`state` = '".$states."', 
			`city` = '".$city."',  
			`y_like_recieved` = '".$yLikeRecieved."', 
			`active` = '".$activasion."'
			";
			$que = mysqli_query($conn,$ins) or die(mysqli_error());
			$id = mysqli_insert_id();
			
			$insrew = "insert into rewards set
					`user_id` = '".$userId."',
			";
			
			
			$to = $_POST['email'];
			$subject = "Registration Confirmation";
			$body = "Thank you for registering at freemedicalinfo site.\n\n To activate your account, please click on this link:\n\n "._MAINPATH_."account-active.php?x=$id-user&y=$activasion\n\n Regards Site Admin \n\n";
			$additionalheaders = "From: <"._MAIL_.">\r\n";
			$additionalheaders .= "Reply-To: "._MAIL_."";
			mail($to, $subject, $body, $additionalheaders);
          			
			header('Location:/registration-successful.php');
		} else {
			foreach($error as $er)
			if(!empty($er)){
				$msg .= '<div class="alert alert-warning">
				  <strong>Warning! </strong>' . $er . '
				</div>';
			}
		}
		
		
	}
	
	
	
	function random_password( $length ) {
		$chars = "0123456789";
		$password = substr( str_shuffle( $chars ), 0, $length );
		return $password;
	}
	$firstCap = random_password(1) ;
	$secondCap = random_password(1) ;
	$_SESSION['captcha'] = $firstCap + $secondCap;
?>


    <!-- Page Content -->
	
    <div class="container">

        <div class="row">
			<? include('include/sidebar.php'); ?>
			<!-- Slider Start -->
			<form method="post" enctype="multipart/form-data" id="formRegistration" >
            <div class="col-md-9">
				<h3>User Registration Form</h3>
                <div class="col-md-12" style="padding-left:0px; padding-right:0px;">
					<div class="col-md-12" id="userIdError">
					<? if(!empty($msg)) { echo $msg; }?>
						<input type="hidden" id="errors" value=""/>
					</div>
					<div class="col-md-12 contact-title" style="background:#00911a; border-radius:5px;" >
						<h4 style="color:#fff; margin-bottom:7px;">Login Information</h4>
					</div>
					
					<div class="col-md-4" style="margin-top:10px;">
						<div class="form-group">
							<label class="control-label" for="Zip Code">User Id <span>*</span></label>
							<div class="controls">
								<input type="text" class="form-control" name="user" id="user" onkeyup="userIdFormat(this.value)" onblur="check_userId(this.value)" value="<?=$userId?>" />
								<input type="hidden" id="userError" value="true" /> 
							</div>  
						</div>
					</div>
					<div class="col-md-4" style="margin-top:10px;">
						<div class="form-group">
							<label class="control-label" for="Email">Email <span>*</span></label>
							<div class="controls">
								<input type="email" class="form-control" name="email" onblur="chkEid()" id="email" value="<?=$_POST['email']?>" />
								<input type="hidden" id="emailError" value="true" /> 								
							</div>  
						</div>
					</div>
					<div class="col-md-4" style="margin-top:10px;">
						<div class="form-group">
							<label class="control-label" for="Password">Password <span>*</span></label>
							<div class="controls">
								<input type="password" class="form-control" name="password" id="password" onblur="chkPass()"  />	
								<input type="hidden" id="passwordError" value="true" />								
							</div>  
						</div>
					</div>
					<div class="col-md-6">
						<div class="control-group">
							<label class="control-label" for="heading">Security Question <span>*</span></label>
							<div class="controls">
								<select name="secuirtyQ" id="secuirtyQ" onchange="securityQ(this.value);" class="form-control">
									<option value="">Choose a Question</option>
									<option value="What is the name of your best friend from childhood?">What is the name of your best friend from childhood?</option>
									<option value=" What was the name of your first teacher?"> What was the name of your first teacher? </option>
									<option value="What is the name of your manager at your first job?">What is the name of your manager at your first job? </option>
									<option value="What was your first phone number?">What was your first phone number?</option>
									<option value=" What is your vehicle registration number?"> What is your vehicle registration number? </option>
									<option value="What is your library card number?">What is your library card number? </option>
								</select>
							</div>
							<input type="hidden" id="secuirtyQError" value="true" />
						</div>
					</div>
					<div class="col-md-4">
						<div class="control-group">
							<label class="control-label" for="Answer">Answer <span>*</span></label>
							<div class="controls">
							   <input type="text" name="answer" id="answer" class="form-control" onblur="secuirtyAns(this.value);" >
							   <input type="hidden" id="answerError" value="true" />
							</div>  
						</div>
					</div>
					<div class="clearfix"></div>
						
					<!----------------------------login info end---------------------------------->	
					
					<div class="col-md-12 contact-title" style="background:#00911a; margin-bottom:20px; margin-top:10px; border-radius:5px;" >
						<h4 style="color:#fff; margin-bottom:7px;">Personal Information</h4>
					</div>
					
					<div class="col-md-4 ">		
						<div class="form-group">
							<label class="info-title" for="exampleInputName">First Name <span>*</span></label>
							<input type="text" class="form-control" id="fname" name="fname"  onblur="firstName(this.value)" value="<?=$_POST['fname']?>" />
							<input type="hidden" id="fnameError" value="true" />
						</div>	   
				  
						<div class="control-group">
							<label class="control-label" for="Gender">Gender </label>			
							<div class="controls">
								<input type="radio" <? if($_POST['gender']=="Male"){ echo "checked"; } ?> name="gender" value="Male" style="margin:0px;">Male
								<input type="radio" <? if($_POST['gender']=="Female"){ echo "checked"; } ?> name="gender" value="Female" style="margin:0px;">Female			  
							</div>		
						</div>
						
					</div>
						
						
					<div class="col-md-4">				
						<div class="form-group">
							<label class="info-title" for="exampleInputName">Last Name </label>
							<input type="text"  value="<?=$_POST['lname']?>" class="form-control" id="name" name="lname"  />
						</div>						
						<div class="form-group">
							<label class="control-label" for="Gender">Interested In</label>
							<div class="clearfix"></div>
							<div style="float:left"><input type="checkbox" name="interested[]" value="Doctor" style="margin:0px;"> Doctor &nbsp;</div> 
							<div style="float:left"><input type="checkbox" name="interested[]" value="Hospital" style="margin:0px;"> Hospital &nbsp;</div>
							<div style="float:left"><input type="checkbox" name="interested[]" value="Other Medical Services" style="margin:0px;"> Other Medical Services &nbsp;</div>
							<div style="float:left"><input type="checkbox" name="interested[]" value="Disease Information" style="margin:0px;"> Disease Information &nbsp;</div>
							<div class="clearfix"></div>	
						</div> 
					</div>
						
					<div class="col-md-4">
						<div class="form-group">
							<label class="control-label" for="Date Of Birth">Date Of Birth</label>
							<input id="inputDatetator1" class="form-control datepicker" name="dateBirth" value="<?=$_POST['dateBirth']?>"   data-date-format="dd/mm/yyyy" />	 
						</div> 
						<div class="form-group">
							<label class="control-label" for="Gender">Qualification</label>
							<div class="clearfix"></div>
							<div style="float:left"><input type="checkbox" name="qualification[]" value="graduate" style="margin:0px;"> Graduate &nbsp;</div> 
							<div style="float:left"><input type="checkbox" name="qualification[]" value="post graduate" style="margin:0px;"> Post Graduate &nbsp;</div>
							<div style="float:left"><input type="checkbox" name="qualification[]" value="Doctrate" style="margin:0px;"> Doctrate &nbsp;</div>
							<div class="clearfix"></div>		
						</div>  
						<div class="control-group " >
							<label class="info-title" for="Photo">Photo</label>
							<input type="file"  id="photo" name="photo"  >
							<p style="color:#6f6f6f;font-size: 12px;"><b>Note:</b> Image Should be 180 px BY 180 px. </p>
						</div>
					</div>
					   
	<div class="clearfix"></div>				   

	<!------------------------------------------ CONTACT INFORMATION SECTION START----------------------------------------->
					<div class="col-md-12 contact-title" style="background:#00911a; margin-top:10px; border-radius:5px;" >
						<h4 style="color:#fff; margin-bottom:7px;">Contact Information</h4>
					</div>
	
					
					<div class="col-md-8" style="margin-top:20px;">
						<div class="control-group">
						<label class="control-label" for="Gender">Phone No</label>
						<div class="controls">
							<div class="col-md-3">
								<select class="form-control input-md" name="countryCode">
									<option>select</option>
									<?   
									$con_Code = fetchAllData(" `country_code`", " order by phonecode");
									foreach($con_Code as $code)
									{
									?>
									<option  value="<?=$code['id']?>" <?php if($code['phonecode'] == 91){ echo 'selected';} ?>>+ <?=$code['phonecode']?> </option> 
									<?php } ?>
								</select>
							</div>
							<div class="col-md-3">
								<input type="text" value="<?=$_POST['stdCode']?>" name="stdCode" placeholder="STD Code" class="form-control">
							</div>
							<div class="col-md-6">
								<input type="text" value="<?=$_POST['phoneNo']?>" name="phoneNo" placeholder="Phone No" class="form-control">
							</div>
						 </div>  
						</div>
					</div>
					
					<div class="col-md-4" style="margin-top:20px;">
						<div class="control-group">
						<label class="control-label" for="Gender">Mobile No</label>
						<div class="controls">
					   <input type="text" value="<?=$_POST['mobileNo']?>" name="mobileNo" id="mobileNo" class="form-control">
						 </div>  
						</div>
					</div>
					<div class="col-md-4" style="margin-top:20px;">
						<div class="control-group">
							<div class="controls">
								<? $country = fetchAllData(" `countries`", " order by name"); ?>
								<label class="control-label" for="Gender">Select the Country</label>
								<select class="form-control input-md" onChange="select_state(this.value);" id="country" name ="country">
										<? foreach($country as $coun)
										{
										?>
										<option  value="<?=$coun['id']?>" <?php if($coun['name'] == "India"){ echo 'selected';} ?>><?=$coun['name']?> </option> 
										<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-4" style="margin-top:20px;">
						<div class="control-group">
							<div class="controls">
								<? $states_res = fetchAllData(" `states`", " where country_id = '101' order by name"); ?>
								<label class="control-label" for="Gender">State in the above Country</label>
								<select class="form-control input-md" id="states" name ="state">
										<option value="" selected disabled>Choose a State</option>
										<? foreach($states_res as $sta)
										{
										?>
										<option  value="<?=$sta['id']?>" ><?=$sta['name']?> </option> 
										<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-3" style="margin-top:20px;">
						<div class="control-group">
						<label class="control-label" for="City">City</label>
						<div class="controls">
					   <input value="<?=$_POST['city']?>" type="text" name="city" id="city" class="form-control">
						 </div>  
						</div>
					</div>
					<div class="col-md-12" style="margin-top:20px;">
						<div class="control-group">
						<label class="info-title" for="Address">Address</label>
						<textarea class="form-control unicase-form-control" id="address" name="address"><?=$_POST['address']?></textarea> 
						</div>
					</div>
		
		
					<div class="col-md-12" style="margin-top:20px;">
						<div class="control-group">
						<label class="control-label" for="Gender">Would you like received ?</label>
						<div class="controls">
						 <input type="checkbox" name="yLikeRecieved[]" value="Receive Discount Packages" style="margin:0px;"> Receive Discount Packages
						 &nbsp; &nbsp; <input type="checkbox" name="yLikeRecieved[]" value="Promotional Emails" style="margin:0px;"> Promotional Emails	 
						 &nbsp; &nbsp; <input type="checkbox" name="yLikeRecieved[]" value="Offers" style="margin:0px;"> Offers<br>
									 
						 </div><br/>
						 <label class="control-label" for="Gender">Sum of <?=$firstCap?> + <?=$secondCap?> = 
						 <input type="text" name="captcha" id="captcha" onblur= "checkCaptcha(this.value)"  class="form-control"></label><br/>
						 <span id="capError" style="color: red;"></span>
						</div>
					</div><br/>
<script>
	function checkCaptcha(captcha){
		if(captcha == "<?=$_SESSION['captcha']?>" ){
			document.getElementById('capError').innerHTML="";
			return true;
		} else {
			document.getElementById('capError').innerHTML="Invalid Captcha!";
			document.getElementById('captcha').focus();
			return false;
			
		}
	}
</script>
					
					<div class="clearfix"></div>


					<div class="col-lg-12">	
						<div class="row" style="margin-top:20px;margin-bottom:40px;padding-left:10px;">	
							<button type="button" class="btn btn-primary" onclick="formValidate();" id="registerBtn" name="register">Register</button><br>
						</div>
					</div>
		
				</div><!-- /.col -->
            </div>
			</form>

			<div class="col-md-12">
				<div class="most-active-profile">
					<h4 class="heading">Our Associate</h4>
					<div id="jssor_2" class="jssor_2">
					<!-- Loading Screen -->
					<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
						<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
						<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
					</div>
					<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 100%; height: 100px; overflow: hidden; ">
						<?php 
						   $queryAs=mysqli_query($conn,"select * from our_associate");
						   while($rowAs=mysqli_fetch_object($queryAs))
						   {
						 ?>
						   <div style="display: none;">
								<img data-u="image" src="/admin/images/uploads/<?php echo $rowAs->image; ?>" style="margin-left:30px;"/>
							</div>
							<?php 
						   }
							?>
						
					</div>
					</div>
				</div>
			</div>
			
        </div>

    </div>
<script  src="/js/form-validation/user-registration.js"></script>
    <!-- /.container -->
<script src="/js/jquery.duplicate.js"></script>
<? include('include/footer.php'); ?>
    <script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>
    <!-- use jssor.slider-21.1.debug.js instead for debug -->
    <script src="/js/bootstrap-datepicker.js"></script>
	 <script>
	 $('.datepicker').datepicker();
        jssor_2_slider_init();
    </script>
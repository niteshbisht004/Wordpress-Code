<?php 
include('include/connection.php');
include('include/function.php');
	
	$lastAppoints = fetchAllData(" `coupan` ", " where coupan_id= '".$_GET['couponid']."' and email='".$_SESSION['userEmail']."' ");
	//echo " `coupan` ", " where coupan_id= '".$_GET['couponid']."' and email='".$_SESSION['userEmail']."' ";
	$dealid = $lastAppoints[0]['deal_id'];
	$deal = fetchData(" `deals` ", " where id= 23 ");
	 $deal_title = $deal['title'];
	
	$logo="https://dev.freemedicalinfo.in/images/free_medical_info.gif";
	//$logo = $logo = . '<img src= "https://dev.freemedicalinfo.in/images/free_medical_info.gif">';
	
	
	    $doctor = $lastAppoints[0]['doctor_id'];
		$hospital = $lastAppoints[0]['hospital_id'];
		$other = $lastAppoints[0]['other_id'];
		
		//$offer_bys = fetchData(" `medical_registration` ", " where id= 574 ");
			//$hospitalname =  ucwords($offer_bys['name']);
			
		if($doctor!=""){
			$offer_by = fetchData(" `doctor_registration` ", " where id= '".$doctor."' ");
			
		}
		if($hospital!=""){
			$offer_by = fetchData(" `medical_registration` ", " where id= '".$hospital."' ");
			
		}
		
		if($other != ""){
		$offer_by = fetchData(" `other_service_registration` ", " where id= '".$other."' ");
		
	     }
		$offerby =  ucwords($offer_by['name']);
		
		

		
		
		
	
	require('fpdf/fpdf.php'); 

	$pdf = new FPDF(); 
	$pdf->AddPage();
	
	
	//$pdf->Image($logo);
	//$pdf->Image('images/pdf-header.jpg',20,60,180,20,'JPG','www.plus2net.com');
	//$pdf->Image($logo,20,60,180,20,'gif','www.plus2net.com');
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'logo',1);
	//$pdf->Image($logo, 10, 30, 'gif');
	 // $pdf-> Image($logo,'gif')
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$logo,1);
	//$pdf->Cell(70,12, $this->Image($logo,10,30),1);
	//$pdf->Image($logo, 0, 0, 'gif',1); 
	$pdf->Ln();

	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Patient Name',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['patient_name'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Email',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['email'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Contact Number',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['contact_number'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Address Name',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['address'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Gender Name',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['gender'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Appointment Date',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['appointment_date'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Appointment Time',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['appointment_time'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Purpose',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['purpose'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Coupon Status	',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['status'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Your Coupon	',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$lastAppoints[0]['coupan_id'],1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Deal Title',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$deal_title,1);
	$pdf->Ln();
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,'Name',1);
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(70,12,$offerby,1);
	$pdf->Ln();
	
	
	$pdf->Output($_GET['couponid'].'.pdf','I'); // send to browser and display

?>
		
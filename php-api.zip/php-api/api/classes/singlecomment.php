<?php
class SingleComment{

        // Connection
        private $conn;

        // Table
        private $db_table = "rnewrating";
     
        // Columns
        public $id;
        public $fname;
        public $email;


        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }


        public function showAllSingleCmnt($id,$srow,$rows)
		{
			$sqlQuery = "SELECT * FROM ". $this->db_table . " WHERE `reply_id` = '$id' LIMIT $srow,$rows";
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
		}
		
		
		   
 }
?>
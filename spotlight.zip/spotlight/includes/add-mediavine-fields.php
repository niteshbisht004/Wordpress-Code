<?php 

function sfc_myplugins_smart_fin_cals()
{
	?>
    <h2>Mediavine Plugin Settings</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <?php 
        settings_fields( 'mediavine_plugin_options' );
        do_settings_sections( 'dbi_example_plugin' ); ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
    </form>
    <?php
}

	
?>
<?php
session_start();

if ($_SESSION['code'] == $_POST["captcha"]) {
    echo "success";
} else {
    die("unsuccess");
}



?>
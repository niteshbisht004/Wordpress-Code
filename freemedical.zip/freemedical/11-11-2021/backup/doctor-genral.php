<?
	include('../include/connection.php');
	include('../include/function.php');
?>
<?
	$resDD = fetchData(' `doctor_registration` ', " where id='".$_SESSION['userId']."' ");
?>
<div class="popup-form">
            <form class="form-horizontal" role="form" action="/doctor-profile" method="post">
				<h4>General Information</h4>
				<hr style="margin-top: 0px;"/>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['name']?>" name="name"  class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Date Of Birth</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['date_birth']?>" name="date_birth" class="form-control datepicker" placeholder="dd/mm/yyyy"/>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Fees</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['fees']?>" name="fees" class="form-control" placeholder="500"/>
                    </div>
                </div>
				<div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="gender" value="Male" <? if($resDD['gender']=="Male"){ echo "checked";} ?> required/>Male
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" name="gender" value="Female" <? if($resDD['gender']=="Female"){ echo "checked";} ?> required/>Female
                                </label>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
				<div class="form-group">
                    <label class="control-label col-sm-3">Qualification</label>
                    <div class="col-sm-4">
					<? $qualification = explode("|",$resDD['qualification']); ?>
						<select name="qualification[]" id="qualification" multiple class="form-control selectpickerQua input-md"  data-size="6" required>
							<?php 
							$querQl=mysqli_query($conn,"select * from qualification ORDER BY qualification ASC");
							while($rowQl=mysqli_fetch_object($querQl))
							{							 
							?>
							<option <? if(in_array($rowQl->id,$qualification)) { echo "selected"; }  ?> value="<?php echo $rowQl->id; ?>"><?php echo $rowQl->qualification; ?></option>
							<?							
							} ?>
							<option <? if($otherQ == "OtherQ"){ echo "selected";} ?> value="Other">Other</option>
						</select>
                    </div>
					<div class="col-sm-5">
						<input type="text" style="display:<? if($otherQ == "OtherQ"){ echo "block"; } else { echo "none"; }  ?> " name="otherQuali" value="<?=$otherQuali?>" id="otherQuali" placeholder="Other Qualification" class="form-control" />
					</div>
                </div>
				
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Specialisation</label>
					<div class="col-sm-5">
					<? $specialisation = explode("|",$resDD['specialisation']);
						$other = explode(":",$resDD['specialisation']);	
						$oth=explode("|",$other[0]);							
					?>
					<select name="specialisation[]" id="specialisation"  class="form-control selectpickerSpe input-md" data-live-search="true" data-size="6" multiple required>
					   <option value=""></option>
						<?php 
							$querSp=mysqli_query($conn,"SELECT * FROM specialisation ORDER BY specialisation ASC");
							while($rowSp=mysqli_fetch_object($querSp))
						 {							 
						?>
						<option <? if(in_array($rowSp->id,$specialisation)) { echo "selected"; }  ?> value="<?php echo $rowSp->id; ?>"><?php echo $rowSp->specialisation; ?></option>
						<?php } 
						foreach($specialisation as $spli){
							 $spl = explode(":",$spli);
							 if(in_array('Other',$spl)){
								 $otherSpli = $spl[1];
								 $otherS = "OtherS";
							 }
						}
						?>
					
						<option <? if(in_array('Other',$oth)){ echo "selected";} ?> value="other">Other</option>
					</select>
					</div>
				
					<div class="col-sm-4">
						<input type="text" style="display:<? if($otherS == "OtherS"){ echo "block"; } else { echo "none"; }  ?> "  name="otherSpeci" value="<?=$otherSpli; ?>" id="otherSpeci" placeholder="Other Specialisation" class="form-control" />
					</div>
					
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Total Experience</label>
                    <div class="col-sm-9">
                    	<select name="total_experience" id="total_experience" class="form-control selectpickerQua input-md"  data-size="6" required>
							<option value="None">None</option>
							<option <? if ( $resDD['total_experience']=="1 year" ) { echo "selected"; }  ?>  value="1 year">1 year</option>
							<?php 
							for($i=2;$i<=80;$i++)
							{							 
							?>
							<option <? if ( $resDD['total_experience']==$i." years" ) { echo "selected"; }  ?> value="<?php echo $i; ?> years"><?php echo $i; ?> years</option>
							<?							
							} ?>
						</select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Registration Authority</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_auth']?>" name="registration_auth" class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Registration No.</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['registration_no']?>" name="registration_no" class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Expertise in</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['expertise_in']?>" name="expertise_in" class="form-control" required>
                    </div>
                </div>
					<div class="form-group">
                    <label for="birthDate" class="col-sm-3 control-label">Description</label>
                    <div class="col-sm-9">
                        <textarea name="summary" class="form-control" maxlength="200"><?=$resDD['summary']?></textarea>
                    </div>
                </div>
                 <!-- /.form-group -->              
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="update_genral" class="btn btn-primary btn-block">Update</button>
                    </div>
                </div>
            </form> <!-- /form -->
</div>
    <script src="/js/bootstrap-datepicker.js"></script>
<script>
  $(document).ready(function () {
    $('.selectpickerQua').selectpicker();
    $('.selectpickerSpe').selectpicker();
  });
  $(function() {
  $('.selectpickerQua').on('change', function(){
	  
    var selected = $(this).find("option:selected").text();	
    if(selected.search("Other")>=0){		
		$("#otherQuali").show();
		$("#otherQuali").prop('required',true);
	} else {
		$("#otherQuali").hide();
		$("#otherQuali").prop('required',false);
	}
  });
  $('.selectpickerSpe').on('change', function(){
	  //alert("hhlll");
    var selected = $(this).find("option:selected").text();
    //if(selected.contains("Other")){
    if(selected.search("Other")>=0){		
		$("#otherSpeci").show();
		$("#otherSpeci").prop('required',true);
	} else {
		$("#otherSpeci").hide();
		$("#otherSpeci").prop('required',false);
	}
  });
  
});
	 //$('.datepicker').datepicker();
 </script>
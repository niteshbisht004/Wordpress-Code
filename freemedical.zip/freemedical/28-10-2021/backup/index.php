<? include("include/header.php");

?>

<!-- Page Content -->

<!--Search Banner Header -->
<div class="main-banner-top-h">
	<div class="container">
		<div class="row">
			<div id="header-main" class="col-md-12 header2-bottom-banner">
				<div class="col-sm-12  col-md-12 caption-full">
					<h1 class="heading text-uppercase">Medical <span style="color:#ed1c24;">Services</span></h1>
					<p>The Largest online database of patient reviews for doctors, facilities and online Appointment.</p>
				</div>

				<div class="col-sm-12 col-md-12 top-search search-by-home">
					<?php include("include/searchbar.php"); ?>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="main-top-detail-12">
	<div class="container set-main-coon">
		<div class="col-md-12" id="main-top-detail-11">

			<h3>Find top doctors <span style="color:#ed1c24;">online</span></h3>
			<p>Private online consultations with verified doctors in all specialists</p>

		</div>
		<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 featuresm-slider main-work-sl-p">
			<?php

			$qry = "select * from specialisation Limit 0,11";
			$run = mysqli_query($conn, $qry);
			while ($result = mysqli_fetch_array($run)) {
				$data[] = $result;
			}
			$i = 1;
			foreach ($data as $row) {
			?>
				<div class="col-lg-2 col-md-4 col-sm-6 col-xs-6 text-center small-header-set-001">
					<div class="set-sider-top-img">
						<a href="/hospitals-filter/speci/<?php echo $row['id']; ?>">
							<? if ($row['header_icon'] != '') { ?>
								<img src="/admin/images/uploads/<?php echo $row['header_icon']; ?>">
							<? } else { ?>
								<img src="../doctor-image-pc.png">
							<? } ?>
							<p><?php echo $row['specialisation']; ?></p>
						</a>
					</div>
				</div>
			<?
				if ($i % 6 == 0) {
					echo '</div><div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 featuresm-slider main-work-sl-p">';
				}
				$i++;
			}
			?>
			<div class="col-lg-2 col-md-4 col-sm-6 col-xs-6 text-center small-header-set-001" id="main-top-detail-11">
				<div class="set-sider-top-img emergency-sign">
					<img src="../images/home-icons/emergency-ixon.png">
					<p><a href="/allspecialisation">View All</a></p>
				</div>
			</div>
		</div>

	</div>
</div>


<div class="section-row-11">
	<div class="container">
		<div class="col-md-12">
			<h2 class="text-uppercase text-center">See How It <span style="color:#ed1c24;">Works</span></h2>
			<div class="col-md-4 top-set-space">
				<div class="top-set-works" id="top-set-lcolor">
					<div class="top-set-left-side">
						<p><i class="fa fa-search"></i></p>
					</div>
					<div class="top-set-right-side">
						<p class="main-work-title">Find The Right Doctor/ Hospital/ Medical Services.</p>
						<p class="main-work-text">The Largest online database of Verified Profiles of Medical practitioners and service providers.</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 top-set-space">
				<div class="top-set-works" id="top-set-lcolor2">
					<div class="top-set-left-side">
						<p><i class="fa fa-calendar-check-o"></i></p>
					</div>
					<div class="top-set-right-side">
						<p class="main-work-title">Rating and Review</p>
						<p class="main-work-text">The latest patient reviews for doctors, hospitals, pathlabs, medical services providers.</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 top-set-space">
				<div class="top-set-works" id="top-set-lcolor3">
					<div class="top-set-left-side">
						<p><i class="fa fa-users"></i></p>
					</div>
					<div class="top-set-right-side">
						<p class="main-work-title">Find the Deals and Generate Coupons</p>
						<p class="main-work-text">Find the exclusive deals and discounts on medical consultation / treatment in your location. Generate the Coupon, visit in person to avail the benefits.</p>
					</div>
				</div>
			</div>
		</div>

		<div class="col-md-12 text-center" id="top-3how">
			<img src="../images/home-icons/tag-pin-line.png">
		</div>
	</div>
</div>
<div id="main-top-detail-16">
	<div class="container">
<div class="col-md-12 deals-slider main-work-sl-p" id="recommend-deals-2">
			<?php
			$res_assoc = fetchAllDatas(" `left_advt` ");
			foreach ($res_assoc as $assoc) {
			?>
				<div class="col-md-3 text-center">
					<div class="set-sider-top-img">
						<a href="<?php echo $assoc['web_url']; ?>"><img src="/admin/images/uploads/Advertisement/<?php echo $assoc['advtImg']; ?>"></a>
					</div>
				</div>

			<?php } ?>

		</div>
	</div>
</div>
<div id="main-top-detail-13">
	<div class="container">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8 col-sm-12">
					<h4>Recommended doctors <span style="color:#ed1c24;">near you</span></h4>
					<p>Private online consultations with verified doctors in all specialists</p>
				</div>
				<div class="col-md-4 col-sm-12">
					<div class="special-btn-area text-right">
						<a href="/doctors">View All Doctors <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>



		<div class="col-md-12 align-center text-sm review-slider" id="recommend-deals-1">

			<?php
			global $specialisations;
			global $qualifications;
			global $hospital_cats;
			global $cities;
			$conn = db();
			//Specialisation List
			$resHD = mysqli_query($conn, "SELECT * FROM specialisation");
			if (mysqli_num_rows($resHD)) {

				$c = 0;
				while ($data = mysqli_fetch_assoc($resHD)) {

					$specialisations[$data['id']] = utf8_encode($data['specialisation']);
					$c++;
				}
			}
			$res_doctor = fetchAllData(" `doctor_registration` ", "WHERE active='Yes'");
			foreach ($res_doctor as $doct) {
				$image = $doct['pro_img'];
				if ($image != "") {

					$image = "/images/profile/$image";
				} else {

					$image = "/images/doctor-face.jpg";
				}

			?>
				<div class="item col-md-3 text-left">
					<div class="d-details-per-column">
						<img src="<?= $image; ?>">
						<div class="col-sm-12 in-details-main-f featured-color">
							<a href="/doctor/<?= $doct['user_id'] ?>" target="_blank">
								<p class="name-d"><?php echo ucfirst($doct['name']) ?></p>
							</a>
							<p class="special-d"><? $specialisation = explode("|", $doct['specialisation']);
													foreach ($specialisation as $spec) {
														echo $specialisations[$spec];
													} ?></p>

							<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");

							?>
							<? $r = 0;
							$i = 0;
							foreach ($res_cmt as $rat) {
								$r = $rat['rate'] + $r;
								$i++;
							}
							$r = $r / $i;
							if (is_nan($r)) {
								$r = 0;
							}
							$r = round($r, 1);
							if ($r == 0) {
								$var = '0%';
							}
							if ($r >= 1 && $r <= 1.5) {
								$var = '20%';
							}
							if ($r >= 1.5 && $r <= 2) {
								$var = '30%';
							}
							if ($r >= 2 && $r <= 2.5) {
								$var = '40%';
							}
							if ($r >= 2.5 && $r <= 3) {
								$var = '50%';
							}
							if ($r >= 3 && $r <= 3.5) {
								$var = '60%';
							}
							if ($r >= 3.5 && $r <= 4) {
								$var = '70%';
							}
							if ($r >= 4 && $r <= 4.5) {
								$var = '80%';
							}
							if ($r >= 4.5 && $r <= 5) {
								$var = '90%';
							}
							if ($r == 5) {
								$var = '100%';
							}
							?>

							<div class="rating-container rating-xs rating-animate">
								<div class="average-rating-d">
									<span><?php if ($r == 0) {
											} else {
												echo $r;
											} ?></span>
								</div>
								<div class="rating">
									<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
										</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
										</span></span>
									<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star"></i></span>
										<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
								</div>
							</div>


						</div>
					</div>
				</div>

			<?php
			}
			?>

		</div>
	</div>
</div>

<!--deals-->
<div id="main-top-detail-14">
	<div class="container">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h5>Burning <span style="color:#ed1c24;">Deals</span></h5>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
						<a href="/deal-list">View All Deals <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>


		<div class="col-md-12 deals-slider main-work-sl-p" id="recommend-deals-2">

			<?php

			$res_deal = fetchAllDatas(" `deals` ");
			foreach ($res_deal as $deal) {
				$image = $deal['image'];
				if ($image != "") {

					$image = "/admin/images/uploads/$image";
				} else {

					$image = "/images/hot-deals-demo.jpg";
				}

				$doctor = $deal['doctor_id'];
				$hospital = $deal['hospital_id'];
				$other = $deal['other_id'];
				if ($doctor != "") {
					$offer_by = fetchData(" `doctor_registration` ", " where id= '" . $doctor . "' ");
				}
				if ($hospital != "") {
					$offer_by = fetchData(" `medical_registration` ", " where id= '" . $hospital . "' ");
				}
				if ($other != "") {
					$offer_by = fetchData(" `other_service_registration` ", " where id= '" . $other . "' ");
				}
				$offerby =  ucwords($offer_by['name']);

			?>
				<div class="col-md-3 text-center">
					<div class="set-sider-top-img">

						<img src="<?php echo $image; ?>">

						<p class="text-left"><a href="/deal.php?id=<?= $deal['id']; ?>"><?php echo $deal['title']; ?></a></p>
						<span class="deal-valid text-left"><strong>Offered By :</strong><?php echo $offerby; ?></span>

					</div>
				</div>
			<?php
			}
			?>

		</div>
	</div>
</div>
<!--Blogs-->
<div id="main-top-detail-15">
	<div class="container">
		
				<div class="col-md-4 col-lg-3 col-xs-12 col-sm-12 blog-main-set-img text-center">
					<div class="row">
					<h6>Latest <span style="color:#ed1c24;">News</span></h6>
					<img src="../images/home-icons/news-article.png">
					<div class="special-btn-area text-center">
						<a href="/blog" class="uppercase">View All <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
				</div>
				<div class="col-md-8 col-lg-9 col-xs-12 col-sm-12">
					<div class="row">
				<?php

				$res_blog = fetchAllDataWithPagination(" `blog` ", "  where `status` !='0' order by id DESC ", 3, "");
				foreach ($res_blog[0] as $val) {
					
					      $simg=$val['image'];
						  if($simg == ''){
							  
							  
						  }else{
							$str_arr=explode('|',$simg);
							if (strpos($simg, '|') !== false) 
							{
							 $simg=$str_arr[0]; 
							}
							else{
								$simg=$val['image'];
							}
						  }
					
				?>
					<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4" id="blog-udate-test">
						<a href="#">
							<img src="/admin/images/uploads/<?= $simg; ?>" class="img-fluid">
						</a>
						<div class="caption-full-main">
							<div class="caption-full-data">
								<p><a href="/blog-detail/id/<?= $val['id']; ?>"><?= $val['title']; ?></a></p>
								<p><?= substr(strip_tags($val['description']), 0, 150) ?>...</p>
							</div>
							<div class="ratings text-right">
								<a href="/blog-detail/id/<?= $val['id']; ?>">Read More <i class="fa fa-angle-right"></i></a>
							</div>
						</div>
					</div>
				<?php } ?>
				</div>
				</div>
	</div>
</div>

<!--our parters-->




<!--App Screen Advertisment-->
<div id="main-top-detail-17">
	<div class="container">
		<div class="col-md-12 my-appscreen">
			<div class="row">
				<div class="col-md-6">
					<p class="text-uppercase">Download FMI <span style="color:#ed1c24;">Mobile App</span></p>
					<p>and never miss out any update</p>
					<ul class="my-app-property">
						<li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
						<li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
					</ul>
					<div class="app-stores-d">
						<img src="../images/home-icons/playstore.png">
						<img src="../images/home-icons/apple-store.png">
					</div>
				</div>
				<div class="col-md-6 mobile-screen-set text-center">
					<div class="row">
					<img src="../images/home-icons/app-screen.jpg">
					</div>
				</div>
			</div>
		</div>

	</div>
</div>



<div id="main-top-detail-18">
	<div class="container">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<p class="text-uppercase">Our <span style="color:#ed1c24;">Partners</span></p>
				</div>
				<div class="col-md-4">
					<!--<div class="special-btn-area text-right">
						<a href="#">View All<i class="fa fa-angle-right"></i></a>
					</div>-->
				</div>
			</div>
		</div>


		<div class="col-md-12 deals-sliders main-work-sl-p" id="recommend-deals-2">
			<?php
			$res_assoc = fetchAllDatas(" `our_associate` ");
			foreach ($res_assoc as $assoc) {
			?>
				<div class="col-md-3 text-center">
					<div class="set-sider-top-img">
						<img src="/admin/images/uploads/<?php echo $assoc['image']; ?>">
					</div>
				</div>

			<?php } ?>

		</div>
	</div>
</div>
<!--  review slider  -->

<style>
	body {
		margin-top: 20px;
	}

	.align-center {
		text-align: center;
	}

	.hash-list {
		display: block;
		padding: 0;
		margin: 0 auto;
	}

	@media (min-width: 768px) {
		.hash-list.cols-3>li:nth-last-child(-n+3) {
			border-bottom: none;
		}
	}

	@media (min-width: 768px) {
		.hash-list.cols-3>li {
			width: 33.3333%;
		}
	}

	.hash-list>li {
		display: block;
		float: left;
		border-right: 1px solid rgba(0, 0, 0, 0.2);
		border-bottom: 1px solid rgba(0, 0, 0, 0.2);
	}

	.pad-30,
	.pad-30-all>* {
		padding: 30px;
	}

	img {
		border: 0;
	}

	.mgb-20,
	.mgb-20-all>* {
		margin-bottom: 20px;
	}

	.wpx-100,
	.wpx-100-after:after {
		width: 100px;
	}

	.img-round,
	.img-rel-round {
		border-radius: 50%;
	}

	.padb-30,
	.padb-30-all>* {
		padding-bottom: 30px;
	}

	.mgb-40,
	.mgb-40-all>* {
		margin-bottom: 40px;
	}

	.align-center {
		text-align: center;
	}

	[class*="line-b"] {
		position: relative;
		padding-bottom: 20px;
		border-color: #E6AF2A;
	}

	.fg-text-d,
	.fg-hov-text-d:hover,
	.fg-active-text-d.active {
		color: #222;
	}

	.font-cond-b {
		font-weight: 700 !important;
	}

	.reviw-t-name {
		font-size: 18px;
		margin-bottom: 8px;
		font-weight: 600;
		color: #000;
		padding: 11px 0px 0;
	}

	.bottom-name-h {
		font-size: 12px;
		font-weight: 600;
	}

	.font-cond-l {
		margin-bottom: 0px;
		font-size: 12px;
		padding: 5px 0px;
	}

	.bottom-name-h {
		padding: 0;
	}

	.rating .glyphicon {
		font-size: 16px;
	}

	.slick-prev:before,
	.slick-next:before {
		color: black !important;
	}

	/*.item.slick-slide:nth-child(even) {
    background: #f9f9f9;
}*/
</style>





<!--- End of review slider	--->



<? include('include/footer.php'); ?>
<script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
<script type="text/javascript" src="/js/script.js"></script>
<!-- use jssor.slider-21.1.debug.js instead for debug -->

<script>
	jssor_2_slider_init();
	$('.rating').rating({
		'showCaption': false
	});
</script>
<!--<script>
	$('.featuresm-slider').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 4000,
		infinite: true,
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'

	});
</script>-->

<script>
	$('.review-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 6000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1220,
				settings: {
					slidesToShow: 3,
				},
			},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>
<script>
	$('.deals-slider').slick({
		slidesToShow: 3,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 4000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
				},
			},
			
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
	
		$('.deals-sliders').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 4000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
				},
			},
			
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>
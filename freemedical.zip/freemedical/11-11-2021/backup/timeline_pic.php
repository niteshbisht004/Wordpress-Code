<?
	include('../include/connection.php');
	include('../include/function.php');
?>

<? if(!empty($_SESSION['userId']) && $_SESSION['userType']=="doctor"){ ?>
<?
	$resDD = fetchData(' `doctor_registration` ', " where id='".$_SESSION['userId']."' ");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
<form class="form-horizontal" method="post" action="/doctor-profile" enctype="multipart/form-data" onsubmit="return checkCoords();">	
		<div style=" 
		height: 900px;
    margin: auto;
    border: 2px solid;
    padding: 20px;  " class="col-md-12 col-sm-12">
				<h4>Change Timeline Pic</h4>
				<div style=" width:40%;float:left;padding:50px;
    margin: auto;">	
<? if($resDD['timeline_img']!="") {?><img src="/images/timeline/<?=$resDD['timeline_img']?>" width="100%" /><? } else {?><img src="/images/about.png" width="250px" /><? } ?>
<h6 style="color:red;">Image size should be 900px by 350px for perfect Look!</h6>	
</div><div style=" width:40%;float:left;padding:50px;
    margin: auto;">
					<div class="form-group">
		
<input name="image" id="fileInput" size="30" type="file" />				
</div>	
<p><img id="imagePreview" style="display:none;"/></p>
<input type="hidden" id="x" name="x" />		
<input type="hidden" id="y" name="y" />	
<input type="hidden" id="w" name="w" />		
<input type="hidden" id="h" name="h" />		
<input type="hidden" name="oldfile" value="<?=$resDD['timeline_img']?>" />	
<div class="form-group">				
<br/><br/><br/>		
<button type="submit" name="update_tps" class="btn btn-primary btn-block">Update</button>
<button type="submit" name="update_tp" class="btn btn-primary btn-block">Crop It</button>

</div>			
</div>			
<!--// <input name="upload" type="submit" value="UPLOAD" />-->	
</div>	
</form>	

<link rel="stylesheet" href="/image_crope/css/imgareaselect.css" />
<script src="/image_crope/js/jquery.imgareaselect.js"></script>
<script>function checkCoords(){    if(parseInt($('#w').val())) return true; }
function updateCoords(im,obj){	
var img = document.getElementById("imagePreview");	
var orgHeight = img.naturalHeight;    var orgWidth = img.naturalWidth;	    var porcX = orgWidth/im.width;    var porcY = orgHeight/im.height;	    $('input#x').val(Math.round(obj.x1 * porcX));    $('input#y').val(Math.round(obj.y1 * porcY));    $('input#w').val(Math.round(obj.width * porcX));    $('input#h').val(Math.round(obj.height * porcY));}$(document).ready(function(){        var p = $("#imagePreview");    $("#fileInput").change(function(){                p.fadeOut();		                var oFReader = new FileReader();        oFReader.readAsDataURL(document.getElementById("fileInput").files[0]);		        oFReader.onload = function(oFREvent){            p.attr('src', oFREvent.target.result).fadeIn();        };    });	        $('#imagePreview').imgAreaSelect({        onSelectEnd: updateCoords    });});</script>
			
<? } ?>


<!---- testing code --->

<!-- testing code end -->

<? if(!empty($_SESSION['userId']) && $_SESSION['userType']=="hospital"){ ?>
<?
	$resHD = fetchData('`medical_registration`', " where id='".$_SESSION['userId']."' ");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
<form class="form-horizontal" method="post" action="/hospital-profile" enctype="multipart/form-data" onsubmit="return checkCoords();">	
		<div style=" 
		height: 900px;
    margin: auto;
    border: 2px solid;
    padding: 20px;  " class="col-md-12 col-sm-12">
					<h4>Change Timeline Pic</h4>
				<div style=" width:40%;float:left;padding:50px;
    margin: auto;">	
<? if($resHD['timeline_img']!="") {?><img src="/images/timeline/<?=$resHD['timeline_img']?>" width="100%" /><? } else {?><img src="/images/about.png" width="250px" /><? } ?>
<h6 style="color:red;">Image size should be 900px by 350px for perfect Look!</h6>	
</div><div style=" width:80%;float:left;padding:50px;
    margin: auto;">
					<div class="form-group">
		
<input name="image" id="fileInput" size="30" type="file" />				
</div>	
<p><img id="imagePreview" style="display:none;"/></p>
<input type="hidden" id="x" name="x" />		
<input type="hidden" id="y" name="y" />	
<input type="hidden" id="w" name="w" />		
<input type="hidden" id="h" name="h" />		
<input type="hidden" name="oldfile" value="<?=$resDD['timeline_img']?>" />	
<div class="form-group">				
<br/><br/><br/>	
<button type="submit" name="update_tps" class="btn btn-primary btn-block">Update</button>	
<button type="submit" name="update_tp" class="btn btn-primary btn-block">Crop It</button>
</div>			
</div>			
<!--// <input name="upload" type="submit" value="UPLOAD" />-->	
</div>	
</form>	

<link rel="stylesheet" href="/image_crope/css/imgareaselect.css" />
<script src="/image_crope/js/jquery.imgareaselect.js"></script>
<script>function checkCoords(){    if(parseInt($('#w').val())) return true; }
function updateCoords(im,obj){	
var img = document.getElementById("imagePreview");	
var orgHeight = img.naturalHeight;    var orgWidth = img.naturalWidth;	    var porcX = orgWidth/im.width;    var porcY = orgHeight/im.height;	    $('input#x').val(Math.round(obj.x1 * porcX));    $('input#y').val(Math.round(obj.y1 * porcY));    $('input#w').val(Math.round(obj.width * porcX));    $('input#h').val(Math.round(obj.height * porcY));}$(document).ready(function(){        var p = $("#imagePreview");    $("#fileInput").change(function(){                p.fadeOut();		                var oFReader = new FileReader();        oFReader.readAsDataURL(document.getElementById("fileInput").files[0]);		        oFReader.onload = function(oFREvent){            p.attr('src', oFREvent.target.result).fadeIn();        };    });	        $('#imagePreview').imgAreaSelect({        onSelectEnd: updateCoords    });});</script>
			
<? } ?>
<? if(!empty($_SESSION['userId']) && $_SESSION['userType']=="user"){ ?>
<?
	$resUD = fetchData(' `users` ', " where id='".$_SESSION['userId']."' ");
?>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
<form class="form-horizontal" method="post" action="/user-profile" enctype="multipart/form-data" onsubmit="return checkCoords();">	
		<div style=" 
		height: 900px;
    margin: auto;
    border: 2px solid;
    padding: 20px;  " class="col-md-12 col-sm-12">
					<h4>Change Timeline Pic</h4>
				<div style=" width:40%;float:left;padding:50px;
    margin: auto;">	
<? if($resUD['timeline_img']!="") {?><img src="/images/timeline/<?=$resUD['timeline_img']?>" width="100%" /><? } else {?><img src="/images/about.png" width="250px" /><? } ?>
<h6 style="color:red;">Image size should be 900px by 350px for perfect Look!</h6>	
</div><div style=" width:40%;float:left;padding:50px;
    margin: auto;">
					<div class="form-group">
		
<input name="image" id="fileInput" size="30" type="file" />				
</div>	
<p><img id="imagePreview" style="display:none;"/></p>
<input type="hidden" id="x" name="x" />		
<input type="hidden" id="y" name="y" />	
<input type="hidden" id="w" name="w" />		
<input type="hidden" id="h" name="h" />		
<input type="hidden" name="oldfile" value="<?=$resDD['timeline_img']?>" />	
<div class="form-group">				
<br/><br/><br/>	
<button type="submit" name="update_tps" class="btn btn-primary btn-block">Update</button>	
<button type="submit" name="update_tp" class="btn btn-primary btn-block">Crop It</button>
</div>			
</div>			
<!--// <input name="upload" type="submit" value="UPLOAD" />-->	
</div>	
</form>	

<link rel="stylesheet" href="/image_crope/css/imgareaselect.css" />
<script src="/image_crope/js/jquery.imgareaselect.js"></script>
<script>function checkCoords(){    if(parseInt($('#w').val())) return true; }
function updateCoords(im,obj){	
var img = document.getElementById("imagePreview");	
var orgHeight = img.naturalHeight;    var orgWidth = img.naturalWidth;	    var porcX = orgWidth/im.width;    var porcY = orgHeight/im.height;	    $('input#x').val(Math.round(obj.x1 * porcX));    $('input#y').val(Math.round(obj.y1 * porcY));    $('input#w').val(Math.round(obj.width * porcX));    $('input#h').val(Math.round(obj.height * porcY));}$(document).ready(function(){        var p = $("#imagePreview");    $("#fileInput").change(function(){                p.fadeOut();		                var oFReader = new FileReader();        oFReader.readAsDataURL(document.getElementById("fileInput").files[0]);		        oFReader.onload = function(oFREvent){            p.attr('src', oFREvent.target.result).fadeIn();        };    });	        $('#imagePreview').imgAreaSelect({        onSelectEnd: updateCoords    });});</script>
			
<? } ?>
<? if(!empty($_SESSION['userId']) && $_SESSION['userType']=="other-medical"){ ?>
<?
	$resUD = fetchData(' `other_service_registration` ', " where id='".$_SESSION['userId']."' ");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>	
<form class="form-horizontal" method="post" action="/other-profile" enctype="multipart/form-data" onsubmit="return checkCoords();">	
		<div style=" 
		height: 1000px;
    margin: auto;
    border: 2px solid;
    padding: 20px;  " class="col-md-12 col-sm-12">
					<h4>Change Timeline Pic</h4>
				<div style=" width:40%;float:left;padding:50px;
    margin: auto;">	
<? if($resUD['timeline_img']!="") {?><img src="/images/timeline/<?=$resUD['timeline_img']?>" width="100%" /><? } else {?><img src="/images/about.png" width="250px" /><? } ?>
<h6 style="color:red;">Image size should be 900px by 350px for perfect Look!</h6>	
</div><div style=" width:80%;float:left;padding:50px;
    margin: auto;">
					<div class="form-group">
		
<input name="image" id="fileInput" size="30" type="file" />				
</div>	
<p><img id="imagePreview" style="display:none;"/></p>
<input type="hidden" id="x" name="x" />		
<input type="hidden" id="y" name="y" />	
<input type="hidden" id="w" name="w" />		
<input type="hidden" id="h" name="h" />		
<input type="hidden" name="oldfile" value="<?=$resDD['timeline_img']?>" />	
<div class="form-group">				
<br/><br/><br/>		
<button type="submit" name="update_tps" class="btn btn-primary btn-block">Update</button>
<button type="submit" name="update_tp" class="btn btn-primary btn-block">Crop It</button>
</div>			
</div>			
<!--// <input name="upload" type="submit" value="UPLOAD" />-->	
</div>	
</form>	

<link rel="stylesheet" href="/image_crope/css/imgareaselect.css" />
<script src="/image_crope/js/jquery.imgareaselect.js"></script>
<script>function checkCoords(){    if(parseInt($('#w').val())) return true; }
function updateCoords(im,obj){	
var img = document.getElementById("imagePreview");	
var orgHeight = img.naturalHeight;    var orgWidth = img.naturalWidth;	    var porcX = orgWidth/im.width;    var porcY = orgHeight/im.height;	    $('input#x').val(Math.round(obj.x1 * porcX));    $('input#y').val(Math.round(obj.y1 * porcY));    $('input#w').val(Math.round(obj.width * porcX));    $('input#h').val(Math.round(obj.height * porcY));}$(document).ready(function(){        var p = $("#imagePreview");    $("#fileInput").change(function(){                p.fadeOut();		                var oFReader = new FileReader();        oFReader.readAsDataURL(document.getElementById("fileInput").files[0]);		        oFReader.onload = function(oFREvent){            p.attr('src', oFREvent.target.result).fadeIn();        };    });	        $('#imagePreview').imgAreaSelect({        onSelectEnd: updateCoords    });});</script>
			
<? } ?>

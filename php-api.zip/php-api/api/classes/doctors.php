<?php
class Doctors{

        // Connection
        private $conn;

        // Table
        private $db_table = "doctor_registration";

        // Columns
        public $id;
        public $fname;
        public $email;
        public $age;
        public $gender;
        public $created;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getDoctors(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getRecDoctors($city,$state){
			
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE (city='$city' AND state='$state') AND  active='Yes' order by featured DESC, arate DESC, last_login DESC LIMIT 0,10";
		    $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getRecDoctorsbystate($state){
			
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE state='$state' AND active='Yes' order by featured DESC, arate DESC, last_login DESC LIMIT 0,10";
	            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getRecDoctorsbycountry(){
			
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE country='101' AND  active='Yes' order by featured DESC, arate DESC, last_login DESC LIMIT 0,10";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		 public function getDoctorReward($doctor){
           $sqlQuery = "SELECT  * FROM
                        doctor_reward
                    WHERE doctor_id =$doctor ";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
             }
		 public function getdoctorsuggestions($search){
            $sqlQuery = "SELECT * FROM `doctor_registration` WHERE active='Yes' AND name like '%$search%' AND active='Yes' LIMIT 0,20";
		 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		 public function gethospitalsuggestions($search){
            $sqlQuery = "SELECT * FROM `medical_registration` WHERE active='Yes' AND name like '%$search%' AND active='Yes' LIMIT 0,20";
		 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		 public function getsearchsuggestions($search){
            $sqlQuery = "SELECT name,'doctor' AS usertype FROM `doctor_registration` WHERE name like '%$search%' AND active='Yes' LIMIT 0,5 UNION SELECT name, 'hospital' AS usertype FROM `medical_registration` WHERE name like '%$search%' AND active='Yes' UNION SELECT name, 'other' AS usertype FROM `other_service_registration` WHERE name like '%$search%' AND active='Yes' LIMIT 0,15";
		 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		
		 public function getaddresssuggestions($search,$city){
            $sqlQuery = "SELECT address FROM `doctor_registration` WHERE address like '%$search%' UNION SELECT address FROM `medical_registration` WHERE address like '%$search%' UNION SELECT address FROM `other_service_registration` WHERE address like '%$search%' AND city = $city LIMIT 0,15";
		 
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		  public function getDoctorsbylimit($skiprow,$row){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' order by featured DESC, arate DESC, last_login DESC LIMIT $skiprow,$row";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getRecommendDoctors($specid,$specity){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE specialisation = '$specid' OR city = '$specity' order by case when specialisation = '$specid' then 0 else 1 end, specialisation LIMIT 0,10";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		  public function getDoctorsbyCategory($id){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE active='Yes' AND specialisation = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
			public function updateproimg($fileName,$current_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET pro_img = '$fileName' ,
                        update_date = '$current_date'
						WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updatetimeimg($fileName,$current_date,$id){
          $sqlQuery = "update ". $this->db_table ." SET timeline_img = '$fileName' ,update_date = '$current_date' WHERE id = '$id'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		  public function getDoctorsbyemail($email){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE email = '$email'";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function getPasswordBymail($otp, $email){
            $sqlQuery = "SELECT `email`, `password` doctor_registration FROM WHERE `email` = '$email' AND `login_code` = $otp";
			
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		public function getPasswordByphone($otp, $phone){
            $sqlQuery = "SELECT `email`, `password` FROM doctor_registration WHERE `phone_no` = '$phone' AND `login_code` = $otp";
            $stmt = $this->conn->query($sqlQuery);
            return $stmt;
        }
		
		public function getDoctorsbyphone($phone){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE phone_no = '$phone'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function updateLoginCodeBymail($rnd, $email){
            $sqlQuery = "UPDATE doctor_registration SET `login_code` = '$rnd' WHERE `email` = '$email'";
			
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		public function updateLoginCodeByphone($rnd, $phone){
            $sqlQuery = "UPDATE doctor_registration SET `login_code` = '$rnd' WHERE `phone_no` = '$phone'";
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		
		
		  public function getCommentsbyDoc($id){
            $sqlQuery = "SELECT * FROM comment_doctor WHERE doc_id = $id";
		
            $stmt = $this->conn->query($sqlQuery);
             return $stmt;
        }
		
		public function setDoctors($userid,$password){
            $sqlQuery = "SELECT * FROM " . $this->db_table . " WHERE `user_id` = '$userid' AND `password` = '$password' AND `active` = 'Yes'";
			
			$stmt = $this->conn->query($sqlQuery);
			return $stmt;
            
        }
		
		public function getVerifyDoctorsbyPhone($phone){ 
            $sqlQuery = "SELECT * FROM all_users WHERE phone_no = '$phone'";
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
		 
	    	public function getDoctorActive($id,$otp)
		{
			
				
				$msql = "select * from doctor_registration WHERE id = '".$id."' AND active = '".$otp."'";
				//echo $msql; die;
				$reslt = $this->conn->query($msql);
				$count = mysqli_num_rows($reslt);
				
				if($count > 0)
				{
					$sqlQuery = "UPDATE doctor_registration SET active = 'Yes' WHERE id = '".$id."' AND active = '".$otp."'";
					$stmt = $this->conn->query($sqlQuery);
					//echo $sqlQuery;die;
					return $stmt;
				}
			
			
		}
		
				public function getActiveuser($id)
		{
			
				
				$msql = "select * from doctor_registration WHERE id = '".$id."' AND active = 'Yes'";
				
				$stmt = $this->conn->query($msql);
				return $stmt;
			
			
			
		}

        // CREATE
       public function createDoctors($foo,$first_name,$phone_no,$password,$email,$active,$insert_date){ 
   $sqlQuery = "INSERT INTO ". $this->db_table ." SET user_id = '$foo' ,
            name = '$first_name', 
                        phone_no = '$phone_no', 
                        password = '$password', 
                        email = '$email', 
                        active = '$active', 
                        insert_date = '$insert_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
			$sqlQuerys ="insert into `all_users` set user_id = '".$foo."', user_type = 'doctor', userId = '".$this->id."', email = '".$email."'";
      		$stmtt = $this->conn->query($sqlQuerys);
			
               return $stmt;
		} 
        }
		
		
	public function addcommentbydoc($name,$email,$comment,$doc_id,$status,$insert_date){ 
   $sqlQuery = "INSERT INTO comment_doctor set
		 `name` = '$name', 
		 `email` = '$email', 
		 `comment` = '$comment', 
		 `doc_id` = '$doc_id', 
		 `status` = '$status',		 
		 `insert_date` = '$insert_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 

			
               return $stmt;
		} 
        }
		
		
		public function addrplycommentbydoc($comment_id,$reply_by_id,$reply_by_name,$reply_by_email,$reply_message,$status){ 
   $sqlQuery = "INSERT INTO comment_reply_doctor set 
		`comment_id`='$comment_id', 
		`reply_by_id`='$reply_by_id',
		`reply_by_name`='$reply_by_name',
		`reply_by_email`='$reply_by_email',
		`reply_message`='$reply_message',
		`status`='$status'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 

			
               return $stmt;
		} 
        }
		
		public function addBlogbydoc($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$val,$post_by){ 
   $sqlQuery = "INSERT INTO blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
						image = '$image', 
                        video = '$video', 
                        insert_date = now(),
						userType = '$val',
						post_by = '$post_by'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
        
		public function updateBlogbydoc($title,$specialisation,$meta_name,$meta_discription,$description,$image,$video,$val,$post_by,$id){ 
   $sqlQuery = "UPDATE blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
						image = '$image', 
                        video = '$video', 
                        updated_date = now(),
						userType = '$val',
						post_by = '$post_by' WHERE id = '$id'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 		
               return $stmt;
		} 
        }
		public function updateBlogbydocs($title,$specialisation,$meta_name,$meta_discription,$description,$video,$val,$post_by,$id){ 
   $sqlQuery = "UPDATE blog SET title = '$title' ,
                         specialisation = '$specialisation', 
                        meta_name = '$meta_name', 
                        meta_discription = '$meta_discription', 
                        description = '$description',
                        video = '$video', 
                        updated_date = now(),
						userType = '$val',
						post_by = '$post_by' WHERE id = '$id'";
     
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 		
               return $stmt;
		} 
        }
		
			public function addDealbydoc($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$doctor_id){ 
   $sqlQuery = "INSERT INTO deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description', 
                        image = '$image', 
                        deal_date = '$deal_date',
						doctor_id = '$doctor_id'";
              
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
		public function updateDealbydoc($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$image,$deal_date,$doctor_id,$id){ 
   $sqlQuery = "UPDATE deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description', 
                        image = '$image', 
                        deal_date = '$deal_date',
						doctor_id = '$doctor_id' WHERE id = '$id'";
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
		
               return $stmt;
		} 
        }
		public function updateDealbydoctorss($title,$valid_from,$valid_to,$short_desc,$specialisation,$description,$deal_date,$doctor_id,$id){ 
   $sqlQuery = "UPDATE deals SET title = '$title' ,
                         valid_from = '$valid_from', 
                        valid_to = '$valid_to', 
                        short_desc = '$short_desc', 
                        specialisation = '$specialisation',
						description = '$description',
                        deal_date = '$deal_date',
						doctor_id = '$doctor_id' WHERE id = '$id'";
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
		
               return $stmt;
		} 
        }
		
		
		
			public function updateAdvbydoc($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg,$id){ 
   $sqlQuery = "UPDATE left_advt SET advtName = '$advtName' ,
                         web_url = '$web_url', 
                        city = '$city', 
                        pincode = '$pincode', 
                        userid = '$userid',
						usertype = '$usertype', 
                        duration = '$duration', 
                        advtImg = '$advtImg' WHERE id = '$id'";
		
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
					
               return $stmt;
		} 
        }
		
		
		public function addAdvbydoc($advtName,$web_url,$city,$pincode,$userid,$usertype,$duration,$advtImg){ 
   $sqlQuery = "INSERT INTO left_advt SET advtName = '$advtName' ,
                         web_url = '$web_url', 
                        city = '$city', 
                        pincode = '$pincode', 
                        userid = '$userid',
						usertype = '$usertype', 
                        duration = '$duration', 
                        advtImg = '$advtImg'";
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
		
               return $stmt;
		} 
        }
		
		
		 public function addProexpDoc($doctor_id,$hospital_id,$designation,$address,$hospital_c_name,$country,$state,$city,$from_date,$to_date){ 
   $sqlQuery = "INSERT INTO prof_exp_doc SET doctor_id = '$doctor_id' ,
            hospital_id = '$hospital_id', 
                        designation = '$designation', 
                        address = '$address', 
                        hospital_c_name = '$hospital_c_name',
						country = '$country', 
                        state = '$state', 
                        city = '$city',
						from_date = '$from_date', 
                        to_date = '$to_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		
		public function addothProexpDoc($doctor_id,$active,$designation,$address,$hospital_c_name,$country,$state,$city,$from_date,$to_date,$insert_date,$timestamp){ 
			
		   $sqlQuerys = "INSERT INTO medical_registration SET name = '$hospital_c_name' ,
						active = '$active', 
                        insert_date = '$insert_date', 
                        address = '$address', 
                        timestamp = '$timestamp',
						country = '$country', 
                        state = '$state', 
                        city = '$city'";
		$stmts = $this->conn->query($sqlQuerys);
		if($stmts){
			 $hospital_id = $this->conn->insert_id; 
			 
   $sqlQuery = "INSERT INTO prof_exp_doc SET doctor_id = '$doctor_id' ,
            hospital_id = '$hospital_id', 
                        designation = '$designation', 
                        address = '$address', 
                        hospital_c_name = '$hospital_c_name',
						country = '$country', 
                        state = '$state', 
                        city = '$city',
						from_date = '$from_date', 
                        to_date = '$to_date'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		}
		
		
		 public function addCurexpDoc($doc_id,$hospital_id,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST){ 
   $sqlQuery = "INSERT INTO current_hospital SET doc_id = '$doc_id' ,
                       hospital_id = '$hospital_id', 
                        level = '$level', 
                        sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		
		
		 public function updateCurexpDoc($doc_id,$hospital_id,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST,$id){ 
   $sqlQuery = "UPDATE current_hospital SET doc_id = '$doc_id' ,
                       hospital_id = '$hospital_id', 
                        level = '$level', 
                        sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		
		public function addothCurexpDoc($doc_id,$active,$address,$hospital_c_name,$country,$state,$city,$insert_date,$timestamp,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST){ 
			
		   $sqlQuerys = "INSERT INTO medical_registration SET name = '$hospital_c_name' ,
						active = '$active', 
                        insert_date = '$insert_date', 
                        address = '$address', 
                        timestamp = '$timestamp',
						country = '$country', 
                        state = '$state', 
                        city = '$city'";
		$stmts = $this->conn->query($sqlQuerys);
		if($stmts){
			 $hospital_id = $this->conn->insert_id; 
			 
   $sqlQuery = "INSERT INTO current_hospital SET doc_id = '$doc_id' ,
                       hospital_id = '$hospital_id', 
                        level = '$level', 
                        sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			 $this->id = $this->conn->insert_id; 
						
               return $stmt;
		} 
        }
		}
		
		
		public function updateothCurexpDoc($doc_id,$hospital_id,$active,$address,$hospital_c_name,$country,$state,$city,$insert_date,$timestamp,$level,$sun_FT,$sun_ST,$mon_FT,$mon_ST,$tue_FT,$tue_ST,$wed_FT,$wed_ST,$thu_FT,$thu_ST,$fri_FT,$fri_ST,$sat_FT,$sat_ST,$id){ 
			
		   $sqlQuerys = "UPDATE medical_registration SET name = '$hospital_c_name' ,
					    address = '$address', 
                      	country = '$country', 
                        state = '$state', 
                        city = '$city' WHERE id = '$hospital_id'";
		$stmts = $this->conn->query($sqlQuerys);
		if($stmts){
			 
			 
   $sqlQuery = "UPDATE current_hospital SET doc_id = '$doc_id' ,
                       hospital_id = '$hospital_id', 
                        level = '$level', 
                        sun_FT = '$sun_FT', 
                        sun_ST = '$sun_ST',
						mon_FT = '$mon_FT', 
                        mon_ST = '$mon_ST', 
                        tue_FT = '$tue_FT',
						tue_ST = '$tue_ST', 
                        wed_FT = '$wed_FT',
						 wed_ST = '$wed_ST',
						thu_FT = '$thu_FT', 
                        thu_ST = '$thu_ST', 
                        fri_FT = '$fri_FT',
						fri_ST = '$fri_ST', 
                        sat_FT = '$sat_FT',
						sat_ST = '$sat_ST' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
						
               return $stmt;
		} 
        }
		}
		
		
		
		
		
		public function updateothProexpDoc($doctor_id,$hospital_id,$active,$designation,$address,$hospital_c_name,$country,$state,$city,$from_date,$to_date,$insert_date,$timestamp,$id){ 
			
		   $sqlQuerys = "UPDATE medical_registration 
		   SET name = '$hospital_c_name' ,
						active = '$active', 
                        insert_date = '$insert_date', 
                        address = '$address', 
                        timestamp = '$timestamp',
						country = '$country', 
                        state = '$state', 
                        city = '$city' WHERE id = '$hospital_id' ";
		$stmts = $this->conn->query($sqlQuerys);
		if($stmts){
			
			 
   $sqlQuery = "UPDATE prof_exp_doc SET doctor_id = '$doctor_id' ,
            hospital_id = '$hospital_id', 
                        designation = '$designation', 
                        address = '$address', 
                        hospital_c_name = '$hospital_c_name',
						country = '$country', 
                        state = '$state', 
                        city = '$city',
						from_date = '$from_date', 
                        to_date = '$to_date' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
               return $stmt;
		} 
        }
		}
		
		
		 public function editProexpDoc($doctor_id,$hospital_id,$designation,$from_date,$to_date,$id){ 
   $sqlQuery = "UPDATE prof_exp_doc SET doctor_id = '$doctor_id' ,
            hospital_id = '$hospital_id', 
                        designation = '$designation', 
                        from_date = '$from_date', 
                        to_date = '$to_date' WHERE id = '$id'";

            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
			
						
               return $stmt;
		} 
        }
		
		
		
        // READ single
        public function getSingleDoctors($id){
            $sqlQuery = "SELECT  * FROM
                        ". $this->db_table ."
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }        

		   public function getPastExperience($id){
            $sqlQuery = "SELECT  * FROM prof_exp_doc WHERE doctor_id = $id";
			
            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
		  public function getCurrentExperience($id){
            $sqlQuery = "SELECT  * FROM current_hospital WHERE doc_id = $id";
            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
        // UPDATE
        public function updateGeneralinformation($name,$gender,$qualification,$dob,$specialisation,$regno,$regauthority,$expertisein,$summary,$metaTitle,$metaDesc,$totalexperience,$date,$userid){
          $sqlQuery = "update ". $this->db_table ." SET name = '$name' ,
                        gender = '$gender', 
                        qualification = '$qualification', 
                        date_birth = '$dob', 
                        specialisation = '$specialisation',
						registration_no = '$regno', 
                        registration_auth = '$regauthority', 
                        expertise_in = '$expertisein',
						summary = '$summary',
						meta_title = '$metaTitle',
						meta_description = '$metaDesc',
                        total_experience = '$totalexperience', 
                        update_date = '$date'
						WHERE id = '$userid'";
          
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		
		        // UPDATE
        public function updateContactinformation($phone_no,$other_phone,$fax_no,$mobile_no,$address,$country,$otherEmail,$city,$state,$district,$zipe_code,$update_date,$userid){
          $sqlQuery = "update ". $this->db_table ." SET phone_no = '$phone_no' ,
                        other_phone = '$other_phone', 
                        fax_no = '$fax_no', 
                        mobile_no = '$mobile_no', 
                        address = '$address',
						country = '$country', 
                        otherEmail = '$otherEmail', 
						  state = '$state',
                        city = '$city',
						district = '$district', 
                        zipe_code = '$zipe_code', 
                        update_date = '$update_date'
						WHERE id = '$userid'";
           
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function updatePersonalinformation($personalPhone,$personalMobile,$personalEmail,$personalUrl,$personalAddress,$update_date,$userid){
          $sqlQuery = "update ". $this->db_table ." SET
                        personalPhone = '$personalPhone' ,
                        personalMobile = '$personalMobile', 
                        personalEmail = '$personalEmail', 
                        personalUrl = '$personalUrl', 
                        personalAddress = '$personalAddress',
					    update_date = '$update_date'
						WHERE id = '$userid'";
                      
            $stmt = $this->conn->query($sqlQuery);
            
        if($stmt){
		               return $stmt;
		}
        }
		
		public function getVerifyDoctorsbyid($id){ 
            $sqlQuery = "SELECT * FROM all_users WHERE user_id = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
		 
		public function getVerifyDoctorsbyemail($id){
            $sqlQuery = "SELECT * FROM all_users WHERE email = '$id'";
         
            $stmt = $this->conn->query($sqlQuery);
		     return $stmt;
         }
		 
		public function setPassworddoc($id,$oldpassword,$newpassword){

             
            $sqlQuerys = "SELECT * FROM doctor_registration WHERE password = '$oldpassword' AND id='$id'";
          
            $stmts = $this->conn->query($sqlQuerys);
			$itemCounts = mysqli_num_rows($stmts);
		    if($itemCounts > 0){
			$sqlQuery =	"UPDATE doctor_registration set password='$newpassword' where id='$id'"; 
		     
				$stmt = $this->conn->query($sqlQuery);

				return $stmt;
			}else{
				
				return false;
				
			}
         } 
		 
		 
		 
		  public function getSingleprofexp($id){
            $sqlQuery = "SELECT  * FROM
                       prof_exp_doc
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
         public function deletePastExperience($id){
            $sqlQuery = "DELETE FROM prof_exp_doc WHERE id=$id"; 
            $stmt = $this->conn->query($sqlQuery);
             
                return true;
           
        }
		
		
		 public function getSinglecurrentexp($id){
            $sqlQuery = "SELECT  * FROM
                       current_hospital
                    WHERE 
                       id = $id
                    LIMIT 0,1";

            $stmt = $this->conn->query($sqlQuery);
            
			return $stmt;
        
        }
		
         public function deleteCurrentExperience($id){
            $sqlQuery = "DELETE FROM current_hospital WHERE id=$id"; 
            $stmt = $this->conn->query($sqlQuery);
             
                return true;
           
        }
		
		
	

    }

?>
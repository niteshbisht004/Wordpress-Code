<?php include("include/header.php");

//Specialisation List
$resHD = mysqli_query($conn, "SELECT * FROM specialisation") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$specialisations[$data['id']] = utf8_encode($data['specialisation']);
		$c++;
	}
}

//Qualification Lists
$resHD = mysqli_query($conn, "SELECT * FROM qualification") or die(mysqli_error());
if (mysqli_num_rows($resHD)) {

	$c = 0;
	while ($data = mysqli_fetch_assoc($resHD)) {

		$qualifications[$data['id']] = utf8_encode($data['qualification']);
		$c++;
	}
}


$resDDs = fetchData(' `doctor_registration` ', " where user_id='" . $did . "' ");

$docid = $resDDs['id'];

if (isset($_POST['rsubmit'])) {
	$rcmnt = $_POST['comnt'];
	$ridd = $_POST['rateIdd'];
	$uid = $_POST['userId'];
	$umail = $_POST['uemail'];
	$utype = $_POST['utype'];
	$urid = $_POST['urateId'];
	$urmail = $_POST['urateMail'];
	$urtype = $_POST['urateType'];
	$date = date("Y-m-d H:i:s");
	$rpId = $_POST['rplyid'];



	$rqry = "insert into rnewrating(`comment`,`rating_id`,`reply_id`,`user_id`,`email`,`rateusertype`,`rating_by_userid`,`rating_by_useremail`,`user_type`,`insert_date`) values('$rcmnt','$ridd','$rpId','$uid','$umail','$utype','$urid','$urmail','$urtype','$date')";
	$run = mysqli_query($conn, $rqry);
	if ($run) {
?>
		<script>
			//alert('Thanks for your comment.');
			if (window.location.href.indexOf("comments") > -1) {
               var url=window.location.href;
			window.history.replaceState(null, null, url);
    }else{
			var url=window.location.href+"#comments";
			window.history.replaceState(null, null, url);
	}
		</script>
<?
	} else {
		echo "error......!";
	}
}

if (isset($_POST['submit'])) {
	$ins = "insert into comment_doctor set
		 `name` = '" . $_POST['name'] . "', 
		 `email` = '" . $_POST['email'] . "', 
		 `comment` = '" . $_POST['comment'] . "', 
		 `doc_id` = '" . $docid . "', 
		 `status` = 'yes',		 
		 `insert_date` = now() 
		 ";
	mysqli_query($conn, $ins) or die(mysqli_error());
	echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
	header('location:/' . $did . '?openTab=commentsTab');
}
if (isset($_POST['rating'])) {
	echo $_POST['rating'];
	echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
	header('location:/' . $did);
}
if (isset($_GET['id'])) {
	$del = "delete from comment_doctor where id = '" . $_GET['id'] . "' ";

	mysqli_query($conn, $del) or die(mysqli_error());
	//echo "<script> alert('Comment has successfully submitted and pending for approval'); </script>";
	header('location:/' . $did . '?openTab=commentsTab');
}
if (isset($_GET['rid'])) {
	$report_cmt = " UPDATE comment_doctor set `status`='no', `report`='report' where id = '" . $_GET['rid'] . "' ";
	mysqli_query($conn, $report_cmt) or die(mysqli_error());

	$Query_cmnt = mysqli_query($conn, " select * from comment_doctor where id = '" . $_GET['rid'] . "' ") or die(mysqli_error());
	$num = mysqli_num_rows($Query_cmnt);
	$res_cmt = mysqli_fetch_array($Query_cmnt);


	// Mail to Report Abuse By...
	$report_by = $_SESSION['userEmail'];
	$comment_by = $res_cmt['email'];

	$subject = "FMI Report Abuse Information";

	$message_to_report_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>You did Report Abuse of <strong>'" . $res_cmt['name'] . "'</strong> Comment. </br>
						Reported Comment :- <strong>'" . $res_cmt['comment'] . "'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";

	$message_to_comment_by = "
				<html>
				<head>
				<title>Report Abuse Information</title>
				</head>
				<body>
					<p>Your Comment have been Reported Abuse By <strong>'" . $_SESSION['userName'] . "'</strong>. so we have to unpublished your comment due to the reason. </br>
						Reported By :- <strong>'" . $_SESSION['userEmail'] . "'</strong></br>
						Reported Comment :- <strong>'" . $res_cmt['comment'] . "'</strong>. </br>
						Path Details :- $url
					</p>				
				</body>
				</html>
				";

	// Always set content-type when sending HTML email
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	// More headers
	$headers .= 'From: <webmaster@example.com>' . "\r\n";
	$headers .= 'Cc: myboss@example.com' . "\r\n";

	$mail1 = mail($report_by, $subject, $message_to_report_by, $headers);
	$mail2 = mail($comment_by, $subject, $message_to_comment_by, $headers);

	// Mail to Commentor ..

	header('location:/' . $did . '?openTab=commentsTab');
}
if (isset($_POST['replysubmit'])) {
	$comment_id = $_POST['cmnt_id'];
	$rpy_commnt = mysqli_query($conn, "insert into comment_reply_doctor set 
		`comment_id`='$comment_id', 
		`reply_by_id`='" . $_SESSION['userId'] . "',
		`reply_by_name`='" . $_SESSION['userName'] . "',
		`reply_by_email`='" . $_SESSION['userEmail'] . "',
		`reply_message`='" . $_POST['Rcomment'] . "',
		`status`='yes' ") or die(mysqli_error());
	header('location:/' . $did);
}
?>

<!-- Page Content -->
<style type="text/css">
	@media screen and (max-width: 768px) {
		.rescontainer {
			margin-top: 176px !important;
		}
	}
</style>

<!--main banner-->
	<?
		$resDD = fetchData(' `doctor_registration` ', " where user_id='" . $did . "' ");
		$res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $docid . "' and rateusertype='doctor'");
		
	 ?>

<div class="container">
	<div class="drmf-main-banner-top col-md-12">
		<div class="row">
		<? if ($resDD['timeline_img'] != "") { ?>
					<img src="/images/timeline/<?= $resDD['timeline_img'] ?>" /><? 
				} else { ?>
					<img src="../images/home-icons/doctor-banner.jpg">
		<? } ?>
			
		</div>
	</div>
	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 drmf-main-section1">
		
			<div class="col-sm-12 col-xs-12 col-md-5 col-lg-3 single-showimg-left">
				<? if ($resDD['pro_img'] != "") { ?>
					<img class="fmi-profiles" src="/images/profile/<?= $resDD['pro_img'] ?>" /><? 
				} else { ?>
					<img class="fmi-profiles" src="/images/default.jpg" />
				<? } ?>
			</div>
			<div class="col-sm-12 col-xs-12 col-md-7 col-lg-9">
				<h1><?= $resDD['name']; ?></h1>
				<div class="rating-container rating-xs rating-animate col-sm-12">
				 <?  $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$count = $i;
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
							?>
					<a href="#review-down">
						<div class="rating">
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						</div>
					</a>
				</div>
				<div class="drmf-main-describe col-sm-12">
					<p class="drmf-110"><span class="text-center"><?= $resDD['total_experience'] ?></span></p>
		             <p class="drmf-111">
		<?
		$specialisation = explode("|", $resDD['specialisation']);
		foreach ($specialisation as $spl) {
		 echo $specialisations[$spl];
		}
			
		?></p>
				</div>
				<? if($resDD['summary'] == ''){ }else{?>
				<div class="col-sm-12">
					<p><?php echo $resDD['summary']; ?></p>
				</div>
				<?php } ?>

			</div>
		
	</div>

	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="info-detail-single-p">
		<div class="row">
		<h2>General Information</h2>

		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-users"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Gender</b></p>
					<p><?= $resDD['gender'] ?></p>
				</div>
			</div>
		</div>
		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-award"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Total Experience</b></p>
					<p><?= $resDD['total_experience'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-graduate"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Qualification</b></p>
					<p>
						<?php $qualification = explode("|", $resDD['qualification']); ?>
											<?
											foreach ($qualification as $quali) {
												$qualiOther = explode(":", $quali);
												if ($qualiOther[0] == "Other") {
													echo $qualiOther[1] . "<br/>";
												} else {
													echo $qualifications[$quali] . "&nbsp;&nbsp;";
												}
											}
										?>
					</p>
				</div>
			</div>
		</div>


		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-address-card"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration Authority</b></p>
					<p><?= $resDD['registration_auth'] ?></p>
				</div>
			</div>
		</div>


		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-info-circle"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Registration No.</b></p>
					<p><?= $resDD['registration_no'] ?></p>
				</div>
			</div>
		</div>

		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Expertise in</b></p>
					<p><?= $resDD['expertise_in'] ?></p>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 info-specialise" id="info-detail-single-p">
		<div class="row">
		<p class="sp-li-title">Specialisations</p>
	
		<?
		$specialisation = explode("|", $resDD['specialisation']);
		foreach ($specialisation as $spl) {
		?>
		<div class="col-sm-6 col-xs-6 col-md-4 col-lg-3 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-user-md"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Specialisation</b></p>
					<p><?php echo $specialisations[$spl]; ?></p>
				</div>
			</div>
		</div>
		<?php 
		}
			
		?>
	
	</div>
	</div>

	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="info-detail-single-p">
	<div class="row">
		<h3>Contact Information</h3>
		<?php if($resDD['phone_no'] == '91--') {}else{ ?>
		<div class="col-sm-6 col-xs-6 col-md-6 col-lg-4 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
				<i class="fas fa-phone"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Phone No</b></p>
					<p><?= $resDD['phone_no'] ?></p>
				</div>
			</div>
		</div>
		<?php } ?>
		<?php if($resDD['mobile_no'] == '') {}else{ ?>
		<div class="col-sm-6 col-xs-6 col-md-6 col-lg-4 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-mobile"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Mobile No</b></p>
					<p><?= $resDD['mobile_no'] ?></p>
				</div>
			</div>
		</div>
        <?php } ?>
		<div class="col-sm-6 col-xs-6 col-md-6 col-lg-4 main-info-sect-001">
			<div class="show-general-datas">
				<div class="show-main-p text-center">
					<i class="fas fa-map-marker-alt"></i>
				</div>
				<div class="show-main-p1">
					<p><b>Address</b></p>
					<p><?= $resDD['address'] ?></p>
				</div>
			</div>
		</div>
	</div>

	</div>
	  <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12 experin-detail-p" id="main-table-sty">
		  <div class="row">
		<h4>Experience</h4>
		   
	<? $resCH = fetchAllData(" `current_hospital` ", " where doc_id = '" . $resDD['id'] . "' "); 
	   if(!empty($resCH)){
	       
	?> 
	 
		<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 show1 tabl-sets" id="show2">
			<table class="table">
		
			<tbody>
			<?php foreach ($resCH  as $CH) {
				
           $hospital = fetchData(" `medical_registration`", " where id = '" . $CH['hospital_id'] . "'"); 
            ?>
				<tr>
				<td><?= $CH['level']; ?></td>
					<td><?= $hospital['name'] ?> -  <a class="ajax cboxElement" href="/doctor-current-hospital.php?id=<?= $CH['id'] ?>"> View Timing</a></td>
					
				</tr>
			<?php } ?>
			</tbody>
		</table>
		</div>
		
	<?php } ?>
	
	<? $resDPI = fetchAllData(" `prof_exp_doc` ", " where doctor_id = '" . $resDD['id'] . "' ");
       if(!empty($resDPI)){
	?>


		<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 show1 tabl-sets" id="show1">
		    <table class="table">
				<tbody>
					
						<? foreach ($resDPI  as $DPI) {
						$hospital = fetchData(" `medical_registration`", " where id = '" . $DPI['hospital_id'] . "'");
						?>
						<tr>
							<td><?= $DPI['designation']; ?>(<?= $DPI['from_date']?> - <?= $DPI['to_date'] ?>)</td>
							<td><?= $hospital['name']; ?></td>
						</tr>
					<? } ?>					
				</tbody>
			</table>
		</div>
	
	
	   <?php } ?>
	  </div>
   </div>
		
	<!--accordian
	<div class="col-md-12 drmf-main-accordion">
		<p class="ac-btn-title">Frequently Asked Questions</p>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>
		<button class="accordion">Q: Where does Dr. Pankaj Sachdeva practice?</button>
		<div class="panel">
			<p>A: Dr. Pankaj Sachdeva practices at Opthalmology - Sector-10, Tooth Care Dental Clinic Zirakpur - Zirakpur.</p>
		</div>


	</div>
	-->
	<!--deals-->
	<? $resdeals = fetchAllData("`deals`", " where doctor_id = '" . $resDD['id'] . "'");
	if(!empty($resdeals)){
	?>
	<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 main-work-sl-p deal-single-p">
		<h5>Burning Deals</h5>
		<div class="deals-slider" id="recommend-deals-2">
			<? foreach ($resdeals as $rd) { ?>
			<div class="col-md-3 text-center">
				<div class="set-sider-top-img">
					<? if (!empty($rd['image'])) { ?>
					<img src="/admin/images/uploads/<?= $rd['image'] ?>" class="img-ho-deal" />
					<? } else { ?>
					<img src="/images/hotdeals.png" class="img-ho-deal" />
					<? } ?>
					<p class="text-left"><a class='ajax' href="/deal.php?id=<?= $rd['id'] ?>"><?= $rd['title'] ?></a></p>
					<!--<span class="deal-valid text-left"><strong>Offered By :</strong>Dr Pawan kumar</span>-->
				</div>
			</div>
			<? } ?>
		</div>
	</div>
	<?php } ?>
	<!--Blogs-->
<? $resBlog = fetchAllData("`blog`", " where `status` !='0' and post_by = '" . $resDD['id'] . "' and userType = 'doctor' "); 
if(!empty($resBlog)){
?>
	<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 news-single-p">
		<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h6>Latest News</h6>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
						<a href="/blog">View All<i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>
		<? foreach ($resBlog as $rb) { ?>
		<div class="col-md-3">
			<a href="/blog-detail.php?id=<?= $rb['id']; ?>">
						<? if ($rb['image'] != "") { ?>
				<img  src="/admin/images/uploads/<?php echo $rb['image'];?>" class="img-fluid">
				<? } else { ?>
				<img src="/uploads/<?php echo $rb['image']; ?>" class="img-fluid">
				<? } ?>
			</a>
			<div class="caption-full-main">
				<div class="caption-full-data">
					<p><a href="/blog-detail.php?id=<?= $rb['id']; ?>"><?= $rb['title'] ?></a></p>
					<p><a href="/blog-detail.php?id=<?= $rb['id']; ?>"></a></p>
				</div>
				<div class="ratings text-right">
					<a href="/blog-detail.php?id=<?= $rb['id']; ?>">Read More <i class="fa fa-angle-right"></i></a>
				</div>
			</div>
		</div>
		<? } ?>
	</div>

<?php } ?>

	<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
		<div class="single-p-review" id="review-down">
			<div class="col-md-6 col-sm-12">
				<div class="single-set-rating text-center">
					<p class="p-rate-1"><b>Overall Rating</b></p>
                  <div class="rating-container rating-xs rating-animate col-sm-12">
					<div class="single-p-rating rating">
				
							<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
								</span></span>
							<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span>
								<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
						
					</div>
					</div>
					<p class="p-rate-2">Based on <?php echo $count; ?> Experiences</p>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="single-set-rating2 text-center">
					<p class="p-rate-1"><b>Rate your experience</b></p>
					<p class="p-rate-2">How likely are you to recommend us?</p>
					<div class="single-p-rating1">
					<a style="" href="/rating/<?= $did ?>">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					</a>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!--Comments-->
	<!-- /Current Hospital -->
<!-- /Current Hospital -->
	<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 tab-pane news-single-p" id="comments">
				<h6>Comments</h6>	

				<? include('comment.php'); ?>

	</div>


</div>



<div class="bottom-footer-slider" id="hospital-detail-top-doct">
	<div class="container">
		<div class="col-md-12" id="main-top-detail-11">
			<div class="row">
				<div class="col-md-8">
					<h4>Recommended doctors <span style="color:#ed1c24;">near you</span></h4>
					<p>Private online consultations with verified doctors in all specialists</p>
				</div>
				<div class="col-md-4">
					<div class="special-btn-area text-right">
						<a href="/doctors">View All Doctors <i class="fa fa-angle-right"></i></a>
					</div>
				</div>
			</div>
		</div>



	<div class="col-md-12 align-center text-sm review-slider" id="recommend-deals-1">
	<?
	
	$sId=$did;
    $res = doctor_detail(" `doctor_registration`", "where user_id='$sId'");
	$vars = $res[0];
			$x = explode("|", "$vars");
		    if(empty($x)){
				
			$specs = ' or specialisation like "%' .$vars . '%"';	
			}else{
			foreach ($x as $val) {
				$specs .= ' or specialisation like "%' . $val . '%"';
			}
            }
	$vars2=$res['city'];
  	$res_doctor = fetchAllData(" `doctor_registration`", "where  active = 'Yes' AND specialisation like '%fgfgfgfgf%' $specs AND city = $vars2");
    foreach($res_doctor as $doct ) {
	
	?>
	
		<div class="item col-md-3 text-left">
			<div class="d-details-per-column">
				<? if ($doct['pro_img'] != "") { ?>
			<img src="/images/profile/<?= $doct['pro_img'] ?>" class="img-responsive">
			<? } else { ?>
			<img src="/images/doctor-face.jpg" class="img-responsive">
		    <? } ?>
				<div class="col-sm-12 in-details-main-f featured-color">
					<p class="name-d"><a href="/<?= $doct['user_id'] ?>" target="_blank"><?php echo ucfirst($doct['name']) ?></a></p>
					<p class="special-d">		
				<? $specialisation = explode("|", $doct['specialisation']);
				$k=0;
				foreach ($specialisation as $spec) 
				{
					if($k==0)
					{
						echo trim($specialisations[$spec] . "&nbsp;");
					}
					else{}
					$k++;
				} 
			    ?>
			</p>
					<div class="rating-container rating-xs rating-animate">
			<div class="average-rating-d">
				<? $res_cmt = fetchAllData(" `newrating` ", " where user_id='" . $doct['id'] . "' and rateusertype='doctor'");

						
                        $r = 0;
						$i = 0;
						foreach ($res_cmt as $rat) {
							$r = $rat['rate'] + $r;
							$i++;
						}
						$r = $r / $i;
						if (is_nan($r)) {
							$r = 0;
						}
                        $r = round($r,1);
						if ($r == 0) {
							$var = '0%';
						}
						if ($r >= 1 && $r <= 1.5) {
							$var = '20%';
						}
						if ($r >= 1.5 && $r <= 2) {
							$var = '30%';
						}
						if ($r >= 2 && $r <= 2.5) {
							$var = '40%';
						}
						if ($r >= 2.5 && $r <= 3) {
							$var = '50%';
						}
						if ($r >= 3 && $r <= 3.5) {
							$var = '60%';
						}
						if ($r >= 3.5 && $r <= 4) {
							$var = '70%';
						}
						if ($r >= 4 && $r <= 4.5) {
							$var = '80%';
						}
						if ($r >= 4.5 && $r <= 5) {
							$var = '90%';
						}
						if ($r == 5) {
							$var = '100%';
						}
						?>
				<? if($r == 0){ }else{ ?><span><?php echo $r; ?></span><? } ?>
			</div>
			<div class="rating">
			<a style="" href="/rating/<?= $doct['user_id'] ?>">
				<span class="empty-stars"><span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star-empty"></i>
					</span><span class="star"><i class="glyphicon glyphicon-star-empty"></i>
					</span></span>
				<span class="filled-stars" style="width: <? echo $var; ?>"><span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span>
					<span class="star"><i class="glyphicon glyphicon-star"></i></span></span>
                    </a></div>
		</div>


				</div>
			</div>
		</div>
		
	<?php } ?>
		


				</div>
			</div>
		</div>


<!-- /.container -->

<? include('include/footer.php'); ?>
<script type="text/javascript" src="/js/jssor.slider-21.1.min.js"></script>
<script type="text/javascript" src="/js/script.js"></script>
<!-- use jssor.slider-21.1.debug.js instead for debug -->
<script src="/js/star-rating.js" type="text/javascript"></script>


<script>


	jssor_2_slider_init();


	$('.rec-doc').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 2000,
		arrows: false,
	});

</script>


<script>
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].addEventListener("click", function() {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		});
	}
</script>
<script>
	$('.deals-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 4000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
				},
			},
			
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>
<script>
	$('.review-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 6000,
		arrows: true,
		infinite: true,
		responsive: [{
				breakpoint: 1220,
				settings: {
					slidesToShow: 3,
				},
			},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				},
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				},
			},
		],
		nextArrow: '<i class="fa fa-angle-right next-arrows"></i>',
		prevArrow: '<i class="fa fa-angle-left prev-arrows"></i>'
	});
</script>
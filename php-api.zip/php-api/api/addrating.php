<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("HTTP/1.1 200 OK");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));


$user_id = $_POST['user_id'];
$rateusertype = $_POST['rateusertype'];
$email = $_POST['email'];
$rate = $_POST['rate'];
$recommend = $_POST['recommend'];
$comment = $_POST['comment'];
$rating_by_userid = $_POST['rating_by_userid'];
$rating_by_useremail = $_POST['rating_by_useremail'];
$user_type = $_POST['user_type'];
$rply_id = $_POST['commentid'];
$rating_id = $_POST['rating_id'];
$val = $_POST['cat']; 

    

    if($val == 'rcomment')
    {
       
    include_once 'classes/rating.php';
    $items = new Ratings($db);
    $stmt = $items->insertComment($rating_id,$rply_id,$user_id,
    $rateusertype,$email,$comment,$rating_by_userid,$rating_by_useremail,
    $user_type);
    //$allArr = array();
            if ($stmt) {

                $usr = array();
                $usr['id'] =  $items->id;
                $response['data'] = $usr;
                $response['message'] = "Data Inserted";
                $response['status'] = 1;


                $json_response = json_encode($response);
                echo $json_response;
                exit;
            } else {
                $response['message'] = "Data Not Inserted";
                $response['status'] = 0;

                $json_response = json_encode($response);
                echo $json_response;
                exit;
            }

    }else{

     
        include_once 'classes/rating.php';
        $items = new Ratings($db);
        $stmt = $items->insertRating(
            $user_id,
            $rateusertype,
            $email,
            $rate,
            $recommend,
            $comment,
            $rating_by_userid,
            $rating_by_useremail,
            $user_type
        );
        //$allArr = array();
        if ($stmt) {
    
            $usr = array();
            $usr['id'] =  $items->id;
            $response['data'] = $usr;
            $response['message'] = "Data Inserted";
            $response['status'] = 1;
    
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
            $response['message'] = "Already Rated";
            $response['status'] = 0;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }   



    }

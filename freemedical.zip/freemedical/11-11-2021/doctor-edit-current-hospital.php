<?
	include('../include/connection.php');
	include('../include/function.php');
?>
<?
	if ($_GET['edit']==1) {
		$resDD = fetchData(' `current_hospital` ', " where doc_id = '".$_SESSION['userId']."' and id = '".$_GET['id']."' ");
	}
?>
<link rel="stylesheet" type="text/css" href="/src/DateTimePicker.css" />
<script type="text/javascript" src="/src/DateTimePicker.js"></script>
<style>
.contact-time select{
	margin: -2px;
}
.dov label{
	font-weight: unset;
}
.dov{
	display: table;
}
.timing_table .row {
	border:1px solid #D1D1D1;
	padding: 4px;
	border-radius: 2px;
}
.timing_table .row label{
	font-weight: unset;
	margin-right: 10px;
	width: 48px;
}
.timing_table .row input[type=text]{
	text-align: center;
}
</style>
<script>
// Select State 
function select_state(str) {
  var xhttp;

  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("states").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "/ajax-file/select_states.php?id="+str, true);
  xhttp.send();  
  
}
function select_city(str) {
	
  var xhttp;

  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
	if (xhttp.readyState == 4 && xhttp.status == 200) {
	  document.getElementById("cities").innerHTML = xhttp.responseText;
	}
  };
  xhttp.open("GET", "/ajax-file/select_cities.php?id="+str, true);
  xhttp.send();  
  
}
</script>
<div class="popup-form">
            <form class="form-horizontal" role="form" action="/doctor-profile" method="post">
				<h4>Current Hospital</h4>
				<hr style="margin-top: 0px;"/>
                
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Hospital/ Poly/ Clinic</label>
                    <div class="col-sm-9">
                        
                        <select name="hospital_id" class="choosen-select" required>
                        	<option value="">Select one</option>
                        	<?php 
	                        	
	                        	$resDPI = fetchAllData(" `medical_registration` ", " ORDER BY name ASC");
	                        	foreach ($resDPI as $hos) {
		                        	
		                        	$selected = "";
		                        	if ($hos['id']==$resDD['hospital_id']) { $selected = "selected='selected'"; }
		                        	
		                        	$country = fetchData(" `countries`", " where id = '".$hos['country']."'"); 
									$state = fetchData(" `states`", " where id = '".$hos['state']."'");
									$city = fetchData(" `cities`", " where id = '".$hos['city']."'");
									$option_name = $hos['name'].", ".$city['name'].", ".$state['name'].", ".$country['name'];
		                        	echo "<option $selected value='".$hos['id']."' >".$option_name.", "."</option>";
	                        	}
	                        	
                        	?>
                        	<option value="other">Other</option> 
                        </select>
                        
                    </div>
                </div>
                
                <div class="other_hospital" >
	                
	                <div class="form-group">
	                    <label for="firstName" class="col-sm-3 control-label">Hospital/ Poly/ Clinic</label>
	                    <div class="col-sm-9">
	                        <input type="text" value="<?=$resDD['hospital_c_name']?>" name="hospital_c_name" class="form-control" id="inp" >
	                        
	                    </div>
	                </div>
					
					
					<? $add = explode("-|-",$resDD['address']); ?>
	                <div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">Address</label>
	                    <div class="col-sm-9">
	                        <textarea class="form-control" name="address" ><?=$add[0]?></textarea>
	                    </div>
	                </div>
	                <div class="form-group">
						<label class="col-sm-3 control-label" for="heading">Country</label>
						<div class="col-sm-9">
							<? $country = fetchAllData(" `countries`", " order by name"); ?>
							<select class="form-control input-md" onChange="select_state(this.value);" id="country" name ="country" >
									<? foreach($country as $coun) {
									
										
									
									?>
									<option  value="<?=$coun['id']?>" <?php if($coun['id'] == '101'){ echo 'selected';} ?>><?=$coun['name']?> </option> 
									<?php } ?>
							</select>
						</div>
						
					</div>
					<div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">State</label>
	                    <div class="col-sm-9">
							<? $states_res = fetchAllData(" `states`", " where country_id = '101' order by name"); ?>
	                        <select class="form-control input-md" id="states" onchange="select_city(this.value)" name ="state" >
									<option value="" selected disabled>Choose a State</option>
									<? foreach($states_res as $sta)
									{
									?>
									<option  <?php if($sta['id'] == $add[2]){ echo 'selected';} ?>  value="<?=$sta['id']?>" ><?=$sta['name']?> </option> 
									<?php } ?>
							</select>
	                    </div>
	                </div>
					
					<div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">City</label>
	                    <div class="col-sm-9">
	                        <? $city_res = fetchAllData(" `cities`", " where state_id = '".$add[3]."' order by name"); ?>
	                        <select class="form-control input-md" id="cities" name ="city" >
									<option value="" selected disabled>Choose a City</option>
									<? foreach($city_res as $ct)
									{
									?>
									<option  <?php if($ct['id'] == $add[3]){ echo 'selected';} ?>  value="<?=$ct['id']?>" ><?=$ct['name']?> </option> 
									<?php } ?>
							</select>
	                    </div>
	                </div>
					<!-- <div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">Zip</label>
	                    <div class="col-sm-9">
	                        <input type="text" name="zip" onkeyup="validateNumber(this)" id="zip" class="form-control" value="<?=$add[4]?>" />
	                    </div>
	                </div> -->
	            </div>
                
                
                
				<div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Designation</label>
                    <div class="col-sm-9">
                        <input type="text" value="<?=$resDD['level']?>" name="level" class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Seating Availability</label>
					<div class="col-sm-9">
						<div class="timing_table">
							
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Mon </label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">	
										<? $time=explode('-',$resDD['mon_FT']);?>
										<label class="">1st Timming</label>																		
										<input type="text" onchange="timevalidateFrom('monF_FT','monT_FT')" id="monF_FT" data-field="time" data-format="hh:mm AA" name="monF_FT" placeholder="From" value="<? echo $time[0]; ?>"/>
										<input type="text" onchange="timevalidateTo('monF_FT','monT_FT')" id="monT_FT" data-field="time" data-format="hh:mm AA" name="monT_FT" placeholder="To" value="<? echo $time[1]; ?>"/>
									</div>
									<div class="col-md-6">	
										<? $time=explode('-',$resDD['mon_ST']);?>
										<label class="">2nd Timming</label>																			
										<input type="text" onchange="timevalidateFrom('monF_ST','monT_ST')" id="monF_ST" data-field="time" data-format="hh:mm AA" name="monF_ST" placeholder="From" value="<? echo $time[0]; ?>"/>
										<input type="text" onchange="timevalidateTo('monF_ST','monT_ST')" id="monT_ST" data-field="time" data-format="hh:mm AA" name="monT_ST" placeholder="To" value="<? echo $time[1]; ?>"/>
									</div>
								</div>
							</div>
							<div class="row"><span onclick="fillAll()" style="font-weight: bold; cursor: pointer;">Apply to all days</span></div>
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Tus</label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">
										<? $time=explode('-',$resDD['tue_FT']);?>
										<label class="">1st Timming</label>
										<input type="text" onchange="timevalidateFrom('tusF_FT','tusT_FT')" id="tusF_FT" data-field="time" data-format="hh:mm AA" name="tusF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('tusF_FT','tusT_FT')" id="tusT_FT" data-field="time" data-format="hh:mm AA" name="tusT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT' />
									</div>
									<div class="col-md-6">
										<? $time=explode('-',$resDD['tue_ST']);?>
										<label class="">2nd Timming</label>	
										<input type="text" onchange="timevalidateFrom('tusF_ST','tusT_ST')" id="tusF_ST" data-field="time" data-format="hh:mm AA" name="tusF_ST" placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('tusF_ST','tusT_ST')" id="tusT_ST" data-field="time" data-format="hh:mm AA" name="tusT_ST" placeholder="To" value="<? echo $time[1]; ?>" class='to_ST' />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Wed</label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">
										<? $time=explode('-',$resDD['wed_FT']);?>
										<label class="">1st Timming</label>
										<input type="text" onchange="timevalidateFrom('wedF_FT','wedT_FT')" id="wedF_FT" data-field="time" data-format="hh:mm AA" name="wedF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('wedF_FT','wedT_FT')" id="wedT_FT" data-field="time" data-format="hh:mm AA" name="wedT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT'/>
									</div>
									<div class="col-md-6">
										<? $time=explode('-',$resDD['wed_ST']);?>
										<label class="">2nd Timming</label>	
										<input type="text" onchange="timevalidateFrom('wedF_ST','wedT_ST')" id="wedF_ST" data-field="time" data-format="hh:mm AA" name="wedF_ST" placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('wedF_ST','wedT_ST')" id="wedT_ST" data-field="time" data-format="hh:mm AA" name="wedT_ST" placeholder="To" value="<? echo $time[1]; ?>" class='to_ST' />
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Thu</label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">
										<? $time=explode('-',$resDD['thu_FT']);?>
										<label class="">1st Timming</label>
										<input type="text" onchange="timevalidateFrom('thuF_FT','thuT_FT')" id="thuF_FT" data-field="time" data-format="hh:mm AA" name="thuF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('thuF_FT','thuT_FT')" id="thuT_FT" data-field="time" data-format="hh:mm AA" name="thuT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT' />
									</div>
									<div class="col-md-6">
										<? $time=explode('-',$resDD['thu_ST']);?>
										<label class="">2nd Timming</label>	
										<input type="text" onchange="timevalidateFrom('thuF_ST','thuT_ST')" id="thuF_ST" data-field="time" data-format="hh:mm AA" name="thuF_ST" placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('thuF_ST','thuT_ST')" id="thuT_ST" data-field="time" data-format="hh:mm AA" name="thuT_ST" placeholder="To" value="<? echo $time[1]; ?>" class='to_ST' />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Fri</label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">
										<? $time=explode('-',$resDD['fri_FT']);?>
										<label class="">1st Timming</label>								
										<input type="text" onchange="timevalidateFrom('friF_FT','friT_FT')" id="friF_FT" data-field="time" data-format="hh:mm AA" name="friF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('friF_FT','friT_FT')" id="friT_FT" data-field="time" data-format="hh:mm AA" name="friT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT' />
									</div>
									<div class="col-md-6">
										<? $time=explode('-',$resDD['fri_ST']);?>
										<label class="">2nd Timming</label>	
										<input type="text" onchange="timevalidateFrom('friF_ST','friT_ST')" id="friF_ST" data-field="time" data-format="hh:mm AA" name="friF_ST" placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('friF_ST','friT_ST')" id="friT_ST" data-field="time" data-format="hh:mm AA" name="friT_ST" placeholder="To" value="<? echo $time[1]; ?>" class='to_ST' />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Sat</label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">
										<? $time=explode('-',$resDD['sat_FT']);?>
										<label class="">1st Timming</label>
										<input type="text" onchange="timevalidateFrom('satF_FT','satT_FT')" id="satF_FT" data-field="time" data-format="hh:mm AA" name="satF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('satF_FT','satT_FT')" id="satT_FT" data-field="time" data-format="hh:mm AA" name="satT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT' />
									</div>
									<div class="col-md-6">
										<? $time=explode('-',$resDD['sat_ST']);?>
										<label class="">2nd Timming</label>	
										<input type="text" onchange="timevalidateFrom('satF_ST','satT_ST')" id="satF_ST" data-field="time" data-format="hh:mm AA" name="satF_ST" placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('satF_ST','satT_ST')" id="satT_ST" data-field="time" data-format="hh:mm AA" name="satT_ST" placeholder="To" value="<? echo $time[1]; ?>" class='to_ST'  />
									</div>
								</div>
							</div>
							<div class=" row">
								<div class="col-md-1">
									<label style="padding-top:50px;">Sun </label>
								</div>
								<div class="col-md-10 ">
									<div class="col-md-6">	
										<? $time=explode('-',$resDD['sun_FT']);?>
										<label class="">1st Timming</label>																		
										<input type="text" onchange="timevalidateFrom('sunF_FT','sunT_FT')" id="sunF_FT" data-field="time" data-format="hh:mm AA" name="sunF_FT" placeholder="From" value="<? echo $time[0]; ?>" class='from_FT' />
										<input type="text" onchange="timevalidateTo('sunF_FT','sunT_FT')" id="sunT_FT" data-field="time" data-format="hh:mm AA" name="sunT_FT" placeholder="To" value="<? echo $time[1]; ?>" class='to_FT' />
									</div>									
									<div class="col-md-6">	
										<? $time=explode('-',$resDD['sun_ST']);?>
										<label class="">2nd Timming</label>																		
										<input type="text" onchange="timevalidateFrom('sunF_ST','sunT_ST')" id="sunF_ST" data-field="time" data-format="hh:mm AA" name="sunF_ST"  placeholder="From" value="<? echo $time[0]; ?>" class='from_ST' />
										<input type="text" onchange="timevalidateTo('sunF_ST','sunT_ST')" id="sunT_ST" data-field="time" data-format="hh:mm AA" name="sunT_ST"  placeholder="To" value="<? echo $time[1]; ?>" class='to_ST' />
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>

                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <?php if ($_GET['edit']==1): ?>
                        <input type="hidden" name="curId" value="<?=$_GET['id']?>"/>
                        <button type="submit" name="update_current" class="btn btn-primary btn-block" >Update</button>
                        <?php else: ?>
                        <button type="submit" name="add_current_hospital" class="btn btn-primary btn-block" >Add</button>	
                        <?php endif; ?> 
                    </div>
                </div>
            </form> <!-- /form -->
</div>
<!-- 
<script>
	function timevalidateFrom(frm,to){
		var val = document.getElementById(frm).value;
		var tov = document.getElementById(to).value;
		if(tov!=""){			
			var start = convertTimeFrom12To24(val);
			var end = convertTimeFrom12To24(tov);
			checktime(start,end,frm);
		}
	}
	function timevalidateTo(frm,to){
		var frmv = document.getElementById(frm).value;
		var val = document.getElementById(to).value;
		if(frmv!=""){			
			var end = convertTimeFrom12To24(val);
			var start = convertTimeFrom12To24(frmv);
			checktime(start,end,to);
		}
	}
	
	
	function convertTimeFrom12To24(timeStr) {
	  var colon = timeStr.indexOf(':');
	  var hours = timeStr.substr(0, colon),
		minutes = timeStr.substr(colon+1, 2),
		meridian = timeStr.substr(colon+4, 2).toUpperCase();
	  var hoursInt = parseInt(hours, 10),
		  offset = meridian == 'PM' ? 12 : 0;
	  if (hoursInt === 12) {
		hoursInt = offset;
	  } else {
		hoursInt += offset;
	  }
	  return hoursInt + ":" + minutes;
	}
	
	 function checktime(start,end,validateId)
	{		
		if(Date.parse('01/01/2011 '+end) < Date.parse('01/01/2011 '+start))
		{
			document.getElementById(validateId).value="";
			alert("End time should exceed the start time");
		}
		else if(Date.parse('01/01/2011 '+end) -Date.parse('01/01/2011 '+start)==0)
		{
			document.getElementById(validateId).value="";
			alert("Start time and end time cannot be same");
		}
		return false;
	}
	
	 function validateNumber(evt) {
			var temVal = evt.value.replace(/[^0-9]/g, '');
			if(temVal!=evt.value){
				
				evt.value = temVal;
				return false;
			}
			if(!evt.value.match(/^[0-9]/g)) {
			  
			  return false;
			}
			return true;
	}
</script>
-->
<script>
	function timevalidateFrom(frm,to){
		var val = document.getElementById(frm).value;
		var tov = document.getElementById(to).value;
		if(tov!=""){			
			var start = convertTimeFrom12To24(val);
			var end = convertTimeFrom12To24(tov);
			checktime(start,end,frm);
		}
	}
	function timevalidateTo(frm,to){
		var frmv = document.getElementById(frm).value;
		var val = document.getElementById(to).value;
		if(frmv!=""){			
			var end = convertTimeFrom12To24(val);
			var start = convertTimeFrom12To24(frmv);
			checktime(start,end,to);
		}
	}
	function fillAll(){
		var from_FT = document.getElementsByClassName('from_FT');
		for (i = 0; i < from_FT.length; i++) {
			from_FT[i].value=document.getElementById('monF_FT').value;
		}
		var to_FT = document.getElementsByClassName('to_FT');
		for (i = 0; i < to_FT.length; i++) {
			to_FT[i].value=document.getElementById('monT_FT').value;
		}
		var from_ST = document.getElementsByClassName('from_ST');
		for (i = 0; i < from_ST.length; i++) {
			from_ST[i].value=document.getElementById('monF_ST').value;
		}
		var to_ST = document.getElementsByClassName('to_ST');
		for (i = 0; i < to_ST.length; i++) {
			to_ST[i].value=document.getElementById('monT_ST').value;
		}
	}
	
	function convertTimeFrom12To24(timeStr) {
	  var colon = timeStr.indexOf(':');
	  var hours = timeStr.substr(0, colon),
		minutes = timeStr.substr(colon+1, 2),
		meridian = timeStr.substr(colon+4, 2).toUpperCase();
	  var hoursInt = parseInt(hours, 10),
		  offset = meridian == 'PM' ? 12 : 0;
	  if (hoursInt === 12) {
		hoursInt = offset;
	  } else {
		hoursInt += offset;
	  }
	  return hoursInt + ":" + minutes;
	}
	
	 function checktime(start,end,validateId)
	{		
		if(Date.parse('01/01/2011 '+end) < Date.parse('01/01/2011 '+start))
		{
			document.getElementById(validateId).value="";
			alert("End time should exceed the start time");
		}
		else if(Date.parse('01/01/2011 '+end) -Date.parse('01/01/2011 '+start)==0)
		{
			document.getElementById(validateId).value="";
			alert("Start time and end time cannot be same");
		}
		return false;
	}
	
	
	 function validateNumber(evt) {
			var temVal = evt.value.replace(/[^0-9]/g, '');
			if(temVal!=evt.value){
				
				evt.value = temVal;
				return false;
			}
			if(!evt.value.match(/^[0-9]/g)) {
			  
			  return false;
			}
			return true;
	}
</script>
<div id="dtBox"></div>
		<script type="text/javascript">
		
			$(document).ready(function()
			{
				$("#dtBox").DateTimePicker();
			});
			
			$(".choosen-select").chosen({ width:300 });
	$(".choosen-select").change(function() {
		
		toggle_other_hospital_fields ();
	});
	
	function toggle_other_hospital_fields () {
    	
    	if($(".choosen-select").val()=="other") {
    		$(".other_hospital").fadeIn(300);
    		$(".other_hospital input").attr("required",true);
    		$(".other_hospital select").attr("required",true);
		} else {
    		$(".other_hospital").fadeOut(300);
    		$(".other_hospital input").removeAttr("required");
    		$(".other_hospital select").removeAttr("required");
		}
    	
	}
	
	toggle_other_hospital_fields ();
			
		
		</script>
<?php
//error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
       header("HTTP/1.1 200 OK");
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');
  
    include_once 'config/database.php';
	$database = new Database();
    $db = $database->getConnection();
	$data = json_decode(file_get_contents("php://input"));
	
	$val = $_POST['cat'];
	$id = $_POST['id'];
	
	$uid = $_POST['uid'];
	$utype = $_POST['utype'];
	$ruid = $_POST['ruid'];
	$rutype = $_POST['rutype'];
		$specid = $_POST['specialization'];
	$ctyid =$_POST['city'];
	$rusertype = $_POST['usertype'];
	 include_once 'classes/city.php';
	$cityitems = new Cities($db);
	
	include_once 'classes/states.php';
	$stateitems = new States($db);
  
    include_once 'classes/country.php';
	$countryitems = new Countries($db);
	
	include_once 'classes/special.php';
	$specialitems = new Special($db);
	
	
	include_once 'classes/qual.php';
	$qualitems = new Qual($db); 
	
	include_once 'classes/rating.php';
	$rateitems = new Ratings($db);
	
	if($val == 'user'){
    include_once 'classes/users.php';
	$items = new Users($db);
    $stmt = $items->getSingleUsers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
												
		 	$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];
			 
		if($row['pro_img'] == ''){
			
			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['userproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['usertimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
			
		}
		
				
									
		 
			 
			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	if($val == 'usergeninfo'){
    include_once 'classes/users.php';
	$items = new Users($db);
    $stmt = $items->getSingleUsers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = array();
												
		    $userArr['first_name'] = $row['first_name'];
			$userArr['last_name'] = $row['last_name'];
			$userArr['date_birth'] = $row['date_birth'];
			$userArr['gender'] = $row['gender'];
			$userArr['blood_group'] = $row['blood_group'];
			$userArr['interested'] = $row['interested'];
			$userArr['qualification'] = $row['qualification'];
			
		
									
		 
			 
			// $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	
	
	if($val == 'doctor'){
		
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getSingleDoctors($id);
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				if($row['pro_img'] == ''){
			
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
		}else{
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['doctortimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			
			 
			 
			 $valq =  explode("|",$row['qualification']);
				
			if(count($valq) > 1){
			
			   $Qual = "";
				foreach($valq as $keyq){
				
				$Qualstmt = $qualitems->getSingleQual($keyq);
			    $qualname =  mysqli_fetch_row($Qualstmt);
		        $Qual .=  $qualname[0]." ";
					
				}
				
			$cityArr['qualificationname'] = $Qual;
			
			}else{
          $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
				}
			 
			 
			 
			 
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);

									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
				
			$cityArr['is_rating'] = 0;	
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);
 
			 
			 
					 
			$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}
	
	
	
	
	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}
			
			
	include_once 'classes/blog.php';		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);



    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
			$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		    include_once 'classes/doctors.php';
			$itemst = new Doctors($db);
			$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
			$rowd = mysqli_fetch_row($stmtt);	
			$cityArrde['offerby'] = $rowd[3];
		 
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	} 
			 
		


        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($id,'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}

			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
		if($val == 'doctorgeninfo'){
		
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getSingleDoctors($id);
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			$userArr['name'] = $row['name'];
			$userArr['gender'] = $row['gender'];
			$userArr['qualification'] = $row['qualification'];
			$userArr['date_birth'] = $row['date_birth'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
			$userArr['expertise_in'] = $row['expertise_in'];
			$userArr['summary'] = $row['summary'];
			
	 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}									
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	if($val == 'hospital'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
			 if($row['pro_img'] == ''){
			
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
		}else{
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
		$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
				
			$cityArr['is_rating'] = 0;	
			
			}
		      $catid = $row['hospital_category'];
			 $catstmt = $items->getHospitalsbyCategoryid($catid);
			  $hosname =  mysqli_fetch_row($catstmt);
			 $cityArr['hospital_categoryname'] = $hosname[1];
			 
			 
			 
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyhospitalid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);

    $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyhospitalid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
			$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			include_once 'classes/hospitals.php';
			$itemst = new Hospitals($db);
			$stmtt = $itemst->getSingleHospitals($rowde['hospital_id']);
			$rowd = mysqli_fetch_row($stmtt);	
			$cityArrde['offerby'] = $rowd[4];
		 
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	} 
			 
			 
			
		        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($id,'hospital');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
              /*
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
         if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}
		    
		   
            }
	}
			 
			 $allArr = array_merge($row,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	if($val == 'hospitalgeninfo'){
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			
		$userArr['name'] = $row['name'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
			$userArr['noOfBeds'] = $row['noOfBeds'];
			$userArr['private_room'] = $row['private_room'];
			
				$userArr['hospital_category'] = $row['hospital_category'];
			$userArr['clinical_test'] = $row['clinical_test'];
			$userArr['ambulance'] = $row['ambulance'];
			$userArr['summary'] = $row['summary'];
			$userArr['heyear'] = $row['heyear'];
			
			$userArr['extra_feature'] = $row['extra_feature'];
			$userArr['update_date'] = $row['update_date'];
			$userArr['id'] = $row['id'];
	
					 
       $val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}									
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	
	
	
	
	if($val == 'other'){
    include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getSingleOthers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				
		     if($row['pro_img'] == ''){
			
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/hospital1.jpg';
		}else{
			$cityArr['hospitalproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$row['pro_img'];
			
		}
		
			if($row['timeline_img'] == ''){
			
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['hospitaltimeline_img'] = 'https://www.freemedicalinfo.in/images/timeline/'.$row['timeline_img'];
			
		}
		
				
				
		     $citystmt = $cityitems->getSingleCity($row['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($row['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($row['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			 
			 $qalistmtr = $qualitems->getSingleQual($row['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
		$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
            }else{
				
			$cityArr['is_rating'] = 0;	
			}

            include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other-medical');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbyotherid($row['id']);
			$cityArr['deal_count'] = mysqli_num_rows($stmtd);
            
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$val =  explode("|",$rowsado['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrad['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
				}
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}







			$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'other');
	$itemCountbo = mysqli_num_rows($stmtbo);


    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}






    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbyotherid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
		 
		  	 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($rowde['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[5];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}			
		 
		 
		 
	        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($id,'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
            /*
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
            */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
         if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
			*/
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		} 
		    
		   
		              
    
            }
	}	 
		 
			 
			 $allArr = array_merge($row,$cityArr);
		   
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	
	
	
	
	if($val == 'othergeninfo'){
include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getSingleOthers($id);
	
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           //$userArr[] = $row;
				
			
		    $userArr['name'] = $row['name'];
			$userArr['specialisation'] = $row['specialisation'];
			$userArr['registration_no'] = $row['registration_no'];
			$userArr['registration_auth'] = $row['registration_auth'];
		
			$userArr['extra_feature'] = $row['extra_feature'];
	
	


           $val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}								
		 
			 
			 $allArr = array_merge($userArr,$cityArr);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
    }
	

	
	if($val == 'pastexpdoctors'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getPastExperience($id);
	
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $userexp = $items->getSingleHospitals($row['hospital_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		  
			 $cityArr['hospitalid'] = $row['hospital_id'];
		     $cityArr['hospitalname'] = $rows['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
	
  	if($val == 'currentexpdoctors'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $stmt = $items->getCurrentExperience($id);
	
	$itemCount = mysqli_num_rows($stmt);

    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $userexp = $items->getSingleHospitals($row['hospital_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		  
			 $cityArr['hospitalid'] = $row['hospital_id'];
		     $cityArr['hospitalname'] = $rows['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }

  	if($val == 'getavailabledoctorsinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getAvailableDoctors($id);
	
	$itemCount = mysqli_num_rows($stmt);

    if($itemCount > 0){
        
        $userArr = array();
       $cityArr = array();
       
        while ($row = $stmt->fetch_assoc()){
	$userArr[] = $row['doctor_id'];
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
    $userexp = $items->getSingleDoctors($row['doctor_id']);

		 while ($rows = $userexp->fetch_assoc()){   
		if($rows['pro_img'] == ''){
			
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArr['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rows['pro_img'];
			
		}
		
		 $cityArr['doctorname'] = $rows['name'];
		   $citystmt = $cityitems->getSingleCity($rows['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArr['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rows['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArr['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rows['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArr['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rows['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArr['qualificationname'] = $qualname[0];
			 
			$val =  explode("|",$rows['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rows['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
		 }
		
		$allArr = array_merge($row,$cityArr);
        }
		
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }
    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    
	}
	
  }
  
  if($val == 'availablefacilityinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['available_facility']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	if($val == 'specialinfrainhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['special_infra']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
		if($val == 'specialmachineinhospitals'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
    $stmt = $items->getSingleHospitals($id);
	
	   $itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        //$allArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr = explode("-|-",$row['special_machine']);
		  foreach($userArr as $facility){
				
		     $allArr .= $facility.",";
			  			 
		  }
			 
			 
		   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	
	
	
	
	
	
	
	if($val == 'deals'){
    include_once 'classes/deals.php';
	$items = new Deals($db);
	if($usertype == 'doctor'){
		
	$stmt = $items->getSingleDealsbydoctorid($id);
	}
	if($usertype == 'hospital'){
		
	$stmt = $items->getSingleDealsbyhospitalid($id);
	}
	if($usertype == 'other'){
		
	$stmt = $items->getSingleDealsbyotherid($id);
	}
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
				
		     $cityArr['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image'];
			    $cityArr['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image']; 
			$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
			  if($row['doctor_id'] != '')
			  {
		 
				include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($row['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[3];
	          }
	           if($row['hospital_id'] != '')
			  {
		 
				include_once 'classes/hospitals.php';
				$itemst = new Hospitals($db);
				$stmtt = $itemst->getSingleHospitals($row['hospital_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[4];
	          }
			   if($row['other_id'] != '')
			  {
		 
				 include_once 'classes/others.php';
				$itemst = new Others($db);
				$stmtt = $itemst->getSingleOthers($row['other_id']);
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArr['offerby'] = $rowd[5];
	          }
		 
			 
			 $allArr[] = array_merge($cityArr,$row);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	
    }
	
    
	if($val == 'blogs'){
    include_once 'classes/blog.php';
	$items = new Blogs($db);
	$stmt = $items->getSingleBlog($id);
	
	$itemCount = mysqli_num_rows($stmt);


    if($itemCount > 0){
        
        $userArr = array();
        $cmntArrr = array();
        $cmntArr = array();
        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     $cityArr['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$row['image'];
			 	$video = explode("/",$row['embed_video']);
		
			 $cityArr['video_id'] = $video[4];  			 
	              
	
			$cmntstmt = $items->getBlogComment($id);
			$comntCount = mysqli_num_rows($cmntstmt);
			if($comntCount>0)
				
			{
				while($rows = $cmntstmt->fetch_assoc())
				{
					$cmntArr[] = $rows;
			      
	        include_once 'classes/users.php';
	        $itemsb = new Users($db);
	        $stmtb = $itemsb->getbloguserbyid($rows['email']);
	        $userid =  mysqli_fetch_row($stmtb);
	        $cmntArrr['userid'] = 	$userid[1];
			$cmntArrr['usertype'] = $userid[2];
					
				$cmntstmtr = $items->getRplyBlogComment($rows['id']);	
					$comntCountr = mysqli_num_rows($cmntstmtr);
					
			if($comntCountr>0){
				
				while($rowsr = $cmntstmtr->fetch_assoc())
				{

                 $cmntArrr['rplycomment'][] = $rowsr;

			}
			$cityArr['comment'][] = array_merge($rows,$cmntArrr);
			}else{
				
			$cityArr['comment'][] = $rows;	
			}					
					
			
				}
				
				
			}
		
			 $allArr[] = array_merge($row,$cityArr);
				
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$allArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
     
	 
	 if($val == 'coupan'){
    include_once 'classes/coupan.php';
	$items = new Coupans($db);
	if($rusertype == 'doctor'){
		
	$stmt = $items->getCoupansbyDoctor($id);
	}
	if($rusertype == 'hospital'){
		
	$stmt = $items->getCoupansbyHospital($id);
	}
	if($rusertype == 'other'){
		
	$stmt = $items->getCoupansbyOther($id);
	}
	$itemCount = mysqli_num_rows($stmt);
	if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
									
		 
			 
			 //$allArr[] = array_merge($cityArr,$row);
		   
       
		 }	
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    
	
    }
	 


	
	
		if($val == 'getCommentsbyDoc'){
    include_once 'classes/doctors.php';
	$items = new Doctors($db);
	$stmt = $items->getCommentsbyDoc($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'getCommentsbyHos'){
    include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	$stmt = $items->getCommentsbyHos($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }
	
	
	if($val == 'getCommentsbyOth'){
    include_once 'classes/others.php';
	$items = new Others($db);
	$stmt = $items->getCommentsbyOth($id);
	$itemCount = mysqli_num_rows($stmt);



    if($itemCount > 0){
        
        $userArr = array();


        while ($row = $stmt->fetch_assoc()){
           $userArr[] = $row;
				
		     	   
        }
		
		$response['message']="Data Found";
	$response['status']=1;
	$response['data']=$userArr;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;			
    }

    else{
    $response['message'] = "No Record Found";
	$response['status'] = 0;
	
	$json_response = json_encode($response);
	echo $json_response;
	exit;
    }
	
    }



	 if($val == 'rating') {
    
        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($id,$rusertype);
             
           $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['username'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['username'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['username'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['username'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/sisdev/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['username'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['username'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['username'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'hhttps://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['username'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $allArr[] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']=array();
			$allArr[] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	
              
            
            $response['message'] = "Data Found";
            //$response['count'] = $itemCount;
            $response['status'] = 1;
            $response['data'] = $allArr;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
    
            $response['message'] = "No Record Found";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }
    }



   
	

    if($val == 'rcomments') {
    
        include_once 'classes/rating.php';
        $items = new Ratings($db);
        $stmt = $items->getcommentssbyratingrid($id);
        $itemCount = mysqli_num_rows($stmt);
        
        if ($itemCount > 0) { 
    
            $userArr = array();
            $cityArr = array();
            $allArr  = array();
    
            while ($row = $stmt->fetch_assoc()) {
                
               $userArr[] = $row;
            
               $uid=$row['user_id'];
               $utype=$row['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
               
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArr['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArr['name']=$rowd['name'];
            }
       
       
           $rid=$row['rating_by_userid'];
           $rtype=$row['user_type'];
    
           if($rtype=='user')
           {
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['first_name'];
                    }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArr['username'] = $rowu['name'];
                    }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArr['username'] = $rowu['name'];
                }
           }
    
           $cityArr['rate'] = $row['rate'];
		   $stmtl = $items->getrlikebyid($row['id']);
           $cityArr['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $items->getrdislikebyid($row['id']);
           $cityArr['dislike'] = mysqli_num_rows($stmtd);
    
                $allArr[] = array_merge($row, $cityArr);
            }
            $response['message'] = "Data Found";
            $response['count'] = $itemCount;
            $response['status'] = 1;
            $response['data'] = $allArr;
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        } else {
    
            $response['message'] = "No Record Found";
            $response['status'] = 0;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }
    }
	
	
	
	
if($val == 'showallrating') {
    
        include_once 'classes/rating.php';
         $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyauserid($uid,$utype,$ruid,$rutype);
        $itemCountrc = mysqli_num_rows($stmtrc);
        $cityArr = array();
        
		
    if ($itemCountrc > 0) { 
    
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
               
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrcs['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
                    }
					else
					{
                        $cityArrrcs['rating_by_user_profile_image'] = 
						'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrcs['name']=$rowd['name'];
            }
           
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
						
				if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
						
                    }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                    {
                        $cityArrrc['rating_by_user_name'] = $rowu['name'];
						
						if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
						
                    }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
           $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrcos['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrcos['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrcos['name']=$rowdco['name'];
            }
       
       
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                  $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
				  
				  if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                    {
                        $cityArrco['comment_by_user_name'] = $rowuco['name'];
						if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                    }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		  
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}  
		    
		   
		              
    
               
            }
			
		$response['is_rating'] = 1;
			$response['data'] = $cityArr;
		    $response['message'] = "Data Found";
            $response['count'] = $itemCount;
            $response['status'] = 1;
			
    
            $json_response = json_encode($response);
            echo $json_response;
            exit;  	
			
	} else {  
            $response['message'] = "No Record Found";
			$response['is_rating'] = 0;
            $response['status'] = 1;
            $json_response = json_encode($response);
            echo $json_response;
            exit;
        }
}
	
	
	
	
	
	

if ($val == 'recommenddoctor'){
	
	include_once 'classes/doctors.php';
	$items = new Doctors($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
      if($specid == '')
	  {
	  $specid = $_POST['specialisationid'];
	  }
	$stmt = $items->getRecommendDoctors($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();
       $k = 1;
		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

          
		//$cityArr['specialisationname'] = $row['specialisation'];
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'doctor';
       
			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'doctor');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
			$cityArr['is_rating'] = 0;	
				
			}
			
		
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'doctor');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
            
	$itemspa = new Doctors($db);		
	$stmtpa = $itemspa->getPastExperience($row['id']);
	$itemCountpa = mysqli_num_rows($stmtpa);



    if($itemCountpa > 0){
        
        $userArrpa = array();
       $cityArrpa = array();
       $cityArr['pastexperience'] = array();
        while ($rowpa = $stmtpa->fetch_assoc()){
	$userArrpa[] = $rowpa['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemsha = new Hospitals($db);
    $userexpa = $itemsha->getSingleHospitals($rowpa['hospital_id']);

		 while ($rowspa = $userexpa->fetch_assoc()){   
		  
			 $cityArrpa['hospitalid'] = $rowpa['hospital_id'];
		     $cityArrpa['hospitalname'] = $rowspa['name'];
		 
		   $citystmt = $cityitems->getSingleCity($rowspa['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrpa['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowspa['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrpa['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowspa['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrpa['countryname'] = $sname[0];
		 }
		
		$cityArr['pastexperience'][] = array_merge($rowpa,$cityArrpa);
        }
		
	}else{
		
		$cityArr['pastexperience'] = array();
	}

	$itemscu = new Doctors($db);
    $stmtcu = $itemscu->getCurrentExperience($row['id']);
	
	$itemCountcu = mysqli_num_rows($stmtcu);

    if($itemCountcu > 0){
        
        $userArrcu = array();
       $cityArrcu = array();
       $cityArr['currentexperience'] = array();
        while ($rowcu = $stmtcu->fetch_assoc()){
	$userArrcu[] = $rowcu['hospital_id'];
	
	include_once 'classes/hospitals.php';
	$itemshu = new Hospitals($db);
    $userexpcu = $itemshu->getSingleHospitals($rowcu['hospital_id']);

		 while ($rowscu = $userexpcu->fetch_assoc()){   
		  
			 $cityArrcu['hospitalid'] = $rowcu['hospital_id'];
		     $cityArrcu['hospitalname'] = $rowscu['name'];
		    $cityArrcu['fulladdress'] = $rowscu['address'];
		    
		   $citystmt = $cityitems->getSingleCity($rowscu['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrcu['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowscu['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrcu['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowscu['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrcu['countryname'] = $sname[0];
		 }
		
		$cityArr['currentexperience'][] = array_merge($rowcu,$cityArrcu);
        }
		
	}else{
		
		$cityArr['currentexperience'] = array();
	}
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'doctor');
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        
        $userArrbo = array();
         $cityArrbo = array();
         $cityArr['blogs'] = array();
        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
			$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
         $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		 $cityArr['deals'] = array();
	}
  
  	     
          include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'doctor');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
		
	}
   
	

			$allArr[] = array_merge($row, $cityArr);
		
		$k++;
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}





if ($val == 'recommendhospital') {
	
	include_once 'classes/hospitals.php';
	$items = new Hospitals($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getRecommendHospital($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

		


            	$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}
				
				
			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'hospital';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'hospital');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
			$cityArr['is_rating'] = 0;
				
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'hospital');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
 $itemsad = new Hospitals($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}
	 
	 
	 
	 
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],'hospital');
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        
        $userArrde = array();
        $cityArrde = array();
         $cityArr['deals'] = array();
        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 	'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
		 
			 include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
				
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		
		$cityArr['deals'] = array();
	}
      
	     include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'hospital');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
            $cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
	
	
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}






if ($val == 'recommendother') {
	
	include_once 'classes/others.php';
	$items = new Others($db);
	//$stmts = $items->getDoctors();
	//$itemCounts = mysqli_num_rows($stmts);
	$stmt = $items->getRecommendOther($specid, $ctyid);
	$itemCount = mysqli_num_rows($stmt);

	if ($itemCount > 0) {

		$userArr = array();
		$cityArr = array();
		$allArr  = array();

		while ($row = $stmt->fetch_assoc()) {
			$userArr[] = $row;

			$citystmt = $cityitems->getSingleCity($row['city']);
			$ffdsf = mysqli_fetch_row($citystmt);

			$cityArr['cityname'] = $ffdsf[0];

			$statestmt = $stateitems->getSingleState($row['state']);
			$snames =  mysqli_fetch_row($statestmt);
			$cityArr['statename'] = $snames[0];

			$countrystmt = $countryitems->getSingleCountry($row['country']);
			$sname =  mysqli_fetch_row($countrystmt);
			$cityArr['countryname'] = $sname[0];

			$qalistmtr = $qualitems->getSingleQual($row['qualification']);
			$qualname =  mysqli_fetch_row($qalistmtr);
			$cityArr['qualificationname'] = $qualname[0];

			
				$val =  explode("|",$row['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArr['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($row['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArr['specialisationname'] = $specialname[0];
				}

			if ($row['pro_img'] == '') {

				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/default.jpg';
			} else {
				$cityArr['profileimg'] = 'https://www.freemedicalinfo.in/images/profile/' . $row['pro_img'];
			}

			if ($row['timeline_img'] == '') {

				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/about.png';
			} else {
				$cityArr['bannerimg'] = 'https://www.freemedicalinfo.in/images/timeline/' . $row['timeline_img'];
			}
			$cityArr['usertype'] = 'other';

			$statestmts = $rateitems->getRatingsbyuserid($row['id'], 'other');
			$itemrating = mysqli_num_rows($statestmts);
			if($itemrating > 0){
			$cityArr['is_rating'] = 1;
			$rating =  mysqli_fetch_row($statestmts);
									$r = 0;
									$a = 0;
									foreach ($rating as $rat)
									{
										$r = $rat[4] + $r;
										$a++;
									}
									$r = $r / $a;
			$cityArr['rating'] = $rating[4];
			}else{
				
			$cityArr['is_rating'] = 0;	
			}
			
			include_once 'classes/blog.php';
			$itemsb = new Blogs($db);
			$stmtb = $itemsb->getSingleBlogs($row['id'], 'other');
			$cityArr['blog_count'] = mysqli_num_rows($stmtb);

			include_once 'classes/deals.php';
			$itemsd = new Deals($db);

			$stmtd = $itemsd->getSingleDealsbydoctorid($row['id']);
			$cityArr['deal_count']  = mysqli_num_rows($stmtd);

       
  
			 $itemsad = new Others($db);
    $stmtad = $itemsad->getAvailableDoctors($row['id']);
	
	$itemCountad = mysqli_num_rows($stmtad);

    if($itemCountad > 0){
        
        $userArrad = array();
       $cityArrad = array();
       $cityArr['availabledoctors'] = array();
        while ($rowad = $stmtad->fetch_assoc()){
	$userArrad[] = $rowad['doctor_id'];
	
	include_once 'classes/doctors.php';
	$itemsad = new Doctors($db);
    $userexpad = $itemsad->getSingleDoctors($rowad['doctor_id']);

		 while ($rowsado = $userexpad->fetch_assoc()){   
		if($rowsado['pro_img'] == ''){
			
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/about.png';
		}else{
			$cityArrad['doctorproimg'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowsado['pro_img'];
			
		}
		
		 $cityArrad['doctorname'] = $rowsado['name'];
		   $citystmt = $cityitems->getSingleCity($rowsado['city']);
		        $ffdsf = mysqli_fetch_row($citystmt);
				
		     $cityArrad['cityname'] = $ffdsf[0];
			  			 
			 $statestmt = $stateitems->getSingleState($rowsado['state']);
			  $snames =  mysqli_fetch_row($statestmt);
		     $cityArrad['statename'] = $snames[0];
			 
			 $countrystmt = $countryitems->getSingleCountry($rowsado['country']);
			  $sname =  mysqli_fetch_row($countrystmt);
		    $cityArrad['countryname'] = $sname[0];
			
				 $qalistmtr = $qualitems->getSingleQual($rowsado['qualification']);
			 $qualname =  mysqli_fetch_row($qalistmtr);
		    $cityArrad['qualificationname'] = $qualname[0];
			 
			$specialstmt = $specialitems->getSingleSpecial($rowsado['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrad['specialisationname'] = $specialname[0];
		 }
		
		$cityArr['availabledoctors'][] = array_merge($rowad,$cityArrad);
        }
	}else{
		
		$cityArr['availabledoctors'] = array();
	}
  
		
	$itemsbo = new Blogs($db);
	$stmtbo = $itemsbo->getSingleBlogs($row['id'],$val);
	$itemCountbo = mysqli_num_rows($stmtbo);

    if($itemCountbo > 0){
        $cityArr['blogs'] = array();
        $userArrbo = array();
         $cityArrbo = array();

        while ($rowbo = $stmtbo->fetch_assoc()){
           $userArrbo[] = $rowbo;
				
		     $cityArrbo['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowbo['image'];
			  	
				$val =  explode("|",$rowbo['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrbo['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowbo['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrbo['specialisationname'] = $specialname[0];
				}
	
			 
			 $cityArr['blogs'][] = array_merge($rowbo,$cityArrbo);
		   
        }
	}else{
		
		$cityArr['blogs'] = array();
	}
	
	
    include_once 'classes/deals.php';
	$itemsde = new Deals($db);
	$stmtde = $itemsde->getSingleDealsbydoctorid($row['id']);
	$itemCountde = mysqli_num_rows($stmtde);
	
	if($itemCountde > 0){
        $cityArr['deals'] = array();
        $userArrde = array();
        $cityArrde = array();

        while ($rowde = $stmtde->fetch_assoc()){
           $userArrde[] = $rowde;
				
				
		     $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image'];
			    $cityArrde['fullimgurl'] = 'https://www.freemedicalinfo.in/admin/images/uploads/'.$rowde['image']; 
				
				
				$val =  explode("|",$rowde['specialisation']);
				
			if(count($val) > 1){
			
			   $special = "";
				foreach($val as $key){
				
				$specialstmt = $specialitems->getSingleSpecial($key);
			    $specialname =  mysqli_fetch_row($specialstmt);
		        $special .=  $specialname[0].",";
					
				}
				
			$cityArrde['specialisationname'] = $special;
			
			}else{
            $specialstmt = $specialitems->getSingleSpecial($rowde['specialisation']);
			 $specialname =  mysqli_fetch_row($specialstmt);
		     $cityArrde['specialisationname'] = $specialname[0];
				}									
			
			    include_once 'classes/doctors.php';
				$itemst = new Doctors($db);
				$stmtt = $itemst->getSingleDoctors($rowde['doctor_id']); 
				$rowd = mysqli_fetch_row($stmtt);	
				$cityArrde['offerby'] = $rowd[3];
			 
			  $cityArr['deals'][]  = array_merge($cityArrde,$rowde);
		   
       
		 }	
		 
	}else{
		
		$cityArr['deals'] = array();
	}
   
   
        include_once 'classes/rating.php';
        $itemsrc = new Ratings($db);
        $stmtrc = $itemsrc->getRatingsbyuserid($row['id'],'other');
        $itemCountrc = mysqli_num_rows($stmtrc);

    if ($itemCountrc > 0) { 
			$cityArr['allreview'] = array();
            $userArrrc = array();
            $cityArrrc = array();
            $allArrrc  = array();
    
            while ($rowrc = $stmtrc->fetch_assoc()) {
                
               $userArrrc[] = $rowrc;
            
               $uid=$rowrc['user_id'];
               $utype=$rowrc['rateusertype'];
               
               if($utype == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemd = new Doctors($db);
                    $stmtd = $itemd->getSingleDoctors($uid);
               }
    
               if($utype == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemd = new Hospitals($db);
                    $stmtd = $itemd->getSingleHospitals($uid);   
            
               }
    
              if($utype == 'other')
              {
                    include_once 'classes/others.php';
                    $itemd = new Others($db);
                    $stmtd = $itemd->getSingleOthers($uid);   
                   
              }
             /*  
            while ($rowd = $stmtd->fetch_assoc())
            {
                    if($rowd['pro_img'] == ''){
                        
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrrc['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowd['pro_img'];
                        
                    }
                    $cityArrrc['name']=$rowd['name'];
            }
           */
       
           $rid=$rowrc['rating_by_userid'];
           $rtype=$rowrc['user_type'];
    
           if($rtype=='user')
           {
			    
                 include_once 'classes/users.php';
                $itemu = new Users($db);
                $stmtu = $itemu->getSingleUsers($rid); 
    
                while ($rowu = $stmtu->fetch_assoc())
    
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['first_name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
            }
    
           if($rtype=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemu = new Doctors($db);
                $stmtu = $itemu->getSingleDoctors($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                     {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
    
           if($rtype=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemu = new Hospitals($db);
                $stmtu = $itemu->getSingleHospitals($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
    
                  {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
           }
           
           if($rtype=='other')
           {
                include_once 'classes/others.php';
                $itemu = new Others($db);
                $stmtu = $itemu->getSingleOthers($rid);
    
                while ($rowu = $stmtu->fetch_assoc())
                {
                      {
                    $cityArrrc['rating_by_user_name'] = $rowu['name'];
					
					if($rowu['pro_img'] == '')
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrrc['rating_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowu['pro_img'];  
				  }
                }
                }
           }
             
           $cityArrrc['rate'] = $rowrc['rate'];
            
           $stmtl = $itemsrc->getlikebyid($rowrc['id']);
           $cityArrrc['like'] = mysqli_num_rows($stmtl);
		   $stmtd = $itemsrc->getdislikebyid($rowrc['id']);
           $cityArrrc['dislike'] = mysqli_num_rows($stmtd);
		   
		  
		 
		   
		    $stmtco = $itemsrc->getcommentssbyratingrid($rowrc['id']);
        $itemCountco = mysqli_num_rows($stmtco);
         
       if ($itemCountco > 0) { 
        
            $userArrco = array();
            $cityArrco = array();
            $allArrco  = array();
            $cityArrrrc = array();
            while ($rowco = $stmtco->fetch_assoc()) {
                
               $userArrco[] = $rowco;
               $uidco=$rowco['user_id'];
               $utypeco=$rowco['rateusertype'];
               
               if($utypeco == 'doctor')
               {
                    include_once 'classes/doctors.php';
                    $itemdco = new Doctors($db);
                    $stmtdco = $itemdco->getSingleDoctors($uidco);
               }
    
               if($utypeco == 'hospital')
               {
                
                    include_once 'classes/hospitals.php';
                    $itemdco = new Hospitals($db);
                    $stmtdco = $itemdco->getSingleHospitals($uidco);   
            
               }
    
              if($utypeco == 'other')
              {
                    include_once 'classes/others.php';
                    $itemdco = new Others($db);
                    $stmtdco = $itemdco->getSingleOthers($uidco);   
                   
              }
             /*
            while ($rowdco = $stmtdco->fetch_assoc())
            {
                    if($rowdco['pro_img'] == ''){
                        
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/default.jpg';
                    }else{
                        $cityArrco['profileimage'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowdco['pro_img'];
                        
                    }
                    $cityArrco['name']=$rowdco['name'];
            }
       
		*/
           $ridco=$rowco['rating_by_userid'];
           $rtypeco=$rowco['user_type'];
    
           if($rtypeco=='user')
           {
                 include_once 'classes/users.php';
                $itemuco = new Users($db);
                $stmtuco = $itemuco->getSingleUsers($ridco); 
    
                while ($rowuco = $stmtuco->fetch_assoc())
    
                      {
                    $cityArrco['comment_by_user_name'] = $rowuco['first_name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
            }
    
           if($rtypeco=='doctor')
           {
                include_once 'classes/doctors.php';
                $itemuco = new Doctors($db);
                $stmtuco = $itemuco->getSingleDoctors($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
    
           if($rtypeco=='hospital')
           {
                include_once 'classes/hospitals.php';
                $itemuco = new Hospitals($db);
                $stmtuco = $itemuco->getSingleHospitals($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
       {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
           
           if($rtypeco=='other')
           {
                include_once 'classes/others.php';
                $itemuco = new Others($db);
                $stmtuco = $itemuco->getSingleOthers($ridco);
    
                while ($rowuco = $stmtuco->fetch_assoc())
                   {
                    $cityArrco['comment_by_user_name'] = $rowuco['name'];
					
				if($rowuco['pro_img'] == '')
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/profile-1.png';
				  }
				  else
				  {
					$cityArrco['comment_by_user_profile_image'] = 'https://www.freemedicalinfo.in/images/profile/'.$rowuco['pro_img'];  
				  }
                }
           }
            
          
		   $stmtlco = $itemsrc->getrlikebyid($rowco['id']);
           $cityArrco['like'] = mysqli_num_rows($stmtlco);
		   $stmtdco = $itemsrc->getrdislikebyid($rowco['id']);
           $cityArrco['dislike'] = mysqli_num_rows($stmtdco);
 
          
		   
		   $cityArrrc['comments'][] = array_merge($rowco, $cityArrco); 
            }
			
		 $cityArr['allreview'][] = array_merge($rowrc,$cityArrrc, $cityArrrrc);  
		}else{
			$cityArrrc['comments']='';
			$cityArr['allreview'][] = array_merge($rowrc,$cityArrrc);
		}   
		    

               
            }
	}else{
		
		$cityArr['allreview'] = array();
	}
	
	
	
			$allArr[] = array_merge($row, $cityArr);
		}

		$response['totalcount'] =  $itemCount;
		$response['message'] = "Data Found";
		$response['status'] = 1;
		$response['data'] = $allArr;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	} else {
		$response['message'] = "No Record Found";
		$response['status'] = 0;

		$json_response = json_encode($response);
		echo $json_response;
		exit;
	}
}	
	
	
	
	
	
	
	
	
?>